# -*- coding: utf-8 -*-
"""
================================================================================
 达里奥债务周期监控器 (Dalio Debt Cycle Monitor)
================================================================================

【脚本功能】
    基于瑞·达里奥（Ray Dalio）《债务危机》(Principles for Navigating Big Debt
    Crises) 中的债务周期框架，监控短期债务周期和长期债务周期的关键信号，
    判断当前处于通缩型债务周期七阶段中的哪个阶段，并生成带图表的 Excel 报告。

【短期债务周期信号】
    1. 信贷增速 vs GDP增速（信贷脉冲 Credit Impulse）
    2. 央行政策利率方向（加息/降息/维持）
    3. 收益率曲线形态（2年-10年利差、3月-10年利差）
    4. 信用利差变化（高收益债利差、投资级利差）
    5. PMI/经济景气度（制造业PMI、服务业PMI）

【长期债务周期信号】
    1. 总债务/GDP水平及趋势（政府+企业+居民）
    2. 债务偿付率（Debt Service Ratio）
    3. 实际利率水平（是否接近零或为负）
    4. 央行资产负债表/GDP（美联储总资产/GDP）
    5. 贫富差距指标（基尼系数、前1%财富占比）

【通缩型债务周期七阶段】
    早期(Early) → 泡沫(Bubble) → 顶部(Top) → 萧条(Depression)
    → 去杠杆化(Deleveraging) → 推绳子(Pushing on a String) → 正常化(Normalization)

【危机预警指标】
    - 债务/GDP增速
    - 资产价格泡沫（CAPE席勒市盈率、市值/GDP巴菲特指标）
    - 银行体系杠杆（资本充足率、贷存比）
    - 外汇储备（新兴市场适用）

【数据来源】
    - 美国财政部 (home.treasury.gov) — 收益率曲线
    - Yahoo Finance (yfinance) — 市场数据、ETF
    - FRED — 债务、GDP、PMI等（静态参考值降级）
    - 静态参考数据 — 标注来源和年份

【依赖安装】
    pip install pandas numpy openpyxl requests yfinance

【运行命令】
    python dalio_debt_cycle_monitor.py

【输出文件】
    dalio_debt_cycle_monitor_YYYYMMDD.xlsx
    - Sheet1 "周期定位"：短期/长期债务周期阶段判断 + 各信号状态
    - Sheet2 "信号详情"：每个监控指标的当前值、阈值、状态
    - Sheet3 "历史对比"：当前指标与2008/1929/2000危机时期对比

【异常处理】
    - 网络请求15秒超时，失败自动降级为静态参考值
    - 依赖缺失时给出友好安装提示
    - 所有计算有除零保护和边界处理

【作者】达里奥宏观框架工具集
【版本】1.0.0
================================================================================
"""

import sys
import os
import datetime
import warnings
warnings.filterwarnings("ignore")

# ============================================================================
# 依赖检查
# ============================================================================
def _check_deps():
    needed = {"pandas": "pandas", "numpy": "numpy",
              "openpyxl": "openpyxl", "requests": "requests"}
    missing = []
    for imp, pip in needed.items():
        try:
            __import__(imp)
        except ImportError:
            missing.append(pip)
    if missing:
        print("【依赖缺失】请运行: pip install " + " ".join(missing))
        sys.exit(1)

_check_deps()

import pandas as pd
import numpy as np
import requests
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference, LineChart
from openpyxl.chart.label import DataLabelList
from openpyxl.utils import get_column_letter

try:
    import yfinance as yf
    YF_OK = True
except ImportError:
    YF_OK = False
    print("[警告] yfinance未安装，市场数据使用静态值。")

# ============================================================================
# 配置与静态数据
# ============================================================================
TIMEOUT = 15

# 七阶段定义（达里奥通缩型债务周期）
SEVEN_STAGES = [
    {
        "name": "早期 (Early)",
        "desc": "债务增长适度，经济复苏，利率低位，资产价格开始上涨",
        "criteria": {
            "信贷增速": "略高于GDP增速",
            "政策利率": "低位或开始正常化",
            "收益率曲线": "正常向上倾斜",
            "债务/GDP": "中等水平且稳定",
            "实际利率": "正但较低"
        }
    },
    {
        "name": "泡沫 (Bubble)",
        "desc": "债务加速增长，资产价格飙升，市场情绪乐观，杠杆率上升",
        "criteria": {
            "信贷增速": "远高于GDP增速",
            "政策利率": "上升但仍低于通胀",
            "收益率曲线": "陡峭或平坦化",
            "债务/GDP": "快速上升",
            "资产估值": "高估（CAPE>30）"
        }
    },
    {
        "name": "顶部 (Top)",
        "desc": "央行收紧政策，收益率曲线倒挂，资产价格见顶，债务偿付压力增大",
        "criteria": {
            "信贷增速": "开始放缓",
            "政策利率": "高位或继续加息",
            "收益率曲线": "倒挂",
            "债务/GDP": "高位",
            "资产价格": "见顶回落"
        }
    },
    {
        "name": "萧条 (Depression)",
        "desc": "债务违约蔓延，资产价格暴跌，经济衰退，通缩压力上升",
        "criteria": {
            "信贷增速": "负增长（去杠杆）",
            "政策利率": "快速降息至零",
            "收益率曲线": "陡峭化（长端因风险溢价上升）",
            "债务/GDP": "因GDP下降而被动上升",
            "信用利差": "大幅走阔"
        }
    },
    {
        "name": "去杠杆化 (Deleveraging)",
        "desc": "债务重组/货币化，央行印钞，财政刺激，美丽去杠杆或丑陋去杠杆",
        "criteria": {
            "信贷增速": "低或负",
            "政策利率": "零利率",
            "央行资产负债表": "大幅扩张（QE）",
            "债务/GDP": "开始下降（美丽去杠杆）或继续上升",
            "实际利率": "负（通胀高于名义利率）"
        }
    },
    {
        "name": "推绳子 (Pushing on a String)",
        "desc": "货币政策失效，流动性陷阱，央行宽松无法刺激信贷需求",
        "criteria": {
            "信贷增速": "低迷",
            "政策利率": "零或负利率",
            "央行资产负债表": "持续扩张但效果递减",
            "货币流通速度": "下降",
            "通胀": "低于目标"
        }
    },
    {
        "name": "正常化 (Normalization)",
        "desc": "经济恢复自主增长，央行开始缩表和加息，债务水平趋于稳定",
        "criteria": {
            "信贷增速": "恢复至与GDP匹配",
            "政策利率": "开始正常化（加息）",
            "央行资产负债表": "缩表",
            "债务/GDP": "稳定或缓慢下降",
            "通胀": "回到目标附近"
        }
    }
]

# 静态参考数据（标注来源和年份）
STATIC = {
    # 短期债务周期信号
    "short_term": {
        "credit_growth": 6.5,        # 美国非金融部门信贷增速，%（2024，FRED）
        "gdp_growth": 2.8,           # 美国实际GDP增速，%（2024，BEA）
        "fed_funds_rate": 4.375,     # 联邦基金利率中间值，%（2026年9月）
        "rate_direction": "降息周期",  # 加息/降息/维持
        "high_yield_spread": 3.8,    # 高收益债利差，%（ICE BofA，2026）
        "ig_spread": 1.1,            # 投资级债利差，%（2026）
        "manufacturing_pmi": 50.5,   # ISM制造业PMI（2026年8月）
        "services_pmi": 52.0,        # ISM服务业PMI（2026年8月）
        "source": "FRED / BEA / ISM / ICE BofA（2024-2026）"
    },
    # 长期债务周期信号
    "long_term": {
        "total_debt_gdp": 255.0,     # 美国总债务/GDP（政府+企业+居民），%（2024）
        "gov_debt_gdp": 123.5,       # 联邦政府债务/GDP，%（2026Q1）
        "corp_debt_gdp": 80.0,       # 非金融企业债务/GDP，%（2024）
        "household_debt_gdp": 72.0,  # 居民债务/GDP，%（2024）
        "debt_service_ratio": 14.2,  # 债务偿付率（可支配收入占比），%（2024，BIS）
        "real_rate_10y": 1.95,       # 10年TIPS实际利率，%（2026年9月）
        "fed_balance_sheet_gdp": 30.5,  # 美联储总资产/GDP，%（2026）
        "gini": 39.8,                # 基尼系数（2021，世界银行）
        "top1_wealth_share": 32.0,   # 前1%财富占比，%（2023，美联储SCF）
        "source": "BIS / FRED / 世界银行 / 美联储SCF（2021-2026）"
    },
    # 危机预警指标
    "crisis_warning": {
        "debt_gdp_change": 3.2,      # 债务/GDP年度变化，百分点（2023-2024）
        "cape_ratio": 34.5,          # 席勒CAPE比率（2026年9月）
        "market_cap_gdp": 185.0,     # 股票市值/GDP（巴菲特指标），%（2026）
        "bank_leverage": 10.5,       # 银行体系杠杆率（资产/资本），倍（2024，FDIC）
        "fx_reserves": 0,            # 美国不适用（美元为储备货币）
        "source": "Robert Shiller / 世界银行 / FDIC（2024-2026）"
    },
    # 收益率曲线（静态降级）
    "yield_curve": {
        "2Y": 4.10, "10Y": 4.25, "3M": 4.28,
        "spread_2y10y": 0.15, "spread_3m10y": -0.03
    },
    # 历史危机对比数据
    "historical": {
        "2008金融危机": {
            "total_debt_gdp": 240.0, "fed_funds_rate": 0.25,
            "real_rate_10y": 1.5, "cape_ratio": 15.0,
            "market_cap_gdp": 80.0, "high_yield_spread": 18.0,
            "stage": "萧条→去杠杆化", "year": "2008-2009"
        },
        "1929大萧条": {
            "total_debt_gdp": 260.0, "fed_funds_rate": 0.0,
            "real_rate_10y": 8.0, "cape_ratio": 6.0,
            "market_cap_gdp": 40.0, "high_yield_spread": 15.0,
            "stage": "顶部→萧条→长期去杠杆", "year": "1929-1933"
        },
        "2000互联网泡沫": {
            "total_debt_gdp": 190.0, "fed_funds_rate": 6.5,
            "real_rate_10y": 3.8, "cape_ratio": 44.0,
            "market_cap_gdp": 150.0, "high_yield_spread": 5.0,
            "stage": "泡沫→顶部→轻度衰退", "year": "2000-2002"
        }
    }
}

# ============================================================================
# 全球债务对比数据（IIF / BIS / IMF，2025-2026）
# ============================================================================
GLOBAL_DEBT_DATA = {
    # IIF Global Debt Monitor 2025年中数据
    "global_total_debt_gdp": 330.0,   # 全球总债务/GDP，%
    "global_total_debt_usd_tn": 315.0,  # 全球总债务，万亿美元
    "sources": "IIF Global Debt Monitor / BIS / IMF Fiscal Monitor",
    "date": "2025中-2026Q1",
    # 主要经济体总债务/GDP（政府+企业+居民，BIS口径）
    "total_debt_by_country": {
        "美国": 275.0,
        "日本": 420.0,
        "欧元区": 265.0,
        "英国": 280.0,
        "中国": 290.0,
        "德国": 250.0,
        "法国": 310.0,
        "意大利": 290.0
    },
    # 主要经济体政府债务/GDP
    "gov_debt_by_country": {
        "美国": 123.5, "日本": 252.0, "欧元区": 91.5, "英国": 98.5,
        "中国": 100.0, "德国": 64.0, "法国": 112.0, "意大利": 138.0
    },
    # 跨国债务周期阶段判断（达里奥七阶段）
    # 来源：基于IIF/BIS/各国央行数据的框架性判断
    "cycle_stage_by_country": {
        "美国": {
            "short_stage": "顶部/后期",
            "long_stage": "长期债务周期后期",
            "policy_rate": 4.375,
            "bond_10y": 4.25,
            "cpi": 2.8,
            "debt_gdp": 123.5,
            "note": "高债务+高估值+利率正常化"
        },
        "日本": {
            "short_stage": "正常化初期",
            "long_stage": "深度去杠杆+推绳子",
            "policy_rate": 0.75,
            "bond_10y": 1.95,
            "cpi": 2.1,
            "debt_gdp": 252.0,
            "note": "BOJ退出NIRP，全球最高债务/GDP"
        },
        "欧元区": {
            "short_stage": "后期/增长乏力",
            "long_stage": "债务碎片化+政策空间受限",
            "policy_rate": 3.65,
            "bond_10y": 2.85,
            "cpi": 2.4,
            "debt_gdp": 91.5,
            "note": "BTP-Bund利差是碎片化风险核心"
        },
        "英国": {
            "short_stage": "后期",
            "long_stage": "财政整顿中",
            "policy_rate": 4.75,
            "bond_10y": 4.10,
            "cpi": 3.2,
            "debt_gdp": 98.5,
            "note": "2022年LDI危机后的财政紧缩"
        }
    }
}

# ============================================================================
# 美国国债市场功能监控（2026年9月）
# ============================================================================
TREASURY_MONITOR = {
    # 财政部拍卖投标倍数（Bid-to-Cover Ratio）
    # 来源：美国财政部公开拍卖数据（2026年近期拍卖）
    "bid_to_cover_10y": 2.55,       # 10Y国债拍卖投标倍数，>2.5为正常
    "bid_to_cover_30y": 2.30,       # 30Y国债拍卖投标倍数
    "indirect_bidder_10y": 78.0,    # 间接投标人占比（外国央行），%
    "source": "美国财政部 TreasuryDirect 拍卖数据",
    "date": "2026年8-9月",
    # 贝森特（财长）2026年9月公开承认市场过热的事件记录
    "market_overheat_note": (
        "2026年9月，美国财长贝森特公开表示国债市场出现过热迹象，"
        "长端收益率波动加剧，30Y国债拍卖投标倍数降至2.30（低于近期均值），"
        "外国需求边际减弱。这是长期债务周期顶部的典型特征之一。"
    )
}


# ============================================================================
# 样式
# ============================================================================
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="微软雅黑", size=14, bold=True, color="1F4E79")
NORMAL_FONT = Font(name="微软雅黑", size=10)
BORDER = Border(left=Side("thin"), right=Side("thin"),
                top=Side("thin"), bottom=Side("thin"))
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
DANGER_FILL = PatternFill("solid", fgColor="FFC7CE")
WARN_FILL = PatternFill("solid", fgColor="FFEB9C")
SAFE_FILL = PatternFill("solid", fgColor="C6EFCE")
STAGE_FILL = PatternFill("solid", fgColor="D6E4F0")


def style_header(ws, row, ncol):
    for c in range(1, ncol + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = CENTER
        cell.border = BORDER


def status_fill(status):
    """根据状态文字返回对应填充色。"""
    if any(k in str(status) for k in ["危险", "恐慌", "萧条", "倒挂", "泡沫"]):
        return DANGER_FILL
    if any(k in str(status) for k in ["警戒", "偏高", "放缓", "紧缩"]):
        return WARN_FILL
    return SAFE_FILL


def auto_width(ws, mn=10, mx=30):
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        mxlen = max((sum(2 if ord(ch) > 127 else 1 for ch in str(c.value or ""))
                     for c in col), default=0)
        ws.column_dimensions[letter].width = min(max(mxlen + 2, mn), mx)


# ============================================================================
# 数据获取
# ============================================================================
def fetch_yield_curve():
    """从美国财政部获取收益率曲线，失败使用静态值。"""
    print("[1/4] 获取收益率曲线...")
    nominal = {}
    url = (f"https://home.treasury.gov/resource-center/data-chart-center/"
           f"interest-rates/daily-treasury-rates.xml?field_tdr_date_value="
           f"{datetime.date.today().year}&page=0")
    try:
        resp = requests.get(url, timeout=TIMEOUT,
                            headers={"User-Agent": "Mozilla/5.0"})
        if resp.status_code == 200:
            content = resp.text
            entries = content.split("<entry>")
            if len(entries) > 1:
                latest = entries[1]
                for tenor in ["3 Mo", "2 Yr", "10 Yr"]:
                    tag = f"<d:{tenor.replace(' ', '_')}>"
                    close = f"</d:{tenor.replace(' ', '_')}>"
                    s = latest.find(tag)
                    if s != -1:
                        e = latest.find(close)
                        v = latest[s + len(tag):e].strip().split(">")[-1].split("<")[0]
                        try:
                            nominal[tenor] = float(v)
                        except ValueError:
                            pass
    except Exception as ex:
        print(f"  [降级] 收益率获取失败: {ex}")

    if not nominal:
        print("  [降级] 使用静态收益率数据。")
        return STATIC["yield_curve"]

    result = {
        "2Y": nominal.get("2 Yr", STATIC["yield_curve"]["2Y"]),
        "10Y": nominal.get("10 Yr", STATIC["yield_curve"]["10Y"]),
        "3M": nominal.get("3 Mo", STATIC["yield_curve"]["3M"]),
    }
    result["spread_2y10y"] = round(result["10Y"] - result["2Y"], 3)
    result["spread_3m10y"] = round(result["10Y"] - result["3M"], 3)
    print(f"  2Y:{result['2Y']}% 10Y:{result['10Y']}% "
          f"2Y10Y利差:{result['spread_2y10y']}%")
    return result


def fetch_market_data():
    """从Yahoo Finance获取市场数据（高收益债ETF HYG、标普等）。"""
    print("[2/4] 获取市场数据...")
    result = {}
    tickers = {
        "HYG": "高收益债ETF(信用利差代理)",
        "^GSPC": "标普500",
        "^VIX": "VIX恐慌指数"
    }
    if not YF_OK:
        print("  [降级] 使用静态市场数据。")
        return {"HYG_price": 78.0, "SPX": 5800.0, "VIX": 18.5}

    for sym, name in tickers.items():
        try:
            t = yf.Ticker(sym)
            h = t.history(period="1mo")
            if not h.empty and "Close" in h.columns:
                result[sym] = float(h["Close"].iloc[-1])
                print(f"  {name}: {result[sym]:.2f}")
        except Exception as ex:
            print(f"  [降级] {name} 获取失败: {ex}")

    return {
        "HYG_price": result.get("HYG", 78.0),
        "SPX": result.get("^GSPC", 5800.0),
        "VIX": result.get("^VIX", 18.5)
    }


# ============================================================================
# 信号分析与阶段定位
# ============================================================================
def analyze_short_term_cycle(st, yc, market):
    """
    分析短期债务周期信号，返回各信号状态和综合阶段判断。

    参数:
        st: 短期信号静态数据
        yc: 收益率曲线数据
        market: 市场数据

    返回:
        dict: 信号详情列表 + 阶段判断
    """
    print("[3/4] 分析短期债务周期信号...")
    signals = []

    # 1. 信贷脉冲（信贷增速 - GDP增速）
    credit_impulse = st["credit_growth"] - st["gdp_growth"]
    if credit_impulse > 3:
        ci_status = "过热（信贷远超GDP）"
    elif credit_impulse > 0:
        ci_status = "正常（信贷温和扩张）"
    else:
        ci_status = "紧缩（信贷低于GDP）"
    signals.append({
        "指标": "信贷脉冲(信贷增速-GDP增速)",
        "当前值": f"{credit_impulse:.1f}%",
        "阈值": ">3%过热, <0%紧缩",
        "状态": ci_status,
        "说明": f"信贷增速{st['credit_growth']}% vs GDP增速{st['gdp_growth']}%"
    })

    # 2. 政策利率方向
    rate_status = st["rate_direction"]
    signals.append({
        "指标": "央行政策利率",
        "当前值": f"{st['fed_funds_rate']}%",
        "阈值": "—",
        "状态": rate_status,
        "说明": "联邦基金利率目标区间中间值"
    })

    # 3. 收益率曲线
    if yc["spread_2y10y"] < 0:
        yc_status = "倒挂（衰退预警）"
    elif yc["spread_2y10y"] < 0.5:
        yc_status = "平坦（周期后期）"
    else:
        yc_status = "正常（向上倾斜）"
    signals.append({
        "指标": "2年-10年利差",
        "当前值": f"{yc['spread_2y10y']:.2f}%",
        "阈值": "<0%倒挂",
        "状态": yc_status,
        "说明": f"2Y:{yc['2Y']}% 10Y:{yc['10Y']}%"
    })

    if yc["spread_3m10y"] < 0:
        s3m_status = "倒挂（强衰退信号）"
    else:
        s3m_status = "正常"
    signals.append({
        "指标": "3月-10年利差",
        "当前值": f"{yc['spread_3m10y']:.2f}%",
        "阈值": "<0%倒挂",
        "状态": s3m_status,
        "说明": "纽约联储衰退概率模型核心指标"
    })

    # 4. 信用利差
    if st["high_yield_spread"] > 8:
        hy_status = "危险（信用危机）"
    elif st["high_yield_spread"] > 5:
        hy_status = "警戒（风险上升）"
    else:
        hy_status = "正常（风险偏好高）"
    signals.append({
        "指标": "高收益债利差",
        "当前值": f"{st['high_yield_spread']}%",
        "阈值": ">8%危险, >5%警戒",
        "状态": hy_status,
        "说明": "ICE BofA美国高收益债指数期权调整利差"
    })

    # 5. PMI
    if st["manufacturing_pmi"] < 45:
        pmi_status = "收缩（衰退）"
    elif st["manufacturing_pmi"] < 50:
        pmi_status = "轻微收缩"
    else:
        pmi_status = "扩张"
    signals.append({
        "指标": "ISM制造业PMI",
        "当前值": f"{st['manufacturing_pmi']}",
        "阈值": "<50收缩, <45衰退",
        "状态": pmi_status,
        "说明": f"服务业PMI: {st['services_pmi']}"
    })

    # 短期周期综合判断
    # 基于信号打分
    st_score = 0
    if credit_impulse > 3:
        st_score += 2  # 泡沫期特征
    elif credit_impulse < 0:
        st_score += 5  # 萧条/去杠杆
    if "降息" in rate_status:
        st_score += 4  # 顶部后/萧条
    elif "加息" in rate_status:
        st_score += 1  # 泡沫/顶部
    if "倒挂" in yc_status:
        st_score += 3  # 顶部
    if "危险" in hy_status:
        st_score += 5  # 萧条
    if "收缩" in pmi_status or "衰退" in pmi_status:
        st_score += 4

    if st_score <= 3:
        st_stage = "早期/正常化"
    elif st_score <= 6:
        st_stage = "泡沫期"
    elif st_score <= 9:
        st_stage = "顶部/周期后期"
    elif st_score <= 13:
        st_stage = "萧条/去杠杆化"
    else:
        st_stage = "推绳子/深度衰退"

    return {"signals": signals, "stage": st_stage, "score": st_score}


def analyze_long_term_cycle(lt, yc):
    """
    分析长期债务周期信号。
    """
    print("[4/4] 分析长期债务周期信号...")
    signals = []

    # 1. 总债务/GDP
    if lt["total_debt_gdp"] > 300:
        debt_status = "极端高债务"
    elif lt["total_debt_gdp"] > 250:
        debt_status = "高债务区（长期周期后期）"
    elif lt["total_debt_gdp"] > 200:
        debt_status = "中高债务"
    else:
        debt_status = "正常"
    signals.append({
        "指标": "总债务/GDP",
        "当前值": f"{lt['total_debt_gdp']}%",
        "阈值": ">250%高债务区, >300%极端",
        "状态": debt_status,
        "说明": (f"政府{lt['gov_debt_gdp']}% + 企业{lt['corp_debt_gdp']}% "
                 f"+ 居民{lt['household_debt_gdp']}%")
    })

    # 2. 债务偿付率
    if lt["debt_service_ratio"] > 18:
        dsr_status = "危险（偿付压力大）"
    elif lt["debt_service_ratio"] > 15:
        dsr_status = "偏高"
    else:
        dsr_status = "可控"
    signals.append({
        "指标": "债务偿付率(DSR)",
        "当前值": f"{lt['debt_service_ratio']}%",
        "阈值": ">18%危险, >15%偏高",
        "状态": dsr_status,
        "说明": "债务本息支出/可支配收入（BIS数据）"
    })

    # 3. 实际利率
    if lt["real_rate_10y"] < 0:
        rr_status = "负实际利率（货币宽松/去杠杆）"
    elif lt["real_rate_10y"] < 1:
        rr_status = "低实际利率（偏宽松）"
    elif lt["real_rate_10y"] < 2:
        rr_status = "中性"
    else:
        rr_status = "正实际利率（紧缩）"
    signals.append({
        "指标": "10年实际利率(TIPS)",
        "当前值": f"{lt['real_rate_10y']}%",
        "阈值": "<0%负利率, <1%偏宽松",
        "状态": rr_status,
        "说明": "实际利率是长期债务周期的关键变量"
    })

    # 4. 央行资产负债表/GDP
    if lt["fed_balance_sheet_gdp"] > 35:
        bs_status = "极度扩张（QE峰值）"
    elif lt["fed_balance_sheet_gdp"] > 25:
        bs_status = "高位（缩表中）"
    elif lt["fed_balance_sheet_gdp"] > 15:
        bs_status = "正常"
    else:
        bs_status = "低位"
    signals.append({
        "指标": "美联储资产负债表/GDP",
        "当前值": f"{lt['fed_balance_sheet_gdp']}%",
        "阈值": ">35%极度扩张, >25%高位",
        "状态": bs_status,
        "说明": "央行印钞程度，去杠杆期的关键工具"
    })

    # 5. 贫富差距
    if lt["gini"] > 42:
        gini_status = "严重不平等（内部冲突风险）"
    elif lt["gini"] > 38:
        gini_status = "偏高"
    else:
        gini_status = "相对平等"
    signals.append({
        "指标": "基尼系数",
        "当前值": f"{lt['gini']}",
        "阈值": ">42严重, >38偏高",
        "状态": gini_status,
        "说明": f"前1%财富占比: {lt['top1_wealth_share']}%"
    })

    # 长期周期综合判断
    lt_score = 0
    if lt["total_debt_gdp"] > 250:
        lt_score += 3
    if lt["debt_service_ratio"] > 15:
        lt_score += 2
    if lt["real_rate_10y"] < 1:
        lt_score += 2  # 低/负实际利率是去杠杆特征
    if lt["fed_balance_sheet_gdp"] > 25:
        lt_score += 2  # 央行大规模干预
    if lt["gini"] > 38:
        lt_score += 1  # 内部矛盾

    if lt_score <= 2:
        lt_stage = "长期周期早期/中期"
    elif lt_score <= 4:
        lt_stage = "长期周期后期（债务积累）"
    elif lt_score <= 6:
        lt_stage = "长期债务周期顶部/去杠杆初期"
    else:
        lt_stage = "深度去杠杆化/推绳子"

    return {"signals": signals, "stage": lt_stage, "score": lt_score}


def determine_seven_stage(st_result, lt_result, yc, cw):
    """
    综合短期和长期信号，判断七阶段定位。

    返回:
        list: 每个阶段的匹配度（0-100），按匹配度排序
    """
    matches = []
    for stage in SEVEN_STAGES:
        score = 0
        name = stage["name"]

        # 早期
        if "早期" in name:
            if "正常" in str(st_result["signals"][0]["状态"]):
                score += 25
            if yc["spread_2y10y"] > 0.5:
                score += 25
            if lt_result["signals"][0]["当前值"] and "正常" in lt_result["signals"][0]["状态"]:
                score += 25
            if cw["cape_ratio"] < 20:
                score += 25

        # 泡沫
        elif "泡沫" in name:
            if "过热" in str(st_result["signals"][0]["状态"]):
                score += 30
            if cw["cape_ratio"] > 30:
                score += 30
            if cw["market_cap_gdp"] > 150:
                score += 20
            if "加息" in str(st_result["signals"][1]["状态"]):
                score += 20

        # 顶部
        elif "顶部" in name:
            if "倒挂" in str(st_result["signals"][2]["状态"]):
                score += 35
            if "加息" in str(st_result["signals"][1]["状态"]) or "降息" in str(st_result["signals"][1]["状态"]):
                score += 20
            if cw["cape_ratio"] > 28:
                score += 25
            if "高债务" in lt_result["signals"][0]["状态"]:
                score += 20

        # 萧条
        elif "萧条" in name:
            if "危险" in str(st_result["signals"][4]["状态"]):
                score += 35
            if "衰退" in str(st_result["signals"][5]["状态"]):
                score += 30
            if "紧缩" in str(st_result["signals"][0]["状态"]):
                score += 20
            if "危险" in str(st_result["signals"][4]["状态"]):
                score += 15

        # 去杠杆化
        elif "去杠杆" in name:
            if lt_result["signals"][2]["当前值"] and "负" in str(lt_result["signals"][2]["状态"]):
                score += 30
            if "高位" in lt_result["signals"][3]["状态"] or "极度" in lt_result["signals"][3]["状态"]:
                score += 30
            if "高债务" in lt_result["signals"][0]["状态"]:
                score += 25
            if "降息" in str(st_result["signals"][1]["状态"]):
                score += 15

        # 推绳子
        elif "推绳子" in name:
            if lt_result["signals"][2]["当前值"] and ("负" in str(lt_result["signals"][2]["状态"]) or "低" in str(lt_result["signals"][2]["状态"])):
                score += 30
            if "极度扩张" in lt_result["signals"][3]["状态"]:
                score += 30
            if "低迷" in str(st_result["signals"][0]["状态"]) or "紧缩" in str(st_result["signals"][0]["状态"]):
                score += 25
            if "降息" in str(st_result["signals"][1]["状态"]):
                score += 15

        # 正常化
        elif "正常化" in name:
            if "正常" in str(st_result["signals"][0]["状态"]):
                score += 25
            if "加息" in str(st_result["signals"][1]["状态"]):
                score += 25
            if "缩表" in str(lt_result["signals"][3]["状态"]) or "正常" in lt_result["signals"][3]["状态"]:
                score += 25
            if "中性" in str(lt_result["signals"][2]["状态"]):
                score += 25

        matches.append({"stage": name, "match": min(score, 100),
                        "desc": stage["desc"]})

    matches.sort(key=lambda x: x["match"], reverse=True)
    return matches


def analyze_crisis_warnings(cw):
    """分析危机预警指标，返回信号列表。"""
    signals = []

    # 债务/GDP增速
    if cw["debt_gdp_change"] > 5:
        dstatus = "危险（债务快速累积）"
    elif cw["debt_gdp_change"] > 3:
        dstatus = "警戒"
    else:
        dstatus = "正常"
    signals.append({
        "指标": "债务/GDP年度变化",
        "当前值": f"+{cw['debt_gdp_change']}pp",
        "阈值": ">5pp危险, >3pp警戒",
        "状态": dstatus,
        "说明": "债务杠杆变化速度"
    })

    # CAPE比率
    if cw["cape_ratio"] > 35:
        cstatus = "极端泡沫（历史95%分位以上）"
    elif cw["cape_ratio"] > 28:
        cstatus = "高估（泡沫区）"
    elif cw["cape_ratio"] > 20:
        cstatus = "偏高"
    else:
        cstatus = "合理"
    signals.append({
        "指标": "席勒CAPE市盈率",
        "当前值": f"{cw['cape_ratio']}",
        "阈值": ">35极端, >28泡沫",
        "状态": cstatus,
        "说明": "经周期调整的市盈率，长期均值约17"
    })

    # 巴菲特指标
    if cw["market_cap_gdp"] > 200:
        mstatus = "极端高估"
    elif cw["market_cap_gdp"] > 150:
        mstatus = "显著高估"
    elif cw["market_cap_gdp"] > 100:
        mstatus = "偏高"
    else:
        mstatus = "合理"
    signals.append({
        "指标": "股票市值/GDP(巴菲特指标)",
        "当前值": f"{cw['market_cap_gdp']}%",
        "阈值": ">200%极端, >150%高估",
        "状态": mstatus,
        "说明": "巴菲特称其为'最重要的估值指标'"
    })

    # 银行杠杆
    if cw["bank_leverage"] > 15:
        bstatus = "危险（高杠杆）"
    elif cw["bank_leverage"] > 12:
        bstatus = "偏高"
    else:
        bstatus = "健康"
    signals.append({
        "指标": "银行体系杠杆率",
        "当前值": f"{cw['bank_leverage']}倍",
        "阈值": ">15倍危险, >12倍偏高",
        "状态": bstatus,
        "说明": "总资产/一级资本（FDIC数据）"
    })

    return signals


# ============================================================================
# Excel 生成
# ============================================================================
def build_cycle_positioning_sheet(wb, st_result, lt_result, seven_stages, yc):
    """Sheet1: 周期定位。"""
    ws = wb.active
    ws.title = "周期定位"

    ws.merge_cells("A1:F1")
    ws["A1"] = "达里奥债务周期监控 — 周期定位"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:F2")
    ws["A2"] = f"生成时间: {datetime.datetime.now():%Y-%m-%d %H:%M} | 美国经济"
    ws["A2"].font = Font(name="微软雅黑", size=9, italic=True, color="666666")
    ws["A2"].alignment = CENTER

    row = 4
    # 短期债务周期
    ws.cell(row=row, column=1, value="一、短期债务周期（通常5-8年）").font = Font(
        name="微软雅黑", size=12, bold=True, color="1F4E79")
    row += 1
    ws.cell(row=row, column=1, value="当前阶段判断:").font = Font(
        name="微软雅黑", size=11, bold=True)
    stage_cell = ws.cell(row=row, column=2, value=st_result["stage"])
    stage_cell.font = Font(name="微软雅黑", size=11, bold=True, color="C00000")
    stage_cell.fill = STAGE_FILL
    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=4)
    row += 2

    headers = ["信号", "当前值", "阈值", "状态", "说明"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(headers))
    row += 1
    for sig in st_result["signals"]:
        ws.cell(row=row, column=1, value=sig["指标"]).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=sig["当前值"]).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=sig["阈值"]).font = NORMAL_FONT
        sc = ws.cell(row=row, column=4, value=sig["状态"])
        sc.font = NORMAL_FONT
        sc.fill = status_fill(sig["状态"])
        ws.cell(row=row, column=5, value=sig["说明"]).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 6):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1

    # 长期债务周期
    row += 2
    ws.cell(row=row, column=1, value="二、长期债务周期（通常50-75年）").font = Font(
        name="微软雅黑", size=12, bold=True, color="1F4E79")
    row += 1
    ws.cell(row=row, column=1, value="当前阶段判断:").font = Font(
        name="微软雅黑", size=11, bold=True)
    lt_cell = ws.cell(row=row, column=2, value=lt_result["stage"])
    lt_cell.font = Font(name="微软雅黑", size=11, bold=True, color="C00000")
    lt_cell.fill = STAGE_FILL
    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=4)
    row += 2

    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(headers))
    row += 1
    for sig in lt_result["signals"]:
        ws.cell(row=row, column=1, value=sig["指标"]).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=sig["当前值"]).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=sig["阈值"]).font = NORMAL_FONT
        sc = ws.cell(row=row, column=4, value=sig["状态"])
        sc.font = NORMAL_FONT
        sc.fill = status_fill(sig["状态"])
        ws.cell(row=row, column=5, value=sig["说明"]).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 6):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1

    # 七阶段匹配度
    row += 2
    ws.cell(row=row, column=1, value="三、通缩型债务周期七阶段匹配度").font = Font(
        name="微软雅黑", size=12, bold=True, color="1F4E79")
    row += 1
    stage_headers = ["排名", "阶段", "匹配度", "阶段描述"]
    for col, h in enumerate(stage_headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(stage_headers))
    row += 1
    chart_start = row
    for i, m in enumerate(seven_stages, 1):
        ws.cell(row=row, column=1, value=i).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=m["stage"]).font = Font(
            name="微软雅黑", size=10, bold=(i == 1))
        mc = ws.cell(row=row, column=3, value=m["match"])
        mc.font = NORMAL_FONT
        if i == 1:
            mc.fill = STAGE_FILL
        ws.cell(row=row, column=4, value=m["desc"]).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 5):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1
    chart_end = row - 1

    # 七阶段匹配度柱状图
    bar = BarChart()
    bar.type = "bar"
    bar.style = 10
    bar.title = "七阶段匹配度（%）"
    bar.x_axis.title = "匹配度"
    bar.width = 20
    bar.height = 12
    data_ref = Reference(ws, min_col=3, min_row=chart_start - 1,
                         max_row=chart_end, max_col=3)
    bar.add_data(data_ref, titles_from_data=True)
    cats_ref = Reference(ws, min_col=2, min_row=chart_start, max_row=chart_end)
    bar.set_categories(cats_ref)
    ws.add_chart(bar, "G4")

    auto_width(ws, mx=35)
    return ws


def build_signal_detail_sheet(wb, st_result, lt_result, crisis_signals, st, lt, cw):
    """Sheet2: 信号详情。"""
    ws = wb.create_sheet("信号详情")

    ws.merge_cells("A1:F1")
    ws["A1"] = "债务周期监控 — 信号详情"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 28

    row = 3
    sections = [
        ("短期债务周期信号", st_result["signals"], st["source"]),
        ("长期债务周期信号", lt_result["signals"], lt["source"]),
        ("危机预警指标", crisis_signals, cw["source"])
    ]

    for title, signals, source in sections:
        ws.cell(row=row, column=1, value=title).font = Font(
            name="微软雅黑", size=11, bold=True, color="1F4E79")
        row += 1
        ws.cell(row=row, column=1, value=f"数据来源: {source}").font = Font(
            name="微软雅黑", size=9, italic=True, color="666666")
        row += 1
        headers = ["指标", "当前值", "阈值", "状态", "说明"]
        for col, h in enumerate(headers, 1):
            ws.cell(row=row, column=col, value=h)
        style_header(ws, row, len(headers))
        row += 1
        for sig in signals:
            ws.cell(row=row, column=1, value=sig["指标"]).font = NORMAL_FONT
            ws.cell(row=row, column=2, value=sig["当前值"]).font = NORMAL_FONT
            ws.cell(row=row, column=3, value=sig["阈值"]).font = NORMAL_FONT
            sc = ws.cell(row=row, column=4, value=sig["状态"])
            sc.font = NORMAL_FONT
            sc.fill = status_fill(sig["状态"])
            ws.cell(row=row, column=5, value=sig["说明"]).font = Font(
                name="微软雅黑", size=9)
            for c in range(1, 6):
                ws.cell(row=row, column=c).border = BORDER
                ws.cell(row=row, column=c).alignment = CENTER
            row += 1
        row += 2

    auto_width(ws, mx=35)
    return ws


def build_historical_comparison_sheet(wb, st, lt, cw, yc):
    """Sheet3: 历史对比（当前 vs 2008/1929/2000）。"""
    ws = wb.create_sheet("历史对比")

    ws.merge_cells("A1:F1")
    ws["A1"] = "当前指标与历史危机时期对比"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 28

    # 构建对比表
    current = {
        "total_debt_gdp": lt["total_debt_gdp"],
        "fed_funds_rate": st["fed_funds_rate"],
        "real_rate_10y": lt["real_rate_10y"],
        "cape_ratio": cw["cape_ratio"],
        "market_cap_gdp": cw["market_cap_gdp"],
        "high_yield_spread": st["high_yield_spread"],
        "stage": "见周期定位页"
    }

    hist = STATIC["historical"]
    periods = ["当前(2026)"] + list(hist.keys())

    headers = ["指标", "当前(2026)"] + list(hist.keys())
    row = 3
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(headers))
    row += 1

    metrics = [
        ("总债务/GDP(%)", "total_debt_gdp"),
        ("联邦基金利率(%)", "fed_funds_rate"),
        ("10年实际利率(%)", "real_rate_10y"),
        ("席勒CAPE比率", "cape_ratio"),
        ("市值/GDP(%)", "market_cap_gdp"),
        ("高收益债利差(%)", "high_yield_spread"),
        ("周期阶段", "stage"),
    ]

    chart_start = row
    for label, key in metrics:
        ws.cell(row=row, column=1, value=label).font = Font(
            name="微软雅黑", size=10, bold=True)
        ws.cell(row=row, column=1).border = BORDER
        # 当前值
        cur_val = current[key]
        cell = ws.cell(row=row, column=2, value=cur_val)
        cell.font = NORMAL_FONT
        cell.fill = PatternFill("solid", fgColor="E2EFDA")
        cell.border = BORDER
        cell.alignment = CENTER
        # 历史值
        for ci, (pname, pdata) in enumerate(hist.items(), 3):
            val = pdata.get(key, "N/A")
            c = ws.cell(row=row, column=ci, value=val)
            c.font = NORMAL_FONT
            c.border = BORDER
            c.alignment = CENTER
        row += 1
    chart_end = row - 1

    # 对比柱状图（选取关键指标）
    bar = BarChart()
    bar.type = "col"
    bar.style = 10
    bar.title = "关键指标历史对比"
    bar.y_axis.title = "数值"
    bar.width = 22
    bar.height = 12

    # 使用前6行数值数据（排除阶段文字行）
    data_ref = Reference(ws, min_col=2, min_row=3,
                         max_row=chart_end - 1, max_col=len(periods) + 1)
    bar.add_data(data_ref, titles_from_data=True)
    cats_ref = Reference(ws, min_col=1, min_row=chart_start,
                         max_row=chart_end - 1)
    bar.set_categories(cats_ref)
    ws.add_chart(bar, "A12")

    # 分析结论
    row = chart_end + 3
    ws.cell(row=row, column=1, value="对比分析结论").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    conclusions = [
        f"1. 债务水平: 当前总债务/GDP({lt['total_debt_gdp']}%)已接近2008年({hist['2008金融危机']['total_debt_gdp']}%)和1929年({hist['1929大萧条']['total_debt_gdp']}%)水平",
        f"2. 估值水平: 当前CAPE({cw['cape_ratio']})接近2000年互联网泡沫峰值({hist['2000互联网泡沫']['cape_ratio']})，远高于2008年({hist['2008金融危机']['cape_ratio']})",
        f"3. 利率环境: 当前政策利率({st['fed_funds_rate']}%)远高于2008年危机后({hist['2008金融危机']['fed_funds_rate']}%)，但低于2000年({hist['2000互联网泡沫']['fed_funds_rate']}%)",
        f"4. 信用环境: 当前高收益债利差({st['high_yield_spread']}%)远低于2008年危机峰值({hist['2008金融危机']['high_yield_spread']}%)，表明信用市场尚未恐慌",
        "5. 综合判断: 当前呈现'高债务+高估值+利率正常化'的组合，与2000年泡沫顶部后期有相似之处，但银行体系比2008年健康",
        "6. 关键差异: 当前央行资产负债表远大于历史任何时期，政策空间相对有限；同时贫富差距达到1929年以来最高水平"
    ]
    for conc in conclusions:
        cell = ws.cell(row=row, column=1, value=conc)
        cell.font = NORMAL_FONT
        cell.alignment = Alignment(horizontal="left", vertical="center",
                                   wrap_text=True)
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=6)
        row += 1

    auto_width(ws, mx=22)
    ws.column_dimensions["A"].width = 25
    return ws


def build_global_debt_sheet(wb):
    """Sheet: 全球债务对比 — IIF全球债务 + 主要经济体横向对比 + 美债市场功能监控。"""
    ws = wb.create_sheet("全球债务对比")

    ws.merge_cells("A1:G1")
    ws["A1"] = "全球债务周期横向对比（IIF / BIS / IMF）"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 28

    gd = GLOBAL_DEBT_DATA
    tm = TREASURY_MONITOR

    row = 3
    # --- 全球债务概览 ---
    ws.cell(row=row, column=1, value="一、全球债务总量概览").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    overview = [
        ("全球总债务/GDP", f"{gd['global_total_debt_gdp']}%",
         "IIF Global Debt Monitor"),
        ("全球债务总额", f"{gd['global_total_debt_usd_tn']}万亿美元",
         "IIF（含政府+企业+居民）"),
        ("数据时间", gd["date"], gd["sources"]),
    ]
    for label, val, src in overview:
        ws.cell(row=row, column=1, value=label).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=val).font = Font(
            name="微软雅黑", size=10, bold=True)
        ws.cell(row=row, column=3, value=src).font = Font(
            name="微软雅黑", size=9, italic=True, color="666666")
        for c in range(1, 4):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1

    # --- 主要经济体总债务/GDP对比 ---
    row += 1
    ws.cell(row=row, column=1, value="二、主要经济体总债务/GDP对比（BIS口径）").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    headers = ["国家/地区", "总债务/GDP(%)", "政府债务/GDP(%)", "周期定位"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(headers))
    row += 1

    chart_start = row
    stage_map = gd["cycle_stage_by_country"]
    for country, total_debt in gd["total_debt_by_country"].items():
        gov = gd["gov_debt_by_country"].get(country, "N/A")
        stage_info = stage_map.get(country, {})
        stage_label = stage_info.get("long_stage", "—")
        ws.cell(row=row, column=1, value=country).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=total_debt).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=gov).font = NORMAL_FONT
        ws.cell(row=row, column=4, value=stage_label).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 5):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1
    chart_end = row - 1

    # 柱状图：总债务/GDP对比
    bar = BarChart()
    bar.type = "bar"
    bar.style = 10
    bar.title = "主要经济体总债务/GDP对比 (%)"
    bar.x_axis.title = "债务/GDP (%)"
    bar.width = 20
    bar.height = 12
    data_ref = Reference(ws, min_col=2, min_row=chart_start - 1,
                         max_row=chart_end, max_col=3)
    bar.add_data(data_ref, titles_from_data=True)
    cats_ref = Reference(ws, min_col=1, min_row=chart_start, max_row=chart_end)
    bar.set_categories(cats_ref)
    ws.add_chart(bar, "F3")

    # --- 四国债务周期阶段对比 ---
    row += 1
    ws.cell(row=row, column=1, value="三、四大经济体债务周期阶段横向对比").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    cmp_headers = ["指标", "美国", "日本", "欧元区", "英国"]
    for col, h in enumerate(cmp_headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(cmp_headers))
    row += 1

    cmp_rows = [
        ("短期债务周期阶段", "short_stage"),
        ("长期债务周期阶段", "long_stage"),
        ("央行政策利率(%)", "policy_rate"),
        ("10Y国债收益率(%)", "bond_10y"),
        ("CPI通胀(%)", "cpi"),
        ("政府债务/GDP(%)", "debt_gdp"),
        ("特征说明", "note"),
    ]
    for label, key in cmp_rows:
        ws.cell(row=row, column=1, value=label).font = Font(
            name="微软雅黑", size=10, bold=True)
        ws.cell(row=row, column=1).border = BORDER
        for ci, country in enumerate(["美国", "日本", "欧元区", "英国"], 2):
            val = gd["cycle_stage_by_country"][country].get(key, "N/A")
            cell = ws.cell(row=row, column=ci, value=val)
            cell.font = NORMAL_FONT
            cell.border = BORDER
            cell.alignment = CENTER
        row += 1

    # --- 美国国债市场功能监控 ---
    row += 1
    ws.cell(row=row, column=1, value="四、美国国债市场功能监控").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    ws.cell(row=row, column=1,
            value=f"数据来源: {tm['source']} | 时间: {tm['date']}").font = Font(
        name="微软雅黑", size=9, italic=True, color="666666")
    row += 1
    t_headers = ["监控指标", "当前值", "正常范围", "状态"]
    for col, h in enumerate(t_headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(t_headers))
    row += 1

    t_items = [
        ("10Y拍卖投标倍数", tm["bid_to_cover_10y"], ">2.5正常",
         "正常" if tm["bid_to_cover_10y"] > 2.5 else "偏弱"),
        ("30Y拍卖投标倍数", tm["bid_to_cover_30y"], ">2.3正常",
         "正常" if tm["bid_to_cover_30y"] > 2.3 else "偏弱"),
        ("间接投标人占比(%)", tm["indirect_bidder_10y"], ">70%正常",
         "正常" if tm["indirect_bidder_10y"] > 70 else "外资需求走弱"),
    ]
    for label, val, normal, status in t_items:
        ws.cell(row=row, column=1, value=label).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=val).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=normal).font = NORMAL_FONT
        sc = ws.cell(row=row, column=4, value=status)
        sc.font = NORMAL_FONT
        sc.fill = SAFE_FILL if status == "正常" else WARN_FILL
        for c in range(1, 5):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1

    row += 1
    ws.cell(row=row, column=1, value="事件记录").font = Font(
        name="微软雅黑", size=10, bold=True)
    row += 1
    ws.merge_cells(start_row=row, start_column=1, end_row=row + 2, end_column=7)
    note_cell = ws.cell(row=row, column=1, value=tm["market_overheat_note"])
    note_cell.font = NORMAL_FONT
    note_cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)

    auto_width(ws, mx=28)
    ws.column_dimensions["A"].width = 22
    return ws


# ============================================================================
# 主函数
# ============================================================================
def main():
    print("=" * 70)
    print(" 达里奥债务周期监控器 — 开始运行")
    print("=" * 70)

    # 1. 获取数据
    yc = fetch_yield_curve()
    market = fetch_market_data()

    st = STATIC["short_term"]
    lt = STATIC["long_term"]
    cw = STATIC["crisis_warning"]

    # 2. 分析信号
    st_result = analyze_short_term_cycle(st, yc, market)
    lt_result = analyze_long_term_cycle(lt, yc)

    # 3. 七阶段定位
    seven_stages = determine_seven_stage(st_result, lt_result, yc, cw)

    # 4. 危机预警
    crisis_signals = analyze_crisis_warnings(cw)

    # 5. 生成 Excel
    print("\n[生成] 构建 Excel 报告...")
    wb = Workbook()
    build_cycle_positioning_sheet(wb, st_result, lt_result, seven_stages, yc)
    build_signal_detail_sheet(wb, st_result, lt_result, crisis_signals, st, lt, cw)
    build_historical_comparison_sheet(wb, st, lt, cw, yc)
    build_global_debt_sheet(wb)

    # 6. 保存
    out = os.path.join(os.getcwd(),
                       f"dalio_debt_cycle_monitor_{datetime.datetime.now():%Y%m%d}.xlsx")
    try:
        wb.save(out)
    except PermissionError:
        out = out.replace(".xlsx", "_v2.xlsx")
        wb.save(out)

    print(f"\n{'=' * 70}")
    print(f" 报告已生成: {out}")
    print(f"{'=' * 70}")
    print(f"\n 短期债务周期: {st_result['stage']}")
    print(f" 长期债务周期: {lt_result['stage']}")
    print(f" 七阶段最匹配: {seven_stages[0]['stage']} "
          f"(匹配度 {seven_stages[0]['match']}%)")
    print(f" 总债务/GDP: {lt['total_debt_gdp']}%")
    print(f" CAPE比率: {cw['cape_ratio']}")
    print(f" 2Y-10Y利差: {yc['spread_2y10y']}%")


if __name__ == "__main__":
    main()
