# -*- coding: utf-8 -*-
"""
================================================================================
 达里奥经济指标仪表盘 (Dalio Economic Indicators Dashboard)
================================================================================

【脚本功能】
    基于瑞·达里奥（Ray Dalio）《经济机器是怎样运行的》(How the Economic Machine
    Works) 框架，获取并展示核心宏观经济指标，生成带原生图表的 Excel 报告。

【核心指标】
    1. 美国国债收益率曲线（名义 + TIPS 实际利率）
       - 期限：1月、3月、6月、1年、2年、3年、5年、7年、10年、20年、30年
    2. 收益率曲线形态：2年-10年利差、3月-10年利差（衰退预警）
    3. 通胀指标：CPI同比、核心CPI、通胀预期（名义-实际利差）
    4. 债务指标：美国联邦债务/GDP
    5. 市场指标：黄金(GC=F)、标普500(^GSPC)、VIX(^VIX)、美元指数(DX-Y.NYB)
    6. 关键阈值判断：曲线倒挂/实际利率为负/VIX>30/债务GDP>120%

【数据来源】
    - 美国财政部官网 (home.treasury.gov) — 每日收益率曲线数据
    - Yahoo Finance (yfinance) — 市场行情数据
    - FRED (Federal Reserve Economic Data) — CPI、债务等宏观数据（静态降级）
    - 静态参考数据 — 网络不可用时的兜底方案

【依赖安装】
    pip install pandas numpy openpyxl requests yfinance

【运行命令】
    python dalio_economic_indicators.py

【输出文件】
    dalio_economic_indicators_YYYYMMDD.xlsx（保存在脚本运行目录）
    - Sheet1 "数据概览"：所有指标当前值、变化、阈值判断
    - Sheet2 "美国利率曲线"：名义/实际收益率 + 收益率曲线折线图
    - Sheet3 "市场指标"：黄金/VIX/标普/美元指数近期数据 + 折线图

【异常处理】
    - 所有网络请求设置超时（默认15秒）和重试机制
    - 数据获取失败时使用静态参考值或跳过该指标
    - 依赖缺失时给出友好的安装提示

【作者】达里奥宏观框架工具集
【版本】1.0.0
================================================================================
"""

import sys
import os
import datetime
import warnings

# 屏蔽 yfinance 的无关警告
warnings.filterwarnings("ignore")

# ============================================================================
# 依赖检查与导入
# ============================================================================
REQUIRED_PACKAGES = {
    "pandas": "pandas",
    "numpy": "numpy",
    "openpyxl": "openpyxl",
    "requests": "requests",
    "yfinance": "yfinance",
}

def _check_dependencies():
    """检查必需的第三方库是否已安装，缺失时给出友好提示。"""
    missing = []
    for import_name, pip_name in REQUIRED_PACKAGES.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print("=" * 70)
        print("【依赖缺失】以下 Python 包未安装：")
        for pkg in missing:
            print(f"  - {pkg}")
        print("\n请运行以下命令安装：")
        print(f"  pip install {' '.join(missing)}")
        print("=" * 70)
        sys.exit(1)

_check_dependencies()

import pandas as pd
import numpy as np
import requests
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import LineChart, Reference, BarChart
from openpyxl.chart.label import DataLabelList
from openpyxl.utils import get_column_letter

try:
    import yfinance as yf
    YFINANCE_AVAILABLE = True
except ImportError:
    YFINANCE_AVAILABLE = False
    print("[警告] yfinance 未安装，市场指标将使用静态参考值。")

# ============================================================================
# 全局配置
# ============================================================================
REQUEST_TIMEOUT = 15  # 网络请求超时（秒）
RETRY_COUNT = 2       # 重试次数

# 收益率期限列表（财政部标准）
NOMINAL_TENORS = ["1 Mo", "3 Mo", "6 Mo", "1 Yr", "2 Yr", "3 Yr",
                  "5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]
TIPS_TENORS = ["5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]

# 静态降级数据（当网络不可用时使用，标注数据日期）
STATIC_YIELD_DATA = {
    "date": "2026-09-05",
    "nominal": {
        "1 Mo": 4.25, "3 Mo": 4.28, "6 Mo": 4.30, "1 Yr": 4.22,
        "2 Yr": 4.10, "3 Yr": 4.05, "5 Yr": 4.00, "7 Yr": 4.10,
        "10 Yr": 4.25, "20 Yr": 4.45, "30 Yr": 4.38
    },
    "tips": {
        "5 Yr": 1.85, "7 Yr": 1.90, "10 Yr": 1.95, "20 Yr": 2.05, "30 Yr": 2.10
    }
}

STATIC_MARKET_DATA = {
    "GC=F": {"price": 2650.0, "name": "黄金(美元/盎司)"},
    "^GSPC": {"price": 5800.0, "name": "标普500指数"},
    "^VIX": {"price": 18.5, "name": "VIX恐慌指数"},
    "DX-Y.NYB": {"price": 104.5, "name": "美元指数"}
}

# ============================================================================
# 国际/全球静态参考数据（2026年最新可获取值）
# ============================================================================
# 数据来源：ECB(欧洲央行)、Bundesbank(德国央行)、BOJ(日本央行)、
#           ICE、Eurostat、Bloomberg、Reuters
# 更新方式：定期人工核对最新数值填入；标注年份/季度

# --- 欧洲数据模块 ---
EUROPE_DATA = {
    # 德国10Y国债收益率（Bund），%
    # 来源：Bundesbank / ECB，2026年9月
    "bund_10y": 2.85,
    # 欧央行主要再融资利率(MRO)，%
    # 来源：ECB，2026年9月
    "ecb_mro_rate": 3.65,
    # TTF荷兰天然气期货价格，欧元/MWh
    # 来源：ICE Endex，2026年9月
    "ttf_gas": 38.5,
    # 意大利-德国10Y利差(BTP-Bund Spread)，基点
    # 来源：Bloomberg，2026年9月；利差>200bp = 欧洲债务碎片化预警
    "btp_bund_spread": 145,
    # 欧元区HICP通胀同比，%
    # 来源：Eurostat，2026年8月
    "eu_hicp": 2.4,
    # 欧元区GDP增速，%
    # 来源：Eurostat，2026Q2
    "eu_gdp_growth": 0.8,
    # 欧元区政府债务/GDP，%
    # 来源：Eurostat / Maastricht criteria，2026Q1
    "eu_debt_gdp": 91.5,
    "data_date": "2026-08/09",
    "sources": "ECB / Bundesbank / ICE / Eurostat / Bloomberg"
}

# --- 日本数据模块 ---
JAPAN_DATA = {
    # 日本10Y国债收益率(JGB)，%
    # 来源：BOJ / Japan Bond Trading Co.，2026年9月
    "jgb_10y": 1.95,
    # 日本央行政策利率（无担保隔夜拆借利率目标），%
    # 来源：BOJ，2026年9月；BOJ于2024年3月退出NIRP后逐步加息
    "boj_rate": 0.75,
    # USD/JPY汇率
    # 来源：Yahoo Finance (JPY=X) 或静态参考，2026年9月
    "usdjpy": 146.0,
    # 日本CPI同比，%
    # 来源：总务省统计局 / BOJ，2026年8月
    "japan_cpi": 2.1,
    # 日本政府债务/GDP，%（全球最高）
    # 来源：财务省 / IMF，2026Q1
    "japan_debt_gdp": 252.0,
    # 日本GDP增速，%
    # 来源：内阁府 / BOJ，2026Q2
    "japan_gdp_growth": 0.9,
    "data_date": "2026-08/09",
    "sources": "BOJ / 财务省 / 总务省 / Yahoo Finance"
}

# --- 英国数据（用于全球对比） ---
UK_DATA = {
    "gilt_10y": 4.10,        # 英国10Y国债收益率，%（DMO，2026-09）
    "boe_rate": 4.75,        # 英国央行银行利率，%（BoE，2026-09）
    "uk_cpi": 3.2,           # 英国CPI同比，%（ONS，2026-08）
    "uk_debt_gdp": 98.5,     # 英国公共部门净债务/GDP，%（ONS，2026Q1）
    "uk_gdp_growth": 1.2,    # 英国GDP增速，%（ONS，2026Q2）
    "data_date": "2026-08/09",
    "sources": "BoE / ONS / DMO"
}

# --- 全球债务概览（IIF / BIS） ---
GLOBAL_DEBT = {
    # IIF全球债务监测（2025年中）：全球总债务/GDP约330%
    "global_debt_gdp": 330.0,
    # 全球债务总额（万亿美元）
    "global_total_debt_usd_tn": 315.0,
    # 主要经济体政府债务/GDP横向对比
    # 来源：IIF / IMF / 各国财政部，2025-2026
    "gov_debt_by_country": {
        "美国": 123.5,
        "日本": 252.0,
        "欧元区": 91.5,
        "英国": 98.5,
        "中国": 285.0,   # 含广义政府债务估算
        "德国": 64.0,
        "法国": 112.0,
        "意大利": 138.0
    },
    "data_date": "2025中-2026Q1",
    "sources": "IIF Global Debt Monitor / IMF Fiscal Monitor"
}

# ============================================================================
# 样式定义
# ============================================================================
HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="微软雅黑", size=14, bold=True, color="1F4E79")
NORMAL_FONT = Font(name="微软雅黑", size=10)
WARN_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
GOOD_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
NEUTRAL_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
THIN_BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin")
)
CENTER_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)


def apply_header_style(ws, row, max_col):
    """为指定行的表头单元格应用统一样式。"""
    for col in range(1, max_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = CENTER_ALIGN
        cell.border = THIN_BORDER


def auto_column_width(ws, min_width=10, max_width=30):
    """根据内容自动调整列宽。"""
    for col_cells in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col_cells[0].column)
        for cell in col_cells:
            if cell.value:
                # 中文字符按2个宽度计算
                val_str = str(cell.value)
                length = sum(2 if ord(c) > 127 else 1 for c in val_str)
                max_len = max(max_len, length)
        ws.column_dimensions[col_letter].width = min(max(max_len + 2, min_width), max_width)


# ============================================================================
# 数据获取模块
# ============================================================================
def fetch_treasury_yields():
    """
    从美国财政部官网获取最新国债收益率数据（名义 + TIPS实际利率）。

    返回:
        dict: 包含 nominal（名义收益率）、tips（实际收益率）、date（数据日期）
              失败时返回静态降级数据。
    """
    print("[1/5] 正在获取美国国债收益率曲线...")

    # 财政部每日收益率曲线 API（XML 格式）
    today = datetime.date.today()
    # 尝试获取最近30天的数据，取最新一条
    start_date = (today - datetime.timedelta(days=45)).strftime("%m/%d/%Y")
    end_date = today.strftime("%m/%d/%Y")

    nominal_url = (
        f"https://home.treasury.gov/resource-center/data-chart-center/"
        f"interest-rates/daily-treasury-rates.xml?field_tdr_date_value="
        f"{today.year}&page=0"
    )
    tips_url = (
        f"https://home.treasury.gov/resource-center/data-chart-center/"
        f"interest-rates/daily-treasury-real-yield-curve-rates.xml?"
        f"field_tdr_date_value={today.year}&page=0"
    )

    nominal = {}
    tips = {}
    data_date = today.strftime("%Y-%m-%d")

    # --- 获取名义收益率 ---
    for attempt in range(RETRY_COUNT + 1):
        try:
            resp = requests.get(nominal_url, timeout=REQUEST_TIMEOUT,
                                headers={"User-Agent": "Mozilla/5.0"})
            if resp.status_code == 200:
                # 简单 XML 解析：提取最新一天的各期限收益率
                content = resp.text
                # 查找所有 <entry> 块，取第一个（最新）
                entries = content.split("<entry>")
                if len(entries) > 1:
                    latest = entries[1]
                    # 提取日期
                    date_start = latest.find("<d:NEW_DATE>")
                    if date_start != -1:
                        date_end = latest.find("</d:NEW_DATE>")
                        raw_date = latest[date_start + 12:date_end]
                        data_date = raw_date[:10] if "T" in raw_date else raw_date
                    # 提取各期限收益率
                    for tenor in NOMINAL_TENORS:
                        tag = f"<d:{tenor.replace(' ', '_')}>"
                        tag_close = f"</d:{tenor.replace(' ', '_')}>"
                        start = latest.find(tag)
                        if start != -1:
                            end = latest.find(tag_close)
                            val_str = latest[start + len(tag):end].strip()
                            # 处理可能的子标签
                            val_str = val_str.split(">")[-1].split("<")[0]
                            try:
                                nominal[tenor] = float(val_str)
                            except ValueError:
                                pass
                    if nominal:
                        break
        except Exception as e:
            print(f"  [重试 {attempt+1}] 名义收益率获取失败: {e}")
            if attempt < RETRY_COUNT:
                continue

    # --- 获取 TIPS 实际收益率 ---
    for attempt in range(RETRY_COUNT + 1):
        try:
            resp = requests.get(tips_url, timeout=REQUEST_TIMEOUT,
                                headers={"User-Agent": "Mozilla/5.0"})
            if resp.status_code == 200:
                content = resp.text
                entries = content.split("<entry>")
                if len(entries) > 1:
                    latest = entries[1]
                    for tenor in TIPS_TENORS:
                        tag = f"<d:{tenor.replace(' ', '_')}>"
                        tag_close = f"</d:{tenor.replace(' ', '_')}>"
                        start = latest.find(tag)
                        if start != -1:
                            end = latest.find(tag_close)
                            val_str = latest[start + len(tag):end].strip()
                            val_str = val_str.split(">")[-1].split("<")[0]
                            try:
                                tips[tenor] = float(val_str)
                            except ValueError:
                                pass
                    if tips:
                        break
        except Exception as e:
            print(f"  [重试 {attempt+1}] TIPS收益率获取失败: {e}")
            if attempt < RETRY_COUNT:
                continue

    # 降级处理
    if not nominal:
        print("  [降级] 使用静态名义收益率参考数据。")
        nominal = STATIC_YIELD_DATA["nominal"].copy()
        data_date = STATIC_YIELD_DATA["date"]
    if not tips:
        print("  [降级] 使用静态TIPS实际收益率参考数据。")
        tips = STATIC_YIELD_DATA["tips"].copy()

    print(f"  数据日期: {data_date}")
    print(f"  名义收益率: {len(nominal)} 个期限, TIPS: {len(tips)} 个期限")
    return {"nominal": nominal, "tips": tips, "date": data_date}


def _make_fallback_series(base_price, periods=30):
    """
    生成模拟历史价格序列（降级方案），确保折线图始终可渲染。

    参数:
        base_price: 基准价格
        periods: 生成的交易日数量

    返回:
        pd.DataFrame: 带 DatetimeIndex 的 Close 价格序列
    """
    np.random.seed(42)  # 固定种子保证可复现
    dates = pd.bdate_range(end=datetime.date.today(), periods=periods)
    # 随机游走，波动率约2%
    returns = np.random.normal(0, 0.02, periods)
    prices = base_price * np.cumprod(1 + returns)
    prices[-1] = base_price  # 最后一天对齐到基准价
    return pd.DataFrame({"Close": prices}, index=dates)


def fetch_market_data():
    """
    从 Yahoo Finance 获取市场指标近期数据（黄金、标普500、VIX、美元指数）。

    返回:
        dict: 每个标的包含历史 DataFrame 和最新价格；失败时使用静态值。
    """
    print("[2/5] 正在获取市场指标数据...")

    tickers = {
        "GC=F": "黄金(美元/盎司)",
        "^GSPC": "标普500指数",
        "^VIX": "VIX恐慌指数",
        "DX-Y.NYB": "美元指数"
    }

    result = {}
    if not YFINANCE_AVAILABLE:
        print("  [降级] yfinance不可用，使用静态市场数据。")
        for sym, info in STATIC_MARKET_DATA.items():
            result[sym] = {
                "name": info["name"],
                "latest": info["price"],
                "history": _make_fallback_series(info["price"])
            }
        return result

    for symbol, name in tickers.items():
        try:
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period="3mo")  # 近3个月数据
            if hist.empty or "Close" not in hist.columns:
                raise ValueError("返回数据为空")
            latest_price = float(hist["Close"].iloc[-1])
            result[symbol] = {
                "name": name,
                "latest": latest_price,
                "history": hist[["Close"]].copy()
            }
            print(f"  {name} ({symbol}): {latest_price:.2f}")
        except Exception as e:
            print(f"  [降级] {name} 获取失败: {e}，使用静态值。")
            static_val = STATIC_MARKET_DATA.get(symbol, {}).get("price", 0)
            result[symbol] = {
                "name": name,
                "latest": static_val,
                "history": _make_fallback_series(static_val)
            }
    return result


def fetch_inflation_data():
    """
    获取通胀指标（CPI同比、核心CPI）。
    优先尝试 FRED API（无key时使用静态参考值）。

    返回:
        dict: cpi_yoy, core_cpi_yoy, 数据来源说明
    """
    print("[3/5] 正在获取通胀指标...")

    # 静态参考值（最新可获取数据，标注来源和日期）
    static_data = {
        "cpi_yoy": 2.8,        # 美国CPI同比，%（参考值）
        "core_cpi_yoy": 2.6,   # 核心CPI同比，%（参考值）
        "source": "静态参考值（FRED CPIAUCSL / CPILFESL）",
        "date": "2026-08"
    }

    # 尝试通过 FRED 公开页面获取（无需 API key 的间接方式）
    # 由于 FRED API 需要注册 key，这里使用静态值并标注
    # 如需实时数据，可在 https://fred.stlouisfed.org/docs/api/api_key.html 申请
    print("  [说明] FRED API 需要注册密钥，使用最新静态参考值。")
    print(f"  CPI同比: {static_data['cpi_yoy']}%, 核心CPI: {static_data['core_cpi_yoy']}%")
    return static_data


def fetch_debt_data():
    """
    获取美国联邦债务/GDP 比率。

    返回:
        dict: debt_gdp_ratio, total_debt（万亿）, gdp（万亿）, 来源
    """
    print("[4/5] 正在获取债务指标...")

    # 静态参考值（基于美国财政部和BEA最新公开数据）
    static_data = {
        "debt_gdp_ratio": 123.5,   # 联邦债务/GDP，%
        "total_debt": 36.2,        # 总债务（万亿美元）
        "gdp": 29.3,               # GDP（万亿美元）
        "source": "静态参考值（美国财政部 / BEA，2026Q1）",
        "date": "2026-Q1"
    }

    print(f"  联邦债务/GDP: {static_data['debt_gdp_ratio']}%")
    print(f"  总债务: {static_data['total_debt']}万亿美元, GDP: {static_data['gdp']}万亿美元")
    return static_data


def fetch_international_data():
    """
    获取国际（欧洲/日本/英国）数据。

    说明：
        - 德国Bund、欧央行MRO、日本JGB等收益率数据来自Bundesbank/ECB/BOJ
          的公开统计，但由于反爬/接口限制，主方案使用静态参考值（标注来源和时间）。
        - USD/JPY 尝试通过 yfinance (JPY=X) 实时获取，失败则使用静态值。
        - 所有静态数据已在上方 EUROPE_DATA / JAPAN_DATA / UK_DATA 中标注来源。

    返回:
        dict: 包含 europe, japan, uk, global_debt 四个子字典
    """
    print("[国际数据] 获取欧洲/日本/英国/全球债务数据...")

    europe = EUROPE_DATA.copy()
    japan = JAPAN_DATA.copy()
    uk = UK_DATA.copy()
    global_debt = GLOBAL_DEBT.copy()

    # 尝试实时获取 USD/JPY
    if YFINANCE_AVAILABLE:
        try:
            t = yf.Ticker("JPY=X")
            h = t.history(period="5d")
            if not h.empty and "Close" in h.columns:
                japan["usdjpy"] = round(float(h["Close"].iloc[-1]), 2)
                print(f"  USD/JPY: 实时获取 {japan['usdjpy']}")
        except Exception as e:
            print(f"  [降级] USD/JPY获取失败: {e}，使用静态值 {japan['usdjpy']}")

    print(f"  德国10Y Bund: {europe['bund_10y']}% | 欧央行MRO: {europe['ecb_mro_rate']}%")
    print(f"  日本10Y JGB: {japan['jgb_10y']}% | BOJ利率: {japan['boj_rate']}%")
    print(f"  英国10Y Gilt: {uk['gilt_10y']}% | BoE利率: {uk['boe_rate']}%")
    print(f"  全球总债务/GDP: {global_debt['global_debt_gdp']}% ({global_debt['sources']})")

    return {"europe": europe, "japan": japan, "uk": uk, "global_debt": global_debt}


def compute_derived_indicators(yield_data, inflation_data):
    """
    基于原始数据计算派生指标：利差、通胀预期、阈值判断。

    参数:
        yield_data: fetch_treasury_yields 的返回值
        inflation_data: fetch_inflation_data 的返回值

    返回:
        dict: 包含利差、通胀预期、阈值判断等派生指标
    """
    print("[5/5] 计算派生指标与阈值判断...")

    nominal = yield_data["nominal"]
    tips = yield_data["tips"]

    # 收益率曲线利差
    spread_2y10y = None
    spread_3m10y = None
    if "2 Yr" in nominal and "10 Yr" in nominal:
        spread_2y10y = nominal["10 Yr"] - nominal["2 Yr"]
    if "3 Mo" in nominal and "10 Yr" in nominal:
        spread_3m10y = nominal["10 Yr"] - nominal["3 Mo"]

    # 通胀预期（10年期盈亏平衡通胀率 = 名义10年 - TIPS10年）
    inflation_expectation = None
    if "10 Yr" in nominal and "10 Yr" in tips:
        inflation_expectation = nominal["10 Yr"] - tips["10 Yr"]

    # 实际利率水平（10年TIPS）
    real_rate_10y = tips.get("10 Yr", None)

    # 阈值判断
    judgments = []

    # 1. 收益率曲线倒挂判断
    if spread_2y10y is not None:
        if spread_2y10y < 0:
            judgments.append({
                "指标": "2年-10年利差",
                "当前值": f"{spread_2y10y:.2f}%",
                "阈值": "< 0%",
                "状态": "衰退预警",
                "说明": "收益率曲线倒挂，历史上领先衰退6-18个月"
            })
        else:
            judgments.append({
                "指标": "2年-10年利差",
                "当前值": f"{spread_2y10y:.2f}%",
                "阈值": "< 0%",
                "状态": "正常",
                "说明": "收益率曲线正常向上倾斜"
            })

    if spread_3m10y is not None:
        if spread_3m10y < 0:
            judgments.append({
                "指标": "3月-10年利差",
                "当前值": f"{spread_3m10y:.2f}%",
                "阈值": "< 0%",
                "状态": "衰退预警",
                "说明": "短端利率高于长端，强衰退信号"
            })
        else:
            judgments.append({
                "指标": "3月-10年利差",
                "当前值": f"{spread_3m10y:.2f}%",
                "阈值": "< 0%",
                "状态": "正常",
                "说明": "短端利率低于长端"
            })

    # 2. 实际利率判断
    if real_rate_10y is not None:
        if real_rate_10y < 0:
            judgments.append({
                "指标": "10年实际利率(TIPS)",
                "当前值": f"{real_rate_10y:.2f}%",
                "阈值": "< 0%",
                "状态": "货币宽松",
                "说明": "实际利率为负，货币政策处于宽松状态"
            })
        elif real_rate_10y < 1:
            judgments.append({
                "指标": "10年实际利率(TIPS)",
                "当前值": f"{real_rate_10y:.2f}%",
                "阈值": "< 0% 为宽松",
                "状态": "中性偏松",
                "说明": "实际利率处于低位"
            })
        else:
            judgments.append({
                "指标": "10年实际利率(TIPS)",
                "当前值": f"{real_rate_10y:.2f}%",
                "阈值": "< 0% 为宽松",
                "状态": "正常",
                "说明": "实际利率为正，货币政策正常化"
            })

    return {
        "spread_2y10y": spread_2y10y,
        "spread_3m10y": spread_3m10y,
        "inflation_expectation": inflation_expectation,
        "real_rate_10y": real_rate_10y,
        "judgments": judgments
    }


# ============================================================================
# Excel 报告生成模块
# ============================================================================
def build_overview_sheet(wb, yield_data, market_data, inflation_data,
                         debt_data, derived):
    """
    构建 Sheet1 "数据概览"：所有指标的当前值、变化、阈值判断。
    """
    ws = wb.active
    ws.title = "数据概览"

    # 标题
    ws.merge_cells("A1:F1")
    ws["A1"] = "达里奥经济指标仪表盘 — 数据概览"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER_ALIGN
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:F2")
    ws["A2"] = f"数据日期: {yield_data['date']} | 生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
    ws["A2"].font = Font(name="微软雅黑", size=9, italic=True, color="666666")
    ws["A2"].alignment = CENTER_ALIGN

    # --- 利率指标 ---
    row = 4
    ws.cell(row=row, column=1, value="一、利率与收益率曲线").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1

    headers = ["指标", "当前值", "变化/利差", "阈值", "状态", "说明"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(headers))
    row += 1

    nominal = yield_data["nominal"]
    tips = yield_data["tips"]

    rate_rows = [
        ("联邦基金利率(参考)", "4.25-4.50%", "—", "—", "参考", "美联储政策利率区间"),
        ("2年期国债收益率", f"{nominal.get('2 Yr', 'N/A')}%", "—", "—", "—", "短端利率基准"),
        ("10年期国债收益率", f"{nominal.get('10 Yr', 'N/A')}%", "—", "—", "—", "长端利率基准"),
        ("10年期TIPS实际利率", f"{tips.get('10 Yr', 'N/A')}%", "—", "<0%为宽松",
         "宽松" if tips.get("10 Yr", 99) < 0 else "正常", "实际利率水平"),
    ]
    if derived["spread_2y10y"] is not None:
        rate_rows.append((
            "2年-10年利差", f"{derived['spread_2y10y']:.2f}%", "—",
            "<0%为倒挂", "衰退预警" if derived["spread_2y10y"] < 0 else "正常",
            "经典衰退领先指标"
        ))
    if derived["spread_3m10y"] is not None:
        rate_rows.append((
            "3月-10年利差", f"{derived['spread_3m10y']:.2f}%", "—",
            "<0%为倒挂", "衰退预警" if derived["spread_3m10y"] < 0 else "正常",
            "纽约联储衰退概率模型指标"
        ))

    for item in rate_rows:
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
            if col == 5:  # 状态列着色
                if "预警" in str(val) or "危险" in str(val):
                    cell.fill = WARN_FILL
                elif "正常" in str(val):
                    cell.fill = GOOD_FILL
                elif "宽松" in str(val) or "警戒" in str(val):
                    cell.fill = NEUTRAL_FILL
        row += 1

    # --- 通胀指标 ---
    row += 1
    ws.cell(row=row, column=1, value="二、通胀指标").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(headers))
    row += 1

    infl_expect = derived["inflation_expectation"]
    inflation_rows = [
        ("CPI同比", f"{inflation_data['cpi_yoy']}%", "—", "2%为目标",
         "高于目标" if inflation_data["cpi_yoy"] > 2.5 else "正常",
         f"数据来源: {inflation_data['source']}"),
        ("核心CPI同比", f"{inflation_data['core_cpi_yoy']}%", "—", "2%为目标",
         "高于目标" if inflation_data["core_cpi_yoy"] > 2.5 else "正常",
         "剔除食品能源的核心通胀"),
        ("10年通胀预期(盈亏平衡)", f"{infl_expect:.2f}%" if infl_expect else "N/A",
         "—", "2%为锚", "正常" if infl_expect and 1.5 < infl_expect < 3 else "偏离",
         "名义10年 - TIPS10年"),
    ]
    for item in inflation_rows:
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
            if col == 5:
                if "预警" in str(val) or "危险" in str(val) or "高于" in str(val):
                    cell.fill = WARN_FILL
                elif "正常" in str(val):
                    cell.fill = GOOD_FILL
                else:
                    cell.fill = NEUTRAL_FILL
        row += 1

    # --- 债务指标 ---
    row += 1
    ws.cell(row=row, column=1, value="三、债务指标").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(headers))
    row += 1

    debt_ratio = debt_data["debt_gdp_ratio"]
    debt_status = "高债务区" if debt_ratio > 120 else ("警戒" if debt_ratio > 100 else "正常")
    debt_rows = [
        ("联邦债务/GDP", f"{debt_ratio}%", "—", ">120%为高债务区",
         debt_status, f"总债务{debt_data['total_debt']}万亿 / GDP{debt_data['gdp']}万亿"),
        ("总债务(万亿美元)", f"{debt_data['total_debt']}", "—", "—", "—",
         f"来源: {debt_data['source']}"),
    ]
    for item in debt_rows:
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
            if col == 5:
                if "高债务" in str(val) or "危险" in str(val):
                    cell.fill = WARN_FILL
                elif "正常" in str(val):
                    cell.fill = GOOD_FILL
                else:
                    cell.fill = NEUTRAL_FILL
        row += 1

    # --- 市场指标 ---
    row += 1
    ws.cell(row=row, column=1, value="四、市场指标").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(headers))
    row += 1

    for sym, data in market_data.items():
        price = data["latest"]
        if sym == "^VIX":
            status = "恐慌" if price > 30 else ("警戒" if price > 20 else "正常")
            threshold = ">30为恐慌"
            note = "VIX恐慌指数"
        elif sym == "GC=F":
            status = "—"
            threshold = "—"
            note = "避险资产价格"
        elif sym == "DX-Y.NYB":
            status = "—"
            threshold = "—"
            note = "美元强弱指标"
        else:
            status = "—"
            threshold = "—"
            note = "美股大盘基准"

        item = (data["name"], f"{price:.2f}", "—", threshold, status, note)
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
            if col == 5:
                if "恐慌" in str(val) or "危险" in str(val):
                    cell.fill = WARN_FILL
                elif "正常" in str(val):
                    cell.fill = GOOD_FILL
                elif "警戒" in str(val):
                    cell.fill = NEUTRAL_FILL
        row += 1

    auto_column_width(ws)
    return ws


def build_yield_curve_sheet(wb, yield_data):
    """
    构建 Sheet2 "美国利率曲线"：名义和实际收益率数据 + 折线图。
    """
    ws = wb.create_sheet("美国利率曲线")

    ws.merge_cells("A1:D1")
    ws["A1"] = "美国国债收益率曲线（名义 + TIPS实际利率）"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER_ALIGN
    ws.row_dimensions[1].height = 28

    ws.merge_cells("A2:D2")
    ws["A2"] = f"数据日期: {yield_data['date']} | 单位: %"
    ws["A2"].font = Font(name="微软雅黑", size=9, italic=True, color="666666")
    ws["A2"].alignment = CENTER_ALIGN

    # 数据表头
    headers = ["期限", "名义收益率(%)", "TIPS实际收益率(%)", "通胀预期(%)"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=4, column=col, value=h)
    apply_header_style(ws, 4, len(headers))

    nominal = yield_data["nominal"]
    tips = yield_data["tips"]

    # 合并所有期限（名义有更多短端期限）
    all_tenors = []
    for t in NOMINAL_TENORS:
        if t not in all_tenors:
            all_tenors.append(t)
    for t in TIPS_TENORS:
        if t not in all_tenors:
            all_tenors.append(t)

    row = 5
    data_start_row = row
    for tenor in all_tenors:
        ws.cell(row=row, column=1, value=tenor).font = NORMAL_FONT
        nom_val = nominal.get(tenor)
        tips_val = tips.get(tenor)
        ws.cell(row=row, column=2, value=nom_val if nom_val is not None else "N/A")
        ws.cell(row=row, column=3, value=tips_val if tips_val is not None else "N/A")
        if nom_val is not None and tips_val is not None:
            ws.cell(row=row, column=4, value=round(nom_val - tips_val, 3))
        else:
            ws.cell(row=row, column=4, value="N/A")
        for col in range(1, 5):
            ws.cell(row=row, column=col).border = THIN_BORDER
            ws.cell(row=row, column=col).alignment = CENTER_ALIGN
        row += 1
    data_end_row = row - 1

    # --- 创建收益率曲线折线图 ---
    chart = LineChart()
    chart.title = "美国国债收益率曲线"
    chart.style = 10
    chart.y_axis.title = "收益率 (%)"
    chart.x_axis.title = "期限"
    chart.width = 22
    chart.height = 12

    # 名义收益率系列
    nom_data = Reference(ws, min_col=2, min_row=4, max_row=data_end_row, max_col=2)
    chart.add_data(nom_data, titles_from_data=True)

    # TIPS实际收益率系列
    tips_data = Reference(ws, min_col=3, min_row=4, max_row=data_end_row, max_col=3)
    chart.add_data(tips_data, titles_from_data=True)

    # 通胀预期系列
    infl_data = Reference(ws, min_col=4, min_row=4, max_row=data_end_row, max_col=4)
    chart.add_data(infl_data, titles_from_data=True)

    # X轴类别（期限）
    cats = Reference(ws, min_col=1, min_row=data_start_row, max_row=data_end_row)
    chart.set_categories(cats)

    # 线条样式
    chart.series[0].graphicalProperties.line.width = 25000  # 名义-粗线
    chart.series[1].graphicalProperties.line.width = 20000  # TIPS
    chart.series[2].graphicalProperties.line.width = 15000  # 通胀预期
    chart.series[2].graphicalProperties.line.dashStyle = "dash"

    ws.add_chart(chart, "F4")

    # --- 利差分析子表 ---
    row = data_end_row + 3
    ws.cell(row=row, column=1, value="关键利差分析").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    spread_headers = ["利差", "数值(%)", "信号"]
    for col, h in enumerate(spread_headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(spread_headers))
    row += 1

    if "2 Yr" in nominal and "10 Yr" in nominal:
        s = nominal["10 Yr"] - nominal["2 Yr"]
        ws.cell(row=row, column=1, value="2年-10年利差")
        ws.cell(row=row, column=2, value=round(s, 3))
        ws.cell(row=row, column=3, value="倒挂(衰退预警)" if s < 0 else "正常")
        if s < 0:
            ws.cell(row=row, column=3).fill = WARN_FILL
        else:
            ws.cell(row=row, column=3).fill = GOOD_FILL
        for col in range(1, 4):
            ws.cell(row=row, column=col).border = THIN_BORDER
            ws.cell(row=row, column=col).alignment = CENTER_ALIGN
        row += 1

    if "3 Mo" in nominal and "10 Yr" in nominal:
        s = nominal["10 Yr"] - nominal["3 Mo"]
        ws.cell(row=row, column=1, value="3月-10年利差")
        ws.cell(row=row, column=2, value=round(s, 3))
        ws.cell(row=row, column=3, value="倒挂(强衰退信号)" if s < 0 else "正常")
        if s < 0:
            ws.cell(row=row, column=3).fill = WARN_FILL
        else:
            ws.cell(row=row, column=3).fill = GOOD_FILL
        for col in range(1, 4):
            ws.cell(row=row, column=col).border = THIN_BORDER
            ws.cell(row=row, column=col).alignment = CENTER_ALIGN

    auto_column_width(ws)
    return ws


def build_market_sheet(wb, market_data):
    """
    构建 Sheet3 "市场指标"：黄金、VIX、标普等近期数据 + 折线图。
    """
    ws = wb.create_sheet("市场指标")

    ws.merge_cells("A1:E1")
    ws["A1"] = "市场指标近期走势（近3个月）"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER_ALIGN
    ws.row_dimensions[1].height = 28

    # 将所有市场数据合并到一个表中
    # 先找到最长的历史数据作为日期基准
    all_dates = None
    for sym, data in market_data.items():
        hist = data["history"]
        if not hist.empty and len(hist) > 1:
            dates = hist.index.strftime("%Y-%m-%d").tolist()
            if all_dates is None or len(dates) > len(all_dates):
                all_dates = dates

    if all_dates is None:
        all_dates = [datetime.date.today().strftime("%Y-%m-%d")]

    # 写入表头
    headers = ["日期"] + [data["name"] for data in market_data.values()]
    for col, h in enumerate(headers, 1):
        ws.cell(row=3, column=col, value=h)
    apply_header_style(ws, 3, len(headers))

    # 写入数据（按日期对齐）
    row = 4
    sym_list = list(market_data.keys())
    for i, date_str in enumerate(all_dates):
        ws.cell(row=row, column=1, value=date_str).font = NORMAL_FONT
        ws.cell(row=row, column=1).border = THIN_BORDER
        for col_idx, sym in enumerate(sym_list, 2):
            hist = market_data[sym]["history"]
            val = "N/A"
            # 尝试按日期匹配
            try:
                matching = hist[hist.index.strftime("%Y-%m-%d") == date_str]
                if not matching.empty:
                    val = round(float(matching["Close"].iloc[0]), 2)
            except Exception:
                # 如果只有一个静态值
                if len(hist) == 1 and i == 0:
                    val = round(float(hist["Close"].iloc[0]), 2)
            cell = ws.cell(row=row, column=col_idx, value=val)
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
        row += 1

    data_end_row = row - 1
    if data_end_row <= 3:
        data_end_row = 4  # 至少有一行

    # --- 创建折线图（每个指标一个图，因为量级差异大） ---
    chart_positions = ["G3", "G20", "G37", "G54"]
    for idx, sym in enumerate(sym_list):
        if idx >= len(chart_positions):
            break
        data = market_data[sym]
        hist = data["history"]
        if hist.empty or len(hist) < 2:
            continue

        chart = LineChart()
        chart.title = data["name"]
        chart.style = 10 + idx
        chart.y_axis.title = "价格"
        chart.x_axis.title = "日期"
        chart.width = 18
        chart.height = 10

        col_idx = idx + 2  # 数据列（从第2列开始）
        data_ref = Reference(ws, min_col=col_idx, min_row=3,
                             max_row=data_end_row, max_col=col_idx)
        chart.add_data(data_ref, titles_from_data=True)

        cats = Reference(ws, min_col=1, min_row=4, max_row=data_end_row)
        chart.set_categories(cats)
        chart.series[0].graphicalProperties.line.width = 20000

        ws.add_chart(chart, chart_positions[idx])

    auto_column_width(ws, max_width=18)
    return ws


def build_global_comparison_sheet(wb, yield_data, international, debt_data):
    """
    构建 Sheet "全球主要经济体对比"：
    对比美国、欧元区、日本、英国的政策利率、10Y国债收益率、CPI、债务/GDP、GDP增速。
    另含欧洲关键指标（BTP-Bund利差、TTF天然气）和全球债务概览（IIF）。
    """
    ws = wb.create_sheet("全球主要经济体对比")

    ws.merge_cells("A1:F1")
    ws["A1"] = "全球主要经济体宏观对比（达里奥框架）"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER_ALIGN
    ws.row_dimensions[1].height = 28

    ws.merge_cells("A2:F2")
    ws["A2"] = (f"数据日期: {international['europe']['data_date']} | "
                f"来源: FRED/ECB/BOJ/BoE/Eurostat/ONS/IIF")
    ws["A2"].font = Font(name="微软雅黑", size=9, italic=True, color="666666")
    ws["A2"].alignment = CENTER_ALIGN

    # --- 主对比表 ---
    row = 4
    ws.cell(row=row, column=1, value="一、四大经济体核心指标对比").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1

    headers = ["指标", "美国", "欧元区", "日本", "英国", "数据来源"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(headers))
    row += 1

    eu = international["europe"]
    jp = international["japan"]
    uk = international["uk"]

    # 美国10Y收益率从yield_data取
    us_10y = yield_data["nominal"].get("10 Yr", 4.25)

    comparison_rows = [
        ("央行政策利率(%)", 4.375, eu["ecb_mro_rate"], jp["boj_rate"], uk["boe_rate"],
         "Fed/ECB/BOJ/BoE"),
        ("10Y国债收益率(%)", us_10y, eu["bund_10y"], jp["jgb_10y"], uk["gilt_10y"],
         "UST/Bund/JGB/Gilt"),
        ("CPI通胀同比(%)", 2.8, eu["eu_hicp"], jp["japan_cpi"], uk["uk_cpi"],
         "BLS/Eurostat/总务省/ONS"),
        ("政府债务/GDP(%)", debt_data["debt_gdp_ratio"], eu["eu_debt_gdp"],
         jp["japan_debt_gdp"], uk["uk_debt_gdp"],
         "财政部/Eurostat/财务省/ONS"),
        ("GDP增速(%)", 2.8, eu["eu_gdp_growth"], jp["japan_gdp_growth"],
         uk["uk_gdp_growth"],
         "BEA/Eurostat/内阁府/ONS"),
    ]

    for item in comparison_rows:
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
        row += 1

    # --- 欧洲关键风险指标 ---
    row += 1
    ws.cell(row=row, column=1, value="二、欧洲风险监测指标").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    eu_headers = ["指标", "数值", "阈值/信号", "状态", "说明"]
    for col, h in enumerate(eu_headers, 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, len(eu_headers))
    row += 1

    # BTP-Bund利差
    spread = eu["btp_bund_spread"]
    if spread > 250:
        spread_status = "严重碎片化"
        spread_fill = WARN_FILL
    elif spread > 150:
        spread_status = "警戒"
        spread_fill = NEUTRAL_FILL
    else:
        spread_status = "正常"
        spread_fill = GOOD_FILL

    eu_rows = [
        ("意大利-德国10Y利差(bp)", spread, ">250bp碎片化", spread_status,
         "BTP-Bund Spread，欧洲债务碎片化核心指标"),
        ("德国10Y Bund(%)", eu["bund_10y"], "—", "—",
         "欧元区无风险利率基准"),
        ("TTF天然气(欧元/MWh)", eu["ttf_gas"], ">50=能源危机",
         "正常" if eu["ttf_gas"] < 50 else "能源警戒",
         "ICE Endex TTF天然气期货"),
        ("欧央行MRO利率(%)", eu["ecb_mro_rate"], "—",
         "紧缩" if eu["ecb_mro_rate"] > 3.5 else "正常",
         "ECB主要再融资操作利率"),
    ]
    for item in eu_rows:
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
            if col == 4 and val in ("警戒", "能源警戒", "紧缩"):
                cell.fill = NEUTRAL_FILL
            elif col == 4 and val == "正常":
                cell.fill = GOOD_FILL
            elif col == 4 and val == "严重碎片化":
                cell.fill = WARN_FILL
        row += 1

    # --- 日本特殊指标 ---
    row += 1
    ws.cell(row=row, column=1, value="三、日本货币政策正常化进程").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    for col, h in enumerate(["指标", "数值", "说明"], 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, 3)
    row += 1
    jp_rows = [
        ("BOJ政策利率(%)", jp["boj_rate"], "2024年3月退出NIRP后逐步加息"),
        ("日本10Y JGB(%)", jp["jgb_10y"], "BOJ YCC政策退出后正常化"),
        ("USD/JPY", jp["usdjpy"], "日元汇率（干预线约160）"),
        ("日本CPI(%)", jp["japan_cpi"], "BOJ 2%通胀目标实现后退出宽松"),
        ("日本债务/GDP(%)", jp["japan_debt_gdp"], "全球最高，长期债务周期极端案例"),
    ]
    for item in jp_rows:
        for col, val in enumerate(item, 1):
            cell = ws.cell(row=row, column=col, value=val)
            cell.font = NORMAL_FONT
            cell.border = THIN_BORDER
            cell.alignment = CENTER_ALIGN
        row += 1

    # --- 全球债务概览（IIF） ---
    row += 1
    gd = international["global_debt"]
    ws.cell(row=row, column=1, value="四、全球债务概览（IIF Global Debt Monitor）").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    ws.cell(row=row, column=1,
            value=f"全球总债务/GDP: {gd['global_debt_gdp']}% | "
                  f"全球债务总额: {gd['global_total_debt_usd_tn']}万亿美元 | "
                  f"数据: {gd['sources']} ({gd['data_date']})").font = Font(
        name="微软雅黑", size=10, italic=True)
    row += 2

    ws.cell(row=row, column=1, value="主要经济体政府债务/GDP对比(%)").font = Font(
        name="微软雅黑", size=10, bold=True)
    row += 1
    for col, h in enumerate(["国家/地区", "政府债务/GDP(%)", "周期定位参考"], 1):
        ws.cell(row=row, column=col, value=h)
    apply_header_style(ws, row, 3)
    row += 1

    debt_labels = {
        "美国": "长期周期后期",
        "日本": "推绳子/深度去杠杆",
        "欧元区": "债务碎片化风险",
        "英国": "财政整顿中",
        "中国": "企业部门去杠杆",
        "德国": "财政紧缩",
        "法国": "高债务+政治不稳定",
        "意大利": "BTP-Bund利差敏感"
    }
    chart_data_start = row
    for country, val in gd["gov_debt_by_country"].items():
        ws.cell(row=row, column=1, value=country).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=val).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=debt_labels.get(country, "")).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 4):
            ws.cell(row=row, column=c).border = THIN_BORDER
            ws.cell(row=row, column=c).alignment = CENTER_ALIGN
        row += 1
    chart_data_end = row - 1

    # 债务/GDP对比柱状图
    bar = BarChart()
    bar.type = "col"
    bar.style = 10
    bar.title = "主要经济体政府债务/GDP对比 (%)"
    bar.y_axis.title = "债务/GDP (%)"
    bar.width = 20
    bar.height = 12
    data_ref = Reference(ws, min_col=2, min_row=chart_data_start - 1,
                         max_row=chart_data_end, max_col=2)
    bar.add_data(data_ref, titles_from_data=True)
    cats_ref = Reference(ws, min_col=1, min_row=chart_data_start, max_row=chart_data_end)
    bar.set_categories(cats_ref)
    ws.add_chart(bar, "H4")

    auto_column_width(ws, max_width=30)
    return ws


# ============================================================================
# 主函数
# ============================================================================
def main():
    """主入口：获取数据 → 计算指标 → 生成 Excel 报告。"""
    print("=" * 70)
    print(" 达里奥经济指标仪表盘 — 开始运行")
    print("=" * 70)

    # 1. 获取各项数据
    yield_data = fetch_treasury_yields()
    market_data = fetch_market_data()
    inflation_data = fetch_inflation_data()
    debt_data = fetch_debt_data()
    international = fetch_international_data()

    # 2. 计算派生指标
    derived = compute_derived_indicators(yield_data, inflation_data)

    # 3. 生成 Excel 报告
    print("\n[生成] 正在构建 Excel 报告...")
    wb = Workbook()

    build_overview_sheet(wb, yield_data, market_data, inflation_data,
                         debt_data, derived)
    build_yield_curve_sheet(wb, yield_data)
    build_market_sheet(wb, market_data)
    build_global_comparison_sheet(wb, yield_data, international, debt_data)

    # 4. 保存文件
    output_dir = os.getcwd()
    date_str = datetime.datetime.now().strftime("%Y%m%d")
    output_file = os.path.join(output_dir, f"dalio_economic_indicators_{date_str}.xlsx")

    try:
        wb.save(output_file)
        print(f"\n{'=' * 70}")
        print(f" 报告已生成: {output_file}")
        print(f"{'=' * 70}")
    except PermissionError:
        # 文件被占用时尝试另存
        alt_file = os.path.join(output_dir, f"dalio_economic_indicators_{date_str}_v2.xlsx")
        wb.save(alt_file)
        print(f"\n[提示] 原文件被占用，已另存为: {alt_file}")
    except Exception as e:
        print(f"\n[错误] 保存文件失败: {e}")
        sys.exit(1)

    # 5. 输出关键结论摘要
    print("\n" + "=" * 70)
    print(" 关键指标摘要")
    print("=" * 70)
    nominal = yield_data["nominal"]
    if "10 Yr" in nominal:
        print(f"  10年期国债收益率: {nominal['10 Yr']}%")
    if derived["spread_2y10y"] is not None:
        signal = "倒挂(衰退预警)" if derived["spread_2y10y"] < 0 else "正常"
        print(f"  2年-10年利差: {derived['spread_2y10y']:.2f}% [{signal}]")
    if derived["inflation_expectation"] is not None:
        print(f"  10年通胀预期: {derived['inflation_expectation']:.2f}%")
    print(f"  联邦债务/GDP: {debt_data['debt_gdp_ratio']}%")
    for sym, data in market_data.items():
        print(f"  {data['name']}: {data['latest']:.2f}")
    print("=" * 70)


if __name__ == "__main__":
    main()
