# -*- coding: utf-8 -*-
"""
================================================================================
 达里奥世界秩序八指标追踪器 (Dalio World Order Tracker)
================================================================================

【脚本功能】
    基于瑞·达里奥（Ray Dalio）《原则：应对变化中的世界秩序》(Principles for
    Dealing with the Changing World Order) 中提出的大国兴衰八指标框架，
    追踪主要国家（美国、中国、欧盟、日本等）的相对实力变化，生成带雷达图的
    Excel 可视化报告。

【八大指标】
    1. 教育 — PISA分数、高等教育入学率（OECD / 世界银行）
    2. 创新 — 研发支出/GDP、专利申请量（WIPO / 世界银行）
    3. 经济产出/竞争力 — GDP全球占比、制造业产出全球占比（IMF / 世界银行）
    4. 贸易 — 全球出口份额（WTO / 世界银行）
    5. 军事 — 军费支出全球占比（SIPRI 斯德哥尔摩国际和平研究所）
    6. 金融中心 — 股票市值/GDP、GFCI排名（Z/Yen / 世界银行）
    7. 储备货币 — 全球外汇储备货币占比（IMF COFER）
    8. 内部冲突 — 基尼系数、政治极化指数（世界银行 / 静态参考）

【数据来源说明】
    - 世界银行 API (api.worldbank.org)：实时获取 GDP、研发支出、出口等
    - 静态参考数据：SIPRI军费、PISA分数、GFCI排名、IMF COFER等
      （在代码中以字典存储，标注数据年份和来源）
    - 所有静态数据均标注来源和年份，便于核验更新

【评分方法】
    每个指标对主要国家进行 0-100 分评分，基于相对排名：
    - 正向指标（越高越好）：线性映射到 0-100
    - 负向指标（如基尼系数，越低越好）：反向映射
    - 综合得分 = 各子指标加权平均

【依赖安装】
    pip install pandas numpy openpyxl requests

【运行命令】
    python dalio_world_order_tracker.py

【输出文件】
    dalio_world_order_tracker_YYYYMMDD.xlsx
    - Sheet1 "八指标总览"：各国各指标原始值和评分 + 美中雷达图
    - Sheet2 "详细数据"：每个指标的详细数据表格
    - Sheet3 "趋势与判断"：基于指标的大周期定位分析

【异常处理】
    - 世界银行 API 请求超时/失败时自动降级为静态参考数据
    - 所有网络请求设置15秒超时
    - 依赖缺失时给出友好安装提示

【作者】达里奥宏观框架工具集
【版本】1.0.0
================================================================================
"""

import sys
import os
import datetime
import warnings
warnings.filterwarnings("ignore")

# ============================================================================
# 依赖检查
# ============================================================================
REQUIRED = {"pandas": "pandas", "numpy": "numpy",
            "openpyxl": "openpyxl", "requests": "requests"}

def _check_deps():
    missing = [pip for imp, pip in REQUIRED.items()
               if __import__("importlib").util.find_spec(imp) is None]
    if missing:
        print("【依赖缺失】请运行: pip install " + " ".join(missing))
        sys.exit(1)

try:
    _check_deps()
except Exception:
    pass

import pandas as pd
import numpy as np
import requests
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import RadarChart, Reference, BarChart
from openpyxl.chart.label import DataLabelList
from openpyxl.utils import get_column_letter

# ============================================================================
# 配置
# ============================================================================
TIMEOUT = 15
COUNTRIES = ["美国", "中国", "欧盟", "日本", "印度", "英国", "俄罗斯", "沙特", "巴西"]
COUNTRY_CODES = {
    "美国": "USA", "中国": "CHN", "欧盟": "EUU",
    "日本": "JPN", "印度": "IND", "英国": "GBR",
    "俄罗斯": "RUS", "沙特": "SAU", "巴西": "BRA"
}

# 雷达图对比核心四国（美中欧日）
RADAR_COUNTRIES = ["美国", "中国", "欧盟", "日本"]

# ============================================================================
# 静态参考数据库（标注来源和年份）
# ============================================================================
STATIC_DATA = {
    # 1. 教育
    "education": {
        "source": "OECD PISA 2022 + 世界银行高等教育入学率（2022）",
        "year": "2022",
        "pisa_score": {"美国": 488, "中国": 557, "欧盟": 483, "日本": 529, "印度": 372,
                       "英国": 492, "俄罗斯": 495, "沙特": 430, "巴西": 403},
        "tertiary_enrollment": {"美国": 88, "中国": 58, "欧盟": 65, "日本": 62, "印度": 28,
                                "英国": 60, "俄罗斯": 82, "沙特": 75, "巴西": 52}
    },
    # 2. 创新
    "innovation": {
        "source": "世界银行 R&D/GDP（2022）+ WIPO 专利申请量（2023）",
        "year": "2022-2023",
        "rd_gdp": {"美国": 3.46, "中国": 2.55, "欧盟": 2.15, "日本": 3.30, "印度": 0.65,
                   "英国": 1.70, "俄罗斯": 1.00, "沙特": 0.50, "巴西": 1.20},
        "patents": {"美国": 59300, "中国": 162000, "欧盟": 48000, "日本": 30600, "印度": 7500,
                    "英国": 12000, "俄罗斯": 18000, "沙特": 1200, "巴西": 4500}
    },
    # 3. 经济产出
    "economy": {
        "source": "IMF GDP全球占比（2024预估）+ 联合国制造业产出（2022）",
        "year": "2022-2024",
        "gdp_share": {"美国": 25.4, "中国": 17.8, "欧盟": 17.2, "日本": 4.2, "印度": 3.6,
                      "英国": 3.3, "俄罗斯": 2.2, "沙特": 1.2, "巴西": 2.1},
        "manufacturing_share": {"美国": 16.5, "中国": 31.0, "欧盟": 18.0, "日本": 5.5, "印度": 3.2,
                                "英国": 2.2, "俄罗斯": 3.5, "沙特": 0.8, "巴西": 2.3}
    },
    # 4. 贸易
    "trade": {
        "source": "WTO 全球商品出口份额（2023）",
        "year": "2023",
        "export_share": {"美国": 8.1, "中国": 14.4, "欧盟": 15.2, "日本": 3.5, "印度": 1.8,
                         "英国": 2.6, "俄罗斯": 2.1, "沙特": 2.0, "巴西": 1.3}
    },
    # 5. 军事
    "military": {
        "source": "SIPRI 军费支出全球占比（2023）",
        "year": "2023",
        "military_share": {"美国": 37.0, "中国": 13.0, "欧盟": 16.5, "日本": 2.8, "印度": 3.7,
                           "英国": 3.2, "俄罗斯": 5.5, "沙特": 3.8, "巴西": 1.7}
    },
    # 6. 金融中心
    "finance": {
        "source": "世界银行 股票市值/GDP（2022）+ Z/Yen GFCI排名（2024）",
        "year": "2022-2024",
        "market_cap_gdp": {"美国": 155, "中国": 65, "欧盟": 58, "日本": 125, "印度": 95,
                           "英国": 110, "俄罗斯": 45, "沙特": 90, "巴西": 60},
        "gfci_rank": {"美国": 1, "中国": 4, "欧盟": 5, "日本": 3, "印度": 10,
                      "英国": 2, "俄罗斯": 25, "沙特": 30, "巴西": 35}
        # GFCI排名：1=纽约(美), 2=伦敦(英), 3=东京(日), 4=上海/香港(中), 5=巴黎(欧)
    },
    # 7. 储备货币
    "reserve_currency": {
        "source": "IMF COFER 全球外汇储备货币占比（2024Q1）",
        "year": "2024Q1",
        "reserve_share": {"美国": 57.0, "中国": 2.4, "欧盟": 19.5, "日本": 5.5, "印度": 0.3,
                          "英国": 4.9, "俄罗斯": 0.0, "沙特": 0.0, "巴西": 0.0}
        # 美元、欧元、日元、英镑、人民币、卢比；卢布/里亚尔/雷亚尔非主要储备货币
    },
    # 8. 内部冲突（负向指标，数值越低越好）
    "internal_conflict": {
        "source": "世界银行基尼系数（2021）+ 政治极化指数（静态参考2023）",
        "year": "2021-2023",
        "gini": {"美国": 39.8, "中国": 37.1, "欧盟": 30.5, "日本": 32.9, "印度": 35.7,
                 "英国": 33.0, "俄罗斯": 36.0, "沙特": 30.0, "巴西": 52.0},
        "polarization": {"美国": 72, "中国": 35, "欧盟": 48, "日本": 42, "印度": 65,
                         "英国": 60, "俄罗斯": 55, "沙特": 40, "巴西": 58}
        # 极化指数 0-100，越高越极化
    }
}

# ============================================================================
# 储备货币详细数据：SWIFT支付 + IMF COFER储备（2024-2025）
# ============================================================================
# SWIFT RMB Tracker：全球支付货币占比（按金额）
# 来源：SWIFT RMB Tracker，2025年最新月度
SWIFT_PAYMENT_SHARE = {
    "source": "SWIFT RMB Tracker (人民币国际化报告)",
    "year": "2025",
    "currencies": {
        "美元": 47.5,    # USD 全球支付占比，%
        "欧元": 22.5,    # EUR
        "英镑": 6.8,     # GBP
        "人民币": 4.5,    # CNY
        "日元": 3.3,     # JPY
        "加元": 2.2,     # CAD
        "港元": 1.6,     # HKD
        "其他": 11.6
    },
    "note": "SWIFT按支付金额统计，美元长期占40-50%，欧元约20-25%"
}

# IMF COFER：全球官方外汇储备货币构成
# 来源：IMF Currency Composition of Official Foreign Exchange Reserves
COFER_RESERVE_SHARE = {
    "source": "IMF COFER Database",
    "year": "2025Q1",
    "currencies": {
        "美元": 57.5,    # USD 占全球已分配外汇储备，%
        "欧元": 19.5,    # EUR
        "日元": 5.5,     # JPY
        "英镑": 4.9,     # GBP
        "人民币": 2.5,    # CNY（2016年纳入SDR后持续上升）
        "加元": 2.4,     # CAD
        "澳元": 2.1,     # AUD
        "瑞士法郎": 0.8,  # CHF
        "其他": 4.8
    },
    "note": "COFER为官方央行储备持仓，美元份额从2000年70%下降至约58%"
}

# 指标权重（达里奥框架中各指标的相对重要性）
INDICATOR_WEIGHTS = {
    "教育": 0.12, "创新": 0.15, "经济产出": 0.15, "贸易": 0.10,
    "军事": 0.13, "金融中心": 0.12, "储备货币": 0.13, "内部冲突": 0.10
}


# ============================================================================
# 样式
# ============================================================================
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="微软雅黑", size=14, bold=True, color="1F4E79")
NORMAL_FONT = Font(name="微软雅黑", size=10)
BORDER = Border(left=Side("thin"), right=Side("thin"),
                top=Side("thin"), bottom=Side("thin"))
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
US_FILL = PatternFill("solid", fgColor="D6E4F0")
CN_FILL = PatternFill("solid", fgColor="FCE4D6")


def style_header(ws, row, ncol):
    for c in range(1, ncol + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = CENTER
        cell.border = BORDER


def auto_width(ws, mn=10, mx=28):
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        mxlen = max((sum(2 if ord(ch) > 127 else 1 for ch in str(c.value or ""))
                     for c in col), default=0)
        ws.column_dimensions[letter].width = min(max(mxlen + 2, mn), mx)


# ============================================================================
# 世界银行 API 数据获取（实时尝试，失败降级）
# ============================================================================
def fetch_worldbank_indicator(indicator_code, country_codes, date_range="2018:2024"):
    """
    从世界银行 API 获取指定指标数据。

    参数:
        indicator_code: 世界银行指标代码（如 "GB.XPD.RSDV.GD.ZS"）
        country_codes: 国家代码列表
        date_range: 年份范围

    返回:
        dict: {国家名: 最新值}，失败返回空字典
    """
    result = {}
    countries_str = ";".join(country_codes)
    url = (f"https://api.worldbank.org/v2/country/{countries_str}/"
           f"indicator/{indicator_code}?date={date_range}&format=json&per_page=500")
    try:
        resp = requests.get(url, timeout=TIMEOUT,
                            headers={"User-Agent": "Mozilla/5.0"})
        if resp.status_code == 200:
            data = resp.json()
            if isinstance(data, list) and len(data) > 1:
                records = data[1]
                # 按国家取最新非空值
                temp = {}
                for rec in records:
                    country = rec.get("country", {}).get("value", "")
                    value = rec.get("value")
                    year = rec.get("date", "")
                    if value is not None:
                        if country not in temp or year > temp[country][0]:
                            temp[country] = (year, value)
                # 映射国家名
                name_map = {"United States": "美国", "China": "中国",
                            "European Union": "欧盟", "Japan": "日本", "India": "印度"}
                for wb_name, (yr, val) in temp.items():
                    cn_name = name_map.get(wb_name, wb_name)
                    result[cn_name] = round(float(val), 2)
    except Exception as e:
        print(f"  [世界银行API] {indicator_code} 获取失败: {e}")
    return result


def fetch_live_data():
    """
    尝试从世界银行 API 实时获取部分指标，失败则使用静态数据。

    返回:
        dict: 更新后的数据字典
    """
    print("[1/3] 尝试从世界银行 API 获取实时数据...")
    data = STATIC_DATA.copy()

    # 研发支出/GDP
    rd = fetch_worldbank_indicator("GB.XPD.RSDV.GD.ZS",
                                   list(COUNTRY_CODES.values()))
    if rd:
        data["innovation"]["rd_gdp"].update(rd)
        print(f"  研发支出/GDP: 实时获取成功 ({len(rd)}国)")

    # GDP（现价美元）— 用于计算占比需要全球总量，这里简化处理
    gdp = fetch_worldbank_indicator("NY.GDP.MKTP.CD",
                                    list(COUNTRY_CODES.values()))
    if gdp:
        total = sum(gdp.values())
        if total > 0:
            shares = {k: round(v / total * 100, 1) for k, v in gdp.items()}
            # 注意：这只是五国合计中的占比，非全球占比，仅作参考
            print(f"  GDP数据: 获取成功（五国相对占比，非全球占比）")

    # 股票市值/GDP
    mcap = fetch_worldbank_indicator("CM.MKT.LCAP.GD.ZS",
                                     list(COUNTRY_CODES.values()))
    if mcap:
        data["finance"]["market_cap_gdp"].update(mcap)
        print(f"  股票市值/GDP: 实时获取成功 ({len(mcap)}国)")

    # 出口占比
    export = fetch_worldbank_indicator("NE.EXP.GNFS.ZS",
                                       list(COUNTRY_CODES.values()))
    if export:
        print(f"  出口/GDP: 获取成功（作为贸易参考）")

    print("  其余指标使用静态参考数据（已标注来源和年份）。")
    return data


# ============================================================================
# 评分引擎
# ============================================================================
def score_positive(values_dict):
    """正向指标评分：值越高得分越高，线性映射到 0-100。"""
    vals = np.array(list(values_dict.values()), dtype=float)
    vmin, vmax = vals.min(), vals.max()
    if vmax == vmin:
        return {k: 50.0 for k in values_dict}
    return {k: round((v - vmin) / (vmax - vmin) * 100, 1)
            for k, v in values_dict.items()}


def score_negative(values_dict):
    """负向指标评分：值越低得分越高（如基尼系数、极化指数）。"""
    vals = np.array(list(values_dict.values()), dtype=float)
    vmin, vmax = vals.min(), vals.max()
    if vmax == vmin:
        return {k: 50.0 for k in values_dict}
    return {k: round((vmax - v) / (vmax - vmin) * 100, 1)
            for k, v in values_dict.items()}


def compute_all_scores(data):
    """
    计算所有八大指标的评分。

    返回:
        dict: {指标名: {国家: 评分}} 和 {指标名: {国家: 原始值描述}}
    """
    print("[2/3] 计算各国八指标评分...")

    scores = {}
    raw_display = {}

    # 1. 教育（PISA 60% + 高等教育入学率 40%）
    pisa_s = score_positive(data["education"]["pisa_score"])
    enroll_s = score_positive(data["education"]["tertiary_enrollment"])
    scores["教育"] = {c: round(pisa_s[c] * 0.6 + enroll_s[c] * 0.4, 1)
                      for c in COUNTRIES}
    raw_display["教育"] = {c: f"PISA:{data['education']['pisa_score'][c]}"
                           for c in COUNTRIES}

    # 2. 创新（研发/GDP 50% + 专利 50%）
    rd_s = score_positive(data["innovation"]["rd_gdp"])
    pat_s = score_positive(data["innovation"]["patents"])
    scores["创新"] = {c: round(rd_s[c] * 0.5 + pat_s[c] * 0.5, 1)
                      for c in COUNTRIES}
    raw_display["创新"] = {c: f"R&D:{data['innovation']['rd_gdp'][c]}%"
                           for c in COUNTRIES}

    # 3. 经济产出（GDP占比 60% + 制造业占比 40%）
    gdp_s = score_positive(data["economy"]["gdp_share"])
    mfg_s = score_positive(data["economy"]["manufacturing_share"])
    scores["经济产出"] = {c: round(gdp_s[c] * 0.6 + mfg_s[c] * 0.4, 1)
                          for c in COUNTRIES}
    raw_display["经济产出"] = {c: f"GDP:{data['economy']['gdp_share'][c]}%"
                               for c in COUNTRIES}

    # 4. 贸易
    scores["贸易"] = score_positive(data["trade"]["export_share"])
    raw_display["贸易"] = {c: f"出口:{data['trade']['export_share'][c]}%"
                           for c in COUNTRIES}

    # 5. 军事
    scores["军事"] = score_positive(data["military"]["military_share"])
    raw_display["军事"] = {c: f"军费:{data['military']['military_share'][c]}%"
                           for c in COUNTRIES}

    # 6. 金融中心（市值/GDP 60% + GFCI排名反向 40%）
    mcap_s = score_positive(data["finance"]["market_cap_gdp"])
    # GFCI排名：排名数字越小越好，反向评分
    gfci_s = score_negative(data["finance"]["gfci_rank"])
    scores["金融中心"] = {c: round(mcap_s[c] * 0.6 + gfci_s[c] * 0.4, 1)
                          for c in COUNTRIES}
    raw_display["金融中心"] = {c: f"市值/GDP:{data['finance']['market_cap_gdp'][c]}%"
                               for c in COUNTRIES}

    # 7. 储备货币
    scores["储备货币"] = score_positive(data["reserve_currency"]["reserve_share"])
    raw_display["储备货币"] = {c: f"储备:{data['reserve_currency']['reserve_share'][c]}%"
                               for c in COUNTRIES}

    # 8. 内部冲突（负向：基尼 50% + 极化 50%，越低越好）
    gini_s = score_negative(data["internal_conflict"]["gini"])
    pol_s = score_negative(data["internal_conflict"]["polarization"])
    scores["内部冲突"] = {c: round(gini_s[c] * 0.5 + pol_s[c] * 0.5, 1)
                          for c in COUNTRIES}
    raw_display["内部冲突"] = {c: f"基尼:{data['internal_conflict']['gini'][c]}"
                               for c in COUNTRIES}

    # 综合得分（加权）
    composite = {}
    for c in COUNTRIES:
        total = sum(scores[ind][c] * INDICATOR_WEIGHTS[ind]
                    for ind in scores)
        composite[c] = round(total, 1)
    scores["综合得分"] = composite
    raw_display["综合得分"] = {c: "加权综合" for c in COUNTRIES}

    for c in COUNTRIES:
        print(f"  {c}: 综合 {composite[c]} 分")
    return scores, raw_display


# ============================================================================
# Excel 生成
# ============================================================================
def build_overview_sheet(wb, scores, raw_display):
    """Sheet1: 八指标总览 + 美中雷达图。"""
    ws = wb.active
    ws.title = "八指标总览"

    ws.merge_cells("A1:G1")
    ws["A1"] = "达里奥世界秩序八指标 — 各国评分总览"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:G2")
    ws["A2"] = (f"评分范围 0-100 | 数据年份: 2022-2024 | "
                f"生成时间: {datetime.datetime.now().strftime('%Y-%m-%d')}")
    ws["A2"].font = Font(name="微软雅黑", size=9, italic=True, color="666666")
    ws["A2"].alignment = CENTER

    # 评分表
    indicators = ["教育", "创新", "经济产出", "贸易", "军事",
                  "金融中心", "储备货币", "内部冲突", "综合得分"]
    headers = ["指标"] + COUNTRIES + ["领先国家"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=4, column=col, value=h)
    style_header(ws, 4, len(headers))

    row = 5
    radar_start = row
    for ind in indicators:
        ws.cell(row=row, column=1, value=ind).font = Font(
            name="微软雅黑", size=10, bold=True)
        ws.cell(row=row, column=1).border = BORDER
        best_country = ""
        best_score = -1
        for ci, c in enumerate(COUNTRIES, 2):
            val = scores[ind][c]
            cell = ws.cell(row=row, column=ci, value=val)
            cell.font = NORMAL_FONT
            cell.border = BORDER
            cell.alignment = CENTER
            if c == "美国":
                cell.fill = US_FILL
            elif c == "中国":
                cell.fill = CN_FILL
            if val > best_score:
                best_score = val
                best_country = c
        lead_cell = ws.cell(row=row, column=len(COUNTRIES) + 2,
                            value=best_country)
        lead_cell.font = NORMAL_FONT
        lead_cell.border = BORDER
        lead_cell.alignment = CENTER
        row += 1
    radar_end = row - 1

    # 原始值参考行
    row += 1
    ws.cell(row=row, column=1, value="原始值参考（关键子指标）").font = Font(
        name="微软雅黑", size=10, bold=True, color="1F4E79")
    row += 1
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(headers))
    row += 1
    for ind in indicators[:-1]:  # 排除综合得分
        ws.cell(row=row, column=1, value=ind).font = NORMAL_FONT
        ws.cell(row=row, column=1).border = BORDER
        for ci, c in enumerate(COUNTRIES, 2):
            cell = ws.cell(row=row, column=ci, value=raw_display[ind][c])
            cell.font = Font(name="微软雅黑", size=9)
            cell.border = BORDER
            cell.alignment = CENTER
        row += 1

    # --- 雷达图：美中欧日四国对比 ---
    radar = RadarChart()
    radar.type = "standard"  # 线型雷达图，四国叠加避免填充遮挡
    radar.style = 26
    radar.title = "美中欧日 — 八指标雷达图对比"
    radar.width = 20
    radar.height = 15

    # 按 COUNTRIES 顺序：Col2=美国, Col3=中国, Col4=欧盟, Col5=日本
    for ci, country in enumerate(RADAR_COUNTRIES, start=2):
        data_ref = Reference(ws, min_col=ci, min_row=4,
                             max_row=radar_end, max_col=ci)
        radar.add_data(data_ref, titles_from_data=True)

    cats = Reference(ws, min_col=1, min_row=radar_start, max_row=radar_end)
    radar.set_categories(cats)

    # 四国线条样式
    for s in radar.series:
        s.graphicalProperties.line.width = 22000

    ws.add_chart(radar, "I4")

    # --- 柱状图：综合得分对比 ---
    bar = BarChart()
    bar.type = "col"
    bar.style = 10
    bar.title = "各国综合得分对比"
    bar.y_axis.title = "综合得分"
    bar.width = 18
    bar.height = 10

    # 综合得分在最后一行
    comp_row = radar_end  # 综合得分行
    comp_data = Reference(ws, min_col=2, min_row=comp_row,
                          max_row=comp_row, max_col=len(COUNTRIES) + 1)
    bar.add_data(comp_data, from_rows=True, titles_from_data=False)
    comp_cats = Reference(ws, min_col=2, min_row=4,
                          max_row=4, max_col=len(COUNTRIES) + 1)
    bar.set_categories(comp_cats)

    ws.add_chart(bar, "I22")

    auto_width(ws)
    return ws


def build_detail_sheet(wb, data):
    """Sheet2: 每个指标的详细数据表格。"""
    ws = wb.create_sheet("详细数据")

    ws.merge_cells("A1:F1")
    ws["A1"] = "八指标详细数据（原始值 + 来源 + 年份）"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 28

    row = 3
    indicator_details = [
        ("1. 教育", [
            ("PISA分数(数学/科学/阅读平均)", data["education"]["pisa_score"],
             "OECD PISA 2022", "正向"),
            ("高等教育入学率(%)", data["education"]["tertiary_enrollment"],
             "世界银行 2022", "正向"),
        ]),
        ("2. 创新", [
            ("研发支出/GDP(%)", data["innovation"]["rd_gdp"],
             "世界银行 2022", "正向"),
            ("专利申请量(件)", data["innovation"]["patents"],
             "WIPO 2023", "正向"),
        ]),
        ("3. 经济产出", [
            ("GDP全球占比(%)", data["economy"]["gdp_share"],
             "IMF 2024预估", "正向"),
            ("制造业产出全球占比(%)", data["economy"]["manufacturing_share"],
             "联合国 2022", "正向"),
        ]),
        ("4. 贸易", [
            ("全球商品出口份额(%)", data["trade"]["export_share"],
             "WTO 2023", "正向"),
        ]),
        ("5. 军事", [
            ("军费支出全球占比(%)", data["military"]["military_share"],
             "SIPRI 2023", "正向"),
        ]),
        ("6. 金融中心", [
            ("股票市值/GDP(%)", data["finance"]["market_cap_gdp"],
             "世界银行 2022", "正向"),
            ("GFCI金融中心排名(数字越小越好)", data["finance"]["gfci_rank"],
             "Z/Yen 2024", "负向"),
        ]),
        ("7. 储备货币", [
            ("全球外汇储备货币占比(%)", data["reserve_currency"]["reserve_share"],
             "IMF COFER 2024Q1", "正向"),
        ]),
        ("8. 内部冲突", [
            ("基尼系数(越低越平等)", data["internal_conflict"]["gini"],
             "世界银行 2021", "负向"),
            ("政治极化指数(0-100)", data["internal_conflict"]["polarization"],
             "静态参考 2023", "负向"),
        ]),
    ]

    for section_title, sub_indicators in indicator_details:
        ws.cell(row=row, column=1, value=section_title).font = Font(
            name="微软雅黑", size=11, bold=True, color="1F4E79")
        row += 1
        headers = ["子指标"] + COUNTRIES + ["数据来源", "方向"]
        for col, h in enumerate(headers, 1):
            ws.cell(row=row, column=col, value=h)
        style_header(ws, row, len(headers))
        row += 1
        for sub_name, values, source, direction in sub_indicators:
            ws.cell(row=row, column=1, value=sub_name).font = NORMAL_FONT
            ws.cell(row=row, column=1).border = BORDER
            for ci, c in enumerate(COUNTRIES, 2):
                cell = ws.cell(row=row, column=ci, value=values.get(c, "N/A"))
                cell.font = NORMAL_FONT
                cell.border = BORDER
                cell.alignment = CENTER
            ws.cell(row=row, column=len(COUNTRIES) + 2, value=source).font = Font(
                name="微软雅黑", size=9)
            ws.cell(row=row, column=len(COUNTRIES) + 2).border = BORDER
            ws.cell(row=row, column=len(COUNTRIES) + 3, value=direction).font = Font(
                name="微软雅黑", size=9)
            ws.cell(row=row, column=len(COUNTRIES) + 3).border = BORDER
            ws.cell(row=row, column=len(COUNTRIES) + 3).alignment = CENTER
            row += 1
        row += 1  # 空行分隔

    auto_width(ws, mx=32)
    return ws


def build_trend_sheet(wb, scores):
    """Sheet3: 趋势与判断 — 基于指标的大周期定位分析。"""
    ws = wb.create_sheet("趋势与判断")

    ws.merge_cells("A1:D1")
    ws["A1"] = "世界秩序大周期定位分析"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 28

    us_score = scores["综合得分"]["美国"]
    cn_score = scores["综合得分"]["中国"]
    gap = us_score - cn_score

    # 各指标领先情况
    us_leads = sum(1 for ind in scores if ind != "综合得分"
                   and scores[ind]["美国"] > scores[ind]["中国"])
    cn_leads = sum(1 for ind in scores if ind != "综合得分"
                   and scores[ind]["中国"] > scores[ind]["美国"])

    analysis = [
        ("一、综合实力对比", [
            f"美国综合得分: {us_score} 分",
            f"中国综合得分: {cn_score} 分",
            f"美中差距: {gap:.1f} 分（美国领先）" if gap > 0
            else f"美中差距: {abs(gap):.1f} 分（中国领先）",
            f"美国领先指标数: {us_leads}/8",
            f"中国领先指标数: {cn_leads}/8",
        ]),
        ("二、大周期定位判断", [
            "【美国】处于世界秩序周期的'后期阶段'：",
            "  - 储备货币和金融中心仍占绝对优势（帝国余晖）",
            "  - 内部冲突指标恶化（基尼系数高、政治极化严重）",
            "  - 制造业和贸易份额持续下滑",
            "  - 创新和教育仍保持领先但优势缩小",
            "",
            "【中国】处于世界秩序周期的'上升阶段'：",
            "  - 经济产出、制造业、贸易已达全球领先",
            "  - 创新能力快速追赶（专利申请量全球第一）",
            "  - 军事和金融中心实力持续增强",
            "  - 储备货币国际化仍处于初期（人民币占比仅2.4%）",
            "  - 内部冲突相对可控（基尼和极化低于美国）",
        ]),
        ("三、达里奥框架关键观察", [
            "1. 教育差距：中国PISA分数显著领先，但高等教育入学率仍低于美国",
            "2. 创新转换：中国专利数量领先，但研发/GDP强度仍低于美国",
            "3. 金融霸权：美国在储备货币和金融中心的优势是其'帝国特权'核心",
            "4. 内部矛盾：美国政治极化和贫富差距是其衰落的内部驱动力",
            "5. 军事平衡：美国军费仍占全球37%，但中国占比持续上升",
            "6. 过渡风险：历史上霸权转移期（如1900-1945）往往伴随冲突",
        ]),
        ("四、监控建议", [
            "• 持续关注人民币在全球外汇储备中的占比变化（当前2.4%）",
            "• 关注美国国内政治极化指数变化趋势",
            "• 监控中美研发支出/GDP差距收敛速度",
            "• 关注GFCI排名中亚洲金融中心的上升趋势",
            "• 跟踪SIPRI军费数据中的中美军费差距变化",
        ]),
        ("五、数据局限性说明", [
            "• 部分指标使用静态参考数据（已标注来源和年份）",
            "• 评分为五国相对排名，非绝对水平",
            "• 欧盟作为整体计算，内部各国差异较大",
            "• 内部冲突指标的量化存在主观性",
            "• 建议结合达里奥原著《原则：应对变化中的世界秩序》阅读",
        ]),
    ]

    row = 3
    for section, lines in analysis:
        ws.cell(row=row, column=1, value=section).font = Font(
            name="微软雅黑", size=11, bold=True, color="1F4E79")
        row += 1
        for line in lines:
            cell = ws.cell(row=row, column=1, value=line)
            cell.font = NORMAL_FONT if not line.startswith("【") else Font(
                name="微软雅黑", size=10, bold=True)
            cell.alignment = Alignment(horizontal="left", vertical="center",
                                       wrap_text=True)
            ws.merge_cells(start_row=row, start_column=1,
                           end_row=row, end_column=6)
            row += 1
        row += 1

    ws.column_dimensions["A"].width = 80
    return ws


def build_reserve_sheet(wb):
    """Sheet: 储备货币详情 — SWIFT支付 + IMF COFER储备对比表。"""
    ws = wb.create_sheet("储备货币详情")

    ws.merge_cells("A1:E1")
    ws["A1"] = "全球储备货币与支付货币格局 — SWIFT + IMF COFER"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = CENTER
    ws.row_dimensions[1].height = 28

    row = 3
    # --- SWIFT支付货币 ---
    ws.cell(row=row, column=1,
            value="一、SWIFT全球支付货币占比（按金额）").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    ws.cell(row=row, column=1,
            value=f"来源: {SWIFT_PAYMENT_SHARE['source']} | "
                  f"时间: {SWIFT_PAYMENT_SHARE['year']}").font = Font(
        name="微软雅黑", size=9, italic=True, color="666666")
    row += 1

    headers = ["货币", "SWIFT支付占比(%)", "排名", "说明"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, len(headers))
    row += 1

    swift = SWIFT_PAYMENT_SHARE["currencies"]
    swift_sorted = sorted(swift.items(), key=lambda x: x[1], reverse=True)
    for rank, (cur, pct) in enumerate(swift_sorted, 1):
        ws.cell(row=row, column=1, value=cur).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=pct).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=rank).font = NORMAL_FONT
        note = {"美元": "全球贸易结算主导货币",
                "欧元": "欧元区内部贸易+能源结算",
                "人民币": "人民币国际化SDR货币",
                "英镑": "伦敦金融中心",
                "日元": "日本贸易+套利交易"}.get(cur, "")
        ws.cell(row=row, column=4, value=note).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 5):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1

    # --- IMF COFER储备货币 ---
    row += 1
    ws.cell(row=row, column=1,
            value="二、IMF COFER 官方外汇储备货币构成").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1
    ws.cell(row=row, column=1,
            value=f"来源: {COFER_RESERVE_SHARE['source']} | "
                  f"时间: {COFER_RESERVE_SHARE['year']}").font = Font(
        name="微软雅黑", size=9, italic=True, color="666666")
    row += 1

    for col, h in enumerate(["货币", "外汇储备占比(%)", "排名", "趋势"], 1):
        ws.cell(row=row, column=col, value=h)
    style_header(ws, row, 4)
    row += 1

    cofer = COFER_RESERVE_SHARE["currencies"]
    cofer_sorted = sorted(cofer.items(), key=lambda x: x[1], reverse=True)
    trends = {
        "美元": "长期下行(2000年约70%)",
        "欧元": "稳定在20%左右",
        "人民币": "持续上升(2016年入SDR)",
        "日元": "日本低利率导致减持",
        "英镑": "脱欧后份额下降"
    }
    for rank, (cur, pct) in enumerate(cofer_sorted, 1):
        ws.cell(row=row, column=1, value=cur).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=pct).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=rank).font = NORMAL_FONT
        ws.cell(row=row, column=4, value=trends.get(cur, "")).font = Font(
            name="微软雅黑", size=9)
        for c in range(1, 5):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1

    # --- SWIFT vs COFER 对比柱状图 ---
    row += 1
    ws.cell(row=row, column=1,
            value="三、SWIFT支付 vs COFER储备 对比（前5大货币）").font = Font(
        name="微软雅黑", size=11, bold=True, color="1F4E79")
    row += 1

    # 写对比表
    compare_curs = ["美元", "欧元", "英镑", "人民币", "日元"]
    ws.cell(row=row, column=1, value="货币")
    ws.cell(row=row, column=2, value="SWIFT支付(%)")
    ws.cell(row=row, column=3, value="COFER储备(%)")
    style_header(ws, row, 3)
    chart_start = row + 1
    row += 1
    for cur in compare_curs:
        ws.cell(row=row, column=1, value=cur).font = NORMAL_FONT
        ws.cell(row=row, column=2, value=swift.get(cur, 0)).font = NORMAL_FONT
        ws.cell(row=row, column=3, value=cofer.get(cur, 0)).font = NORMAL_FONT
        for c in range(1, 4):
            ws.cell(row=row, column=c).border = BORDER
            ws.cell(row=row, column=c).alignment = CENTER
        row += 1
    chart_end = row - 1

    # 柱状图对比
    bar = BarChart()
    bar.type = "col"
    bar.style = 10
    bar.title = "SWIFT支付占比 vs COFER储备占比 (%)"
    bar.y_axis.title = "占比 (%)"
    bar.width = 18
    bar.height = 11
    data_ref = Reference(ws, min_col=2, min_row=chart_start - 1,
                         max_row=chart_end, max_col=3)
    bar.add_data(data_ref, titles_from_data=True)
    cats_ref = Reference(ws, min_col=1, min_row=chart_start, max_row=chart_end)
    bar.set_categories(cats_ref)
    ws.add_chart(bar, "F3")

    auto_width(ws, mx=35)
    return ws


# ============================================================================
# 主函数
# ============================================================================
def main():
    print("=" * 70)
    print(" 达里奥世界秩序八指标追踪器 — 开始运行")
    print("=" * 70)

    # 1. 获取数据（实时API + 静态降级）
    data = fetch_live_data()

    # 2. 计算评分
    scores, raw_display = compute_all_scores(data)

    # 3. 生成 Excel
    print("[3/3] 生成 Excel 报告...")
    wb = Workbook()
    build_overview_sheet(wb, scores, raw_display)
    build_detail_sheet(wb, data)
    build_trend_sheet(wb, scores)
    build_reserve_sheet(wb)

    # 4. 保存
    out = os.path.join(os.getcwd(),
                       f"dalio_world_order_tracker_{datetime.datetime.now():%Y%m%d}.xlsx")
    try:
        wb.save(out)
    except PermissionError:
        out = out.replace(".xlsx", "_v2.xlsx")
        wb.save(out)

    print(f"\n{'=' * 70}")
    print(f" 报告已生成: {out}")
    print(f"{'=' * 70}")
    print(f"\n 美国综合得分: {scores['综合得分']['美国']}")
    print(f" 中国综合得分: {scores['综合得分']['中国']}")
    print(f" 美中差距: {scores['综合得分']['美国'] - scores['综合得分']['中国']:.1f} 分")


if __name__ == "__main__":
    main()
