---
name: "poor-charlies-almanack-skill"
display_name: "穷查理宝典 · 思维与决策"
description: "从《穷查理宝典》提炼的 12 个思维与决策子技能，涵盖逆向思考、多元思维模型、能力圈、激励分析和误判心理学；完整保留索引、案例、测试与审计资料。"
version: "1.0.0"
author: "袋鼠帝 kangarooking"
tags: ["芒格","思维模型","决策方法","认知偏差"]
category: "学习与研究"
---

# 穷查理宝典 · 思维与决策

本文件为 Skill Cabinet 添加的技能集导航入口。上游 12 个子技能与资料均保留原目录结构和原始内容。

## 适用任务

从《穷查理宝典》提炼的 12 个思维与决策子技能，涵盖逆向思考、多元思维模型、能力圈、激励分析和误判心理学；完整保留索引、案例、测试与审计资料。

## 使用步骤

1. 先读取 [INDEX.md](INDEX.md)，了解子技能的触发条件、依赖和组合关系。
2. 根据用户的具体问题，选择相关模块并读取对应的 SKILL.md；需要上下文时读取 [BOOK_OVERVIEW.md](BOOK_OVERVIEW.md)。
3. 按模块中的执行步骤处理问题，遵守它的适用边界，必要时通过索引组合其他模块。
4. 各模块的 test-prompts.json 是上游测试用例；导入不代表已执行这些测试或验证模型回答效果。

## 子技能索引

- [检查清单决策](checklist-decision/SKILL.md)
- [能力圈判断 (Circle of Competence)](circle-of-competence/SKILL.md)
- [达尔文极端客观性方法](darwinian-objectivity/SKILL.md)
- [被剥夺超级反应倾向防范](deprival-superreaction/SKILL.md)
- [双轨分析 (Dual-Track Analysis)](dual-track-analysis/SKILL.md)
- [激励机制分析](incentive-analysis/SKILL.md)
- [逆向思维 (Inversion)](inversion-thinking/SKILL.md)
- [多元思维模型框架 (Latticework of Mental Models)](latticework-mental-models/SKILL.md)
- [Lollapalooza 效应识别](lollapalooza-effect/SKILL.md)
- [误判心理学检查清单](misjudgment-psychology-checklist/SKILL.md)
- [规模优势/劣势分析](scale-advantage-analysis/SKILL.md)
- [价值评估原则](value-assessment/SKILL.md)

## 来源与文件完整性

上游来源：[kangarooking/poor-charlies-almanack-skill](https://github.com/kangarooking/poor-charlies-almanack-skill/tree/d477e516920995b6e54d66c7441f17048188303a)。本入口不改写原有子技能。LICENSE、README、INDEX、原始候选、验证记录及其余跟踪文件均随包保存。收藏入口版本为 1.0.0；上游未声明发布版本。
