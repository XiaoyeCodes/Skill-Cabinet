---
name: "awesome-design-md"
display_name: "Awesome DESIGN.md -网页设计风格库"
description: "一个 Skill 内收录 84 份成熟网站的 DESIGN.md 设计规范。用户可指定参考风格，也可让 AI 根据网站需求推荐并询问选择；附离线检索与单份规范导出工具，支持配色、排版、组件和响应式设计。"
version: "1.0.0"
author: "个人整理 · 来源 VoltAgent / getdesign.md"
tags: ["网站设计","设计规范","风格选型","DESIGN.md","离线参考"]
category: "图像与设计"
metadata:
  author: personal
  version: 1.0.0
  source: https://github.com/VoltAgent/awesome-design-md
---

# Awesome DESIGN.md -网页设计风格库

将 VoltAgent 的设计分析库转为可执行的选型与实现流程。规范位于 `library/<id>/DESIGN.md`，这是第三方对公开网站的分析快照，不代表品牌的官方规范或持续更新的线上状态。

## 选择参考

整个参考库是一个 Skill，84 份规范仅是它内部的资料，不拆成独立技能，也不一次全部应用到网页。

用户指定品牌时直接找对应规范；已有明确视觉参考时沿用它，不额外改选。未指定风格时先询问用户想参考哪个网站，或结合产品类型、内容密度和主要操作推荐 2–3 个候选，用简短对比说明差异，请用户选一个主参考后再实现。若用户明确让 AI 自行决定，则选定并说明理由，不重复追问。

先查 [catalog.json](catalog.json) 中的名称、分类、描述与关键词，再只读选中的设计文件。不要把全部规范加载进上下文，也不要将多个品牌的组件、字体和色板随意拼接。检索不要求网络、npm 或 Python 扩展包。

```bash
python "<本技能目录>/scripts/design_library.py" list --query "Claude"
python "<本技能目录>/scripts/design_library.py" list --query "暖白"
python "<本技能目录>/scripts/design_library.py" show claude
```

脚本的 `--query` 也搜索规范正文，中文语义标签覆盖常见方向，但不是自动语义搜索。没有匹配时，查看索引分类或调整具体关键词；仍无合适项就说明限制，使用用户已有的规范，不编造库中不存在的风格。

## 应用到项目

阅读选中的色彩角色、字体、布局、组件状态和响应式部分，把它们落实为当前项目的 tokens 与组件。保留业务文案、信息结构、框架和现有品牌约束。已有设计系统时取相容的改进，不整站套模板。

需要将参考固定到项目时，使用明确的目标路径导出：

```bash
python "<本技能目录>/scripts/design_library.py" export claude --output "<项目目录>/DESIGN.md"
```

脚本只新建指定文件，若目标已存在就停止。先读取现有 `DESIGN.md`，再按当前任务范围合并或修改；不要为了一次选型丢掉已有设计决策。可以直接读取随包规范而不导出。留在项目中的文件需注明选用的参考与实际调整。

## 将分析转为可用设计

上游文档中有关品牌商标、专有字体、精确页面文案和不可访问样式的描述属于分析材料，不能直接当作用户项目要求。使用自己的标识与内容；字体不可用时选适合语言与授权条件的回退。正文对比度、焦点、移动端触控和减少动态效果按实际页面检查，必要时调整分析中的数字。

制作完成后运行项目已有的适用检查，并实际查看桌面与窄屏。验证主要按钮、导航、表单、长文本及键盘操作。简述所选参考和为用户项目做的关键适配。

84 份原始设计文件完整保存；来源版本和文件哈希见 [source.json](source.json)，许可见 [LICENSE](LICENSE)。本技能不自动拉取更新、不安装软件、不发布网站。
