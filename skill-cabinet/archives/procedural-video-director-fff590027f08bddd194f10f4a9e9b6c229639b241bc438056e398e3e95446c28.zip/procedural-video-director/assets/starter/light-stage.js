/* Reusable analytical light field. Noise/HDR approach: dario-genesis (MIT). */
class LightStage{
 constructor(w,h){
  this.canvas=document.createElement('canvas');this.canvas.width=w;this.canvas.height=h;this.w=w;this.h=h;
  const g=this.g=this.canvas.getContext('webgl2',{alpha:false,preserveDrawingBuffer:true,antialias:false});if(!g)throw Error('WebGL2 unavailable');
  if(!g.getExtension('EXT_color_buffer_float')||!g.getExtension('EXT_float_blend'))throw Error('Float HDR/blending unavailable');g.getExtension('OES_texture_float_linear');
  const ext=g.getExtension('WEBGL_debug_renderer_info');this.renderer=ext?g.getParameter(ext.UNMASKED_RENDERER_WEBGL):'WebGL2';
  const vs=`#version 300 es\nin vec2 p;out vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0,1);}`;
  const common=`#version 300 es\nprecision highp float;in vec2 uv;out vec4 c;`;
  const program=fs=>{const p=g.createProgram();for(const [type,src]of [[g.VERTEX_SHADER,vs],[g.FRAGMENT_SHADER,fs]]){const s=g.createShader(type);g.shaderSource(s,src);g.compileShader(s);if(!g.getShaderParameter(s,g.COMPILE_STATUS))throw Error(g.getShaderInfoLog(s));g.attachShader(p,s);}g.linkProgram(p);if(!g.getProgramParameter(p,g.LINK_STATUS))throw Error(g.getProgramInfoLog(p));return p;};
  this.scene=program(common+`uniform vec2 res;uniform float t;uniform float strength;
   float hash(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
   float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
   void main(){vec2 p=(gl_FragCoord.xy-.5*res)/res.y;float r=length(p);float warp=noise(p*9.+t*.15);float wave=sin(r*77.-t*2.4+warp*1.1);float rings=pow(max(0.,wave),18.)*exp(-r*4.);float core=exp(-r*r/0.0028);vec3 col=vec3(.002,.004,.009)+vec3(1.,.68,.30)*(rings*.7+core*3.2)*strength;col+=vec3(.05,.12,.22)*exp(-r*3.);c=vec4(col,1.);}`);
  this.bright=program(common+`uniform sampler2D image;void main(){c=vec4(max(texture(image,uv).rgb-.55,0.),1.);}`);
  this.blur=program(common+`uniform sampler2D image;uniform vec2 dir;void main(){vec3 v=texture(image,uv).rgb*.227027;v+=texture(image,uv+dir*1.384615).rgb*.316216;v+=texture(image,uv-dir*1.384615).rgb*.316216;v+=texture(image,uv+dir*3.230769).rgb*.070270;v+=texture(image,uv-dir*3.230769).rgb*.070270;c=vec4(v,1.);}`);
  this.final=program(common+`uniform sampler2D image;uniform sampler2D glow;void main(){vec3 x=texture(image,uv).rgb+texture(glow,uv).rgb*.45;x=clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);c=vec4(pow(x,vec3(1./2.2)),1.);}`);
  const vao=g.createVertexArray();g.bindVertexArray(vao);const b=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,b);g.bufferData(g.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),g.STATIC_DRAW);
  for(const p of [this.scene,this.bright,this.blur,this.final]){g.useProgram(p);let a=g.getAttribLocation(p,'p');g.enableVertexAttribArray(a);g.vertexAttribPointer(a,2,g.FLOAT,false,0,0);}
  const target=(x,y)=>{let t=g.createTexture();g.bindTexture(g.TEXTURE_2D,t);g.texImage2D(g.TEXTURE_2D,0,g.RGBA16F,x,y,0,g.RGBA,g.HALF_FLOAT,null);for(const k of [g.TEXTURE_MIN_FILTER,g.TEXTURE_MAG_FILTER])g.texParameteri(g.TEXTURE_2D,k,g.LINEAR);for(const k of [g.TEXTURE_WRAP_S,g.TEXTURE_WRAP_T])g.texParameteri(g.TEXTURE_2D,k,g.CLAMP_TO_EDGE);let f=g.createFramebuffer();g.bindFramebuffer(g.FRAMEBUFFER,f);g.framebufferTexture2D(g.FRAMEBUFFER,g.COLOR_ATTACHMENT0,g.TEXTURE_2D,t,0);if(g.checkFramebufferStatus(g.FRAMEBUFFER)!==g.FRAMEBUFFER_COMPLETE)throw Error('Incomplete HDR framebuffer');return{t,f,w:x,h:y};};
  this.main=target(w,h);this.qw=Math.max(2,Math.ceil(w/4));this.qh=Math.max(2,Math.ceil(h/4));this.a=target(this.qw,this.qh);this.b=target(this.qw,this.qh);
 }
 draw(time,samples=1,strength=1,dt=1/30,shutter=.5){
  const g=this.g,loc=(p,n)=>g.getUniformLocation(p,n),quad=()=>g.drawArrays(g.TRIANGLES,0,3);
  const pass=(p,d)=>{g.useProgram(p);g.bindFramebuffer(g.FRAMEBUFFER,d?d.f:null);g.viewport(0,0,d?d.w:this.w,d?d.h:this.h);};
  const bind=(p,name,slot,t)=>{g.activeTexture(g.TEXTURE0+slot);g.bindTexture(g.TEXTURE_2D,t);g.uniform1i(loc(p,name),slot);};
  pass(this.scene,this.main);g.disable(g.BLEND);g.clearColor(0,0,0,0);g.clear(g.COLOR_BUFFER_BIT);g.enable(g.BLEND);g.blendFunc(g.CONSTANT_ALPHA,g.ONE);g.blendColor(0,0,0,1/samples);g.uniform2f(loc(this.scene,'res'),this.w,this.h);g.uniform1f(loc(this.scene,'strength'),strength);
  for(let i=0;i<samples;i++){g.uniform1f(loc(this.scene,'t'),time+((i+.5)/samples-.5)*dt*shutter);quad();}g.disable(g.BLEND);
  pass(this.bright,this.a);bind(this.bright,'image',0,this.main.t);quad();pass(this.blur,this.b);bind(this.blur,'image',0,this.a.t);g.uniform2f(loc(this.blur,'dir'),1/this.qw,0);quad();pass(this.blur,this.a);bind(this.blur,'image',0,this.b.t);g.uniform2f(loc(this.blur,'dir'),0,1/this.qh);quad();pass(this.final,null);bind(this.final,'image',0,this.main.t);bind(this.final,'glow',1,this.a.t);quad();
 }
}
