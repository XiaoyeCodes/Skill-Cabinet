/* Runnable primitive demonstration, not a completed story. Replace scene design. */
(async()=>{
  const cfg=await(await fetch('film.json')).json();
  const fps=typeof cfg.fps==='string'&&cfg.fps.includes('/')?cfg.fps.split('/').map(Number).reduce((a,b)=>a/b):+cfg.fps;
  const W=cfg.width,H=cfg.height,C=document.querySelector('#film');C.width=W;C.height=H;
  const F=C.getContext('2d',{willReadFrequently:true}),S=Math.min(W,H);
  const clamp=x=>Math.min(1,Math.max(0,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x);};
  let light=null,lightError=null;
  if(cfg.scenes.some(s=>s.family==='light')){try{light=new LightStage(W,H);}catch(e){lightError=String(e);}}
  const paper=document.createElement('canvas');paper.width=W;paper.height=H;const P=paper.getContext('2d');
  let state=526;const rand=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
  P.fillStyle='#e9e2d2';P.fillRect(0,0,W,H);const pixels=P.getImageData(0,0,W,H);
  for(let i=0;i<pixels.data.length;i+=4){let n=(rand()-.5)*8;pixels.data[i]+=n;pixels.data[i+1]+=n;pixels.data[i+2]+=n;}P.putImageData(pixels,0,0);
  const font='"Noto Sans CJK SC","Microsoft YaHei","PingFang SC",sans-serif';
  function label(s,x,y,size,color,align='center'){F.fillStyle=color;F.font=`${size}px ${font}`;F.textAlign=align;F.textBaseline='middle';F.fillText(s,x,y);}
  function title(text,y,color){let chars=[...text],limit=Math.max(6,Math.floor(W*.79/(S*.065))),lines=[];while(chars.length)lines.push(chars.splice(0,limit).join(''));lines.slice(0,3).forEach((s,i)=>label(s,W/2,y+i*S*.085,S*.065,color));}
  function line(x1,y1,x2,y2,color,width=1){F.strokeStyle=color;F.lineWidth=width;F.beginPath();F.moveTo(x1,y1);F.lineTo(x2,y2);F.stroke();}
  function frame(index,samples=cfg.subframes||1){
    const t=index/fps,scene=cfg.scenes.find(s=>t>=s.start&&t<s.end)||cfg.scenes[cfg.scenes.length-1];
    const p=ease((t-scene.start)/(scene.end-scene.start)),dark=scene.family!=='paper';
    F.setTransform(1,0,0,1,0,0);F.globalAlpha=1;F.clearRect(0,0,W,H);
    if(scene.family==='light'){
      if(light){light.draw(t,samples,.3+.65*p,1/fps,cfg.shutter??.5);F.drawImage(light.canvas,0,0,W,H);}
      else{F.fillStyle='#080b10';F.fillRect(0,0,W,H);const g=F.createRadialGradient(W/2,H*.46,0,W/2,H*.46,S*.36);g.addColorStop(0,'#e8c88c');g.addColorStop(.2,'#916330');g.addColorStop(1,'#080b10');F.fillStyle=g;F.fillRect(0,0,W,H);}
    }else if(scene.family==='paper'){
      F.drawImage(paper,0,0);F.save();F.translate(W*.5,H*.47);F.rotate(-.025*(1-p));F.shadowColor='rgba(30,20,10,.20)';F.shadowBlur=S*.025;F.shadowOffsetY=S*.016;F.fillStyle='#f4eddd';F.fillRect(-W*.37,-H*.26,W*.74,H*.53);F.shadowColor='transparent';
      for(let k=0;k<4;k++)line(-W*.29,-H*.13+k*H*.08,-W*.29+W*.58*ease(p*2-k*.16),-H*.13+k*H*.08,'#71776d',S*.002);F.restore();
    }else{
      F.fillStyle='#0b1220';F.fillRect(0,0,W,H);
      const values=[.28,.53,.42,.77,.64],base=H*.66,barW=W*.09;
      values.forEach((v,k)=>{const x=W*.20+k*W*.13,h=H*.32*v*ease(p*2-k*.15);F.fillStyle=k===3?'#d0b27f':'#697f9c';F.fillRect(x,base-h,barW,h);});line(W*.16,base,W*.88,base,'#727c88',S*.002);
    }
    label(scene.label,W*.09,H*.11,S*.024,dark?'#baa783':'#6f6b5e','left');
    title(cfg.title,scene.family==='light'?H*.78:H*.83,dark?'#eee6d6':'#333a34');
    label('可编辑的管线示意',W/2,H*.94,S*.019,dark?'#959caa':'#7b7b6e');
  }
  await document.fonts.ready;frame(0);
  window.film={ready:true,width:W,height:H,fps,frames:Math.round(cfg.duration*fps),origin:'top-left',capture:'canvas2d',canvas:C,
    renderer:light?light.renderer:'Canvas2D',capabilities:{webgl2:!!light,hdr:!!light,bloom:!!light,fallbackReason:lightError},renderFrame:frame};
})().catch(e=>{console.error(e);throw e;});
