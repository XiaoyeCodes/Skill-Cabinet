"""Deterministic Canvas/WebGL capture over binary loopback HTTP."""
import argparse,asyncio,functools,json,os,shutil,subprocess,sys,tempfile,threading,time
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from common import browser_path,load_project,probe,require_tools,visual_hash,write_json

class Handler(SimpleHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args):pass
    def do_POST(self):
        if self.path!='/__frame':self.send_error(404);return
        s=self.server
        try:
            size=int(self.headers.get('Content-Length','0'));index=int(self.headers.get('X-Frame','-1'))
            if size!=s.frame_bytes or not s.first<=index<s.end:raise ValueError('Invalid frame dimensions or index')
            raw=self.rfile.read(size)
            if len(raw)!=size:raise ValueError('Incomplete frame body')
            with s.capture_lock:
                if index==s.next_frame:
                    count=s.encoder.stdin.write(raw)
                    if count!=size:raise RuntimeError('Short encoder write')
                    s.next_frame+=1
                    if (index-s.first)%60==0:print(f'{index-s.first+1}/{s.end-s.first} frames; {time.monotonic()-s.started:.1f}s',flush=True)
                elif index>s.next_frame:raise ValueError('Out of order frame')
        except Exception as e:
            s.failure=str(e)
            try:self.send_error(500,str(e))
            except OSError:pass
            return
        try:self.send_response(204);self.send_header('Content-Length','0');self.end_headers()
        except OSError:pass  # Capture succeeded; a retry receives the same ACK.

async def render(a):
    from PIL import Image,ImageDraw
    from playwright.async_api import async_playwright
    require_tools();root,cfg,fps,frames=load_project(a.project);out=root/'outputs';out.mkdir(exist_ok=True)
    samples=a.subframes if a.subframes is not None else int(cfg.get('subframes',1))
    if samples<1:raise ValueError('Positive subframe count required')
    start=a.start_frame;end=frames if a.end_frame is None else a.end_frame
    if not 0<=start<end<=frames:raise ValueError('Invalid source frame range')
    server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(root)))
    threading.Thread(target=server.serve_forever,daemon=True).start();encoder=None;errors=[];started=time.monotonic()
    try:
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(executable_path=browser_path(a.browser),headless=True,args=['--enable-gpu','--ignore-gpu-blocklist'])
            try:
                page=await browser.new_page(viewport={'width':cfg['width'],'height':cfg['height']})
                page.on('pageerror',lambda e:errors.append(str(e)))
                await page.goto(f'http://127.0.0.1:{server.server_port}/index.html')
                await page.wait_for_function('window.film && window.film.ready===true',timeout=120000)
                info=await page.evaluate('''()=>{const f=window.film;return {width:f.width,height:f.height,fps:f.fps,frames:f.frames,origin:f.origin,capture:f.capture,renderer:f.renderer,capabilities:f.capabilities||{}};}''')
                if errors:raise RuntimeError(errors)
                if (info['width'],info['height'],info['frames'])!=(cfg['width'],cfg['height'],frames) or abs(info['fps']-float(fps))>1e-5:raise ValueError('Page/config frame contract mismatch')
                if info['origin'] not in ('top-left','bottom-left') or info['capture'] not in ('canvas2d','webgl'):raise ValueError('Unsupported pixel protocol')
                if cfg.get('require_hdr') and not info['capabilities'].get('hdr') and not a.allow_degraded:raise RuntimeError('Requested HDR is unavailable: '+str(info['capabilities']))
                software='swiftshader' in info.get('renderer','').lower()
                if software and a.mode=='video' and not a.allow_software:raise RuntimeError('Software WebGL: benchmark stills/short range, then use --allow-software if appropriate')
                print(json.dumps(info,ensure_ascii=False),flush=True)
                capture='''async({index,samples})=>{const f=window.film;await f.renderFrame(index,samples);let raw;if(f.capture==='webgl'){raw=new Uint8Array(f.width*f.height*4);f.gl.readPixels(0,0,f.width,f.height,f.gl.RGBA,f.gl.UNSIGNED_BYTE,raw);}else raw=f.canvas.getContext('2d').getImageData(0,0,f.width,f.height).data;let s='';for(let k=0;k<raw.length;k+=32768)s+=String.fromCharCode.apply(null,raw.subarray(k,k+32768));return btoa(s);}'''
                if a.at:times=[float(x) for x in a.at.split(',')]
                else:times=[float(s['start'])+(float(s['end'])-float(s['start']))*.5 for s in cfg.get('scenes',[])][:12] or [float(cfg['duration'])*.5]
                if any(not 0<=t<float(cfg['duration']) for t in times):raise ValueError('Still time outside duration')
                import base64
                cw=480;ch=round(cw*cfg['height']/cfg['width']);cols=min(3,len(times));sheet=Image.new('RGB',(cw*cols,(ch+25)*((len(times)+cols-1)//cols)),'#171717');pen=ImageDraw.Draw(sheet)
                for k,t in enumerate(times):
                    index=min(frames-1,round(t*float(fps)));raw=base64.b64decode(await page.evaluate(capture,{'index':index,'samples':samples}))
                    if len(raw)!=cfg['width']*cfg['height']*4:raise ValueError('Invalid still payload')
                    image=Image.frombytes('RGBA',(cfg['width'],cfg['height']),raw)
                    if info['origin']=='bottom-left':image=image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                    image=image.convert('RGB');image.save(out/f'frame-{index:06d}.png');x=k%cols*cw;y=k//cols*(ch+25);sheet.paste(image.resize((cw,ch),Image.Resampling.LANCZOS),(x,y+25));pen.text((x+8,y+6),f'{index/float(fps):.3f}s / frame {index}',fill='white')
                sheet.save(out/'contact-sheet.jpg',quality=93)
                report={'mode':a.mode,'full_timeline':start==0 and end==frames,'first_frame':start,'end_frame_exclusive':end,'encoded_frames':0,'fps_expression':str(fps),'subframes':samples,'pixel_contract':info,'source_hash':visual_hash(root,cfg),'free_disk_bytes':shutil.disk_usage(out).free}
                if a.mode=='stills':write_json(out/'stills-report.json',report);return
                name='video-silent.mp4' if report['full_timeline'] else f'segment-{start}-{end}.mp4';temp=out/(name+'.partial.mp4')
                vf=['vflip'] if info['origin']=='bottom-left' else []
                vf.append('scale=out_color_matrix=bt709:out_range=tv')
                encoder=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgba','-s',f'{cfg["width"]}x{cfg["height"]}','-r',str(fps),'-i','-',
                   '-vf',','.join(vf),'-an','-c:v','libx264','-preset','fast','-crf',str(a.crf),'-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart',str(temp)],stdin=subprocess.PIPE)
                server.encoder=encoder;server.frame_bytes=cfg['width']*cfg['height']*4;server.first=start;server.end=end;server.next_frame=start;server.started=time.monotonic();server.capture_lock=threading.Lock();server.failure=None
                await page.evaluate('''async({start,end,samples})=>{const f=window.film;const raw=new Uint8Array(f.width*f.height*4);for(let i=start;i<end;i++){
                 await f.renderFrame(i,samples);let data;if(f.capture==='webgl'){f.gl.readPixels(0,0,f.width,f.height,f.gl.RGBA,f.gl.UNSIGNED_BYTE,raw);data=raw;}else data=f.canvas.getContext('2d').getImageData(0,0,f.width,f.height).data;
                 let response;for(let attempt=0;attempt<5;attempt++){try{response=await fetch('/__frame',{method:'POST',headers:{'X-Frame':String(i)},body:data});break;}catch(error){if(attempt===4)throw error;await new Promise(r=>setTimeout(r,150*(attempt+1)));}}if(!response.ok)throw Error('Frame capture failed at '+i);
                }}''',{'start':start,'end':end,'samples':samples})
                if errors or server.failure or server.next_frame!=end:raise RuntimeError([errors,server.failure,server.next_frame])
                encoder.stdin.close();code=encoder.wait(timeout=120);encoder=None
                if code:raise RuntimeError(f'Encoder failed: {code}')
                v=next(s for s in probe(temp)['streams'] if s['codec_type']=='video')
                if int(v.get('nb_frames',0))!=end-start:raise RuntimeError('Encoded frame count mismatch')
                temp.replace(out/name);report.update(encoded_frames=end-start,file=name,elapsed_seconds=time.monotonic()-started)
                write_json(out/('render-report.json' if report['full_timeline'] else f'segment-{start}-{end}-report.json'),report)
            finally:await browser.close()
    finally:
        if encoder is not None:
            if not encoder.stdin.closed:encoder.stdin.close()
            try:encoder.wait(timeout=15)
            except subprocess.TimeoutExpired:encoder.terminate();encoder.wait()
        server.shutdown();server.server_close()

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--mode',choices=['stills','video'],default='stills');p.add_argument('--browser');p.add_argument('--at');p.add_argument('--subframes',type=int);p.add_argument('--crf',type=int,default=18);p.add_argument('--start-frame',type=int,default=0);p.add_argument('--end-frame',type=int);p.add_argument('--allow-software',action='store_true');p.add_argument('--allow-degraded',action='store_true');a=p.parse_args()
    root=Path(a.project).expanduser().resolve();temp=root/'outputs'/'tmp';temp.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='capture-',dir=temp) as browser_tmp:
        os.environ['TEMP']=os.environ['TMP']=os.environ['TMPDIR']=browser_tmp
        asyncio.run(render(a))

if __name__=='__main__':main()
