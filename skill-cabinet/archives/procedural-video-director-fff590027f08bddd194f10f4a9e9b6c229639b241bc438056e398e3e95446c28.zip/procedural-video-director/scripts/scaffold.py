"""Copy a runnable plumbing example; scene design must be adapted per brief."""
import argparse,json,math,shutil,struct,sys,wave
from fractions import Fraction
from pathlib import Path
from common import write_json

SKILL=Path(__file__).resolve().parents[1]

def demo_audio(path,duration):
    path.parent.mkdir(parents=True,exist_ok=True);sr=48000
    with wave.open(str(path),'wb') as w:
        w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr)
        for start in range(0,round(duration*sr),4096):
            block=bytearray()
            for i in range(start,min(start+4096,round(duration*sr))):
                t=i/sr;y=0
                for at,f in [(.25,261.63),(duration*.38,329.63),(duration*.72,392.0)]:
                    d=t-at
                    if 0<=d<1.5:y+=.10*math.sin(2*math.pi*f*d)*math.exp(-d*4)*min(1,d/.01)*min(1,(1.5-d)/.1)
                s=round(max(-1,min(1,y))*32767);block.extend(struct.pack('<hh',s,s))
            w.writeframesraw(block)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True);p.add_argument('--topic',required=True)
    p.add_argument('--preset',choices=['light','paper','diagram'],default='diagram');p.add_argument('--duration',type=float,default=12)
    p.add_argument('--width',type=int,default=1920);p.add_argument('--height',type=int,default=1080);p.add_argument('--fps',default='30')
    p.add_argument('--demo-audio',action='store_true');p.add_argument('--silent',action='store_true');a=p.parse_args()
    if a.demo_audio and a.silent:p.error('Choose demo audio or intentional silence')
    if a.duration<=0 or not math.isfinite(a.duration) or min(a.width,a.height)<=0 or a.width%2 or a.height%2:p.error('Positive duration and even dimensions required')
    try:fps=Fraction(a.fps)
    except (ValueError,ZeroDivisionError):p.error('Invalid frame rate')
    if fps<=0 or round(a.duration*float(fps))<1:p.error('Positive fps and at least one output frame required')
    root=Path(a.output).expanduser().resolve()
    if root.exists() and any(root.iterdir()):raise FileExistsError('Refusing to overwrite a nonempty project')
    root.mkdir(parents=True,exist_ok=True)
    shutil.copytree(SKILL/'assets'/'starter',root,dirs_exist_ok=True)
    stages=[('s1','起因',0,a.duration/3),('s2','变化',a.duration/3,2*a.duration/3),('s3','结果',2*a.duration/3,a.duration)]
    layers=[]
    if a.demo_audio:
        demo_audio(root/'assets'/'demo-score.wav',a.duration)
        layers=[{'path':'assets/demo-score.wav','role':'music','start':0,'gain_db':0}]
    cfg={'title':a.topic,'width':a.width,'height':a.height,'fps':a.fps,'duration':a.duration,'subframes':3,'require_hdr':a.preset=='light',
         'scenes':[{'id':id,'label':label,'start':s,'end':e,'family':a.preset} for id,label,s,e in stages],
         'events':{'main.reveal':a.duration*.45},
         'captions':[{'start':a.duration*.1,'end':a.duration*.3,'text':a.topic,'style':'light' if a.preset=='paper' else 'dark'}],
         'audio':{'silent':a.silent,'target_lufs':-16,'peak_dbtp':-1.5,'layers':layers},
         'typography':{}}
    write_json(root/'film.json',cfg)
    (root/'BRIEF.md').write_text(f'# {a.topic}\n\n当前是可执行管线示意，尚未完成本题材的镜头创作。\n\n主材料：{a.preset}。目标画幅：{a.width}×{a.height}，{a.duration:g} 秒。\n\n正式制作前补充：观众与主张、事实来源或虚构定位、起始状态与可见后果、镜头接续、真实音轨与事件锚点。\n',encoding='utf-8')
    print(json.dumps({'project':str(root),'entry':'index.html','config':'film.json','status':'runnable plumbing example; adapt scenes before production'},ensure_ascii=False))

if __name__=='__main__':main()
