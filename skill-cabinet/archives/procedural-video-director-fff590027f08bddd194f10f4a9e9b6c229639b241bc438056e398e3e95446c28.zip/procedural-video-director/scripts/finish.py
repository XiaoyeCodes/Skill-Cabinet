"""Mix actual audio layers and export captioned/clean films independently of visuals."""
import argparse,json,math,os,subprocess,sys
from pathlib import Path
from common import delivery_hash,load_project,probe,require_tools,visual_hash,write_json

def run(args,**kw):return subprocess.run([str(x) for x in args],check=True,**kw)
def ass_time(t):
    n=round(t*100);return f'{n//360000}:{n//6000%60:02d}:{n//100%60:02d}.{n%100:02d}'
def srt_time(t):
    n=round(t*1000);return f'{n//3600000:02d}:{n//60000%60:02d}:{n//1000%60:02d},{n%1000:03d}'

def subtitles(out,cfg):
    w,h=cfg['width'],cfg['height'];typo=cfg.get('typography',{})
    default='Microsoft YaHei' if sys.platform=='win32' else 'PingFang SC' if sys.platform=='darwin' else 'Noto Sans CJK SC'
    font=typo.get('caption_font',default)
    if any(c in font for c in ',\r\n'):raise ValueError('Invalid ASS font family')
    size=int(typo.get('caption_size',min(h*.055,w*.075)));margin=int(typo.get('caption_margin',h*.065))
    if size<=0 or margin<0:raise ValueError('Invalid caption size/margin')
    head=f'''[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: dark,{font},{size},&H00E9EFEF,&H00E9EFEF,&H00100D09,&H00000000,0,0,0,0,100,100,0,0,1,{max(.8,h*.0018):.2f},0,2,{round(w*.06)},{round(w*.06)},{margin},1
Style: light,{font},{size},&H00303732,&H00303732,&H00D0DFE8,&H00000000,0,0,0,0,100,100,0,0,1,{max(.3,h*.0005):.2f},0,2,{round(w*.06)},{round(w*.06)},{margin},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    rows=[];srt=[]
    for i,c in enumerate(cfg.get('captions',[])):
        style=c.get('style','dark')
        if style not in ('dark','light'):raise ValueError('Caption style must be dark or light')
        raw=str(c['text']);text=raw.replace('\\','\\\\').replace('{','\\{').replace('}','\\}').replace('\n',r'\N')
        rows.append(f'Dialogue: 0,{ass_time(c["start"])},{ass_time(c["end"])},{style},,0,0,0,,{{\\fad(60,90)}}{text}')
        srt.append(f'{i+1}\n{srt_time(c["start"])} --> {srt_time(c["end"])}\n{raw}\n')
    (out/'subtitles.ass').write_text(head+'\n'.join(rows)+'\n',encoding='utf8');(out/'subtitles.srt').write_text('\n'.join(srt),encoding='utf8')

def mix_audio(root,out,cfg,duration):
    audio=cfg.get('audio',{});layers=audio.get('layers',[])
    if not layers:
        if audio.get('silent') is True:return None,{'intentional_silence':True}
        raise ValueError('No audio configured. Provide real layers, or explicitly set audio.silent=true for an intentional silent film.')
    if audio.get('silent'):raise ValueError('audio.silent conflicts with configured layers')
    command=['ffmpeg','-y','-v','error'];filters=[];groups={'narration':[],'bed':[]}
    for k,l in enumerate(layers):
        path=(root/l['path']).resolve()
        if not path.is_file():raise FileNotFoundError(f'Missing audio layer: {path}')
        info=probe(path)
        if not any(s['codec_type']=='audio' for s in info['streams']):raise ValueError(f'No audio stream: {path}')
        role=l.get('role','music');start=float(l.get('start',0));gain=float(l.get('gain_db',0));source_dur=float(info['format']['duration'])
        if role not in ('narration','music','sfx') or not math.isfinite(start+gain+source_dur) or start<0 or start>=duration:raise ValueError('Invalid audio layer role/start/gain')
        if role=='narration' and start+source_dur>duration+.025:raise ValueError(f'Narration overruns film: {path.name}. Revise text/timing or extend duration; do not cut speech.')
        command+=['-i',str(path)];label=f'a{k}'
        filt=f'[{k}:a:0]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,asetpts=PTS-STARTPTS,volume={gain:.6f}dB,adelay={round(start*48000)}S:all=1,apad=whole_dur={duration:.9f},atrim=duration={duration:.9f}'
        if role!='narration':filt+=f',afade=t=out:st={max(0,duration-min(1,duration/4)):.6f}:d={min(1,duration/4):.6f}'
        filters.append(filt+f'[{label}]');groups['narration' if role=='narration' else 'bed'].append(f'[{label}]')
    active={}
    for group,labels in groups.items():
        if not labels:continue
        filters.append(''.join(labels)+f'amix=inputs={len(labels)}:normalize=0[{group}]');active[group]=group
    if len(active)==2:
        filters.extend(['[narration]asplit=2[voice][control]','[bed][control]sidechaincompress=threshold=0.03:ratio=5:attack=20:release=250[duck]','[voice][duck]amix=inputs=2:normalize=0[mix]']);target='mix'
    else:target=next(iter(active))
    raw=out/'mix-raw.wav';run(command+['-filter_complex',';'.join(filters),'-map',f'[{target}]','-ar','48000','-c:a','pcm_f32le',str(raw)])
    integrated=float(audio.get('target_lufs',-16));peak=float(audio.get('peak_dbtp',-1.5));lra=float(audio.get('lra',11))
    if not -70<=integrated<=-5 or not -9<=peak<=0 or not 1<=lra<=50:raise ValueError('Invalid loudness target')
    first=run(['ffmpeg','-hide_banner','-nostats','-i',raw,'-af',f'loudnorm=I={integrated}:TP={peak}:LRA={lra}:print_format=json','-f','null','-'],capture_output=True,text=True,encoding='utf8')
    measured=json.loads(first.stderr[first.stderr.rfind('{'):])
    if not math.isfinite(float(measured['input_i'])):raise ValueError('Configured audio is silent or unmeasurable')
    filt=f"loudnorm=I={integrated}:TP={peak}:LRA={lra}:measured_I={measured['input_i']}:measured_TP={measured['input_tp']}:measured_LRA={measured['input_lra']}:measured_thresh={measured['input_thresh']}:offset={measured['target_offset']}:linear=true:print_format=json"
    master=out/'master.wav';result=run(['ffmpeg','-y','-hide_banner','-nostats','-i',raw,'-af',filt,'-ar','48000','-c:a','pcm_s24le',master],capture_output=True,text=True,encoding='utf8')
    report=json.loads(result.stderr[result.stderr.rfind('{'):]);report.update(target_lufs=integrated,target_peak_dbtp=peak,layers=layers,ducking=len(active)==2)
    return master,report

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf8')
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);a=p.parse_args();require_tools()
    root,cfg,fps,frames=load_project(a.project);out=root/'outputs';report=json.loads((out/'render-report.json').read_text(encoding='utf8'))
    if not report.get('full_timeline') or report.get('encoded_frames')!=frames or report.get('source_hash')!=visual_hash(root,cfg):raise ValueError('Missing/stale full visual render; rerender changed scenes/events before finishing')
    silent=out/'video-silent.mp4';info=probe(silent);v=next(s for s in info['streams'] if s['codec_type']=='video')
    if int(v.get('nb_frames',0))!=frames or (v['width'],v['height'])!=(cfg['width'],cfg['height']):raise ValueError('Visual file does not match render report')
    duration=frames/float(fps);subtitles(out,cfg);master,audio_report=mix_audio(root,out,cfg,duration)
    clean=out/'film-clean.mp4';cmd=['ffmpeg','-y','-v','error','-i',str(silent)]
    if master is not None:cmd+=['-i',str(master),'-map','0:v:0','-map','1:a:0','-c:a','aac','-b:a','256k']
    else:cmd+=['-map','0:v:0','-an']
    cmd+=['-c:v','copy','-t',f'{duration:.9f}','-metadata','title='+str(cfg.get('title','')),'-movflags','+faststart',str(clean)];run(cmd)
    final=out/'film.mp4'
    if cfg.get('captions'):
        run(['ffmpeg','-y','-v','error','-i',clean,'-vf','ass=outputs/subtitles.ass','-c:v','libx264','-preset','fast','-crf','17','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','copy','-movflags','+faststart',final],cwd=root)
    else:
        import shutil
        shutil.copyfile(clean,final)
    write_json(out/'audio-report.json',audio_report);write_json(out/'finish-report.json',{'source_hash':report['source_hash'],'delivery_hash':delivery_hash(root,cfg),'duration':duration,'frames':frames,'caption_blocks':len(cfg.get('captions',[])),'audio':master is not None,'files':['film.mp4','film-clean.mp4']})
    print(json.dumps({'final':str(final),'clean':str(clean),'audio':master is not None,'duration':duration},ensure_ascii=False))

if __name__=='__main__':main()
