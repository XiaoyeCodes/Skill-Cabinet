"""Inspect actual encodes, final audio metrics and representative decoded frames."""
import argparse,hashlib,json,math,subprocess,sys
from fractions import Fraction
from pathlib import Path
from common import delivery_hash,load_project,probe,require_tools,visual_hash,write_json

def main():
    from PIL import Image,ImageDraw
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf8')
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);a=p.parse_args();require_tools();root,cfg,fps,frames=load_project(a.project);out=root/'outputs';expected=frames/float(fps)
    render=json.loads((out/'render-report.json').read_text(encoding='utf8'));finish=json.loads((out/'finish-report.json').read_text(encoding='utf8'))
    if render['source_hash']!=visual_hash(root,cfg) or finish['source_hash']!=render['source_hash']:raise ValueError('Stale visual source or finish')
    if finish.get('delivery_hash')!=delivery_hash(root,cfg):raise ValueError('Stale audio/captions or visual export; finish again before inspection')
    expected_audio=bool(cfg.get('audio',{}).get('layers'));files=[]
    for name in ('film.mp4','film-clean.mp4'):
        path=out/name;data=probe(path);v=next(s for s in data['streams'] if s['codec_type']=='video');audios=[s for s in data['streams'] if s['codec_type']=='audio']
        if (v['width'],v['height'])!=(cfg['width'],cfg['height']) or int(v.get('nb_frames',0))!=frames or Fraction(v['avg_frame_rate'])!=fps:raise ValueError(f'{name}: dimensions, frame count or rate mismatch')
        if abs(float(data['format']['duration'])-expected)>max(.06,1/float(fps)):raise ValueError(f'{name}: duration mismatch')
        if bool(audios)!=expected_audio:raise ValueError(f'{name}: missing or unexpected audio')
        if audios and (int(audios[0]['sample_rate'])!=48000 or audios[0]['channels']!=2):raise ValueError('Audio format mismatch')
        with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest() if hasattr(hashlib,'file_digest') else hashlib.sha256(f.read()).hexdigest()
        files.append({'file':name,'bytes':path.stat().st_size,'sha256':digest,'frames':frames,'duration':data['format']['duration'],'audio':bool(audios)})
    command=['ffmpeg','-hide_banner','-nostats','-xerror','-i',str(out/'film.mp4')]
    if expected_audio:command+=['-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json']
    decoded=subprocess.run(command+['-f','null','-'],capture_output=True,text=True,encoding='utf8',check=True);audio=None
    if expected_audio:
        stats=json.loads(decoded.stderr[decoded.stderr.rfind('{'):]);audio={'integrated_lufs':float(stats['input_i']),'true_peak_dbtp':float(stats['input_tp'])}
        target=cfg['audio'].get('target_lufs',-16);peak=cfg['audio'].get('peak_dbtp',-1.5)
        if not math.isfinite(audio['integrated_lufs']) or abs(audio['integrated_lufs']-target)>1.5 or audio['true_peak_dbtp']>peak+.6:raise ValueError(f'Final AAC outside target tolerance: {audio}')
    moments=[0,max(0,expected-1/float(fps))]
    moments += [float(s['start'])+(float(s['end'])-float(s['start']))*.5 for s in cfg.get('scenes',[])]
    moments += [float(c['start'])+(float(c['end'])-float(c['start']))*.5 for c in cfg.get('captions',[])][:4]
    moments=sorted(set(min(expected-1/float(fps),max(0,t)) for t in moments))[:12]
    cw=400;ch=round(cw*cfg['height']/cfg['width']);cols=min(3,len(moments));sheet=Image.new('RGB',(cw*cols,(ch+25)*math.ceil(len(moments)/cols)),'#141414');pen=ImageDraw.Draw(sheet)
    for k,t in enumerate(moments):
        path=out/f'encoded-{k:02d}.png';subprocess.run(['ffmpeg','-y','-v','error','-ss',f'{t:.9f}','-i',str(out/'film.mp4'),'-frames:v','1',str(path)],check=True)
        with Image.open(path) as im:image=im.convert('RGB').resize((cw,ch),Image.Resampling.LANCZOS)
        x=k%cols*cw;y=k//cols*(ch+25);sheet.paste(image,(x,y+25));pen.text((x+8,y+6),f'{t:.3f}s',fill='white')
    sheet.save(out/'encoded-contact-sheet.jpg',quality=93)
    result={'files':files,'full_decode':'passed','audio':audio,'visual_capabilities':render['pixel_contract'].get('capabilities',{}),'sampled_frames':len(moments),'review_scope':'Technical stream/decode checks and sampled frames; inspect glyphs and aesthetics separately; no claim of human listening review.'}
    write_json(out/'quality-report.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
