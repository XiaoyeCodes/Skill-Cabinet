"""Shared project validation; no user-machine paths or account assumptions."""
import hashlib,json,math,os,shutil,subprocess,sys
from fractions import Fraction
from pathlib import Path

def load_project(path):
    root=Path(path).expanduser().resolve()
    cfg=json.loads((root/'film.json').read_text(encoding='utf-8'))
    for key in ('width','height'):
        if not isinstance(cfg.get(key),int) or cfg[key]<=0 or cfg[key]%2:raise ValueError(f'{key} must be a positive even integer')
    fps=Fraction(str(cfg['fps']));duration=float(cfg['duration'])
    if fps<=0 or not math.isfinite(duration) or duration<=0:raise ValueError('Positive finite duration/fps required')
    frames=round(duration*float(fps))
    if frames<1:raise ValueError('Duration must contain at least one frame')
    for scene in cfg.get('scenes',[]):
        if not 0<=float(scene['start'])<float(scene['end'])<=duration+.0001:raise ValueError('Invalid scene range')
    for c in cfg.get('captions',[]):
        if not 0<=float(c['start'])<float(c['end'])<=duration+.0001:raise ValueError('Invalid caption range')
    for value in cfg.get('events',{}).values():
        if not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=duration:raise ValueError('Events must contain finite in-range seconds')
    return root,cfg,fps,frames

def write_json(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)],encoding='utf-8'))

def browser_path(explicit=None):
    if explicit or os.environ.get('CHROME_PATH'):
        p=Path(explicit or os.environ['CHROME_PATH']).expanduser()
        if not p.is_file():raise FileNotFoundError(f'Browser does not exist: {p}')
        return str(p)
    names=['google-chrome','google-chrome-stable','chromium','chromium-browser','chrome','msedge']
    for name in names:
        found=shutil.which(name)
        if found:return found
    candidates=[]
    if sys.platform=='win32':
        for env in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
            base=os.environ.get(env)
            if base:candidates.extend([Path(base)/'Google/Chrome/Application/chrome.exe',Path(base)/'Microsoft/Edge/Application/msedge.exe'])
    elif sys.platform=='darwin':candidates=[Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),Path('/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge')]
    for p in candidates:
        if p.is_file():return str(p)
    return None  # Playwright's own browser, when installed.

def require_tools():
    missing=[name for name in ('ffmpeg','ffprobe') if not shutil.which(name)]
    if missing:raise RuntimeError('Missing tools on PATH: '+', '.join(missing))

def visual_hash(root,cfg):
    visual={k:v for k,v in cfg.items() if k not in ('audio','captions','typography')}
    h=hashlib.sha256(json.dumps(visual,sort_keys=True,ensure_ascii=False).encode('utf8'))
    files=sorted([*root.glob('*.html'),*root.glob('*.js')])
    files.extend(root/str(p) for p in cfg.get('visual_assets',[]))
    for p in files:
        h.update(str(p.relative_to(root)).encode('utf8'))
        with p.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def delivery_hash(root,cfg):
    h=hashlib.sha256(visual_hash(root,cfg).encode('ascii'))
    h.update(json.dumps({k:cfg.get(k) for k in ('audio','captions','typography')},sort_keys=True,ensure_ascii=False).encode('utf8'))
    for layer in cfg.get('audio',{}).get('layers',[]):
        path=(root/layer['path']).resolve();h.update(str(layer['path']).encode('utf8'))
        with path.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
