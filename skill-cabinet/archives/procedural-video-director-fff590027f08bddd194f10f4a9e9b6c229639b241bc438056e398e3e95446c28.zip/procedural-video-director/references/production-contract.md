# 可移植工程与执行接口

## 环境与起步

使用实际可用的 Python 3.11+、FFmpeg/FFprobe 与 Chrome/Edge/Chromium。Python 捕获/检查依赖 `playwright`、`pillow`；混音由 FFmpeg 完成。可在项目虚拟环境安装 `assets/starter/requirements.txt`，不硬编码作者电脑的盘符、Python 环境、字体或工作区。

浏览器顺序：命令参数 `--browser` → 环境变量 `CHROME_PATH` → 常见已安装浏览器/可执行文件 → Playwright 自带浏览器。缺项如实报出。先检查空闲磁盘、时长和复杂度；临时文件与输出放到有空间的项目目录。

```text
python SKILL/scripts/scaffold.py --output PROJECT --topic "解释能量守恒" --preset light --duration 60
python SKILL/scripts/render.py --project PROJECT --mode stills --at 1,10,22,40,58
python SKILL/scripts/render.py --project PROJECT --mode video
python SKILL/scripts/finish.py --project PROJECT
python SKILL/scripts/inspect_video.py --project PROJECT
```

初始化拒绝覆盖非空目录。脚手架可运行，但“起因—变化—结果”只是接线示意。应按分镜改写 `film.js` 和场景对象，不把 demo 作为成片。`--demo-audio` 仅为管线测试生成短音，不能冒充旁白或完成的声音设计。

## 目录和配置

```text
PROJECT/
  BRIEF.md
  film.json                 唯一配置：画幅、帧率、长度、场景、锚点、字幕、音轨
  index.html / film.js       可跳帧母版
  light-stage.js            可复用 HDR 光场示意，可替换
  assets/                   合法素材、字体或项目自己的分轨
  outputs/                  编码文件、ASS/SRT、联系表、报告
```

`film.json` 的核心字段：

```json
{
  "title": "片名",
  "width": 1920, "height": 1080, "fps": 30, "duration": 60,
  "subframes": 3,
  "scenes": [{"id":"s1","start":0,"end":12,"family":"diagram","label":"需要重新设计的叙事动作"}],
  "events": {"main.reveal":7.2},
  "captions": [{"start":1,"end":4,"text":"字幕正文","style":"dark"}],
  "typography": {"caption_font":"Microsoft YaHei"},
  "audio": {
    "silent":false, "target_lufs":-16, "peak_dbtp":-1.5,
    "layers":[{"path":"assets/narration.wav","role":"narration","start":0,"gain_db":0}]
  }
}
```

路径相对项目。场景 family 为 `light` / `paper` / `diagram` 是示意实现，生产中可增加新材质或改变渲染后端。字幕 `dark` 表示在暗背景上用浅字，`light` 表示浅背景用深字；跨底色转场可拆分字幕块或手工扩展 ASS。

帧率支持正数或 `"30000/1001"` 这样的有理数字符串。总帧数为 `round(duration × fps)`；实际视频长度按总帧数/帧率计算，不能假装任意十进制长度都恰好落在帧边界。YUV420 输出要求宽高为正偶数。

## 页面协议

页面准备完成后暴露 `window.film`：

```js
window.film = {
  ready: true,
  width, height, fps, frames,
  origin: 'top-left',
  capture: 'canvas2d',
  canvas: mainCanvas,
  renderer: '实际渲染器名称',
  capabilities: { webgl2: true, hdr: true, bloom: true },
  renderFrame: async (index, samples) => { /* 只根据帧号决定状态 */ }
};
```

直接 WebGL readPixels 的工程可用 `capture:'webgl'`、`origin:'bottom-left'` 并提供 `gl`。集成 WebGL 离屏光场再画到主 Canvas 的脚手架仍按主 Canvas 的 `top-left` 捕获，不再次翻转。

`render.py` 启动回环临时 HTTP 服务，逐帧传输原始 RGBA；Canvas 不翻转，底部起始的 WebGL 翻正。固定序号使丢失 ACK 后重试不会重复编码。样片范围可用 `--start-frame`、`--end-frame`，输出明确标记为 segment；它不能冒充全片。

## 输出与后端替换

- `render.py` → `outputs/video-silent.mp4`、`render-report.json`、关键帧。
- `finish.py` → `film-clean.mp4`、`film.mp4`、ASS/SRT、母带/混音报告。音轨必须实际存在；有意无声需配置 `audio.silent:true`。旁白超过片尾会报错。
- `inspect_video.py` → `quality-report.json`、最终编码联系表，检查真实文件而非只看计划。

视觉指纹覆盖画面配置、根目录 HTML/JS 和 `visual_assets` 显式列出的视觉素材；改变镜头或事件后需重渲。音轨、字幕和字幕字体在交付指纹中单独记录，因此只改字幕/混音可复用视觉渲染，但仍需重新 finish。更改额外的视觉素材或子目录模块时应列入 `visual_assets`，不能凭旧报告认定新画面已生成。

WebGL、Canvas、SVG/HTML、Three.js 或已有 Remotion 工程都可承担镜头；不要为了统一名字重写一个工作正常的后端。保持相同的权威时钟、事件和检查结果即可。示意脚手架不自动重排复杂真实素材，也不自动生成任意题材的高质量镜头。
