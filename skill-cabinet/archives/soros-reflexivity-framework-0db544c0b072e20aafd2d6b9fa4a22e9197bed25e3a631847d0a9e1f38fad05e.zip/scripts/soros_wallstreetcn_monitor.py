"""
索罗斯反身性框架 - 华尔街见闻事件监控器
==========================================
自动抓取华尔街见闻热门新闻，用索罗斯反身性框架判断事件重要性，
触发关键事件时记录并推送提醒。

触发逻辑基于索罗斯Skill中的核心观察维度：
- 货币危机与汇率异动（固定汇率制压力、央行干预能力耗尽）
- 央行政策转向（利率突变、QE/QT、资本管制）
- 泡沫破裂信号（股市暴跌、房地产泡沫、信贷危机）
- 主权债务危机（违约、评级下调、IMF救助）
- 金融机构风险（银行倒闭、对冲基金爆仓、流动性危机）
- 信贷周期拐点（信贷扩张/收缩、杠杆率变化）
- 资本流动逆转（外资撤离、外汇储备下降）
- 政治/地缘冲击（战争、制裁、政策不可持续）

索罗斯式高优先级事件特征：
1. 政策承诺与基本面严重背离（如固定汇率+高通胀+高赤字）
2. 央行/政府干预能力正在耗尽（外汇储备不足、政治意愿薄弱）
3. 反身性正反馈即将启动（预期→行动→现实改变→预期强化）
4. 市场处于"远离均衡且局面不稳定"状态

使用方法：
    python soros_wallstreetcn_monitor.py

输出：
    alerts/ 目录下生成事件提醒文件
    控制台打印触发的事件
"""

import datetime
import json
import os
import re
import sys
from pathlib import Path

import requests

# ============================================================
# 配置
# ============================================================

ALERTS_DIR = Path(__file__).parent.parent / "alerts"
ALERTS_DIR.mkdir(exist_ok=True)

HISTORY_FILE = ALERTS_DIR / "seen_articles.json"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

# ============================================================
# 索罗斯框架事件触发规则
# ============================================================

# 排除词：包含这些词的新闻不触发（日常市场动态、非核心事件）
EXCLUDE_KEYWORDS = [
    "早盘收盘", "午盘", "收盘综述", "日经", "韩国KOSPI", "澳洲联储", "新西兰",
    "加拿大央行", "期货早盘", "期货午盘", "A股收盘", "港股收盘", "欧股收盘",
    "美股收盘", "三大指数", "纳指", "标普500", "道指",
    "黑客", "失窃", "被盗", "攻击案", "发图", "梗图", "社交媒体",
    "英镑债", "欧元债", "发行债券", "聘请银行",
    "停办", "代理", "贵金属业务", "银行调整",
    "个股", "财报", "业绩预告", "分红", "回购",
    "IPO", "上市", "招股", "打新",
]

# 高优先级：立即触发提醒（索罗斯式"攻击弱者"信号）
HIGH_PRIORITY_RULES = {
    "货币危机/汇率异动": {
        "keywords": [
            "货币贬值", "汇率暴跌", "汇率崩盘", "固定汇率", "联系汇率",
            "央行干预", "外汇储备", "耗尽储备", "放弃汇率", "汇率机制",
            "货币危机", "本币暴跌", "资本管制", "外汇管制", "美元荒",
            "IMF救助", "紧急贷款", "汇率保卫战", "抛售外汇",
            "泰铢", "里拉", "比索", "卢比", "雷亚尔", "坚戈",
        ],
        "framework": "反身性 - 固定汇率制与基本面背离，央行干预能力耗尽",
        "impact": "索罗斯式战机：政策承诺不可持续→预期自我实现→货币危机→资本外逃→经济恶化的正反馈螺旋",
        "soros_action": "识别不可持续的汇率承诺，评估央行干预能力，等待催化剂后建立空头头寸"
    },
    "央行政策转向": {
        "keywords": [
            "美联储", "加息", "降息", "暂停加息", "缩表", "扩表", "QE", "QT",
            "点阵图", "FOMC", "鲍威尔", "耶伦",
            "欧央行", "拉加德", "日本央行", "植田和男", "英国央行", "贝利",
            "中国人民银行", "降准", "降息", "LPR", "MLF", "逆回购",
            "意外加息", "意外降息", "紧急会议", "政策转向", "鹰派", "鸽派",
        ],
        "framework": "反身性 - 政策预期与现实的双向反馈，政策转向是趋势催化剂",
        "impact": "央行政策是全球宏观最大变量，转向瞬间改变所有资产的定价锚，触发跨市场连锁反应",
        "soros_action": "判断政策承诺的可信度，识别政策不可持续的临界点，在转向前后建立立体头寸"
    },
    "泡沫破裂/市场崩盘": {
        "keywords": [
            "暴跌", "崩盘", "熔断", "闪崩", "踩踏", "股灾",
            "泡沫破裂", "泡沫破灭", "见顶", "顶部", "牛市结束",
            "千点暴跌", "暴跌超", "大跌", "重挫", "恐慌",
            "VIX飙升", "恐慌指数", "避险情绪", "风险偏好下降",
            "房地产泡沫", "房价暴跌", "楼市崩盘", "地产危机",
            "加密货币暴跌", "比特币暴跌", "币圈崩盘",
        ],
        "framework": "繁荣-萧条模型 - 阶段五（现实与观念决裂）→阶段六（反向自我推进）",
        "impact": "反身性负反馈启动：价格下跌→信心丧失→更多抛售→基本面恶化→价格进一步下跌的螺旋",
        "soros_action": "在泡沫膨胀期识别主流偏向，在临界点附近建立空头，在恐慌中获利"
    },
    "主权债务危机": {
        "keywords": [
            "债务违约", "主权违约", "债务重组", "债务上限", "美债违约",
            "评级下调", "主权评级", "信用评级", "降级", "垃圾级",
            "财政危机", "预算危机", "政府停摆", "财政赤字", "利息支出",
            "国债收益率飙升", "国债拍卖失败", "国债危机",
            "希腊债务", "欧债危机", "新兴市场债务", "美元债",
            "破产", "国家破产", "主权破产",
        ],
        "framework": "反身性 - 债务可持续性预期与融资成本的正反馈",
        "impact": "评级下调→融资成本上升→偿债压力增大→进一步降级的死亡螺旋，可能引发全球金融动荡",
        "soros_action": "识别债务不可持续的国家，做空其货币和债券，等待IMF介入或债务重组"
    },
    "金融机构风险": {
        "keywords": [
            "银行倒闭", "银行破产", "银行危机", "银行挤兑", "储户挤兑",
            "流动性危机", "爆仓", "强平", "追加保证金", "保证金追缴",
            "对冲基金亏损", "对冲基金爆仓", "基金清盘", "巨额亏损",
            "雷曼", "贝尔斯登", "硅谷银行", "瑞信", "德银",
            "系统性风险", "金融稳定", "救市", "救助", "注资",
            "影子银行", "非标", "理财", "信托违约",
        ],
        "framework": "反身性 - 金融机构健康预期与融资能力的双向反馈",
        "impact": "机构风险→融资成本上升→资产抛售→资产减值→进一步风险的传染链，可能触发系统性危机",
        "soros_action": "识别脆弱的金融机构，做空其股票/债券/CDS，利用恐慌情绪放大收益"
    },
    "信贷周期拐点": {
        "keywords": [
            "信贷收缩", "信贷紧缩", "信贷扩张", "社融", "信贷数据",
            "杠杆率", "去杠杆", "加杠杆", "债务杠杆",
            "坏账率", "不良贷款", "违约率", "信用利差", "利差走阔",
            "M2", "货币供应", "流动性", "资金面", "钱荒",
            "房贷", "居民杠杆", "企业债务", "地方债",
        ],
        "framework": "信贷与管制的反身性循环 - 信贷扩张→资产价格上涨→抵押品增值→更多信贷",
        "impact": "信贷周期是繁荣-萧条的底层驱动力，拐点处所有资产类别同时重新定价",
        "soros_action": "监控信贷脉冲方向，扩张末期做多风险资产，收缩初期做空"
    },
    "资本流动逆转": {
        "keywords": [
            "外资撤离", "资本外流", "资金外流", "热钱流出",
            "外资卖出", "北向资金", "南向资金", "外资流出",
            "外汇储备下降", "储备减少", "国际收支", "经常账户",
            "美元走强", "美元指数", "美联储加息周期", "美元流动性",
            "新兴市场", "EM危机", "前沿市场",
        ],
        "framework": "全球宏观 - 美元周期驱动的全球资本流动，新兴市场的原罪",
        "impact": "美元走强→资本从新兴市场回流美国→新兴市场货币贬值→资产价格下跌→进一步资本外流",
        "soros_action": "在美元走强周期中做空新兴市场货币和资产，选择基本面最脆弱的国家攻击"
    },
    "地缘政治冲击": {
        "keywords": [
            "战争", "开战", "军事打击", "空袭", "入侵", "冲突升级",
            "制裁", "全面制裁", "经济制裁", "金融制裁", "SWIFT",
            "关税", "贸易战", "贸易制裁", "出口管制", "实体清单",
            "政变", "政权更迭", "大选", "极右翼", "民粹",
            "脱欧", "公投", "独立公投", "分裂",
            "油价暴涨", "原油暴涨", "能源危机", "天然气",
            "红海", "霍尔木兹", "苏伊士", "航运危机",
            "特朗普", "普京", "泽连斯基", "内塔尼亚胡",
        ],
        "framework": "反身性 - 政治不确定性与市场风险偏好的双向反馈",
        "impact": "地缘冲击→风险偏好骤降→资本涌向避险资产→受冲击国家融资成本上升→经济恶化→政治更不稳定",
        "soros_action": "识别地缘冲击中的弱者（经济脆弱、外汇储备不足、依赖外资的国家），做空其资产"
    },
}

# 中优先级：汇总提醒
MEDIUM_PRIORITY_RULES = {
    "重要经济数据": {
        "keywords": ["CPI", "PPI", "非农", "失业率", "GDP", "PMI", "零售销售", "工业增加值", "通胀数据"],
        "framework": "宏观数据验证 - 数据可能改变政策预期和市场偏向",
    },
    "官员重要讲话": {
        "keywords": ["行长", "主席", "部长", "总理", "总统", "讲话", "证词", "表态", "记者会"],
        "framework": "政策预期管理 - 官员讲话可能是趋势催化剂",
    },
    "大宗商品异动": {
        "keywords": ["原油", "黄金", "铜", "铁矿石", "大豆", "玉米", "大宗商品", "商品暴涨", "商品暴跌"],
        "framework": "全球宏观 - 大宗商品是通胀和增长的先行指标",
    },
    "房地产动态": {
        "keywords": ["房价", "楼市", "房地产", "房贷", "首付", "限购", "房企", "地产政策"],
        "framework": "信贷周期 - 房地产是信贷周期的核心载体",
    },
}

# ============================================================
# 新闻抓取
# ============================================================

def fetch_wallstreetcn_news():
    """从华尔街见闻抓取热门新闻"""
    print("\n[1/3] 抓取华尔街见闻新闻...")

    articles = []

    # 华尔街见闻API端点（热门/最新新闻）
    endpoints = [
        "https://api-one-wscn.awtmt.com/apiv1/content/lives?channel=global-channel&limit=30",
        "https://api-one-wscn.awtmt.com/apiv1/content/articles?limit=20",
    ]

    for url in endpoints:
        try:
            resp = requests.get(url, timeout=15, headers=HEADERS)
            resp.raise_for_status()
            data = resp.json()

            items = data.get("data", {}).get("items", []) or data.get("data", {}).get("articles", [])
            for item in items:
                title = item.get("title", "") or item.get("content_text", "")[:100]
                if title and len(title) > 5:
                    articles.append({
                        "title": title.strip(),
                        "url": item.get("uri", ""),
                        "time": item.get("display_time", item.get("created_at", "")),
                        "source": "华尔街见闻"
                    })
        except Exception as e:
            print(f"  端点失败: {type(e).__name__}: {e}")
            continue

    # 去重
    seen = set()
    unique = []
    for a in articles:
        if a["title"] not in seen:
            seen.add(a["title"])
            unique.append(a)

    print(f"  ✓ 获取到 {len(unique)} 条新闻")
    return unique


def load_seen_articles():
    """加载已处理的文章记录"""
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                return set(json.load(f))
        except:
            return set()
    return set()


def save_seen_articles(seen):
    """保存已处理的文章记录"""
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(list(seen)[-500:], f, ensure_ascii=False)  # 只保留最近500条


# ============================================================
# 事件匹配（索罗斯反身性框架）
# ============================================================

def match_events(articles):
    """用索罗斯反身性框架匹配新闻事件"""
    print("\n[2/3] 用索罗斯反身性框架匹配事件...")

    seen = load_seen_articles()
    new_alerts = []

    for article in articles:
        title = article["title"]

        # 跳过已处理
        if title in seen:
            continue

        # 排除词检查：日常市场动态不触发
        if any(ex in title for ex in EXCLUDE_KEYWORDS):
            seen.add(title)
            continue

        # 高优先级匹配
        for event_name, rule in HIGH_PRIORITY_RULES.items():
            if any(kw in title for kw in rule["keywords"]):
                alert = {
                    "priority": "HIGH",
                    "event_type": event_name,
                    "title": title,
                    "framework": rule["framework"],
                    "impact": rule["impact"],
                    "soros_action": rule["soros_action"],
                    "url": article["url"],
                    "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "source": article["source"]
                }
                new_alerts.append(alert)
                print(f"  🔴 [高优先级] {event_name}: {title[:50]}...")
                break  # 一条新闻只触发一个高优先级事件

        # 中优先级匹配（仅当未触发高优先级时）
        else:
            for event_name, rule in MEDIUM_PRIORITY_RULES.items():
                if any(kw in title for kw in rule["keywords"]):
                    alert = {
                        "priority": "MEDIUM",
                        "event_type": event_name,
                        "title": title,
                        "framework": rule["framework"],
                        "impact": "",
                        "soros_action": "",
                        "url": article["url"],
                        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "source": article["source"]
                    }
                    new_alerts.append(alert)
                    print(f"  🟡 [中优先级] {event_name}: {title[:50]}...")
                    break

        seen.add(title)

    save_seen_articles(seen)

    high_count = sum(1 for a in new_alerts if a["priority"] == "HIGH")
    medium_count = sum(1 for a in new_alerts if a["priority"] == "MEDIUM")
    print(f"  ✓ 触发 {high_count} 个高优先级事件，{medium_count} 个中优先级事件")

    return new_alerts


# ============================================================
# 事件推送
# ============================================================

def push_alerts(alerts):
    """推送事件提醒"""
    print("\n[3/3] 生成事件提醒...")

    if not alerts:
        print("  无新事件触发")
        return

    high_alerts = [a for a in alerts if a["priority"] == "HIGH"]
    medium_alerts = [a for a in alerts if a["priority"] == "MEDIUM"]

    # 生成提醒文件
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    alert_file = ALERTS_DIR / f"alert_{timestamp}.md"

    content = f"""# 索罗斯反身性框架事件提醒
生成时间：{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 🔴 高优先级事件（{len(high_alerts)}条）

"""
    for i, alert in enumerate(high_alerts, 1):
        content += f"""### {i}. [{alert['event_type']}] {alert['title']}

- **反身性框架定位**：{alert['framework']}
- **影响分析**：{alert['impact']}
- **索罗斯式应对**：{alert['soros_action']}
- **来源**：{alert['source']}
- **时间**：{alert['time']}
- **链接**：{alert['url']}

"""

    if medium_alerts:
        content += f"""## 🟡 中优先级事件（{len(medium_alerts)}条）

"""
        for i, alert in enumerate(medium_alerts, 1):
            content += f"{i}. **[{alert['event_type']}]** {alert['title']}\n"

    content += f"""
---
*本提醒由索罗斯反身性框架事件监控器自动生成*
*触发规则基于 soros-reflexivity-framework Skill 的核心观察维度*
*高优先级事件特征：政策承诺与基本面背离 / 干预能力耗尽 / 反身性正反馈即将启动 / 远离均衡且局面不稳定*
"""

    with open(alert_file, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"  ✓ 提醒文件已生成：{alert_file}")

    # 同时追加到总日志
    log_file = ALERTS_DIR / "alert_log.md"
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"\n\n## {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 监控结果\n")
        f.write(f"高优先级：{len(high_alerts)}条，中优先级：{len(medium_alerts)}条\n")
        for alert in high_alerts:
            f.write(f"- 🔴 [{alert['event_type']}] {alert['title']}\n")
        for alert in medium_alerts:
            f.write(f"- 🟡 [{alert['event_type']}] {alert['title']}\n")

    # 控制台汇总
    print(f"\n{'='*60}")
    print(f"监控完成：触发 {len(high_alerts)} 个高优先级，{len(medium_alerts)} 个中优先级")
    if high_alerts:
        print(f"\n🔴 高优先级事件：")
        for alert in high_alerts:
            print(f"  - [{alert['event_type']}] {alert['title'][:60]}")
    print(f"{'='*60}")

    return alert_file


# ============================================================
# 主程序
# ============================================================

def main():
    print("=" * 60)
    print("索罗斯反身性框架 - 华尔街见闻事件监控器")
    print("=" * 60)
    print(f"启动时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # 1. 抓取新闻
    articles = fetch_wallstreetcn_news()

    if not articles:
        print("\n⚠ 未获取到新闻，可能是网络问题或API变更")
        return

    # 2. 匹配事件
    alerts = match_events(articles)

    # 3. 推送提醒
    if alerts:
        alert_file = push_alerts(alerts)
        return alert_file
    else:
        print("\n✓ 本次监控无新事件触发")


if __name__ == "__main__":
    main()
