---
name: philosophy-video-studio
description: Create original Chinese philosophy explainer films with dark illustrated interiors, silhouette figures, symbolic lighting, timed narration, subtitles and music. Use for making similar philosophy videos, turning a philosophical topic into narrated animation, or reusing this local code-driven production workflow. Not a generic live-action or AI-video-generation skill.
metadata:
  short-description: 原创哲学动画、中文旁白、字幕、配乐与可复用渲染流程
  version: 1.0.0
---

# 哲学暗房视频工作室

把哲学问题做成有叙事的中文动画短片。默认路线是**原创代码插画与动画 + Microsoft Edge TTS 中文合成旁白 + 本地合成配乐 + FFmpeg**。不依赖 Renoise，不把“参考了 Renoise 工作流”说成“Renoise 生成了素材”。TTS 首次合成需要联网；已有语音缓存可复用。

## 确定本期内容

沿用用户已明确的主题、片长、声音和风格。若未指定，采用约两分钟的 1920×1080 横屏、24fps、中文男声、暗色宋体标题与剪影插画。片长随实际旁白时长计算，不能只给字幕视频或只有分镜而宣称成片。

先读 [哲学写作](references/philosophy-writing.md)，核对核心概念，再写原创口语脚本。使用权威研究与可核验的原著；把事实、解释和本片的生活比喻分开。不要把不同流派揉成一套口号。记录来源到 episode.json，不搬用参考视频的台词、素材、音乐或标志。

推荐叙事：生活中的困惑 → 明确问题 → 一个思想切口 → 可见的隐喻 → 限制或反例 → 回到生活。段落数量由内容决定，示例的 16 段不是硬性要求。结束不必强行变成励志结论。

## 设计视觉与声音

读 [视觉语言](references/visual-language.md) 和 [配置格式](references/episode-format.md)。先给每一段一个论点和一种能“发生变化”的隐喻，再选场景类型。可扩充 renderer.py 的符号与场景；不要只替换标题，把不相干的椅子或客厅硬套给每一个哲学主题。

使用空房间、人物剪影、光束、摆灯、书页、门、群像、宇宙、坍塌的基座、植物或提灯等原创几何插画。冷暖变化服务于论点，字体、人物和场景保持连续。所有动画由帧号决定；不使用系统时间或随机漂移。声画共用实际配音生成的 timeline.json。

默认本地路线不调用 Renoise 付费服务。若用户要求 AI 素材、其他付费配音或云渲染，先列明供应商、模型、数量、参数、素材、具体报价和预算边界，等待确认后再执行；不要把旧的“继续制作”当成新增付费授权。

## 执行

将每期放在独立项目目录；创建 episode.json，格式见参考文档，完整范例在 assets/episodes/。不复用旧片的音频文件名或依赖旧项目路径。

使用当前主机可用的 Python、FFmpeg、ffprobe 和 CJK 字体。在 Codex Desktop 可调用 load_workspace_dependencies 获取捆绑 Python；需要的 Python 包为 Pillow、NumPy、edge-tts。优先复用已有环境；缺包时仅安装到本期项目 .deps，避免改全局环境：

```text
python -m pip install --target <PROJECT>/.deps -r <SKILL>/scripts/requirements.txt
python <SKILL>/scripts/studio.py check --project <PROJECT>
python <SKILL>/scripts/studio.py prepare --project <PROJECT>
python <SKILL>/scripts/studio.py preview --project <PROJECT>
```

已有独立依赖目录时，可在各条命令后加 `--deps <PATH>`。这些命令只是参数示意；实际执行时替换占位路径，Windows 使用原生 PowerShell 引号。

检查 qa/contact-sheet.jpg，必要时查看单张全尺寸预览并修正排版与隐喻。然后：

```text
python <SKILL>/scripts/studio.py all --project <PROJECT>
```

all 会依次完成配音、预览、配乐、全片渲染、音量处理、编码检查和导出，自动跳过输入未变且产物完整的步骤。详见 [运行与恢复](references/production.md)。TTS 请求最多重试三次，并只在成功且验证后替换缓存；失败时保留已完成的语音，不生成空白静音版本冒充完成。

## 检查和交付

查看最终 MP4 的每段开头、中间和结尾关键帧：qa/encoded-contact-start.jpg、middle.jpg、end.jpg。自动检查覆盖：尺寸、帧率、时长、音轨覆盖、字幕越界和重叠、响度与编码峰值。它不能证明运动自然或旁白听感优秀；在交付中请用户观看这两项。发现问题就修正相应配置或代码并重新执行，缓存会使受影响步骤重建。

交付可播放的 film.mp4，而不是只给源码；同时提供 cover.jpg、subtitles.srt、制作说明与旁白.md、editable-source.zip 和 watch.html。使用实际工具返回的绝对路径展示视频；明确实际时长、是否合成语音、Renoise 积分消耗。没有实测就不要声称已听完、节奏已验证或某个平台一定适用。

若安装 skill，默认放在 ~/.codex/skills/philosophy-video-studio。分发包只包含本 skill 的说明、代码、配置示例和依赖清单；排除依赖包、缓存、凭据、用户浏览器资料、旧项目的私人文件和视频大文件。
