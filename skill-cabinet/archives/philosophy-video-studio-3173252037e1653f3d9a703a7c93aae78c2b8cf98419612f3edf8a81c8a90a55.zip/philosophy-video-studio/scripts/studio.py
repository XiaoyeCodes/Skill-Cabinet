"""Resumable command entry point. Writes only inside --project; no automatic paid services."""
import argparse,hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
from common import validate_episode,tool,font_path,atomic_json

SCRIPTS=Path(__file__).parent
ORDER=['prepare','preview','audio','render','finish','qa','export']
FILES={'prepare':('prepare.py',['timeline.json']),'preview':('renderer.py',['qa/contact-sheet.jpg','subtitles.srt']),'audio':('sound.py',['mix.wav']),'render':('renderer.py',['silent.mp4']),'finish':('finish.py',['film.mp4','qa/media-info.json']),'qa':('qa.py',['qa/checks.json','qa/encoded-contact-start.jpg','qa/encoded-contact-middle.jpg','qa/encoded-contact-end.jpg']),'export':('export.py',['cover.jpg','watch.html','制作说明与旁白.md','editable-source.zip','provenance.json'])}
def sha(paths):
 h=hashlib.sha256()
 for p in paths:
  h.update(str(p.name).encode());h.update(p.read_bytes())
 return h.hexdigest()

def artifacts(root,stage):
 names=list(FILES[stage][1])
 if stage=='prepare' and (root/'timeline.json').exists():
  timeline=json.loads((root/'timeline.json').read_text(encoding='utf8'))
  for scene in timeline['scenes']:names.extend([scene['audio'],scene['metadata']])
 return list(dict.fromkeys(names))

def main():
 parser=argparse.ArgumentParser(description='Create code-built, narrated Chinese philosophy films.')
 parser.add_argument('stage',choices=['check','all']+ORDER);parser.add_argument('--project',required=True,type=Path);parser.add_argument('--deps',type=Path);parser.add_argument('--force',action='store_true')
 args=parser.parse_args();root=args.project.expanduser().resolve()
 if not (root/'episode.json').exists():raise RuntimeError('Create episode.json in the project directory first; see the skill episode examples.')
 os.environ['PHILOSOPHY_PROJECT']=str(root)
 deps=[root/'.deps']+([args.deps.expanduser().resolve()] if args.deps else [])
 for dep in deps:
  if dep.exists():sys.path.insert(0,str(dep))
 env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join([str(d) for d in deps if d.exists()]+[env.get('PYTHONPATH','')]);env['PYTHONIOENCODING']='utf-8'
 episode=json.loads((root/'episode.json').read_text(encoding='utf-8-sig'));errors=validate_episode(episode)
 if errors:raise RuntimeError('Invalid episode:\n'+'\n'.join(errors))
 for dep in ['PIL','numpy','edge_tts']:
  if importlib.util.find_spec(dep) is None:raise RuntimeError(f'Missing dependency {dep}; install scripts/requirements.txt in project/.deps or pass --deps.')
 for binary in ['ffmpeg','ffprobe']:tool(binary)
 for style in [True,False]:font_path(style)
 (root/'qa').mkdir(exist_ok=True)
 print('Preflight passed: schema, dependencies, ffmpeg/ffprobe, CJK fonts.',flush=True)
 if args.stage=='check':return
 statepath=root/'build-state.json';state=json.loads(statepath.read_text(encoding='utf8')) if statepath.exists() else {}
 for stage in ORDER if args.stage=='all' else [args.stage]:
  script,outputs=FILES[stage]
  inputs=[root/'episode.json',SCRIPTS/script,SCRIPTS/'common.py']
  if stage!='prepare':
   if not (root/'timeline.json').exists():raise RuntimeError('Run prepare first.')
   inputs.append(root/'timeline.json')
  if stage in ['preview','qa','export']:inputs.append(SCRIPTS/'renderer.py')
  if stage in ['preview','render','audio']:
   timeline=json.loads((root/'timeline.json').read_text(encoding='utf8'))
   for scene in timeline['scenes']:inputs.extend([root/scene['audio'],root/scene['metadata']])
  for name in {'finish':['silent.mp4','mix.wav'],'qa':['film.mp4','subtitles.srt'],'export':['film.mp4','subtitles.srt','qa/checks.json']}.get(stage,[]):inputs.append(root/name)
  signature=sha(inputs)
  outputs=artifacts(root,stage)
  intact=all((root/o).exists() and (root/o).stat().st_size>0 for o in outputs)
  if not args.force and state.get(stage,{}).get('signature')==signature and intact and state.get(stage,{}).get('outputSignature')==sha([root/o for o in outputs]):
   print('Cache hit: '+stage,flush=True);continue
  print('Stage: '+stage,flush=True)
  command=[sys.executable,str(SCRIPTS/script)]+(['--preview'] if stage=='preview' else [])
  subprocess.run(command,env=env,cwd=root,check=True)
  outputs=artifacts(root,stage)
  if not all((root/o).exists() and (root/o).stat().st_size>0 for o in outputs):raise RuntimeError(f'{stage} did not produce all required artifacts')
  state[stage]={'signature':signature,'outputSignature':sha([root/o for o in outputs]),'outputs':outputs};atomic_json(statepath,state)
 print('Requested stages completed.',flush=True)

if __name__=='__main__':
 try:main()
 except Exception as e:print(f'ERROR: {e}',file=sys.stderr,flush=True);raise SystemExit(1)
