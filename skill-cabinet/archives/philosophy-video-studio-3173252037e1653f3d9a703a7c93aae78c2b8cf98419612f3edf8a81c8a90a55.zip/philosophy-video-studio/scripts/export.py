"""Deliverable player, narration notes, provenance, and reproducible editable source archive."""
from pathlib import Path
import json,html,zipfile,hashlib,shutil
from common import project_dir,atomic_json
import renderer
ROOT=project_dir();data=renderer.DATA;src=Path(__file__).parent
title_scene=next((s for s in data['scenes'] if s['kind']=='title'),data['scenes'][0])
im=renderer.scene_frame(title_scene,min(4,title_scene['duration']/2));p=renderer.Pen(im)
p.text((66,52),'哲 学 暗 房  /  '+data.get('episodeNumber','01'),15,renderer.GOLD,'lm')
p.text((640,627),data.get('tagline',data['shortTitle']),23,renderer.WHITE)
im.save(ROOT/'cover.jpg',quality=95)
lines=[f'# {data["title"]}','','## 制作与预算','','- 1920×1080 横屏；'+str(data['fps'])+'fps；实际时长 '+f'{data["duration"]:.2f} 秒。','- 原创代码插画与动画，Microsoft Edge TTS 中文合成旁白，按词边界对齐字幕，本地合成配乐。','- 配音合成需要联网；已经生成的音频可离线复用。没有调用 Renoise 分析或素材生成；Renoise 积分消耗 0。','- 客观检查见 qa/checks.json；画面抽查见 qa/encoded-contact-*.jpg。运动与听感仍需观看成片确认。','','## 内容边界','',data.get('scope',''),'', '## 参考资料','']
for source in data.get('sources',[]):lines.append(f'- [{source["title"]}]({source["url"]})：{source.get("use","")}')
lines+=['','## 旁白与分镜','']
for s in data['scenes']:
 lines += [f'### {s["index"]+1:02d} · {s["name"]}（{s["start"]:.2f}–{s["start"]+s["duration"]:.2f}s）','',s['text'],'',f'视觉：{s["kind"]}；屏幕重点：{s["headline"]}。','']
lines+=['## 再制作','','修改 episode.json，再调用 skill 的 scripts/studio.py。音频按文本与语音设置缓存，修改某一段只会重做该段配音；时间轴会按新音频时长重算，受影响的画面和字幕会重新渲染。','', '示例：python scripts/studio.py all --project /path/to/project。需要 Python 3.10+、Pillow、NumPy、edge-tts、ffmpeg、ffprobe 和 CJK 字体。']
(ROOT/'制作说明与旁白.md').write_text('\n'.join(lines),encoding='utf8');(ROOT/'旁白.txt').write_text('\n\n'.join(s['text'] for s in data['scenes']),encoding='utf8')
buttons=''.join(f'<button onclick="jump({s["start"]})"><span>{s["index"]+1:02d}</span> {html.escape(s["name"])} <small>{int(s["start"])//60:02d}:{int(s["start"])%60:02d}</small></button>' for s in data['scenes'])
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'''+html.escape(data['title'])+'''</title><style>*{box-sizing:border-box}body{margin:0;background:#090e15;color:#e9e7dc;font:16px/1.6 system-ui,sans-serif}main{max-width:1200px;margin:40px auto;padding:24px}h1{font-family:serif;font-size:40px;font-weight:400}.label{color:#c2aa78;font-size:13px;letter-spacing:3px}p{color:#9eacba}video{width:100%;display:block;background:#05080c;border-radius:8px;margin:28px 0}.chapters{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:10px}button{padding:14px 18px;background:#141d28;color:#d3d8dc;border:1px solid #283545;border-radius:5px;text-align:left;cursor:pointer;font:inherit}span,a{color:#c3ab79}small{float:right;color:#78899b}footer{margin-top:26px;font-size:13px;color:#7b8c9f}</style><main><div class="label">PHILOSOPHY FILM</div><h1>'''+html.escape(data['title'])+'''</h1><p>'''+html.escape(data.get('tagline',''))+'''</p><video id="film" controls preload="metadata" poster="cover.jpg" src="film.mp4"></video><div class="chapters">'''+buttons+'''</div><footer>中文合成旁白与字幕 · <a href="subtitles.srt" download>字幕</a> · <a href="制作说明与旁白.md">旁白与制作说明</a></footer></main><script>function jump(t){const v=document.getElementById('film');v.currentTime=t;v.play().catch(()=>{});v.scrollIntoView({behavior:'smooth',block:'center'});}</script></html>'''
(ROOT/'watch.html').write_text(page,encoding='utf8')
provenance=dict(method='original-code-animation',narration='Microsoft Edge TTS (network synthesis)',music='local deterministic synthesis',renoiseGeneratedAssets=False,renoiseCreditsSpent=0,sourceMediaReused=False,episodeSHA256=hashlib.sha256((ROOT/'episode.json').read_bytes()).hexdigest(),videoSHA256=hashlib.sha256((ROOT/'film.mp4').read_bytes()).hexdigest())
atomic_json(ROOT/'provenance.json',provenance)
with zipfile.ZipFile(ROOT/'editable-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for script in src.glob('*.py'):z.write(script,'scripts/'+script.name)
 z.write(src/'requirements.txt','scripts/requirements.txt')
 for name in ['episode.json','timeline.json','subtitles.srt','旁白.txt','制作说明与旁白.md','provenance.json','cover.jpg','watch.html']:
  z.write(ROOT/name,name)
 for f in (ROOT/'audio').glob('*'):
  if '.partial.' not in f.name:z.write(f,'audio/'+f.name)
print('Exported film.mp4, cover.jpg, subtitles.srt, watch.html, notes and editable-source.zip',flush=True)
