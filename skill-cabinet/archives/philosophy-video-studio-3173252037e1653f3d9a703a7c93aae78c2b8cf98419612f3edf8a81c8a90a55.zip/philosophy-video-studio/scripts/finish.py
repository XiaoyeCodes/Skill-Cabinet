"""Two-pass loudness normalization, muxing, and codec metadata."""
import json,re,subprocess,math
from common import project_dir,tool,probe,atomic_json
ROOT=project_dir();data=json.loads((ROOT/'timeline.json').read_text(encoding='utf8'))
with (ROOT/'loudness-pass1.txt').open('w',encoding='utf8') as log:
 subprocess.run([tool('ffmpeg'),'-hide_banner','-nostats','-i',str(ROOT/'mix.wav'),'-af','loudnorm=I=-14:TP=-1.5:LRA=8:print_format=json','-f','null','-'],stderr=log,stdout=subprocess.DEVNULL,check=True)
stats=json.loads(re.search(r'\{[\s\S]*?\}',(ROOT/'loudness-pass1.txt').read_text(encoding='utf8',errors='replace')).group(0))
af=f'loudnorm=I=-14:TP=-1.5:LRA=8:measured_I={stats["input_i"]}:measured_TP={stats["input_tp"]}:measured_LRA={stats["input_lra"]}:measured_thresh={stats["input_thresh"]}:offset={stats["target_offset"]}:linear=true:print_format=json'
tmp=ROOT/'film.partial.mp4';target=ROOT/'film.mp4'
with (ROOT/'loudness-pass2.txt').open('w',encoding='utf8') as log:
 subprocess.run([tool('ffmpeg'),'-hide_banner','-y','-i',str(ROOT/'silent.mp4'),'-i',str(ROOT/'mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-af',af,'-c:a','aac','-b:a','192k','-ar','48000','-t',str(math.ceil(data['duration']*data['fps'])/data['fps']),'-movflags','+faststart',str(tmp)],stderr=log,check=True)
probe(tmp);tmp.replace(target);atomic_json(ROOT/'qa'/'media-info.json',probe(target))
print('Muxed film.mp4',flush=True)
