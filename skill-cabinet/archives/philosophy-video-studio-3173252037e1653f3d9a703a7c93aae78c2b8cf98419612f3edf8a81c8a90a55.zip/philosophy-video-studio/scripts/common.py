"""Shared project, dependency, font, and process helpers; no machine-specific project paths."""
from pathlib import Path
import json, os, shutil, subprocess, sys

if hasattr(sys.stdout,'reconfigure'):
 sys.stdout.reconfigure(encoding='utf-8',errors='replace')

KINDS={'room','routine','crowd','title','chair','book','labels','doors','pendulum','mask','limits','bridge','garden','others','return','ending','cosmos','pedestal','lantern'}

def project_dir():
 value=os.environ.get('PHILOSOPHY_PROJECT')
 if not value:raise RuntimeError('Use studio.py with --project PATH; this module needs PHILOSOPHY_PROJECT.')
 return Path(value).expanduser().resolve()

def episode():return json.loads((project_dir()/'episode.json').read_text(encoding='utf-8-sig'))

def tool(name):
 result=shutil.which(name)
 if not result:raise RuntimeError(f'{name} is required and was not found on PATH. Install it or provide a process-scoped PATH.')
 return result

def probe(path):
 return json.loads(subprocess.check_output([tool('ffprobe'),'-v','error','-show_format','-show_streams','-of','json',str(path)]))

def font_path(serif=True):
 configured=episode().get('fonts',{}).get('serif' if serif else 'sans')
 if configured:
  p=Path(configured).expanduser()
  if not p.is_absolute():p=project_dir()/p
  if not p.exists():raise RuntimeError(f'Font does not exist: {p}')
  return str(p)
 candidates=(
  ['C:/Windows/Fonts/simsun.ttc','/System/Library/Fonts/Supplemental/Songti.ttc','/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc','/usr/share/fonts/truetype/noto/NotoSerifCJK-Regular.ttc']
  if serif else
  ['C:/Windows/Fonts/msyh.ttc','/System/Library/Fonts/PingFang.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc'])
 for candidate in candidates:
  if Path(candidate).exists():return candidate
 raise RuntimeError('A Chinese font is required. Set fonts.serif and fonts.sans in episode.json to local CJK font files.')

def atomic_json(path,value):
 tmp=Path(str(path)+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)

def validate_episode(data):
 errors=[]
 if not isinstance(data,dict):return ['Episode must be an object.']
 for key in ['title','topic','shortTitle']:
  if not isinstance(data.get(key),str) or not data[key].strip():errors.append(f'{key} must be a nonempty string.')
 if len(data.get('topic',''))>8:errors.append('topic must fit the header: at most 8 CJK characters.')
 if data.get('fps',24) not in [24,30]:errors.append('fps must be 24 or 30.')
 if data.get('width',1920)!=1920 or data.get('height',1080)!=1080:errors.append('This renderer currently supports 1920x1080 landscape only; do not silently crop for vertical output.')
 if not isinstance(data.get('voice',{}),dict) or any(k not in {'voice','rate','pitch'} for k in data.get('voice',{})):errors.append('voice accepts only voice, rate and pitch; word boundaries are maintained by the engine.')
 scenes=data.get('scenes',[])
 if not isinstance(scenes,list) or not 1<=len(scenes)<=40:errors.append('scenes must contain 1–40 scenes.');return errors
 ids=set()
 for i,s in enumerate(scenes):
  label=f'scenes[{i}]'
  if not isinstance(s,dict):errors.append(f'{label} must be an object.');continue
  sid=s.get('id')
  if not isinstance(sid,str) or not sid or not all(c.isalnum() or c in '-_' for c in sid):errors.append(f'{label}.id needs a stable path-safe identifier.')
  elif sid in ids:errors.append(f'{label}.id duplicates {sid}.')
  if isinstance(sid,str):ids.add(sid)
  for key in ['name','narration','headline']:
   if not isinstance(s.get(key),str) or not s[key].strip():errors.append(f'{label}.{key} must be a nonempty string.')
  if len(s.get('narration',''))>220:errors.append(f'{label}.narration is too long for one visual beat; split it.')
  if len(s.get('headline',''))>18:errors.append(f'{label}.headline is too long; use a shorter display line.')
  if s.get('kind') not in KINDS:errors.append(f'{label}.kind is unsupported: {s.get("kind")}')
  if not isinstance(s.get('visual',{}),dict):errors.append(f'{label}.visual must be an object.')
  else:
   visual=s.get('visual',{});counts={'routine':5,'crowd':7,'labels':4,'doors':3,'limits':3,'garden':3,'pedestal':3}
   if 'labels' in visual:
    values=visual['labels']
    if not isinstance(values,list) or len(values)!=counts.get(s.get('kind'),len(values)) or not all(isinstance(v,str) and v.strip() for v in values):errors.append(f'{label}.visual.labels has an invalid count or non-text value.')
  pause=s.get('pause',.85)
  if not isinstance(pause,(int,float)) or not .2<=pause<=5:errors.append(f'{label}.pause must be between .2 and 5 seconds.')
 return errors
