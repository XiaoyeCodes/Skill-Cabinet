"""Content-addressed TTS cache, atomic promotion, measured timeline; three bounded retries."""
from pathlib import Path
import asyncio, hashlib, json, os
from common import project_dir,episode,validate_episode,probe,atomic_json

ROOT=project_dir()

async def main():
 data=episode();errors=validate_episode(data)
 if errors:raise RuntimeError('\n'.join(errors))
 import edge_tts
 config=dict(voice='zh-CN-YunxiNeural',rate='-3%',pitch='-4Hz',boundary='WordBoundary');config.update(data.get('voice',{}))
 (ROOT/'audio').mkdir(exist_ok=True)
 timeline=[];intro=float(data.get('intro',1.2));cursor=intro
 for i,scene in enumerate(data['scenes']):
  digest=hashlib.sha256(json.dumps({'text':scene['narration'],'config':config},sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:16]
  stem=f'{scene["id"]}-{digest}';audio=ROOT/'audio'/f'{stem}.mp3';metadata=ROOT/'audio'/f'{stem}.jsonl'
  valid=audio.exists() and audio.stat().st_size>1000 and metadata.exists() and metadata.stat().st_size>0
  if valid:
   try:valid=float(probe(audio)['format']['duration'])>0
   except Exception:valid=False
  if not valid:
   print(f'TTS {i+1}/{len(data["scenes"])}: {scene["name"]}',flush=True)
   for attempt in range(3):
    tmp_audio=audio.with_suffix('.partial.mp3');tmp_meta=metadata.with_suffix('.partial.jsonl')
    try:
     await edge_tts.Communicate(scene['narration'],**config).save(str(tmp_audio),str(tmp_meta))
     if tmp_audio.stat().st_size<1000 or tmp_meta.stat().st_size==0 or float(probe(tmp_audio)['format']['duration'])<=0:raise RuntimeError('Incomplete speech result')
     tmp_audio.replace(audio);tmp_meta.replace(metadata);break
    except Exception as e:
     if attempt==2:raise RuntimeError(f'TTS failed after 3 attempts for {scene["id"]}; completed scenes remain cached.') from e
     await asyncio.sleep(2)
  length=float(probe(audio)['format']['duration']);duration=length+float(scene.get('pause',.85))
  item=dict(scene);item.update(index=i,text=scene['narration'],start=cursor,duration=duration,voiceDuration=length,voiceStart=cursor,audio='audio/'+audio.name,metadata='audio/'+metadata.name)
  timeline.append(item);cursor+=duration
 timeline[0]['start']=0;timeline[0]['duration']+=intro
 outro=float(data.get('outro',2.0));timeline[-1]['duration']+=outro
 result={k:v for k,v in data.items() if k!='scenes'};result.update(duration=cursor+outro,scenes=timeline,fps=data.get('fps',24),width=1920,height=1080)
 atomic_json(ROOT/'timeline.json',result)
 print(f'Timeline ready: {result["duration"]:.2f}s; {len(timeline)} scenes',flush=True)

if __name__=='__main__':asyncio.run(main())
