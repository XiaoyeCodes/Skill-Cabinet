"""Check the encoded file, subtitle intervals, audio loudness, and export visual evidence."""
from concurrent.futures import ThreadPoolExecutor
from PIL import Image,ImageDraw,ImageFont
import json,subprocess,re,math
from common import project_dir,tool,probe,font_path,atomic_json
import renderer
ROOT=project_dir();data=renderer.DATA;video=ROOT/'film.mp4';info=probe(video);issues=[]
vs=next(s for s in info['streams'] if s['codec_type']=='video');audio=[s for s in info['streams'] if s['codec_type']=='audio']
duration=float(info['format']['duration'])
if (vs['width'],vs['height'])!=(1920,1080):issues.append('Unexpected video dimensions')
if abs(duration-math.ceil(data['duration']*data['fps'])/data['fps'])>.15:issues.append('Duration does not match measured timeline')
if not audio:issues.append('Missing audio stream')
if abs(float(vs['r_frame_rate'].split('/')[0])/float(vs['r_frame_rate'].split('/')[1])-data['fps'])>.001:issues.append('Unexpected frame rate')
if audio and float(audio[0].get('duration',duration))<data['duration']-.2:issues.append('Audio ends too early')
for i,c in enumerate(renderer.CUES):
 if c['start']<0 or c['end']>duration or c['end']<=c['start']:issues.append(f'Invalid subtitle interval: {i}')
 if i and c['start']<renderer.CUES[i-1]['end']-.05:issues.append(f'Overlapping subtitles: {i}')
 if not c['text'].strip():issues.append(f'Empty subtitle: {i}')
tasks=[]
for s in data['scenes']:
 for label,at in [('start',s['start']+.8),('middle',s['start']+s['duration']/2),('end',s['start']+s['duration']-.35)]:
  tasks.append((s['index'],label,at,ROOT/'qa'/f'encoded-{s["index"]:02d}-{label}.jpg'))
def capture(item):
 i,label,at,path=item
 subprocess.run([tool('ffmpeg'),'-hide_banner','-loglevel','error','-y','-ss',str(at),'-i',str(video),'-frames:v','1','-vf','scale=640:-1',str(path)],check=True)
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(capture,tasks))
fnt=ImageFont.truetype(font_path(False),20)
for phase in ['start','middle','end']:
 sheet=Image.new('RGB',(1920,math.ceil(len(data['scenes'])/4)*312),'#0d121a');d=ImageDraw.Draw(sheet)
 for i,label,at,path in [t for t in tasks if t[1]==phase]:
  im=Image.open(path).resize((480,270));x=i%4*480;y=i//4*312;sheet.paste(im,(x,y));d.text((x+10,y+278),f'{i+1:02d} {phase} {at:.2f}s',font=fnt,fill='white')
 sheet.save(ROOT/'qa'/f'encoded-contact-{phase}.jpg',quality=92)
with (ROOT/'qa'/'loudness-final.txt').open('w',encoding='utf8') as log:
 subprocess.run([tool('ffmpeg'),'-hide_banner','-nostats','-i',str(video),'-af','ebur128=peak=true','-f','null','-'],stderr=log,stdout=subprocess.DEVNULL,check=True)
log=(ROOT/'qa'/'loudness-final.txt').read_text(encoding='utf8',errors='replace');summary=log.rsplit('Summary:',1)[-1]
integrated=float(re.search(r'I:\s+(-?[\d.]+) LUFS',summary).group(1));peak=float(re.search(r'Peak:\s+(-?[\d.]+) dBFS',summary).group(1))
if not -16<=integrated<=-12:issues.append('Integrated loudness outside -16 to -12 LUFS')
if peak>-.5:issues.append('True peak exceeds -0.5 dBFS after AAC encoding')
report=dict(encodedFramesChecked=len(tasks),subtitleCues=len(renderer.CUES),duration=duration,width=vs['width'],height=vs['height'],fps=data['fps'],loudnessLUFS=integrated,truePeakDBFS=peak,issues=issues,renoiseCreditsSpent=0,visualReview='Contact sheets require human/agent image inspection; automated checks do not assess motion or voice quality.')
atomic_json(ROOT/'qa'/'checks.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)
if issues:raise RuntimeError('Quality checks failed; see qa/checks.json')
