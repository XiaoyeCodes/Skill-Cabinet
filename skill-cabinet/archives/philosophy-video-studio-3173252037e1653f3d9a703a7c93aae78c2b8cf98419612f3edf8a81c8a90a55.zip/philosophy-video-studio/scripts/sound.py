"""Locally synthesized score and timed voice mix, driven by timeline.json."""
from pathlib import Path
from common import project_dir,tool
import json, subprocess, wave, math
import numpy as np
ROOT=project_dir()
data=json.loads((ROOT/'timeline.json').read_text(encoding='utf8'))
SR=48000;N=math.ceil(data['duration']*SR);mix=np.zeros((N,2),np.float32)
music=np.zeros_like(mix)
def note(at,midi,duration=5.3,gain=.022,pan=0):
 start=int(at*SR);end=min(N,start+int(duration*SR));t=np.arange(end-start)/SR
 frequency=440*2**((midi-69)/12)
 envelope=(1-np.exp(-t*110))*np.exp(-t/1.9)*np.minimum(1,(duration-t)/.8)
 signal=np.zeros_like(t)
 for h,level in [(1,1),(2,.24),(3,.075),(4,.035)]:signal+=level*np.sin(2*np.pi*frequency*h*t+(.15 if h%2 else 0))*np.exp(-t*.08*h)
 signal=(signal*envelope*gain).astype(np.float32)
 music[start:end,0]+=signal*math.sqrt((1-pan)/2);music[start:end,1]+=signal*math.sqrt((1+pan)/2)
 # A gentle stereo room reflection is fully deterministic.
 delay=int(.19*SR);r=min(N-end,delay)
 ds=start+delay;de=min(N,end+delay)
 music[ds:de,1]+=signal[:de-ds]*.18
progressions=data.get('music',{}).get('chords',[[50,57,62,65],[46,53,58,62],[48,55,60,64],[45,52,57,60]])
for i,at in enumerate(np.arange(1, data['duration']-2,3.2)):
 chord=progressions[(i//4)%4];midi=chord[i%4]+(12 if i%4==3 else 0)
 note(at,midi,gain=.024 if i%4 else .032,pan=math.sin(i*1.7)*.5)
for scene in data['scenes']:
 at=scene['voiceStart']
 raw=subprocess.check_output([tool('ffmpeg'),'-hide_banner','-loglevel','error','-i',str(ROOT/scene['audio']),'-ar',str(SR),'-ac','1','-f','f32le','pipe:1'])
 voice=np.frombuffer(raw,dtype='<f4').copy();peak=np.max(np.abs(voice));voice*=.68/max(.001,peak)
 start=int(at*SR);end=min(N,start+len(voice));mix[start:end,:]+=voice[:end-start,None]*.85
 # Soft low-register cue, tied exactly to scene boundaries.
 if scene.get('accent',False):note(max(0,scene['start']),38,duration=3.5,gain=.017)
t=np.arange(N,dtype=np.float32)/SR
fade=np.clip(t/3,0,1)*np.clip((data['duration']-t)/3.5,0,1)
mix+=music*fade[:,None]
mix*=fade[:,None]
peak=float(np.max(np.abs(mix)))
if peak>.93:mix*=.93/peak
with wave.open(str(ROOT/'mix.wav'),'wb') as f:
 f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
print('Audio mix ready',data['duration'],'seconds; peak',round(peak,4),flush=True)
