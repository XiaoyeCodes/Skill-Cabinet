"""Original deterministic illustration/animation; no source footage is reused."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np
import json, math, subprocess, sys, re, time, functools
from common import project_dir,font_path,tool

ROOT=project_dir()
DATA=json.loads((ROOT/'timeline.json').read_text(encoding='utf8'))
W,H=1920,1080; S=1.5; FPS=int(DATA.get("fps",24))
GOLD=DATA.get('palette',{}).get('gold','#d6b77b'); WHITE='#e9e8df'; BLUE=DATA.get('palette',{}).get('blue','#9bb2c5'); INK='#101822'
def clamp(x,a=0,b=1):return max(a,min(b,x))
def smooth(x):x=clamp(x);return x*x*(3-2*x)
def lerp(a,b,t):return a+(b-a)*t
@functools.lru_cache(100)
def font(size,serif=True):return ImageFont.truetype(font_path(serif),round(size*S))
def rgb(c):return tuple(int(c[i:i+2],16) for i in (1,3,5))

class Pen:
 def __init__(self,im):self.im=im;self.d=ImageDraw.Draw(im)
 def pts(self,p):return [(round(x*S),round(y*S)) for x,y in p]
 def line(self,p,c,w=1):self.d.line(self.pts(p),fill=c,width=max(1,round(w*S)),joint='curve')
 def poly(self,p,c):self.d.polygon(self.pts(p),fill=c)
 def rect(self,box,c,outline=None,width=1,r=0):
  box=tuple(round(x*S) for x in box)
  if r:self.d.rounded_rectangle(box,radius=round(r*S),fill=c,outline=outline,width=max(1,round(width*S)))
  else:self.d.rectangle(box,fill=c,outline=outline,width=max(1,round(width*S)))
 def ellipse(self,box,c,outline=None,width=1):self.d.ellipse(tuple(round(x*S) for x in box),fill=c,outline=outline,width=max(1,round(width*S)))
 def text(self,xy,txt,size,c=WHITE,anchor='mm',serif=True):self.d.text((round(xy[0]*S),round(xy[1]*S)),txt,font=font(size,serif),fill=c,anchor=anchor,stroke_width=0)

yy,xx=np.mgrid[0:H,0:W];xn=xx/W;yn=yy/H
noise=np.random.default_rng(1993).normal(0,0.85,(H,W,1))
@functools.lru_cache(8)
def background(warm=False):
 base=np.zeros((H,W,3),np.float32)+[7,11,17]
 light=np.exp(-(((xn-.50)/.58)**2+((yn-.46)/.6)**2)*2)
 base+=light[:,:,None]*np.array([25,29,36] if not warm else [53,37,23])
 base+=noise
 return Image.fromarray(np.uint8(np.clip(base,0,255)),'RGB')

@functools.lru_cache(64)
def halo(color,radius):
 size=radius*2+1;y,x=np.mgrid[-radius:radius+1,-radius:radius+1]
 a=np.exp(-(x*x+y*y)/(radius*.32)**2)*.75
 arr=np.zeros((size,size,4),np.uint8);arr[:,:,:3]=rgb(color);arr[:,:,3]=np.uint8(a*255)
 return Image.fromarray(arr)
def glow(im,x,y,color=GOLD,r=70,alpha=1):
 g=halo(color,int(r*S))
 if alpha<1:g=g.copy();g.putalpha(g.getchannel('A').point(lambda a:int(a*clamp(alpha))))
 im.paste(g,(round(x*S-g.width/2),round(y*S-g.height/2)),g)

def person(p,x,y,h=245,color='#111b26',edge='#586c7d',pose='stand',light=0):
 # Coordinates are relative to the soles; the same symbol is reused throughout.
 k=h/245; X=lambda a:x+a*k;Y=lambda a:y+a*k
 p.ellipse((X(-17),Y(-244),X(17),Y(-203)),color,edge,1.1)
 if pose=='sit':
  p.poly([(X(-23),Y(-199)),(X(25),Y(-199)),(X(33),Y(-117)),(X(-20),Y(-116))],color)
  p.line([(X(-18),Y(-125)),(X(58),Y(-105)),(X(73),Y(-27))],color,16*k)
  p.line([(X(3),Y(-122)),(X(38),Y(-97)),(X(45),Y(-20))],color,15*k)
  p.line([(X(-21),Y(-191)),(X(-35),Y(-145)),(X(7),Y(-133))],color,11*k)
  p.line([(X(23),Y(-190)),(X(33),Y(-152)),(X(53),Y(-142))],color,11*k)
 else:
  pts=[(-23,-198),(22,-198),(31,-112),(18,-104),(14,-12),(3,-12),(-1,-104),(-7,-104),(-13,-12),(-24,-12),(-22,-107),(-32,-115)]
  p.poly([(X(a),Y(b)) for a,b in pts],color)
  p.line([(X(-21),Y(-194)),(X(-39),Y(-149)),(X(-37),Y(-115))],color,12*k)
  p.line([(X(22),Y(-193)),(X(39),Y(-151)),(X(42),Y(-116))],color,12*k)
 p.line([(X(-19),Y(-200)),(X(-27),Y(-189)),(X(-26),Y(-132))],edge,1*k)
 p.line([(X(19),Y(-200)),(X(28),Y(-187)),(X(30),Y(-145))],edge,1*k)
 p.line([(X(-11),Y(-201)),(X(0),Y(-194)),(X(12),Y(-202))],edge,.8*k)
 if light:
  glow(p.im,X(1),Y(-170),WHITE,25*k,light)
  p.ellipse((X(-3),Y(-177),X(3),Y(-162)),WHITE)

def lamp(p,x=640,y=175,angle=0,warm=True,beam=True):
 # Rotation is around the ceiling, including lamp and light cone.
 pivot=(x,30);theta=angle
 def t(a,b):
  dx=a-pivot[0];dy=b-pivot[1]
  return (pivot[0]+dx*math.cos(theta)-dy*math.sin(theta),pivot[1]+dx*math.sin(theta)+dy*math.cos(theta))
 if beam:
  layer=Image.new('RGBA',(W,H));lp=Pen(layer)
  lp.poly([t(x-13,y+8),t(x+13,y+8),t(x+190,575),t(x-190,575)],(224,195,135,23) if warm else (173,201,223,24))
  layer=layer.filter(ImageFilter.GaussianBlur(8*S));p.im.paste(layer,(0,0),layer)
  glow(p.im,*t(x,y+115),GOLD if warm else BLUE,170,.28)
 p.line([pivot,t(x,y-22)],'#73808b',.8)
 p.poly([t(x-35,y+5),t(x-26,y-14),t(x-9,y-25),t(x+10,y-25),t(x+28,y-13),t(x+36,y+5)],'#18232e')
 c=t(x,y+7);p.ellipse((c[0]-17,c[1]-4,c[0]+17,c[1]+4),WHITE)

def room(p,t,warm=False,hero=True):
 # Architectural lines and foreground create a reusable, layered interior.
 p.rect((80,75,350,387),'#111c2c',outline='#54616d',width=2)
 p.line([(215,77),(215,384)],'#485766',2);p.line([(82,240),(348,240)],'#485766',2)
 glow(p.im,290,140,BLUE,55,.32);p.ellipse((280,129,301,150),'#d7dce6')
 for i in range(32):
  bx=90+(i*73)%245;by=280+(i*43)%100
  p.rect((bx,by,bx+3,by+5),'#a99c75' if i%3 else '#5f788d')
 p.rect((70,65,92,432),'#2a2830');p.rect((340,65,364,433),'#2a2830')
 p.line([(0,497),(1280,497)],'#30343b',1)
 p.poly([(410,499),(870,499),(1100,650),(190,650)],'#141c26')
 # bookshelf
 p.rect((1025,140,1140,449),'#121920',outline='#25313b',width=2)
 for row in range(4):
  for col in range(7):
   bx=1036+col*13;by=151+row*70
   p.rect((bx,by+(col*7)%12,bx+8,by+49),['#2d3841','#33312b','#263d45'][col%3])
  p.line([(1027,210+row*70),(1138,210+row*70)],'#41403b',2)
 # sofa
 p.rect((410,344,888,475),'#283647',r=35);p.rect((434,355,638,435),'#304052',r=25);p.rect((653,355,863,435),'#304052',r=25)
 p.rect((393,418,901,493),'#202f40',r=20);p.rect((382,386,427,487),'#2e3d4d',r=20);p.rect((868,386,913,487),'#2e3d4d',r=20)
 p.line([(426,491),(420,515)],'#0c1119',7);p.line([(871,491),(880,515)],'#0c1119',7)
 # side table and standing lamp
 p.line([(989,304),(989,481)],'#554e40',3);p.poly([(952,303),(1025,303),(1012,257),(966,257)],'#6a604a' if warm else '#333b43')
 p.ellipse((940,482,1039,492),'#1a2027')
 # desk foreground
 p.poly([(425,531),(860,531),(930,579),(357,579)],'#27303a');p.line([(395,580),(386,624)],'#171e25',6);p.line([(890,580),(904,624)],'#171e25',6)
 p.line([(610,546),(635,542),(655,548),(638,555),(610,546)],'#777b7a',1)
 lamp(p,640,220,warm=warm)
 if hero:person(p,520,550,245,pose='sit',light=.7)

def book(p,x=640,y=350,scale=1,opening=1,words=False):
 k=scale;L=lambda a,b:(x+a*k,y+b*k)
 p.poly([L(-170,-108),L(-11,-85),L(0,119),L(-179,86)],'#334351')
 p.poly([L(170,-108),L(11,-85),L(0,119),L(179,86)],'#334351')
 p.poly([L(-160,-100),L(-9,-78),L(-4,106),L(-166,78)],'#c9c5ae')
 p.poly([L(160,-100),L(9,-78),L(4,106),L(166,78)],'#e3ddc8')
 p.line([L(0,-80),L(0,111)],'#746b58',2)
 if words:
  for j in range(6):p.line([L(30,-55+j*22),L(137,-69+j*22)],'#827962',1)

def dust(p,t,color=GOLD,amount=38,region=(180,90,1100,540),progress=1):
 a,b,c,d=region
 for j in range(amount):
  seed=(j*0.61803398875)%1
  x=a+(c-a)*seed+math.sin(t*.22+j)*8;y=b+((j*73+t*(3+j%4))%(d-b))
  if j/amount>progress:continue
  rr=.7+(j%3)*.35
  p.ellipse((x-rr,y-rr,x+rr,y+rr),color if j%4==0 else '#6f7980')

def header(p,s,t):
 p.text((56,35),DATA['topic'],19,WHITE,'lm');p.text((56,57),DATA.get('eyebrow','PHILOSOPHY'),8,'#6f7d8a','lm',False)
 p.text((1224,38),f'{s["index"]+1:02d}  /  {len(DATA["scenes"]):02d}',11,'#81909e','rm',False)
 p.line([(56,670),(1224,670)],'#27323e',.7)
 p.line([(56,670),(56+1168*clamp(t/DATA['duration']),670)],'#ae9971',1)
 p.text((56,688),DATA['shortTitle'],9,'#657380','lm')
 p.text((1224,688),'原创哲学短片 · 中文合成旁白',8,'#657380','rm',False)

def chair(p,x,y,k=1,col='#566a79'):
 p.poly([(x-65*k,y-65*k),(x+62*k,y-65*k),(x+82*k,y-35*k),(x-51*k,y-35*k)],col)
 p.line([(x-62*k,y-70*k),(x-65*k,y-180*k),(x+48*k,y-180*k),(x+58*k,y-70*k)],col,9*k)
 for a,b in [(-45,-47),(65,81)]:p.line([(x+a*k,y-35*k),(x+b*k,y+55*k)],col,9*k)
 p.line([(x-53*k,y-35*k),(x-72*k,y+49*k)],'#344552',8*k)

def scene_frame(s,local):
 u=clamp(local/s['duration']);a=smooth(local/1.1);kind=s['kind'];t=s['start']+local
 visual=s.get('visual',{});v=lambda key,default='':visual.get(key,default)
 headline=s['headline']
 im=background(kind=='routine').copy();p=Pen(im)
 if kind in ['room','return','ending']:
  room(p,t,warm=False,hero=True)
  if kind=='room':
   glow(im,775,398,BLUE,130,.35);p.text((793,389),v('symbol','？'),100,'#a9bbc8')
   p.text((748,456),v('subheading',headline),20,'#a1b1bd')
  elif kind=='return':
   # A lit, unfinished page becomes a concrete action rather than an abstract slogan.
   p.poly([(681,484),(821,467),(830,542),(690,559)],'#c9c1a6')
   p.line([(711,513),(795,502)],'#565747',1);p.line([(712,530),(764,522)],'#565747',1)
   glow(im,747,511,GOLD,120,.3)
  else:
   dust(p,t,WHITE,80,progress=smooth(local/5))
   p.text((800,335),v('heroWord','未完'),76,WHITE)
   p.text((800,403),v('subheading',headline),20,'#b6bec5')
 elif kind=='routine':
  p.poly([(0,495),(1280,495),(1280,580),(0,580)],'#222a31')
  for j,x in enumerate([200,420,640,860,1080]):
   person(p,x-((local*21)%55),505,208,color='#202731',edge='#7b7564')
   p.line([(x-70,505),(x+70,505)],'#5c5140',1)
   p.text((x,230),v('labels',['清晨','出发','奔跑','抵达','再出发'])[j],25,GOLD)
   p.line([(x,257),(x,280)],'#8d7957',1)
  p.text((640,140),headline,38,WHITE)
  glow(im,640,435,GOLD,200,.2)
 elif kind=='crowd':
  for j in range(13):
   x=125+(j%7)*173;y=460+(j//7)*90
   person(p,x,y,170,edge='#575545',color='#23251f')
   p.text((x,y-210),v('labels',['规则','习惯','期待','方向','目标','认可','标准'])[j%7],16,'#8b806a')
  # A single different figure; labels fade rather than jumping off the screen.
  person(p,640,545,245,edge=BLUE,light=1)
  p.text((640,139),headline,44,WHITE)
 elif kind=='title':
  lamp(p,640,155,warm=False);person(p,640,550,190,edge=BLUE,light=1)
  p.text((640,287),DATA['topic'],86,WHITE)
  p.text((640,363),DATA['shortTitle'],27,GOLD)
  p.text((640,412),v('subheading','哲学，回到生活之中'),15,'#8193a4')
  dust(p,t,BLUE,22)
 elif kind=='chair':
  # blueprint and physical chair share a silhouette.
  for j in range(9):p.line([(170+j*31,240),(170+j*31,492)],'#263641',.5)
  for j in range(9):p.line([(170,240+j*31),(418,240+j*31)],'#263641',.5)
  chair(p,300,420,.85,'#8ba4b7');chair(p,890,420,1.25,'#a48a5e')
  p.line([(490,362),(710,362)],GOLD,1.3);p.poly([(710,362),(697,355),(697,369)],GOLD)
  p.text((300,153),v('left','设计'),45,BLUE);p.text((890,153),v('right','结果'),45,GOLD)
  p.text((640,553),headline,25,WHITE)
 elif kind=='book':
  book(p,420,363,.88)
  person(p,906,528,269,edge=BLUE,light=1)
  p.text((420,150),v('left','空白'),35,WHITE);p.text((906,150),v('right','可能'),35,WHITE)
  q=smooth((local-2)/3)
  for j in range(4):p.line([(448,306+j*24),(448+q*(66-j*8),297+j*24)],'#5c6257',1.1)
  p.text((640,570),headline,43,GOLD)
 elif kind=='labels':
  person(p,640,538,270,edge=BLUE,light=1)
  for j,(x,y,label) in enumerate([(305,240,v('labels',['标签一','标签二','标签三','标签四'])[0]),(950,240,v('labels',['标签一','标签二','标签三','标签四'])[1]),(325,435,v('labels',['标签一','标签二','标签三','标签四'])[2]),(950,435,v('labels',['标签一','标签二','标签三','标签四'])[3])]):
   delta=smooth((local-2)/4)*65
   x+=(-delta if x<640 else delta)
   p.rect((x-72,y-27,x+72,y+27),'#1b2732',outline='#6e6c5b',r=4)
   p.text((x,y),label,23,GOLD)
   p.line([(x+(-78 if x>640 else 78),y),(640+(70 if x>640 else -70),375)],'#48515a',1)
  p.text((640,140),headline,40,WHITE)
 elif kind=='doors':
  person(p,640,559,195,edge=BLUE,light=1)
  for j,x in enumerate([315,640,965]):
   p.rect((x-65,169,x+65,388),'#182431',outline='#8d9baa',width=1.3)
   intensity=.7 if j==1 else .28
   p.poly([(x-62,388),(x+62,388),(x+162,552),(x-162,552)],'#29303a')
   glow(im,x,320,GOLD if j==1 else BLUE,120,intensity)
   p.text((x,126),v('labels',['此处','彼处','未知'])[j],24,GOLD if j==1 else BLUE)
  p.text((640,75),headline,34,WHITE)
 elif kind=='pendulum':
  angle=math.sin(local*.8)*.25;lamp(p,640,255,angle,warm=True)
  person(p,640,574,190,edge=BLUE,light=.7)
  for x,word in [(270,v('left','可能')),(1010,v('right','不确定'))]:p.text((x,366),word,49,GOLD if x<640 else BLUE)
  p.text((640,132),v('heroWord','之间'),61,WHITE)
  p.line([(380,541),(900,541)],'#34404b',.7)
 elif kind=='mask':
  person(p,640,566,270,edge=BLUE,light=.8)
  # A theatrical mask moves away, revealing the same persistent person.
  x=640+smooth((local-2)/4)*230;y=318-smooth((local-2)/4)*20
  p.poly([(x-48,y-54),(x+48,y-54),(x+39,y+14),(x,y+47),(x-39,y+14)],'#b5aa8f')
  p.ellipse((x-27,y-19,x-8,y-10),'#26313b');p.ellipse((x+8,y-19,x+27,y-10),'#26313b')
  p.line([(x-17,y+13),(x+17,y+13)],'#26313b',2)
  p.text((320,281),v('left','听从众人'),25,'#a59b83');p.text((984,461),v('right','回到自己'),25,'#a59b83')
  p.text((640,146),headline,40,WHITE)
 elif kind=='limits':
  # A bounded room with an open segment is more accurate than unlimited power.
  p.poly([(300,490),(985,490),(855,540),(405,540)],'#1d2b37')
  for x in [350,450,550,750,850,950]:p.line([(x,220),(x,490)],'#3b4a57',6)
  p.line([(350,220),(950,220)],'#3b4a57',7)
  person(p,640,533,228,edge=BLUE,light=1)
  for x,word in [(280,v('labels',['边界','条件','处境'])[0]),(640,v('labels',['边界','条件','处境'])[1]),(1000,v('labels',['边界','条件','处境'])[2])]:p.text((x,159),word,27,'#9aa7b3')
  p.text((640,568),headline,31,GOLD)
 elif kind=='bridge':
  p.poly([(0,432),(425,432),(470,600),(0,600)],'#26333c');p.poly([(848,432),(1280,432),(1280,600),(800,600)],'#26333c')
  q=smooth(local/5)
  for j in range(12):
   if j/12<q:p.poly([(422+j*35,429),(450+j*35,429),(451+j*35,440),(423+j*35,440)],'#b89c66')
  x=lerp(360,900,smooth((local-2)/6));person(p,x,430,200,edge=BLUE,light=1)
  for j in range(3):p.line([(90,486+j*32),(390,486+j*32)],'#344651',.7)
  glow(im,964,310,GOLD,170,.25);p.text((640,143),headline,42,WHITE)
 elif kind=='garden':
  p.poly([(220,531),(1040,531),(1130,581),(130,581)],'#24332e')
  for j,(x,delay) in enumerate([(390,0),(640,1.4),(890,2.5)]):
   q=smooth((local-delay)/5);top=531-190*q
   p.line([(x,531),(x,top)],'#a9b999',3)
   p.poly([(x,lerp(531,441,q)),(x-51*q,lerp(531,393,q)),(x-44*q,lerp(531,449,q)),(x,lerp(531,469,q))],'#526b59')
   p.poly([(x,lerp(531,416,q)),(x+48*q,lerp(531,372,q)),(x+47*q,lerp(531,425,q)),(x,lerp(531,446,q))],'#758366')
   glow(im,x,top,GOLD,40,q*.6)
   p.text((x,583),v('labels',['尝试','照料','坚持'])[j],22,GOLD)
  p.text((640,164),headline,43,WHITE);dust(p,t,GOLD,24)
 elif kind=='others':
  for j,x in enumerate([320,640,960]):person(p,x,543,225,edge=BLUE if j==1 else '#9a9077',light=1)
  progress=smooth((local-1)/3)
  p.line([(330,387),(330+300*progress,387)],GOLD,1.5);p.line([(650,387),(650+300*progress,387)],GOLD,1.5)
  for j in range(9):
   x=330+((local*54+j*71)%620);p.ellipse((x-2,385,x+2,389),WHITE)
  p.text((640,150),headline,40,WHITE)
  p.text((640,585),v('subheading','彼此相连'),25,GOLD)

 elif kind=='cosmos':
  # Scale is a visual question, not a proof about value.
  for j in range(175):
   sx=60+(j*0.61803398875%1)*1160;sy=80+((j*97)%430)
   rr=.45+(j%5)*.2;p.ellipse((sx-rr,sy-rr,sx+rr,sy+rr),'#9ca9b5' if j%4 else '#ddd9c9')
  p.ellipse((435,172,845,582),None,'#334554',1)
  p.ellipse((490,227,790,527),'#172637',outline='#668499',width=1)
  p.line([(250,575),(1030,575)],'#3d4b56',1)
  person(p,640,574,92,edge=BLUE,light=1)
  p.text((640,129),headline,40,WHITE)
  p.text((640,598),v('subheading',''),19,GOLD)
 elif kind=='pedestal':
  q=smooth((local-1.4)/5)
  for j,x in enumerate([325,640,955]):
   height=180*(1-q*.75)
   p.poly([(x-65,520),(x+65,520),(x+52,520-height),(x-52,520-height)],'#2b3540')
   p.line([(x-52,520-height),(x+52,520-height)],GOLD,2)
   layer=Image.new('RGBA',(W,H));lp=Pen(layer)
   lp.text((x,249),v('labels',['目标','秩序','保证'])[j],32,GOLD)
   layer.putalpha(layer.getchannel('A').point(lambda a:int(a*(1-q))));im.paste(layer,(0,0),layer)
   for k in range(17):
    px=x+math.sin(k*5.1)*60+q*math.sin(k)*80;py=lerp(286,554,q)+(k%4)*6
    if q>.05:p.rect((px,py,px+2,py+3),GOLD)
  p.text((640,114),headline,43,WHITE)
 elif kind=='lantern':
  q=smooth((local-1)/5);x=lerp(470,655,q)
  p.line([(155,550),(1125,550)],'#3c4549',1)
  for j in range(9):
   if j/9<q:p.rect((450+j*53,554,482+j*53,560),'#667469')
  person(p,x,548,252,edge=BLUE,light=.8)
  lx=x+75;ly=375
  glow(im,lx,ly,GOLD,100+q*95,.8)
  p.rect((lx-19,ly-31,lx+19,ly+27),'#202b32',outline=GOLD,width=2,r=3)
  p.line([(lx-13,ly-31),(lx-10,ly-46),(lx+10,ly-46),(lx+13,ly-31)],GOLD,1.5)
  p.poly([(lx-3,ly+14),(lx-7,ly),(lx,ly-17),(lx+6,ly),(lx+3,ly+14)],'#eee2aa')
  p.text((640,151),headline,43,WHITE)
  p.text((640,585),v('subheading',''),23,GOLD)

 dust(p,t,BLUE,16)
 return im

def read_cues():
 cues=[]
 for s in DATA['scenes']:
  metadata=ROOT/s['metadata']
  words=[json.loads(l) for l in metadata.read_text(encoding='utf8').splitlines()] if metadata.exists() else []
  # Word offsets are from the synthesis service; punctuation is retained in the source script.
  source=s['text'];chunks=re.findall(r'[^，。？！：；]+[，。？！：；]?',source)
  chunks=[c for c in chunks if c.strip()]
  if words:
   wordstream=''.join(re.sub(r'[^\w\u4e00-\u9fff]','',w['text']) for w in words)
   index=0
   for chunk in chunks:
    clean=re.sub(r'[^\w\u4e00-\u9fff]','',chunk);end=index+len(clean);count=0;selected=[]
    for w in words:
     length=len(re.sub(r'[^\w\u4e00-\u9fff]','',w['text']))
     if count<end and count+length>index:selected.append(w)
     count+=length
    if selected:
     start=s['voiceStart']+selected[0]['offset']/1e7
     finish=s['voiceStart']+(selected[-1]['offset']+selected[-1]['duration'])/1e7+.12
     cues.append(dict(start=start,end=finish,text=chunk))
    index=end
  else:
   cursor=s['start']+.3
   for chunk in chunks:
    d=s['voiceDuration']*len(chunk)/len(source);cues.append(dict(start=cursor,end=cursor+d,text=chunk));cursor+=d
 return cues
CUES=read_cues()

def get_frame(t):
 scenes=DATA['scenes'];idx=max(i for i,s in enumerate(scenes) if s['start']<=t)
 s=scenes[idx];local=t-s['start'];im=scene_frame(s,local)
 # One consistent 650ms dissolve; time continues inside both scenes.
 if idx>0 and local<.65:
  previous=scenes[idx-1];old=scene_frame(previous,t-previous['start']);im=Image.blend(old,im,smooth(local/.65))
 p=Pen(im);header(p,s,t)
 for cue in CUES:
  if cue['start']<=t<cue['end']:
   text=cue['text'].rstrip('，。；：')
   lines=[text[i:i+31] for i in range(0,len(text),31)]
   for j,line in enumerate(lines):
    width=p.d.textlength(line,font=font(25));x=(W-width)/2;y=round((617+j*31)*S)
    p.d.text((x,y),line,font=font(25),fill=WHITE,stroke_width=2,stroke_fill='#0a1018')
   break
 fade=smooth(t/1.2)*smooth((DATA['duration']-t)/1.8)
 if fade<1:im=Image.blend(Image.new('RGB',(W,H),'#06090e'),im,fade)
 return im

def srt_time(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'

def main():
 (ROOT/'qa').mkdir(exist_ok=True)
 (ROOT/'subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{srt_time(c["start"])} --> {srt_time(c["end"])}\n{c["text"]}' for i,c in enumerate(CUES)),encoding='utf8')
 if '--preview' in sys.argv:
  samples=[]
  for s in DATA['scenes']:
   tm=s['start']+min(s['duration']*.55,6);im=get_frame(tm);im.save(ROOT/'qa'/f'scene-{s["index"]:02d}.jpg',quality=92);samples.append((s['index'],tm,im))
  sheet=Image.new('RGB',(1920,math.ceil(len(samples)/4)*320),'#0b1119');d=ImageDraw.Draw(sheet)
  for i,tm,im in samples:
   thumb=im.resize((480,270),Image.Resampling.LANCZOS);x=i%4*480;y=i//4*320;sheet.paste(thumb,(x,y));d.text((x+14,y+278),f'{i+1:02d} | {tm:.1f}s',font=ImageFont.truetype(font_path(False),23),fill='white')
  sheet.save(ROOT/'qa'/'contact-sheet.jpg',quality=94)
  print('Previews and subtitles ready',flush=True);return
 frames=math.ceil(DATA['duration']*FPS)
 args=[tool('ffmpeg'),'-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(ROOT/'silent.mp4')]
 proc=subprocess.Popen(args,stdin=subprocess.PIPE);start=time.time()
 for f in range(frames):
  proc.stdin.write(get_frame(f/FPS).tobytes())
  if f%(FPS*5)==0:print(f'Render {f/FPS:.0f}/{DATA["duration"]:.0f}s; {f/max(.1,time.time()-start):.1f} fps',flush=True)
 proc.stdin.close();code=proc.wait()
 if code:raise SystemExit(code)
 print('Video render complete',flush=True)
if __name__=='__main__':main()
