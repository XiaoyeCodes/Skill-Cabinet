# 运行、恢复与分发

## 环境

Python 3.10+、FFmpeg/ffprobe、Pillow、NumPy、edge-tts 和中文字体。Windows 默认宋体/微软雅黑；macOS 为 Songti/PingFang；Linux 为 Noto CJK。缺字体时提供本机可用的 CJK 字体，不捆绑系统商业字体。

用项目 .deps 或 --deps 提供 Python 包。脚本不修改全局 PATH、浏览器资料、Codex 配置或其他项目。TTS 首次合成会联网发送旁白；画面、音乐、渲染和检查在本地完成。不要描述为完全离线生成。

## 分阶段

1. check：检查配置、依赖、工具和字体。
2. prepare：逐段配音与词边界，测量实际时长，生成时间轴。
3. preview：关键帧与字幕；查看图像后继续。
4. audio：复用语音和时间轴，合成本地音乐与立体声混音。
5. render：确定性逐帧绘制，编码 silent.mp4。
6. finish：测量混音，两遍响度处理，合成 film.mp4。
7. qa：验证实际编码文件，导出每段首/中/末画面与响度结果。
8. export：封面、带章节的本地播放器、旁白说明、来源记录和源码包。

all 按上述顺序运行。build-state.json 保存输入签名；输入或代码变化会让阶段失效。不要把同名 MP4 存在当成可以复用的证据。语音以段落 id 和内容摘要命名，.partial 不算缓存；三次失败后停止，只在成功验证后原子提升缓存。

## 修正

改 episode.json 的旁白、标题或 visual，再运行 all。修改绘图逻辑时才改 renderer.py，触发全片重建。单段拼接优化仅用于明确的大型项目，不能破坏转场或帧数。

QA 报错时不宣称通过。即使自动检查通过，也要查看导出画面，检查中文缺字、标题压道具、字幕与底部线重叠等。运动与声音主观听感需要播放审核，不能用抽帧代替。

## 分发

目录包含 SKILL.md、agents/openai.yaml、scripts/、references/、assets/episodes/。ZIP 根目录保留 philosophy-video-studio/，便于解压到 ~/.codex/skills。可同时提供同内容 .skill 文件，说明是 ZIP 格式打包，不保证宿主支持一键导入。

排除 __pycache__、.deps、*.pyc、MP4、临时文件和凭据。真实测试输出属于独立项目。分发前运行 Skill Creator 的 quick_validate.py，再用真实新主题执行 check → prepare → preview → all，并检查 MP4。只报告做过的测试。
