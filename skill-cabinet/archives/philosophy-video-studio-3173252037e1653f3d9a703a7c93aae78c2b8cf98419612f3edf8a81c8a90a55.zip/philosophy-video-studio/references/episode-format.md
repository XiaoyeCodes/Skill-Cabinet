# episode.json 配置格式

可运行范例：assets/episodes/nihilism.json 和 existentialism.json。

| 顶层字段 | 含义 |
|---|---|
| title / topic | 完整片名 / 左上角短主题，topic 最多 8 个汉字 |
| shortTitle / tagline | 主题副标题 / 封面和播放器的一句话 |
| episodeNumber / eyebrow | 如 02 / NIHILISM |
| scope | 本片观点边界，写进制作说明 |
| sources | 对象数组：title、url、use；实际查阅的支持资料 |
| fps | 24 或 30；width/height 固定为 1920/1080 |
| intro / outro | 首句前和末句后的秒数，默认 1.2 / 2.0 |
| voice | voice、rate、pitch；Edge TTS 支持的值 |
| fonts | 可选 serif/sans 字体文件；相对路径基于项目目录 |
| palette | 可选 gold/blue 十六进制颜色 |
| music.chords | 可选 MIDI 音高数组的数组 |
| scenes | 按播放顺序排列的视觉叙事段落 |

每个场景：稳定 id（字母数字/横线/下划线）、name、narration、headline、kind；可选 pause（.2–5 秒）、accent（布尔）、visual（符号参数）。id 不能包含路径；缓存不依赖段落序号。修改 narration 或 voice 会生成新语音缓存。

| kind | 表现 | visual 参数 |
|---|---|---|
| room | 夜间客厅、独坐、疑问 | symbol、subheading |
| routine | 队列与重复日程 | labels，5 项 |
| crowd | 群像与中心人物 | labels，7 项 |
| title | 摆灯下主题与副标题 | subheading |
| chair | 蓝图到实物的比喻 | left、right |
| book | 空白书页与人物 | left、right |
| labels | 人物周围的标签 | labels，4 项 |
| doors | 三条方向 | labels，3 项 |
| pendulum | 相对概念与摆灯 | left、right、heroWord |
| mask | 面具离开人物 | left、right |
| limits | 边界与中间空隙 | labels，3 项 |
| bridge | 搭桥与前行 | 无 |
| garden | 三株生长的植物 | labels，3 项 |
| others | 三个人与连接线 | subheading |
| return | 回到客厅与书页 | 无 |
| ending | 客厅回环、粒子、收束 | heroWord（2–4 字）、subheading |
| cosmos | 星点、天体与小人物 | subheading；大小不是价值的逻辑证明 |
| pedestal | 基座与价值文字逐步崩解 | labels，3 项 |
| lantern | 人物携灯前行、路径显现 | subheading |

headline 是本场的屏幕重点，最多 18 个汉字；有些符号镜头将它放在副标题区域。visual 的短标签通常 2–6 字。主标题、旁白和 visual 都应是本期内容；场景类型是视觉语法，不自动提供哲学论点。

prepare.py 把实际音频时长、语音开始、场景起止和缓存路径写入 timeline.json。不要手改某个 start 来修字幕；改源配置后重建，让声画都读同一时间轴。不要在配置或 skill 中保存凭据、令牌或签名链接。
