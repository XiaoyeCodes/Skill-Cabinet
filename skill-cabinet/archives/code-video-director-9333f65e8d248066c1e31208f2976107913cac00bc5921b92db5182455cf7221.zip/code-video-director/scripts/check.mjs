import {createHash} from 'node:crypto';
import {options,openScene} from './render.mjs';

const scene=await openScene(options());
try {
  const {duration,subtitles,fonts}=scene.meta;
  if(fonts.some(f=>f.status!=='loaded'))throw Error('Some declared fonts are not loaded');
  for(const s of subtitles)if(!Number.isFinite(s.t0)||!Number.isFinite(s.t1)||s.t0<0||s.t1<=s.t0||s.t1>duration+.001)throw Error(`Invalid subtitle: ${s.text}`);
  const times=[0,duration*.38,duration*.72,duration-.05];
  const hash=async t=>{await scene.page.evaluate(t=>window.render(t),t);return createHash('sha256').update(await scene.page.screenshot({type:'png'})).digest('hex');};
  const expected=new Map();
  for(const t of times)expected.set(t,await hash(t));
  for(const t of [...times].reverse())if(await hash(t)!==expected.get(t))throw Error(`Non-deterministic frame at ${t}`);
  if(scene.errors.length)throw Error(scene.errors.join('\n'));
  console.log(JSON.stringify({status:'passed',duration,subtitles:subtitles.length,fonts,deterministicSamples:times}));
} finally {await scene.close();}
