"""Copy the self-contained animation starter into a new user project."""
import argparse
import json
import shutil
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project', type=Path)
    parser.add_argument('--title', default='把想法变成画面')
    parser.add_argument('--duration', type=float, default=12)
    parser.add_argument('--preset', choices=['living-screencast', 'kinetic-type'], default='living-screencast')
    args = parser.parse_args()
    if not 3 <= args.duration <= 3600:
        parser.error('duration must be between 3 and 3600 seconds')
    destination = args.project.resolve()
    if destination.exists():
        parser.error(f'target already exists: {destination}')
    skill = Path(__file__).resolve().parent.parent
    shutil.copytree(skill / 'assets' / 'starter', destination)
    if args.preset != 'living-screencast':
        shutil.copytree(skill / 'assets' / args.preset, destination, dirs_exist_ok=True)
    (destination / 'tools').mkdir()
    for name in ('render.mjs', 'check.mjs'):
        shutil.copy2(skill / 'scripts' / name, destination / 'tools' / name)
    config = json.loads((destination / 'scene.json').read_text(encoding='utf-8'))
    scale = args.duration / config['duration']
    config.update(title=args.title, duration=args.duration)
    for cue in config['cues']:
        cue['t'] = round(cue['t'] * scale, 4)
    for sub in config['subtitles']:
        sub['t0'] = round(sub['t0'] * scale, 4)
        sub['t1'] = round(sub['t1'] * scale, 4)
    for frame in config['camera']:
        frame['t'] = round(frame['t'] * scale, 4)
    (destination / 'scene.json').write_text(json.dumps(config, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    brief = dict(topic=args.title, audience='按用户需求确定', duration=args.duration, language='zh-CN',
                 preset=args.preset, output=dict(width=1920, height=1080, fps=30),
                 audio='none: starter preview only', source='original generic starter; fictional UI')
    (destination / 'brief.json').write_text(json.dumps(brief, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (destination / 'TREATMENT.md').write_text(
        '# ' + args.title + '\n\n技术演示预设：' + args.preset + '。\n\n'
        '制作用户主题时，先改写本文件、scene.json、scene.js 和界面样式。当前骨架无声音，无真实产品功能声明。\n', encoding='utf-8')
    print(f'Created {destination}')


if __name__ == '__main__':
    main()
