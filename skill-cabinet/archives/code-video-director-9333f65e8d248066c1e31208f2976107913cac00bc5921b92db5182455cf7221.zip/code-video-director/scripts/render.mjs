import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {spawn} from 'node:child_process';
import {once} from 'node:events';

export function options(argv=process.argv.slice(2)) {
  const value=(key,fallback)=>{const i=argv.indexOf(key);if(i<0)return fallback;if(!argv[i+1]||argv[i+1].startsWith('--'))throw Error(`Missing value for ${key}`);return argv[i+1];};
  const result={project:path.resolve(value('--project','.')),browser:value('--browser',process.env.PLAYWRIGHT_CHROME),playwright:value('--playwright',null),
    width:Number(value('--width','1920')),height:Number(value('--height','1080')),fps:Number(value('--fps','30')),
    out:path.resolve(value('--out','film.mp4')),audio:value('--audio',null),stills:value('--stills',null)};
  for(const k of ['width','height'])if(!Number.isInteger(result[k])||result[k]<16||result[k]>8192||result[k]%2)throw Error(`${k} must be an even integer, 16–8192`);
  if(!Number.isFinite(result.fps)||result.fps<=0||result.fps>120)throw Error('fps must be > 0 and <= 120');
  return result;
}

export async function openScene(o) {
  if(!fs.existsSync(path.join(o.project,'index.html')))throw Error('Project needs index.html');
  const require=createRequire(path.join(o.project,'package.json'));
  const modulePath=o.playwright?path.resolve(o.playwright):require.resolve('playwright-core');
  const api=createRequire(import.meta.url)(modulePath);
  const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.ttf':'font/ttf','.woff2':'font/woff2','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.mp4':'video/mp4','.wav':'audio/wav'};
  const server=http.createServer((req,res)=>{
    try {
      if(!/^127\.0\.0\.1(:\d+)?$/.test(req.headers.host||'')){res.writeHead(403).end();return;}
      const url=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
      const file=path.resolve(o.project,'.'+(url==='/'?'/index.html':url));
      const relative=path.relative(o.project,file);
      if(relative.startsWith('..')||path.isAbsolute(relative)){res.writeHead(403).end();return;}
      fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':(types[path.extname(file)]||'application/octet-stream')+'; charset=utf-8'}).end(data);});
    } catch {res.writeHead(400).end();}
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  let browser;
  try {
    browser=await api.chromium.launch({executablePath:o.browser||undefined,args:['--force-color-profile=srgb','--font-render-hinting=none']});
    const page=await browser.newPage({viewport:{width:o.width,height:o.height},deviceScaleFactor:1});
    const errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    page.on('response',r=>{if(r.status()>=400&&!r.url().endsWith('favicon.ico'))errors.push(`${r.status()} ${r.url()}`);});
    await page.goto(`http://127.0.0.1:${server.address().port}/`);
    await page.waitForFunction(()=>window.READY===true,null,{timeout:30000});
    if(errors.length)throw Error(errors.join('\n'));
    const meta=await page.evaluate(()=>({duration:window.DUR,subtitles:window.SUBS||[],events:window.EV||[],fonts:[...document.fonts].map(f=>({family:f.family,status:f.status}))}));
    if(!Number.isFinite(meta.duration)||meta.duration<=0)throw Error('window.DUR must be a positive finite number');
    return {page,meta,errors,close:async()=>{await browser.close();await new Promise(r=>server.close(r));}};
  } catch(error) {
    if(browser)await browser.close();await new Promise(r=>server.close(r));throw error;
  }
}

function exportTimeline(o,meta) {
  const outputDir=o.stills?o.out:path.dirname(o.out);
  fs.mkdirSync(outputDir,{recursive:true});
  const stamp=s=>{const ms=Math.round(s*1000);return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${String(Math.floor(ms/60000)%60).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`;};
  fs.writeFileSync(path.join(outputDir,'timeline.json'),JSON.stringify(meta,null,2));
  fs.writeFileSync(path.join(outputDir,'subtitles.srt'),meta.subtitles.map((s,i)=>`${i+1}\n${stamp(s.t0)} --> ${stamp(s.t1)}\n${s.text}\n`).join('\n'));
}

async function run() {
  const o=options();
  if(o.audio&&!fs.existsSync(path.resolve(o.audio)))throw Error('Audio file not found');
  const scene=await openScene(o);
  let ff,temporary,encoderDone,encoderClosed=false;
  try {
    exportTimeline(o,scene.meta);
    if(o.stills){
      const times=o.stills.split(',').map(Number);
      if(times.some(t=>!Number.isFinite(t)||t<0||t>scene.meta.duration))throw Error('Invalid still time');
      for(const t of times){await scene.page.evaluate(t=>window.render(t),t);await scene.page.screenshot({path:path.join(o.out,`frame-${t}.png`)});}
      if(scene.errors.length)throw Error(scene.errors.join('\n'));
      console.log(`Saved ${times.length} stills to ${o.out}`);return;
    }
    // Temp directory isolates partial output; only a completed file replaces the requested result.
    temporary=fs.mkdtempSync(path.join(path.dirname(o.out),'.render-'));
    const finalFile=path.join(temporary,'finished.mp4');
    const frames=Math.round(scene.meta.duration*o.fps),duration=frames/o.fps;
    const args=['-y','-v','error','-f','image2pipe','-framerate',String(o.fps),'-c:v','mjpeg','-i','pipe:0'];
    if(o.audio)args.push('-i',path.resolve(o.audio),'-map','0:v:0','-map','1:a:0','-af','apad','-c:a','aac','-b:a','192k');
    else args.push('-an');
    args.push('-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-t',String(duration),'-movflags','+faststart',finalFile);
    ff=spawn('ffmpeg',args,{stdio:['pipe','ignore','inherit']});
    ff.once('close',()=>{encoderClosed=true;});
    let failure;
    ff.on('error',e=>{failure=e;});
    ff.stdin.on('error',e=>{failure=e;});
    const finished=encoderDone=new Promise(resolve=>{ff.once('close',code=>resolve(code));ff.once('error',()=>resolve(-1));});
    for(let f=0;f<frames;f++) {
      if(failure)throw failure;
      await scene.page.evaluate(t=>window.render(t),f/o.fps);
      const buffer=await scene.page.screenshot({type:'jpeg',quality:95});
      if(!ff.stdin.write(buffer))await Promise.race([once(ff.stdin,'drain'),finished.then(()=>{throw Error('ffmpeg stopped before rendering finished');})]);
      if(f%90===0)console.log(`Rendered ${f}/${frames}`);
    }
    ff.stdin.end();
    const code=await finished;
    if(code!==0||failure)throw failure||Error(`ffmpeg exit ${code}`);
    if(scene.errors.length)throw Error(scene.errors.join('\n'));
    fs.renameSync(finalFile,o.out);
    console.log(`Saved ${o.out}; ${frames} frames, ${o.fps} fps; audio: ${o.audio?'provided mix':'none (silent)'}`);
  } finally {
    if(ff&&ff.pid&&!encoderClosed){ff.kill();await encoderDone;}
    await scene.close();
    if(temporary)fs.rmSync(temporary,{recursive:true,force:true});
  }
}

if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url)run().catch(e=>{console.error(e.message);process.exitCode=1;});
