export const clamp = (v,a=0,b=1) => Math.min(b,Math.max(a,v));
export const ease = v => {const x=clamp(v);return x*x*(3-2*x);};
export const lerp = (a,b,t) => a+(b-a)*t;
export const phase = (t,a,b) => clamp((t-a)/(b-a));
export const snap = x => Math.round(x*2)/2;

export function cameraAt(keys,t,w,h) {
  const index=keys.findIndex(k=>k.t>t);
  const a=index===0?keys[0]:index<0?keys.at(-1):keys[index-1];
  const b=index<0?a:keys[index];
  const u=a===b?0:ease(phase(t,a.t,b.t));
  const z=Math.max(1,lerp(a.z,b.z,u));
  return {z,x:clamp(lerp(a.x,b.x,u),w/(2*z),w-w/(2*z)),y:clamp(lerp(a.y,b.y,u),h/(2*z),h-h/(2*z))};
}

export function anchor(element,camera,viewport,scale,w,h,fx=.5) {
  const rect=element.getBoundingClientRect(),v=viewport.getBoundingClientRect();
  return {x:((rect.left+rect.width*fx-v.left)/scale-w/2)/camera.z+camera.x,
          y:((rect.top-v.top)/scale-h/2)/camera.z+camera.y};
}

export function jump(a,b,t,start,end,height=115) {
  const u=phase(t,start,end),v=ease(u);
  return {x:lerp(a.x,b.x,v),y:lerp(a.y,b.y,v)-Math.sin(Math.PI*u)*height};
}

export function jumpScale(t,start,end) {
  if(t>=start-.14&&t<start){const k=Math.sin(phase(t,start-.14,start)*Math.PI);return [1+.16*k,1-.25*k];}
  if(t>=start&&t<end){const k=Math.sin(phase(t,start,end)*Math.PI);return [1-.1*k,1+.14*k];}
  const d=t-end;
  if(d>=0&&d<.35){const k=Math.cos(d*30)*Math.exp(-d*12);return [1+.2*k,1-.25*k];}
  return [1,1];
}

// Original robot sprite. All components use the same square grid.
export function sprite(t,color) {
  const blink=Math.sin(t*1.73)>.985||Math.sin(t*.91+2.1)>.997;
  const cells=[[3,0,2,1],[1,2,8,5],[0,4,1,2],[9,4,1,2],[2,7,2,1],[6,7,2,1]];
  return `<svg width="80" height="64" viewBox="0 0 10 8" shape-rendering="crispEdges">${cells.map(([x,y,w,h])=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color}"/>`).join('')}<path d="M3 4h1v${blink ? 0.25 : 1}H3z M6 4h1v${blink ? 0.25 : 1}H6z" fill="#f7fff9"/><path d="M4 6h2" stroke="#12493f" stroke-width=".35"/></svg>`;
}
