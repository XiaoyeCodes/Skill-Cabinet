# 验证与交付

根据复杂度选检查，不为简单改字追加完整测试体系。

## 画面

渲染各章节关键帧；跳跃、点击、转场和主题变化附近多采样。检查可读、无缺字、重点不出画、角色脚底贴锚点、镜头不露出画布边缘。

同一时间从不同前置时间 seek 过去应得到相同画面。`tools/check.mjs --project . --browser <exe>` 检查乱序采样确定性、字体状态、时长和字幕范围，不代替内容与审美检查。

## 成片

```text
ffmpeg -v error -xerror -i film.mp4 -f null -
ffprobe -v error -count_frames -show_entries format=duration,size:stream=codec_name,width,height,r_frame_rate,nb_read_frames -of json film.mp4
ffmpeg -hide_banner -nostats -i film.mp4 -af ebur128=peak=true -vn -f null -
```

核对帧数和时长，完整解码通过；最后一条仅用于有声视频。混音可目标约 −14 LUFS，真峰值不高于 −1 dBTP；要求保留原轨时如实记录原值。旁白清楚、拟音不盖字、音乐无爆音；核对音画同步，不能只靠格式检查宣布全片质量通过。

只宣称执行过的检查。无法播放或听辨时说明采用的验证及其边界，不宣称已完整观看或试听。

## 交付文件

默认成片与可编辑工程。把实际构建命令、依赖、素材来源写进工程说明；按需给字幕、预览图、音轨与 verification 记录。

说清来源：代码重渲染、重新设计、原片音轨复用、素材混剪或模型生成。示例内容只称技术演示，不能冒充用户主题的完成片。

新片不自动继承参考片作者尾卡、品牌背书、配音或样本署名；实际用了哪些就记录哪些。
