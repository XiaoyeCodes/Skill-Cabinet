# 可执行制作骨架

## 新建工程

使用当前环境可用的 Python、Node 和 ffmpeg；不要假定 `python` 就是有依赖的解释器。

```text
python <skill-dir>/scripts/new_project.py <project-dir> --title "我的视频" --duration 12
python <skill-dir>/scripts/new_project.py <another-project-dir> --preset kinetic-type --title "动态排版" --duration 15
```

目标必须尚不存在，以免覆盖用户工作。创建 `brief.json`、`TREATMENT.md`、`scene.json`、`scene.js`、`motion.js`、`index.html`、`package.json` 和构建脚本副本。两个预设均为原创技术演示，无品牌资产、外部字体、配乐或旁白；活体录屏预设使用虚构界面，动态排版预设不含 UI 或角色。`brief.json` 记录需求，`scene.json` 是实现配置；改编后保持一致。修改工程不会写回已安装 skill。

工程内执行 `npm install` 安装 `playwright-core`。浏览器优先复用已安装 Chromium/headless-shell；指定真实路径。没有浏览器时再安装与 Playwright 匹配的 Chromium。

```text
node tools/render.mjs --project . --browser <chromium-executable> --stills 0,4.6,8.6,11 --out out/review
node tools/render.mjs --project . --browser <chromium-executable> --out film.mp4
```

可用 `--playwright <module-directory-or-entry>` 复用现有 `playwright-core` 安装。`--width 1080 --height 1920` 导出竖屏，但必须先为竖屏重新设计配置 designWidth/designHeight 和布局；改变尺寸不会自动重排。

默认 `--fps 30`。`--audio <mixed.wav>` 合并完成的音轨，短则补静音、长则截到动画时长；先确认不是误配。没有 `--audio` 输出明确的无声视频。`--stills` 只导出图片。

## 页面接口

```js
window.DUR = 12;
window.render = t => { /* 全部状态由 t 推导 */ };
window.SUBS = [{t0: 0, t1: 3.8, text: '一句字幕'}];
window.EV = [{t: 4.6, type: 'click'}];
window.READY = true; // 字体/素材准备完毕后
```

渲染器本地起 HTTP 服务，逐帧采样，导出 `timeline.json` 与 `.srt`，通过 ffmpeg 编码 H.264，混入音频时编码 AAC。结束时关闭浏览器和服务。复杂工程可用现有并发渲染器，勿同时写同一输出。

## 时间轴与音频

用配置 cues 作为共用事件源，旁白生成后更新 cue 和 SUBS。不要按字符数猜测已录旁白的词级位置。合成语音或音乐前检查当前工具能力并遵循宿主收费规则，skill 本身不附带模型或消费授权。

拟音由事件触发，离线混音，而非逐帧播放。用 ffmpeg 或可用音频库合成音轨，再用 `--audio` 合并。品牌名、数字和多语言需要听辨实际发音。

## 跨平台经验

- PowerShell 调用含空格的可执行文件用调用运算符和独立参数，不拼接 shell 字符串。
- 源码可能使用 Unix `.venv/bin/python`、`sh` 与硬编码路径；在工程内适配，不改共享工具库。
- browser 文件必须存在，字体必须加载。系统字形和浏览器版本可能造成细微差异，不声称像素级一致。
- 下载参考片用于检查或经用户要求复用；不要把下载原片说成重新制作画面。
