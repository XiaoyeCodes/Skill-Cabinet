"""Real per-line multilingual ASR, preserving raw output and stated aliases."""
import argparse,difflib,json,re
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('project');ap.add_argument('--model',default='small');a=ap.parse_args();p=Path(a.project).resolve()
    import numpy as np,soundfile as sf,soxr
    from faster_whisper import WhisperModel
    lines=json.loads((p/'lines.json').read_text(encoding='utf-8'));af=p/'asr-aliases.json';aliases=json.loads(af.read_text(encoding='utf-8')) if af.exists() else {}
    def norm(s,alias=False):
        s=re.sub(r'[^a-z0-9\u3400-\u9fff]','',s.lower())
        if alias:
            for k,v in aliases.items():s=s.replace(k,v)
        return s
    model=WhisperModel(a.model,device='cpu',compute_type='int8');report=[];words={}
    for row in lines:
        y,sr=sf.read(p/'voices'/f"{row['id']}.wav");y=y.mean(axis=1) if y.ndim>1 else y;y=soxr.resample(y,sr,16000);y=np.pad(y,(9600,9600)).astype('float32')
        lang=row.get('lang') or ('zh' if re.search(r'[\u3400-\u9fff]',row['text']) else 'en')
        segs,_=model.transcribe(y,language=lang,beam_size=5,word_timestamps=True,condition_on_previous_text=False,initial_prompt='以下是普通话的句子。' if lang=='zh' else None);segs=list(segs)
        raw=''.join(s.text for s in segs);want=row.get('asr',row['text']);score=difflib.SequenceMatcher(None,norm(want,True),norm(raw,True)).ratio();ok=score>=.92 if lang=='zh' else norm(want)==norm(raw)
        item={'id':row['id'],'language':lang,'expected':want,'rawASR':raw,'similarity':round(score,4),'pass':ok};report.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
        words[row['id']]=[(w.word,round(w.start-.6,3),round(w.end-.6,3)) for s in segs for w in s.words]
    result={'ok':all(x['pass'] for x in report),'model':a.model,'aliases':aliases,'lines':report};(p/'speech-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');(p/'voices/words.json').write_text(json.dumps(words,ensure_ascii=False),encoding='utf-8');raise SystemExit(0 if result['ok'] else 1)
if __name__=='__main__':main()
