"""Run selected real production stages, or print a mutation-free dry run."""
import argparse,json,math,os,re,subprocess,sys
from pathlib import Path
from runtime import find_lib,find_node,browser_path
HERE=Path(__file__).resolve().parent
STAGES=['voice','speech','export','audit','mix','render','mux','qc']
def call(args,**kw):
    return subprocess.run([str(x) for x in args],check=True,text=True,encoding='utf-8',errors='replace',**kw)
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--lib');ap.add_argument('--project',required=True);ap.add_argument('--node');ap.add_argument('--browser');ap.add_argument('--stage',choices=['all',*STAGES],default='all');ap.add_argument('--dry-run',action='store_true');ap.add_argument('--skip-voice',action='store_true');ap.add_argument('--skip-speech',action='store_true');ap.add_argument('--workers',type=int,default=3);a=ap.parse_args()
    p=Path(a.project).expanduser().resolve();lib=find_lib(a.lib,p);node=find_node(a.node)
    if not lib:raise ValueError('No library. Run runtime.py doctor/setup first.')
    if not node:raise ValueError('No runnable Node 20+. Use --node or runtime.py setup.')
    cfg=json.loads((p/'film.json').read_text(encoding='utf-8'));slug=cfg['slug']
    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',slug):raise ValueError('slug must be a safe lowercase hyphenated filename.')
    for k in ['width','height','fps','duration','bpm']:
        if not isinstance(cfg[k],(int,float)) or not math.isfinite(cfg[k]) or cfg[k]<=0:raise ValueError(f'Invalid {k}')
    if cfg['width']%2 or cfg['height']%2:raise ValueError('Video dimensions must be even.')
    if not 1<=a.workers<=6:raise ValueError('Use 1–6 workers.')
    selected=STAGES[:] if a.stage=='all' else [a.stage]
    selected=[s for s in selected if not(s=='voice' and a.skip_voice or s=='speech' and a.skip_speech)]
    env=os.environ.copy();env['PYTHONIOENCODING']='utf-8';env['PYTHONUTF8']='1'
    browser=a.browser or browser_path(lib,node)
    if browser:env['PLAYWRIGHT_CHROME']=str(Path(browser).resolve())
    out=p/'out';target=p/(slug+'.mp4');size=f"{cfg['width']}x{cfg['height']}"
    commands={
      'voice':[sys.executable,lib/'core/tts/tts_zh.py',p/'lines.json',p/'voices'],
      'speech':[sys.executable,HERE/'check_speech.py',p],
      'export':[node,HERE/'page-task.mjs',lib,p,'export'],
      'audit':[node,HERE/'page-task.mjs',lib,p,'audit'],
      'mix':[sys.executable,p/'mix.py'],
      'render':[node,lib/'core/render/video.mjs',p,'--fps',str(cfg['fps']),'--workers',str(a.workers),'--size',size,'--out',out/'video.mp4']}
    plan={'project':str(p),'lib':str(lib),'stages':selected,'commands':{s:[str(x) for x in commands[s]] if s in commands else f'{s}: ffmpeg/ffprobe, duration from film.json' for s in selected},'final':str(target)}
    if a.dry_run:print(json.dumps(plan,ensure_ascii=False,indent=2));return
    if any(s in selected for s in ['export','audit','render']) and not browser:raise ValueError('Chromium for this Playwright version is missing. Run runtime.py setup --install, or provide a tested --browser path.')
    out.mkdir(exist_ok=True);run={'plan':plan,'completed':[],'skippedVoice':a.skip_voice,'skippedSpeech':a.skip_speech}
    for stage in selected:
        print('Stage: '+stage,flush=True)
        if stage in commands:call(commands[stage],cwd=lib,env=env)
        elif stage=='mux':
            raw=call(['ffmpeg','-hide_banner','-i',out/'mix.wav','-af','loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json','-f','null','-'],capture_output=True).stderr
            (out/'loudness-pass1.log').write_text(raw,encoding='utf-8');x=json.loads(re.findall(r'\{[\s\S]*?\}',raw)[-1])
            if any(not math.isfinite(float(x[k])) for k in ['input_i','input_tp','input_lra','input_thresh','target_offset']):raise ValueError('Mix is silent or cannot be measured; refusing a silent narrated film.')
            flt=f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={x['input_i']}:measured_TP={x['input_tp']}:measured_LRA={x['input_lra']}:measured_thresh={x['input_thresh']}:offset={x['target_offset']}:linear=true:print_format=json"
            r=call(['ffmpeg','-y','-hide_banner','-i',out/'video.mp4','-i',out/'mix.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-af',flt,'-ar','48000','-c:a','aac','-b:a','256k','-t',str(cfg['duration']),'-movflags','+faststart','-metadata','title='+cfg['title'],target],capture_output=True);(out/'mux.log').write_text(r.stderr,encoding='utf-8')
        elif stage=='qc':
            probe=json.loads(call(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',target],capture_output=True).stdout);(out/'ffprobe.json').write_text(json.dumps(probe,indent=2),encoding='utf-8')
            v=next(s for s in probe['streams'] if s['codec_type']=='video');streams=[s['codec_type'] for s in probe['streams']]
            if (v['width'],v['height'])!=(cfg['width'],cfg['height']) or abs(float(probe['format']['duration'])-cfg['duration'])>.1 or int(v['nb_read_frames'])!=round(cfg['fps']*cfg['duration']) or 'audio' not in streams:raise ValueError('Final dimensions, frame count, duration or audio stream failed.')
            r=call(['ffmpeg','-hide_banner','-i',target,'-vf','blackdetect=d=0.1:pix_th=0.05','-af','ebur128=peak=true','-f','null','-'],capture_output=True);(out/'final-qc.log').write_text(r.stderr,encoding='utf-8')
            tail=r.stderr.rsplit('Summary:',1)[-1];i=re.search(r'I:\s*(-?[\d.]+) LUFS',tail);pk=re.search(r'Peak:\s*(-?[\d.]+) dBFS',tail)
            if 'black_start:' in r.stderr or not i or not pk or abs(float(i[1])+14)>1 or float(pk[1])>-1:raise ValueError('Black-frame/loudness/peak check failed. Inspect final-qc.log.')
        run['completed'].append(stage);(p/'production-run.json').write_text(json.dumps(run,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'completed':run['completed'],'final':str(target) if target.exists() else None},ensure_ascii=False,indent=2))
if __name__=='__main__':
    try:main()
    except (ValueError,OSError,subprocess.CalledProcessError) as e:print(str(e),file=sys.stderr);sys.exit(1)
