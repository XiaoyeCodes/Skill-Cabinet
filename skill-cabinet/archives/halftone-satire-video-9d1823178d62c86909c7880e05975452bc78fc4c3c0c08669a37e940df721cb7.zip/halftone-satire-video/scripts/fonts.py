"""Refresh self-hosted OFL subsets after script or headline edits."""
import argparse,json,re,urllib.parse,urllib.request
from pathlib import Path
FAMILIES=[('Noto Serif SC',900,'serif'),('Noto Sans SC',900,'sans'),('Bagel Fat One',400,'fat'),('JetBrains Mono',800,'mono')]
def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 Chrome/130.0.0.0 Safari/537.36'})
    with urllib.request.urlopen(req,timeout=45) as r:return r.read()
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('project');a=ap.parse_args();p=Path(a.project).resolve();source=''
    for f in p.iterdir():
        if f.suffix in {'.js','.json','.html','.txt'}:
            s=f.read_text(encoding='utf-8');source+=s
            if f.suffix=='.json':source+=json.dumps(json.loads(s),ensure_ascii=False)
    chars=''.join(sorted(set(re.findall(r'[\u3400-\u9fff]',source))))+'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,?!/·？。，、（）＋－≠ :;\'" '
    rules=[];(p/'fonts').mkdir(exist_ok=True)
    for name,weight,stem in FAMILIES:
        query=urllib.parse.urlencode({'family':f'{name}:wght@{weight}','text':chars});css=get('https://fonts.googleapis.com/css2?'+query).decode()
        urls=re.findall(r'url\(([^)]+)\)',css)
        if len(urls)!=1:raise ValueError(f'Expected one text subset for {name}, got {len(urls)}')
        url=urls[0].strip('"\' ')
        if urllib.parse.urlparse(url).hostname!='fonts.gstatic.com':raise ValueError('Unexpected font host')
        payload=get(url)
        if payload[:4] not in {b'wOF2',b'wOFF',b'\x00\x01\x00\x00'}:raise ValueError('Not a font response')
        (p/f'fonts/{stem}.woff2').write_bytes(payload)
        rules.append(f'@font-face{{font-family:"{name}";font-style:normal;font-weight:{weight};font-display:block;src:url("fonts/{stem}.woff2")}}')
    (p/'fonts.css').write_text('\n'.join(rules)+'\n',encoding='utf-8');print('Updated four local OFL font subsets.')
if __name__=='__main__':main()
