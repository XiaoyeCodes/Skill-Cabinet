"""Initialize editable source; no rendering, TTS, or existing-file overwrite."""
import argparse,json,re,shutil
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True);ap.add_argument('--topic',default='调侃 Claude 封号');a=ap.parse_args();p=Path(a.output).expanduser().resolve()
    if p.exists() and (not p.is_dir() or any(f.name!='TREATMENT.md' for f in p.iterdir())):raise ValueError(f'Refusing to overwrite a nonempty project: {p}')
    p.mkdir(parents=True,exist_ok=True);source=Path(__file__).resolve().parents[1]/'assets/claude-example';shutil.copytree(source,p,dirs_exist_ok=True)
    slug=re.sub(r'[^a-z0-9-]+','-',p.name.lower()).strip('-') or 'satire-video'
    config={'title':'Claude 封号奇遇记','topic':a.topic,'slug':slug,'width':1080,'height':1920,'fps':30,'duration':30.0,'bpm':120,'musicSeed':9381,'silences':[[6.82,7.1],[11.65,12.3],[20.45,20.8],[26.86,27.15]],'sourceRevision':'413a6bd6d78ebd3bdd5abaec9538a26867f890df'}
    (p/'film.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    (p/'asr-aliases.json').write_text(json.dumps({'封控':'风控','识区':'时区','实区':'时区','又疯了':'又封了'},ensure_ascii=False,indent=2),encoding='utf-8')
    shutil.copy2(Path(__file__).with_name('mix.py'),p/'mix.py');(p/'voices').mkdir();(p/'out').mkdir()
    lines=json.loads((p/'lines.json').read_text(encoding='utf-8'));(p/'SCRIPT.txt').write_text('\n\n'.join(x['text'] for x in lines)+'\n',encoding='utf-8')
    print(json.dumps({'project':str(p),'topic':a.topic,'next':'Edit story, film.js, lines.json and film.json before production. No media generated.'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
