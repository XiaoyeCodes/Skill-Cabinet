"""Discover or install the private Lemo runtime. Doctor never writes files."""
import argparse,json,os,re,shutil,subprocess,sys
from pathlib import Path
REV='413a6bd6d78ebd3bdd5abaec9538a26867f890df'
URL='https://github.com/lemomo-ai/lemo-opuscar.git'
CACHE=Path(os.environ.get('HALFTONE_VIDEO_CACHE',str(Path.home()/'.cache/halftone-satire-video'))).expanduser()
def run(argv,**kw):
    return subprocess.run([str(x) for x in argv],check=True,text=True,encoding='utf-8',errors='replace',**kw)
def valid_lib(p):
    return all((p/s).is_file() for s in ['package.json','core/render/page.mjs','core/render/video.mjs','core/tts/tts_zh.py','styles/halftone-dossier/STYLE.md'])
def find_lib(explicit=None,search_root=None):
    if explicit:
        p=Path(explicit).expanduser().resolve()
        if not valid_lib(p):raise ValueError(f'Not a compatible Lemo library: {p}')
        return p
    candidates=[]
    if os.environ.get('LEMO_OPUSCAR_LIB'):candidates.append(Path(os.environ['LEMO_OPUSCAR_LIB']))
    root=Path(search_root or Path.cwd()).resolve()
    for p in [root,*list(root.parents)[:4]]:candidates.extend([p,p/'lemo-opuscar'])
    candidates.extend([Path.home()/'lemo-opuscar',CACHE/'lemo-opuscar'])
    return next((p.resolve() for p in candidates if valid_lib(p)),None)
def version(exe):
    try:return run([exe,'--version'],capture_output=True).stdout.strip().splitlines()[0]
    except (OSError,subprocess.SubprocessError,IndexError):return ''
def find_node(explicit=None):
    if explicit:
        if not version(explicit):raise ValueError(f'Node is not runnable: {explicit}')
        return str(Path(explicit).resolve()) if Path(explicit).is_file() else explicit
    base=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin'
    found=[]
    for p in dict.fromkeys(x for x in [shutil.which('node'),str(base/'node.exe'),str(base/'node')] if x):
        m=re.search(r'v?(\d+)\.(\d+)\.(\d+)',version(p))
        if m and int(m[1])>=20:found.append((tuple(map(int,m.groups())),p))
    return max(found)[1] if found else None
def venv_python():return CACHE/'venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
def browser_path(lib,node):
    override=os.environ.get('PLAYWRIGHT_CHROME')
    if override and Path(override).is_file():return override
    if not lib or not node:return None
    code="const{createRequire}=require('node:module');let r=createRequire(process.argv[1]);console.log(r('playwright-core').chromium.executablePath());"
    try:
        p=run([node,'-e',code,str(lib/'package.json')],capture_output=True).stdout.strip()
        if Path(p).is_file():return p
    except (OSError,subprocess.SubprocessError):pass
    try:
        entries=json.loads((lib/'node_modules/playwright-core/browsers.json').read_text(encoding='utf-8'))['browsers']
        revision=next(x['revision'] for x in entries if x['name']=='chromium-headless-shell')
        roots=[Path.home()/'AppData/Local/ms-playwright',Path.home()/'.cache/ms-playwright',Path.home()/'Library/Caches/ms-playwright']
        override=os.environ.get('PLAYWRIGHT_BROWSERS_PATH')
        if override:roots.insert(0,lib/'node_modules/playwright-core/.local-browsers' if override=='0' else Path(override))
        for base in roots:
            folder=base/f'chromium_headless_shell-{revision}'
            for name in ['chrome-headless-shell.exe','chrome-headless-shell']:
                hit=next((p for p in folder.rglob(name) if p.is_file()),None) if folder.exists() else None
                if hit:return str(hit)
    except (OSError,ValueError,KeyError,StopIteration):pass
    return None
def diagnose(lib,node):
    py=venv_python() if venv_python().is_file() else Path(sys.executable)
    code="import importlib.util,json;print(json.dumps({s:importlib.util.find_spec(s) is not None for s in ['numpy','scipy','soundfile','edge_tts','faster_whisper','soxr']}))"
    try:packages=json.loads(run([py,'-c',code],capture_output=True).stdout)
    except (OSError,subprocess.SubprocessError,ValueError):packages={}
    return {'lib':str(lib) if lib else None,'verifiedBaseRevision':REV,'node':node,'nodeVersion':version(node) if node else None,'python':str(py),'pythonVersion':version(py),'ffmpeg':shutil.which('ffmpeg'),'ffprobe':shutil.which('ffprobe'),'git':shutil.which('git'),'browser':browser_path(lib,node),'pythonPackages':packages,'cache':str(CACHE)}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('action',choices=['doctor','setup']);ap.add_argument('--lib');ap.add_argument('--node');ap.add_argument('--search-root');ap.add_argument('--fetch',action='store_true');ap.add_argument('--install',action='store_true');a=ap.parse_args()
    lib=find_lib(a.lib,a.search_root);node=find_node(a.node)
    if a.action=='setup':
        if not lib:
            if not a.fetch:raise ValueError('No library found. Use setup --fetch to clone into the private cache.')
            if not shutil.which('git'):raise ValueError('Git is missing.')
            lib=CACHE/'lemo-opuscar'
            if lib.exists():raise ValueError(f'Preserve the unusable existing cache and choose HALFTONE_VIDEO_CACHE elsewhere: {lib}')
            CACHE.mkdir(parents=True,exist_ok=True)
            run(['git','clone','--filter=blob:none','--sparse',URL,lib])
            run(['git','-C',lib,'sparse-checkout','set','core','styles/halftone-dossier'])
            run(['git','-C',lib,'checkout','--detach',REV])
        if a.install:
            if not node:raise ValueError('Node 20+ is missing.')
            for x in ['ffmpeg','ffprobe']:
                if not shutil.which(x):raise ValueError(f'{x} is missing; system tools were not installed.')
            if not (lib/'node_modules/playwright-core/cli.js').is_file():
                npm=Path(node).parent/('npm.cmd' if os.name=='nt' else 'npm');npm=str(npm) if npm.is_file() else shutil.which('npm')
                if not npm:raise ValueError('npm is missing.')
                run([npm,'ci'],cwd=lib)
            if not browser_path(lib,node):run([node,lib/'node_modules/playwright-core/cli.js','install','chromium'])
            if not venv_python().is_file():run([sys.executable,'-m','venv',CACHE/'venv'])
            run([venv_python(),'-m','pip','install','numpy>=1.26,<3','scipy>=1.11,<2','soundfile>=0.12,<1','edge-tts>=7.2,<8','faster-whisper>=1.1,<2','soxr>=0.5,<2'])
    print(json.dumps(diagnose(lib,node),ensure_ascii=False,indent=2))
if __name__=='__main__':
    try:main()
    except (ValueError,OSError,subprocess.CalledProcessError) as e:print(str(e),file=sys.stderr);sys.exit(1)
