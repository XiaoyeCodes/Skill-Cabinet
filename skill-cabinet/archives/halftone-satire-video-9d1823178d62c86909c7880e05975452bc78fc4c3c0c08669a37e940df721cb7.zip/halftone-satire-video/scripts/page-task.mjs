import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {pathToFileURL} from 'node:url';
const [libArg,projectArg,mode='export']=process.argv.slice(2);
if(!libArg||!projectArg||!['export','audit'].includes(mode))throw new Error('Usage: node page-task.mjs LIB PROJECT export|audit');
const lib=path.resolve(libArg),project=path.resolve(projectArg),cfg=JSON.parse(fs.readFileSync(path.join(project,'film.json'),'utf8'));
const {openDemo,closeServer}=await import(pathToFileURL(path.join(lib,'core/render/page.mjs')).href);
const {page,browser}=await openDemo(project,{w:cfg.width,h:cfg.height});
try{
 const data=await page.evaluate(()=>({duration:window.DUR,voices:window.VOICE_CUES,events:window.EV}));
 if(Math.abs(data.duration-cfg.duration)>.01)throw new Error('film.json duration disagrees with window.DUR. Update both before production.');
 if(!Array.isArray(data.voices)||!Array.isArray(data.events))throw new Error('Missing VOICE_CUES / EV.');
 if(mode==='export'){
  function stamp(t){let ms=Math.round(t*1000),s=Math.floor(ms/1000);return `${String(Math.floor(s/3600)).padStart(2,'0')}:${String(Math.floor(s/60)%60).padStart(2,'0')}:${String(s%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`}
  let previous=0;for(const v of data.voices){if(v.t<previous||v.end<=v.t||v.end>cfg.duration)throw new Error('Invalid or overlapping subtitle cues.');previous=v.end;if(!Array.isArray(v.sub)||v.sub.length>2)throw new Error('Each cue needs one or two subtitle lines.');}
  fs.writeFileSync(path.join(project,'cues.json'),JSON.stringify(data,null,2));
  fs.writeFileSync(path.join(project,cfg.slug+'.srt'),data.voices.map((v,i)=>`${i+1}\n${stamp(v.t)} --> ${stamp(v.end)}\n${v.sub.join('\n')}\n`).join('\n'));
  const lines=JSON.parse(fs.readFileSync(path.join(project,'lines.json'),'utf8'));fs.writeFileSync(path.join(project,'SCRIPT.txt'),lines.map(v=>v.text).join('\n\n')+'\n');console.log('Exported cues and SRT.');
 }else{
  const issues=[],samples=[0,.8,...data.voices.flatMap(v=>[v.t+.3,(v.t+v.end)/2,v.end-.04]),cfg.duration-.03];
  const repeat=Math.min(cfg.duration-1,9.6);samples.push(repeat,2,repeat);const hashes=[];
  for(const t of samples){
   await page.evaluate(t=>window.render(t),t);
   const found=await page.evaluate(({w,h})=>{
    const caps=[...document.querySelectorAll('#captions > g')].filter(e=>getComputedStyle(e).display!=='none');let out=[];
    if(caps.length>1)out.push({code:'overlapping_captions'});
    for(const e of caps){let b=e.getBoundingClientRect();if(b.left<w*.08||b.right>w*.92||b.top<h*.76||b.bottom>h*.95)out.push({code:'caption_outside_safe',box:{x:b.x,y:b.y,w:b.width,h:b.height}})}
    return out;
   },{w:cfg.width,h:cfg.height});issues.push(...found.map(x=>({...x,t})));
   const bytes=await page.screenshot({type:'png'});hashes.push({t,hash:crypto.createHash('sha256').update(bytes).digest('hex')});
  }
  const same=hashes.filter(x=>x.t===repeat);const deterministic=same[0].hash===same.at(-1).hash;if(!deterministic)issues.push({code:'nondeterministic_seek'});
  const result={ok:issues.length===0,size:[cfg.width,cfg.height],duration:cfg.duration,samples:samples.length,repeatFrameIdentical:deterministic,findings:issues};fs.writeFileSync(path.join(project,'audit.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));if(!result.ok)process.exitCode=1;
 }
}finally{await browser.close();closeServer()}
