"""Project-local original score, synchronized foley, VO ducking and stems."""
from pathlib import Path
import importlib.util,json,math,subprocess
import numpy as np
import soundfile as sf
from scipy.signal import butter,resample_poly,sosfilt
P=Path(__file__).resolve().parent;cfg=json.loads((P/'film.json').read_text(encoding='utf-8'));meta=json.loads((P/'cues.json').read_text(encoding='utf-8'))
spec=importlib.util.spec_from_file_location('synth',P/'instruments.py');S=importlib.util.module_from_spec(spec);spec.loader.exec_module(S)
SR=S.SR;DUR=float(cfg['duration']);N=round(DUR*SR);S.N=N;S.L=np.zeros(N);S.R=np.zeros(N);S.rng=np.random.default_rng(cfg.get('musicSeed',9381));rng=np.random.default_rng(cfg.get('musicSeed',9381))
O=P/'out';O.mkdir(exist_ok=True);beat=60/cfg['bpm'];bar=beat*4
# Original Claude adaptation's D-minor palette, repeated or replaced for this story.
chords=cfg.get('chords',[[50,57,62],[53,60,65],[48,55,60],[45,52,57],[46,53,58],[43,50,55]])
motif=cfg.get('motif',[74,77,81,76,74,69,72,76])
for k in range(math.ceil(DUR/bar)):
    base=k*bar;notes=chords[k%len(chords)];phase=base/DUR;mode='sneak' if .40<=phase<.68 else 'end' if phase>.86 else 'full'
    for j in range(4):
        t=base+j*beat
        if t>=DUR:break
        if mode=='full':S.add(S.kick(),t,.13 if j%2==0 else .07);S.add(S.hat(),t+beat/2,.075,pan=.2)
        if j%2:S.add(S.snap() if mode=='sneak' else S.snare(),t,.085,pan=-.13)
        S.add(S.bass(notes[j%len(notes)],.18),t,.11)
        if mode!='end':
            pitch=motif[(k*3+j)%len(motif)];S.add(S.pizz(pitch,.2) if mode=='sneak' else S.pluck(pitch,.3,.7),t+beat/2,.10,pan=(-.2 if j%2 else .2))
    if mode=='end':
        for j,pitch in enumerate([74,77,81]):S.add(S.bell(pitch,1.4),base+j*.3,.09,pan=(j-1)*.2)
music=np.stack([S.L.copy(),S.R.copy()],axis=1);S.L[:]=0;S.R[:]=0
for e in meta['events']:
    typ=e['type'];t=e['t'];gain=e.get('gain',1);pan=e.get('pan',0)
    if typ=='stamp':S.add(S.stamp(big=e.get('big',t>DUR*.66)),t,gain*(.40 if t>DUR*.66 else .29),pan=pan)
    elif typ=='paper':S.add(S.whoosh(.28),t,.12*gain,pan=pan)
    elif typ=='whoosh':S.add(S.whoosh(.45),t,.16*gain,pan=pan)
    elif typ=='pop':S.add(S.pop(700),t,.17*gain,pan=pan)
    elif typ=='alarm':
        for j in range(2):S.add(S.bell(72+j*6,.22),t+j*.16,.16*gain,pan=pan)
    else:raise ValueError(f'Unimplemented sound event: {typ}')
sfx=np.stack([S.L.copy(),S.R.copy()],axis=1);voice=np.zeros((N,2));duck=np.ones(N);records=[];previous_end=0
for v in sorted(meta['voices'],key=lambda x:x['t']):
    src=P/'voices'/f"{v['id']}.wav";tempo=v.get('tempo',1)
    if not .75<=tempo<=1.35:raise ValueError('Extreme post-speed is not a fix for an overlong line; rewrite or retime it.')
    if tempo!=1:
        target=O/f"{v['id']}-timed.wav";subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(src),'-af',f'atempo={tempo}',str(target)],check=True);src=target
    y,sr=sf.read(src,dtype='float64');y=y.mean(axis=1) if y.ndim==2 else y;g=math.gcd(SR,sr);y=resample_poly(y,SR//g,sr//g)
    end=v['t']+len(y)/SR
    if end>DUR+.01 or end>v['end']+.04:raise ValueError(f"Speech {v['id']} overflows its caption/film. Retime or shorten it; no audio was clipped.")
    if v['t']<previous_end-.02:raise ValueError(f"Overlapping narration at {v['id']}")
    previous_end=end;y=np.tanh(y*2.2)/1.6;y*=.14/max(float(np.sqrt(np.mean(y*y))),.001)
    i=round(v['t']*SR);voice[i:i+len(y)]+=y[:,None];a=max(0,i-round(.11*SR));b=min(N,i+len(y)+round(.20*SR));duck[a:b]=np.minimum(duck[a:b],.29)
    records.append({'id':v['id'],'start':v['t'],'speechEnd':round(end,3),'captionEnd':v['end'],'captionTail':round(v['end']-end,3)})
gate=np.ones(N)
for a,b in cfg.get('silences',[]):gate[max(0,round(a*SR)):min(N,round(b*SR))]=.015
music*=duck[:,None]*gate[:,None];room=sosfilt(butter(2,1700,fs=SR,output='sos'),rng.standard_normal((N,2)),axis=0)*.0008
mix=voice+music+sfx+room;fade=np.clip(np.arange(N)/SR/.03,0,1)*np.clip((DUR-np.arange(N)/SR)/.22,0,1);mix*=fade[:,None];mix*=min(1,.92/max(float(np.abs(mix).max()),.001))
for name,y in [('mix',mix),('voice',voice),('music',music),('sfx',sfx)]:sf.write(O/f'{name}.wav',y,SR,subtype='PCM_24')
(O/'voice-timing.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'duration':DUR,'peak':float(np.abs(mix).max()),'voices':len(records)},indent=2))
