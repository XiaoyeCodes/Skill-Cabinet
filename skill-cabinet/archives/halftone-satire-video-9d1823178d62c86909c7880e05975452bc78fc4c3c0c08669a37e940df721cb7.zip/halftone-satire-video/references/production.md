# 可执行接口

## 路径与运行时

helpers 可从任意目录运行，`--lib`、`--project` 用实际绝对路径。`runtime.py doctor` 只读；`setup --fetch --install` 首次在独立缓存克隆 https://github.com/lemomo-ai/lemo-opuscar 的已验证版本 `413a6bd6d78ebd3bdd5abaec9538a26867f890df`。已有 checkout 不更新、不重置。

依赖安装在缓存 venv 后，用 doctor 返回的 Python 启动 produce.py。`--node` 选择 Node 20+，`--browser` 或 PLAYWRIGHT_CHROME 选择 Chromium，否则由所选仓库 Playwright 缓存解析。无需视频生成 API 或 GPU；首次 npm、浏览器、Python 包、Whisper 模型和 TTS 需要网络。

## 项目合同

| 文件 | 用途 |
|---|---|
| film.json | title、slug、width、height、fps、duration、bpm、musicSeed、silences |
| index.html | SVG、纸张与颗粒 Canvas、本地字体、engine.js、film.js |
| engine.js | 绘图原语，当前示例 FPS=30、DUR=30，不需要旧项目 prepare.py |
| film.js | 故事和角色；暴露 READY、DUR、render(t)、EV、VOICE_CUES、TEXTS(t) |
| lines.json | id、text、voice、rate、pitch，可选 lang/asr；对应 voices/id.wav |
| cues.json | 从实际网页导出 duration、voices、events |
| asr-aliases.json | 有明确发音依据的同音归一；不能掩盖漏词错读，原始识别保留 |
| mix.py / instruments.py | 新乐曲编排、声画事件、旁白避让、分轨 |

字幕项为 `{id,t,end,sub:[第一行,第二行],tempo:1}`，最多两行。t 是开始，end 是字幕结束，tempo 是轻微变速。EV 支持 stamp、paper、whoosh、pop、alarm，可选 gain/pan/big。新事件须加对应合成，不静默丢音效。

## 修改时长时同步

1. engine.js 的 FPS / DUR。
2. film.js 的 cuts、hits、VO、scene 的 a/b、ACTIONS 内条件及 seg/pop/stamp 时间。
3. render() 末帧 clamp、深色区间，init() 的 window.DUR。
4. film.json 的 duration/fps/bpm/silences。不要另维护一份独立字幕时间轴。

先测语音再排镜头，缩短句子优先于过度加速。长旁白应延长场景。静音只影响配乐和氛围，不能剪旁白。旧 30 秒快节奏例子存在极短的“又封了”字幕，制作新片时按实际语音和阅读检查重新排。

## 阶段

`produce.py --lib LIB --project PROJECT --stage <阶段>`。voice 用 Microsoft TTS；speech 用本地 Whisper 自动选中英文；export 从真实网页取 cues 并生成 SRT；audit 用 DOM 几何与截图哈希检查；mix 合成音轨；render 调用原生逐帧渲染器；mux 两遍响度归一；qc 解码并测帧数、黑帧和响度。all 顺序运行以上全部。

`--dry-run` 只返回计划，不创建媒体。已有用户配音可 `--skip-voice`，WAV 命名仍按 id。`--skip-speech` 只用于明确的替代核对或依赖不可用，最终说明跳过，不能说通过。

用 `node LIB/core/render/still.mjs PROJECT <时刻> --size 1080x1920 --out PROJECT/review` 看画面；用 readcheck.mjs 检查实际阅读时间。每次调整字体、标题或构图后看真实帧，不靠文字正则判断视觉正确。

## 字体与封面

附带 OFL 字体是先前示例的子集。文字变化后运行 fonts.py 更新，脚本还会收集 JSON 转义字符。若下载不可用，可换同名字体的完整本地 OFL 文件，不让缺字静默回退。字体加载完成后才测逐字布局。

封面先取一个标题和主体清晰的帧，例如 `node .../still.mjs PROJECT 2.2 --out PROJECT/cover-review`，再按用户平台排标题。封面不能只交文件名占位。

交付 MP4、cover.jpg、SRT、SCRIPT.txt、STORY.md、TREATMENT.md、需要时的 FACTS.md、CREDITS.md 和可编辑源码。保留原始转写、时长、字卡/字幕检查与最终编码检查。用户明确不要成片时，不能用测试为由生成新片。
