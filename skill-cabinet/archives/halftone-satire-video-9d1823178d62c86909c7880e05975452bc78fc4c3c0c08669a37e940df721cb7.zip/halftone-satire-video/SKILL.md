---
name: halftone-satire-video
description: 制作“胖橘受审／胖橘案卷”同类的复古半调案卷喜剧短视频，适用于“帮我做一个调侃 Claude 封号的视频”、会员吐槽、产品讽刺和荒诞审判动画。自动完成故事、冷面配音、角色动画、印章、卡点剪辑、配乐音效、检查及 MP4 交付。用户只要脚本、制作或修改 skill 时，按该范围工作，不启动视频生产。
---

# 复古案卷喜剧视频

把小事拍成一本过分严肃的调查案卷。参考 Lemo Opuscar 的 **Halftone Dossier／复古半调案卷**，原演示为《胖橘案卷 Case File: Chubby》，位于 `styles/halftone-dossier/`。原演示无旁白，本技能新增冷面口播。

## 一句话启动

“帮我做一个调侃 Claude 封号的视频”已经足够。默认中文、约 30 秒、9:16、1080×1920、30 fps，冷面男声、烧录字幕，输出完整有声视频。自行决定缺少的创意偏好，不反复询问时长、声音、画幅和是否继续。用户明确的故事、规格和素材优先。

用户要制作 skill、只要文案或只改某项素材时，严格按该范围工作，不启动整片制作。

## 保留的风格

写镜头前读 [references/style.md](references/style.md)。主要约束如下。

- 暖奶油纸张、折痕颗粒、20–26 px 套印网点、深墨轮廓。平涂颜色，网点承担明暗，纸张与案卷装置贯穿全片。
- 大号粗宋体标题配错位套印影子；编号证物、审查表、档案夹。红色留给印章和警报。
- 角色有表情、呼吸、眨眼、挤压回弹及动作；道具承担笑点，不能交静态图片轮播。
- 30 fps 位移，约 10 fps 角色线条抖动，文本不套抖动滤镜。标题逐字弹入；点阵擦除切镜，重锤处可硬切，不溶解。
- 印章约 0.09 秒从 2.6 倍砸到原位，同帧有震动、适度闪光与音效。裁决前抽空音乐。
- 默认 Yunxi 中文冷面叙述；故事需要时才插英语或换声。用木琴拨音、方波低音、指弹和铃音，音乐自动避让口播。

## 故事与事实

在项目先写 `TREATMENT.md`，简列三个叙事方向并自行选一个，然后才打开示例镜头实现。通常用“期待 → 荒诞规则 → 补救 → 再失败 → 物理化反转”。无需沿用猫片的罪状结构。

Claude 主题可读 [references/claude-recipe.md](references/claude-recipe.md)，含先前用户指定的付款、盘问、情书申诉、戏剧化伪装、再次封号及反转。这是可改写的先前作品，换主题应重写故事、道具与场景，不只替换字卡名词。

未经核实的检测逻辑、邮件和身份判定标明“虚构讽刺／剧情演绎”，不冒充真实通知。事实性指控查当时的一手来源，记录在 `FACTS.md`。VPN、英语和时区在该故事中只作为戏服道具，不扩成规避教程。吐槽针对产品体验与公司做法，不攻击用户群体。

## 执行

`SKILL` 为本技能目录，`LIB` 为仓库，`PROJECT` 为新片目录。命令中的占位路径由实际路径替换，不写入原作者机器路径。

1. **环境。** 运行 `python SKILL/scripts/runtime.py doctor --search-root <工作区>`。优先复用正确的已有仓库，不更新、重置 checkout。缺仓库或依赖时用 `runtime.py setup --fetch --install --search-root <工作区>`；可指定 `--lib <路径>`。它返回 `lib/node/python/browser`，依赖装进独立缓存。缺系统工具时使用已有运行时或报告缺项，不改系统安装和其他项目配置。
2. **初始化。** 先写 treatment，再运行 `python SKILL/scripts/new_project.py --output PROJECT --topic <主题>`。非空项目拒绝覆盖，只允许已存在的 treatment。它复制可编辑 Claude 示例、字体和 MIT 原语，不包含 MP4、WAV 或缓存依赖。随后按本期故事编辑 `film.js`、`lines.json`、`film.json`、`STORY.md`。
3. **配音先测时。** 用 doctor 返回的 Python 运行 `produce.py --lib LIB --project PROJECT --stage voice`，再用 `--stage speech` 逐句核对中英文。保留原始转写，同音归一另写 `asr-aliases.json`。句子太长则改短、调整语速或延长镜头，不能截音频。TTS 失败尝试已连接的语音服务，没有有声方案时说明未完成，不把静音片冒充完成。
4. **画面与字体。** 读 [references/production.md](references/production.md) 的文件和时间轴接口，按故事修改角色动作。新文字出现后运行 `python SKILL/scripts/fonts.py PROJECT`。用 `node LIB/core/render/still.mjs PROJECT <关键时刻> --size 1080x1920 --out PROJECT/review` 检查实际画面，字幕安全区、印章落点及擦除均要看。
5. **合成检查。** `produce.py` 的 `export` 阶段导出 cues 和 SRT，`audit` 检查字幕和确定性，`mix` 生成新配乐、动作音效、旁白和分轨。共用真实页面导出的时间轴。目标字幕停留为语音加 0.6 秒，且足够阅读；不足时缩短句子或延长镜头，不能宣称示例天然符合所有阅读标准。
6. **导出。** 改完后运行 `python SKILL/scripts/produce.py --lib LIB --project PROJECT --node <路径> --stage all`。可先加 `--dry-run`，只列计划，不生成任何媒体。`render/mux/qc` 分别负责逐帧编码、两遍响度归一和最终解码检查。查看最终编码帧及动作，有问题修复后再导出。

修改时长必须同步 engine.js 的 DUR、film.js 的切点/事件/字幕/动作边界与 film.json，具体位置见 production.md。helper 不会把硬编码动作自动猜成新故事。

## 完成标准

交付有声 MP4、封面、SRT、完整口播/故事、源码和素材许可，优先展示实际视频。保留语音检查、真实帧数/尺寸/时长、响度峰值及黑帧检查证据；目标 −14 LUFS，真峰值不高于 −1 dBTP。程序检查不等于真人试听，不声称做过未做的主观检查。

没有用户素材时无需等待上传，自动推进可逆制作与修复。同一失败最多重试三次后换方案或报告依赖问题。“制作视频”不授权平台发布、发邮件、购买服务或修改真实账户。新片只写新项目，上游 core/styles 和既有作品保持原样，结束自己启动的服务。
