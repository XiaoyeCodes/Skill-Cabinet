// Drawing primitives adapted from Lemo-Opuscar, MIT; see CREDITS.
const NS = 'http://www.w3.org/2000/svg';
const C = {
  paper: '#FFF2D5', navy: '#14293B', blue: '#2E55D6', pink: '#FF5A87', yellow: '#FFC628',
  orange: '#F58A34', ored: '#D9621E', cream: '#FFF4E2', red: '#E8384F', night: '#18203F',
  night2: '#2A3568', skin: '#F7C9A1', mint: '#56C29E',
};
const F = {
  serif: "'Noto Serif SC'", cute: "'ZCOOL KuaiLe'", bagel: "'Bagel Fat One'",
  mono: "'JetBrains Mono', 'Noto Sans SC'", sans: "'Noto Sans SC'",
};
const FPS = 30, DUR = 30;

function el(tag, attrs = {}, parent) {
  const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}
function txt(parent, str, attrs) { const e = el('text', attrs, parent); e.textContent = str; return e; }
function tf(e, x = 0, y = 0, s = 1, r = 0, sy) {
  e.setAttribute('transform', `translate(${x.toFixed(2)} ${y.toFixed(2)}) rotate(${r.toFixed(2)}) scale(${s.toFixed(4)} ${(sy ?? s).toFixed(4)})`);
}
function op(e, o) { e.setAttribute('opacity', Math.max(0, Math.min(1, o)).toFixed(3)); }
function show(e, v) { e.style.display = v ? '' : 'none'; }

const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const seg = (t, a, b) => clamp((t - a) / (b - a));
const lerp = (a, b, p) => a + (b - a) * p;
const E = {
  out: p => 1 - Math.pow(1 - p, 3),
  in: p => p * p * p,
  io: p => p < .5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2,
  back: p => { const c = 1.9; return 1 + (c + 1) * Math.pow(p - 1, 3) + c * Math.pow(p - 1, 2); },
  elastic: p => p <= 0 ? 0 : p >= 1 ? 1 : Math.pow(2, -10 * p) * Math.sin((p * 10 - 0.75) * 2 * Math.PI / 3) + 1,
};
const pop = (t, t0, d = 0.35) => t < t0 ? 0 : E.back(seg(t, t0, t0 + d));
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

const mctx = document.createElement('canvas').getContext('2d');
function measure(str, size, family, weight = 900) { mctx.font = `${weight} ${size}px ${family}`; return mctx.measureText(str).width; }

// per-character text (can pop in char by char), optional misregistration shadow
function chars(parent, str, o) {
  const { x, y, size, family, weight = 900, fill = C.navy, anchor = 'start', ls = 0, shadow, stroke, sw = 0 } = o;
  const g = el('g', {}, parent);
  const arr = [...str];
  const widths = arr.map(c => measure(c, size, family, weight));
  const total = widths.reduce((a, b) => a + b, 0) + ls * (arr.length - 1);
  let cx = anchor === 'middle' ? x - total / 2 : anchor === 'end' ? x - total : x;
  const items = arr.map((ch, i) => {
    const cg = el('g', {}, g);
    const base = { x: 0, y: 0, 'font-size': size, 'font-family': family, 'font-weight': weight, 'text-anchor': 'middle' };
    if (shadow) txt(cg, ch, { ...base, x: shadow.dx, y: shadow.dy, fill: shadow.fill, class: 'mul' });
    const st = stroke ? { stroke, 'stroke-width': sw, 'paint-order': 'stroke', 'stroke-linejoin': 'round' } : {};
    txt(cg, ch, { ...base, fill, ...st });
    const it = { g: cg, x: cx + widths[i] / 2, y, w: widths[i], size };
    cx += widths[i] + ls;
    tf(cg, it.x, it.y);
    return it;
  });
  return { g, items, total };
}
// per-character animation: pop in (squash-and-rebound from below)
function charsPop(c, t, t0, stagger = 0.05, d = 0.38, from = 60) {
  c.items.forEach((it, i) => {
    const s = t0 + i * stagger;
    const p = seg(t, s, s + d);
    const h = it.size * 0.35;
    if (t < s) { op(it.g, 0); return; }
    op(it.g, 1);
    const sc = E.back(p);
    const sq = 1 + 0.25 * Math.sin(p * Math.PI) * (1 - p);
    it.g.setAttribute('transform', `translate(${it.x} ${it.y + from * (1 - E.out(p))}) translate(0 ${-h}) scale(${(sc / sq).toFixed(3)} ${(sc * sq).toFixed(3)}) translate(0 ${h})`);
  });
}
function charsIdle(c, t, amp = 4, spd = 3) {
  c.items.forEach((it, i) => tf(it.g, it.x, it.y + Math.sin(t * spd + i * 0.8) * amp));
}

// halftone dots: f(x,y) → 0..1 dot size
function halftone(parent, { x0 = 0, y0 = 0, w = 1080, h = 1920, step = 22, angle = 15, color, f, maxK = 0.62 }) {
  const a = angle * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
  const n = Math.ceil(Math.hypot(w, h) / step / 2) + 2;
  let d = '';
  for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
    const u = i * step, v = j * step;
    const x = x0 + w / 2 + u * ca - v * sa, y = y0 + h / 2 + u * sa + v * ca;
    if (x < x0 - step || x > x0 + w + step || y < y0 - step || y > y0 + h + step) continue;
    const s = clamp(f(x, y)); if (s < 0.05) continue;
    const r = s * step * maxK;
    d += `M${(x - r).toFixed(1)} ${y.toFixed(1)}a${r.toFixed(1)} ${r.toFixed(1)} 0 1 0 ${(2 * r).toFixed(1)} 0a${r.toFixed(1)} ${r.toFixed(1)} 0 1 0 ${(-2 * r).toFixed(1)} 0`;
  }
  return el('path', { d, fill: color }, parent);
}
const radial = (cx, cy, R, pw = 1.2) => (x, y) => Math.pow(clamp(1 - Math.hypot(x - cx, y - cy) / R), pw);
const edge = (R = 900, pw = 1.6) => (x, y) => Math.pow(clamp(Math.hypot(x - 540, y - 960) / R - 0.35), pw) * 1.3;

function bg(parent, color) { return el('rect', { width: 1080, height: 1920, fill: color }, parent); }

// subtitle bar
function caption(parent, parts, { x = 540, y = 1700, size = 46 } = {}) {
  const g = el('g', {}, parent);
  const inner = el('g', {}, g);
  const w = parts.reduce((a, [s]) => a + measure(s, size, F.sans, 900), 0);
  const padX = 34, hgt = size * 1.7;
  el('rect', { x: -w / 2 - padX + 8, y: -hgt / 2 + 8, width: w + padX * 2, height: hgt, rx: 14, fill: C.pink, class: 'mul' }, inner);
  el('rect', { x: -w / 2 - padX, y: -hgt / 2, width: w + padX * 2, height: hgt, rx: 14, fill: C.navy }, inner);
  const t = el('text', { x: -w / 2, y: size * 0.36, 'font-size': size, 'font-family': F.sans, 'font-weight': 900 }, inner);
  parts.forEach(([s, col]) => { const sp = el('tspan', { fill: col || C.cream }, t); sp.textContent = s; });
  return { g, inner, x, y };
}
function captionAnim(c, t, t0) {
  const p = seg(t, t0, t0 + 0.4);
  if (t < t0) { op(c.g, 0); return; }
  op(c.g, seg(t, t0, t0 + 0.12));
  tf(c.g, c.x, c.y + 40 * (1 - E.out(p)), lerp(0.8, 1, E.back(p)), -1.2 * (1 - p) - 0.6);
}

// stamp
function stampEl(parent, str, { size = 200, color = C.red, family = F.sans, padX = 50, padY = 26, border = 12 } = {}) {
  const g = el('g', {}, parent);
  const inner = el('g', { filter: 'url(#stampInk)' }, g);
  const w = measure(str, size, family, 900) + padX * 2, h = size * 1.08 + padY * 2;
  el('rect', { x: -w / 2, y: -h / 2, width: w, height: h, rx: 22, fill: 'none', stroke: color, 'stroke-width': border }, inner);
  el('rect', { x: -w / 2 + border * 1.8, y: -h / 2 + border * 1.8, width: w - border * 3.6, height: h - border * 3.6, rx: 12, fill: 'none', stroke: color, 'stroke-width': border * 0.35 }, inner);
  txt(inner, str, { x: 0, y: size * 0.36, 'font-size': size, 'font-family': family, 'font-weight': 900, fill: color, 'text-anchor': 'middle' });
  return { g, w, h };
}
function stampAnim(s, t, t0, x, y, rot) {
  if (t < t0 - 0.09) { op(s.g, 0); return; }
  const p = seg(t, t0 - 0.09, t0);
  const after = Math.max(0, t - t0);
  const bounce = 1 + 0.05 * Math.sin(after * 30) * Math.exp(-after * 9);
  op(s.g, p < 1 ? 0.3 + 0.7 * p : 0.93);
  tf(s.g, x, y, lerp(2.6, 1, E.in(p)) * bounce, rot);
}

