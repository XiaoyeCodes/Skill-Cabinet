// An original story using the halftone-dossier drawing grammar. See CREDITS.
const W=1080,H=1920,world=document.getElementById('world'),cam=document.getElementById('cam');
const SCENES=[],ACTIONS=[],READS=[],events=[];
let currentTime=0;
const line={stroke:C.navy,'stroke-width':7,'stroke-linecap':'round','stroke-linejoin':'round'};
const cuts=[3.4,7.5,12.3,17.5,22,26];
const hits=[[1.2,12],[7.1,23],[11.0,13],[20.8,27],[23.65,13],[27.15,21]];
const VO=[
 {id:'v01',t:0.25,end:3.35,sub:['会员刚买','风控就上班了']},
 {id:'v02',t:3.65,end:7.45,tempo:1.16,sub:['查 IP，查时区','疑似中国用户？封']},
 {id:'v03',t:7.8,end:12.25,sub:['申诉信写成情书','回信，比前任还冷']},
 {id:'v04',t:12.55,end:15.1,sub:['换 IP，改时区','全程英语']},
 {id:'v04en',t:15.1,end:17.45,sub:["Hello. I'm from New York.",'你好，我来自纽约']},
 {id:'v05',t:17.8,end:20.75,sub:['刚坐稳','系统，你怎么还在？']},
 {id:'v06',t:20.9,end:21.98,sub:['又封了']},
 {id:'v07',t:22.2,end:26.1,sub:['人工负责充值','智能负责拉黑']},
 {id:'v08',t:26.25,end:29.9,sub:['对齐全人类？','先查你是哪类']}
];
function group(p,attrs={}){return el('g',attrs,p)}
function rect(p,x,y,w,h,fill=C.cream,rx=18,stroke=true){return el('rect',{x,y,width:w,height:h,rx,fill,...(stroke?line:{})},p)}
function text(p,s,x,y,size=48,fill=C.navy,family=F.sans,anchor='middle',weight=900){return txt(p,s,{x,y,'font-size':size,'font-family':family,'font-weight':weight,fill,'text-anchor':anchor,'data-read':s})}
function path(p,d,fill='none',stroke=C.navy,sw=7){return el('path',{d,fill,stroke,'stroke-width':sw,'stroke-linecap':'round','stroke-linejoin':'round'},p)}
function circle(p,x,y,r,fill=C.yellow,sw=7){return el('circle',{cx:x,cy:y,r,fill,stroke:C.navy,'stroke-width':sw},p)}
function headline(p,s,y,size=132,fill=C.navy,at=0){let a=chars(p,s,{x:540,y,size,family:F.serif,fill,anchor:'middle',shadow:{fill:C.pink,dx:8,dy:8}});a.g.setAttribute('data-read-label',s);ACTIONS.push(t=>charsPop(a,t,at,.045,.36,55));return a}
function popAt(e,t,t0,x,y,scale=1,angle=0){tf(e,x,y,Math.max(.001,pop(t,t0,.38))*scale,angle)}
function heart(p,x,y,s=1,fill=C.pink){let g=group(p);path(g,'M0 18 C-72 -25 -36 -80 0 -42 C36 -80 72 -25 0 18Z',fill,C.navy,5);tf(g,x,y,s);return g}
function tick(p,x,y,good=true,scale=1){let g=group(p);circle(g,0,0,53,good?C.blue:C.red,5);path(g,good?'M-25 0L-6 21L28 -20':'M-21 -21L21 21M-21 21L21 -21','none',C.cream,10);tf(g,x,y,scale);return g}
function eyeRig(p,x,y){let g=group(p);el('ellipse',{cx:0,cy:0,rx:25,ry:36,fill:C.cream,...line,'stroke-width':5},g);let pupil=el('ellipse',{cx:0,cy:3,rx:12,ry:21,fill:C.navy},g);circle(g,-5,-5,5,C.cream,0);circle(g,6,11,2.7,C.cream,0);tf(g,x,y);return {g,pupil}}
function person(p){
 let g=group(p),drawing=group(g,{filter:'url(#boil)'});
 let legs=group(drawing);let legL=group(legs),legR=group(legs);
 for(let [leg,x] of [[legL,-48],[legR,48]]){path(leg,'M0 0L0 115','none',C.navy,45);el('ellipse',{cx:10,cy:123,rx:42,ry:19,fill:C.navy},leg);tf(leg,x,70)}
 let body=group(drawing);rect(body,-99,-77,198,216,C.blue,53);path(body,'M-14 -65L0 -32L15 -65','none',C.cream,6);path(body,'M0 -30V75','none',C.navy,4);
 let armL=group(drawing),armR=group(drawing);for(let [a,x,flip] of [[armL,-86,-1],[armR,86,1]]){path(a,`M0 0Q${flip*45} 28 ${flip*49} 92`,'none',C.blue,39);circle(a,flip*49,96,22,C.cream,5);tf(a,x,-30)}
 let head=group(drawing);el('ellipse',{cx:0,cy:-169,rx:115,ry:108,fill:C.cream,...line},head);
 path(head,'M-106 -197Q-112 -271 -47 -275Q-50 -302 -13 -292Q12 -316 35 -278Q96 -276 110 -212Q60 -241 35 -230Q-8 -250 -30 -229Q-72 -246 -106 -197Z',C.navy,C.navy,3);
 el('ellipse',{cx:-77,cy:-145,rx:23,ry:11,fill:C.pink,opacity:.65},head);el('ellipse',{cx:77,cy:-145,rx:23,ry:11,fill:C.pink,opacity:.65},head);
 let e1=eyeRig(head,-45,-183),e2=eyeRig(head,45,-183),brow1=path(head,'M-71 -225Q-46 -239 -20 -226','none',C.navy,7),brow2=path(head,'M20 -226Q46 -239 71 -225','none',C.navy,7),mouth=path(head,'M-25 -123Q0 -106 25 -123','none',C.navy,7);
 let glasses=group(head);for(let x of [-47,47])rect(glasses,x-37,-211,74,49,C.navy,15);path(glasses,'M-12 -193L12 -193','none',C.navy,10);path(glasses,'M-79 -202L-62 -194M62 -194L85 -202','none',C.navy,7);show(glasses,false);
 return {g,head,armL,armR,legL,legR,e1,e2,mouth,brow1,brow2,glasses};
}
function face(c,t,mood='neutral',sunglasses=false){
 let blink=1;for(let at of [2.2,5.4,8.8,10.8,14.2,16.3,19,24.1,28])if(Math.abs(t-at)<.10)blink=Math.max(.04,Math.abs(t-at)/.10);
 tf(c.e1.g,-45,-183,1,0,blink);tf(c.e2.g,45,-183,1,0,blink);
 c.mouth.setAttribute('d',mood==='sad'?'M-24 -112Q0 -135 24 -112':mood==='shock'?'M-13 -124Q0 -140 13 -124Q16 -103 0 -103Q-16 -103 -13 -124Z':mood==='happy'?'M-30 -127Q0 -92 30 -127':'M-22 -119L22 -119');
 c.mouth.setAttribute('fill',mood==='shock'?C.navy:'none');
 tf(c.brow1,0,mood==='shock'?-10:0,1,mood==='sad'?-7:0);tf(c.brow2,0,mood==='shock'?-10:0,1,mood==='sad'?7:0);show(c.glasses,sunglasses);
}
function pose(c,t,{x=540,y=1340,s=1,mood='neutral',glasses=false,run=0,arm=0,lean=0}={}){
 const breath=1+.012*Math.sin(t*3.1),squash=1-.10*run*Math.abs(Math.sin(t*24));tf(c.g,x,y,s/squash,lean,s*squash*breath);face(c,t,mood,glasses);
 tf(c.armL,-86,-30,1,run*Math.sin(t*24)*38-arm);tf(c.armR,86,-30,1,-run*Math.sin(t*24)*38+arm);
 tf(c.legL,-48,70,1,run*Math.sin(t*24)*24);tf(c.legR,48,70,1,-run*Math.sin(t*24)*24);
}
function scene(id,a,b,bgcol=C.paper){let g=group(world,{'data-scene':id});bg(g,bgcol);SCENES.push({id,a,b,g});return g}
function dots(p,{x=600,y=1000,r=700,col=C.blue,step=24,angle=18}={}){let q=halftone(p,{x0:0,y0:0,w:W,h:H,step,angle,color:col,f:radial(x,y,r,1.25),maxK:.60});q.setAttribute('class','mul');return q}
function documentProp(p,w=720,h=650){let g=group(p);rect(g,-w/2+15,-h/2+15,w,h,C.pink,12,false);rect(g,-w/2,-h/2,w,h,C.cream,12);path(g,`M${-w/2+45} ${-h/2+110}H${w/2-45}`,'none',C.navy,4);return g}
function lock(p,x,y,scale=1,fill=C.red){let g=group(p);path(g,'M-42 -12V-49C-42 -108 42 -108 42 -49V-12','none',C.navy,17);rect(g,-60,-10,120,95,fill,14);circle(g,0,24,12,C.cream,0);path(g,'M0 31V53','none',C.cream,8);tf(g,x,y,scale);return g}
function envelope(p,x,y,scale=1){let g=group(p);rect(g,-180,-115,360,230,C.cream,13);path(g,'M-172 -103L0 20L172 -103M-172 106L-40 0M172 106L40 0');heart(g,0,50,.5);tf(g,x,y,scale);return g}
function band(p,s,y,col=C.blue){let g=group(p);rect(g,110,y-65,860,130,col,8);text(g,s,540,y+20,66,C.cream);return g}
function build(){
 // 01: payment and a risk desk wake on the same beat.
 let g=scene('payment',0,3.4,C.blue);dots(g,{x:860,y:1100,r:920,col:C.navy});
 headline(g,'CLAUDE',350,172,C.cream,.03);headline(g,'封号奇遇记',505,118,C.cream,.13);
 let card=documentProp(g,680,330);text(card,'MEMBERSHIP',0,-75,38,C.blue,F.mono);text(card,'会员付款成功',0,35,76);let paid=tick(card,253,-81,true,.62);tf(card,540,805,1,-5);
 let p=person(g),purchaser=p;let shield=group(g);path(shield,'M0 -95L82 -60V17Q75 92 0 121Q-75 92 -82 17V-60Z',C.yellow,C.navy,8);text(shield,'风控',0,22,45);let lamp=eyeRig(shield,0,-27);tf(shield,850,1120,.8,8);
 let st=stampEl(g,'已收款',{size:100,color:C.yellow});
 ACTIONS.push(t=>{if(t>=3.4)return;pose(purchaser,t,{x:450,y:1310,s:1.13,mood:t>1.2?'shock':'happy',arm:16});tf(shield,850,1140+Math.sin(t*7)*8,pop(t,.7),8);tf(card,540,805+40*(1-E.out(seg(t,.1,.5))),1,-5);stampAnim(st,t,1.2,540,863,-8);});
 // 02: the filing apparatus turns location into a fictional accusation.
 g=scene('scan',3.4,7.5);dots(g,{x:900,y:950,r:1000,col:C.pink});headline(g,'付款完毕',360,126,C.navy,3.43);headline(g,'开始盘问',520,126,C.navy,3.55);
 let form=documentProp(g,760,700);text(form,'风险审查 · 虚构道具',0,-265,35,C.blue,F.mono);text(form,'IP',-274,-120,62,C.navy,F.mono,'start');text(form,'中国',252,-120,62,C.red,F.serif,'end');text(form,'时区',-274,10,62,C.navy,F.serif,'start');text(form,'北京时间',252,10,58,C.red,F.serif,'end');path(form,'M-280 70H280');text(form,'疑似中国用户',0,173,73,C.navy);tf(form,540,980,1,-3);
 let scan=group(g);rect(scan,-325,-27,650,54,C.yellow,0,false);path(scan,'M-360 -50V50M360 -50V50','none',C.red,9);tf(scan,540,850);
 p=person(g);let suspect=p;let stamp=stampEl(g,'账号封禁',{size:143,color:C.red,border:13});
 ACTIONS.push(t=>{if(t<3.4||t>=7.5)return;let s=t-3.4;tf(scan,540,790+310*seg(t,3.8,5.4),1,-3);op(scan,t<6.1?1:0);pose(suspect,t,{x:800,y:1390,s:.67,mood:'shock',lean:7});stampAnim(stamp,t,7.1,540,1150,-11)});
 // 03: a plea really becomes a love letter, then comes back.
 g=scene('loveletter',7.5,12.3);dots(g,{x:100,y:1180,r:920,col:C.pink});headline(g,'亲爱的',350,141,C.navy,7.53);headline(g,'审核员',515,141,C.navy,7.66);
 let letter=documentProp(g,730,680);text(letter,'我真的很爱用你',0,-200,57,C.red,F.serif);for(let i=0;i<4;i++)path(letter,`M-265 ${-100+i*75}Q-50 ${-115+i*75} ${230-i*20} ${-105+i*75}`,'none',C.blue,5);text(letter,'盼复',235,240,60,C.red,F.serif,'end');tf(letter,540,950,1,-5);
 let env=envelope(g,540,1320,.9),hearts=[heart(g,170,900,.7),heart(g,880,780,.55),heart(g,830,1280,.8)];let ret=stampEl(g,'申诉未果',{size:145,color:C.red});p=person(g);let lover=p;
 ACTIONS.push(t=>{if(t<7.5||t>=12.3)return;let q=seg(t,9.8,10.7);tf(env,540+Math.sin(q*Math.PI)*270,1320-q*600,.9-q*.4,-q*65);hearts.forEach((h,i)=>tf(h,[170,880,830][i],[900,780,1280][i]+Math.sin(t*3+i)*18,pop(t,7.9+i*.25)*[.7,.55,.8][i],Math.sin(t*3+i)*12));pose(lover,t,{x:240,y:1390,s:.65,mood:t<11?'happy':'sad',arm:22});stampAnim(ret,t,11,540,1060,9);});
 // 04: an obviously theatrical American disguise.
 g=scene('disguise',12.3,17.5,C.navy);dots(g,{x:600,y:950,r:1030,col:'#2A3568'});headline(g,'重返江湖',355,136,C.cream,12.33);
 let labels=[];for(let [i,label] of ['VPN 网络','纽约时区','全程英语'].entries()){let q=group(g);rect(q,140,465+i*120,800,100,i===2?C.yellow:C.blue,12);text(q,label,540,532+i*120,58,i===2?C.navy:C.cream);labels.push(q)}
 p=person(g);let spy=p;let hat=group(g,{filter:'url(#boil)'});path(hat,'M-120 0L-90 -90L80 -90L114 0Z',C.yellow,C.navy,8);rect(hat,-150,-5,300,32,C.yellow,10);text(hat,'USA',0,-29,47,C.navy,F.mono);
 let bubble=group(g);rect(bubble,100,1370,880,150,C.cream,25);path(bubble,'M650 1370L700 1310L745 1370',C.cream,C.navy,6);text(bubble,'Hello, New York.',540,1460,65,C.navy,F.mono);
 ACTIONS.push(t=>{if(t<12.3||t>=17.5)return;labels.forEach((q,i)=>tf(q,0,80*(1-pop(t,12.55+i*.36)),Math.max(.001,pop(t,12.55+i*.36))));pose(spy,t,{x:540,y:1230,s:1.08,mood:'happy',glasses:t>13.6,arm:15});tf(hat,540,914,Math.max(.001,pop(t,14.2)),6);op(bubble,t>15.1?1:0);});
 // 05: the scanner recognises the same character. No detection tutorial.
 g=scene('ban-again',17.5,22);dots(g,{x:800,y:900,r:1030,col:C.blue});headline(g,'你怎么',355,146,C.navy,17.53);headline(g,'还在？',535,146,C.navy,17.68);
 let identification=documentProp(g,760,580);text(identification,'身份比对 · 虚构道具',0,-215,35,C.blue,F.mono);let pic1=person(identification),pic2=person(identification);text(identification,'上次的你',-165,180,45);text(identification,'纽约的你',165,180,45);path(identification,'M-40 -10H40M15 -35L40 -10L15 15','none',C.red,11);tf(identification,540,930);
 p=person(g);let caught=p,again=stampEl(g,'再次封禁',{size:147,color:C.red,border:14});
 ACTIONS.push(t=>{if(t<17.5||t>=22)return;pose(pic1,t,{x:-170,y:50,s:.53,mood:'neutral'});pose(pic2,t,{x:170,y:50,s:.53,mood:'neutral',glasses:true});pose(caught,t,{x:540,y:1380,s:.85,mood:'shock',glasses:t<20.4,arm:25,lean:Math.sin(t*14)*2});stampAnim(again,t,20.8,540,1020,-10);});
 // 06: an original two-drawer machine makes the final accusation physical.
 g=scene('machine',22,26,C.yellow);dots(g,{x:940,y:750,r:1160,col:C.pink});headline(g,'ANTHROPIC',350,121,C.navy,22.02);headline(g,'人工智能',520,133,C.navy,22.11);
 let machine=group(g);rect(machine,140,670,800,690,C.blue,25);rect(machine,190,740,700,220,C.cream,14);rect(machine,190,1010,700,220,C.navy,14);text(machine,'人工',380,831,76);text(machine,'收款',720,901,87,C.red);text(machine,'智能',380,1095,76,C.cream);text(machine,'拉黑',720,1175,87,C.yellow);path(machine,'M510 780H570M510 825H570M510 1050H570M510 1095H570','none',C.pink,9);rect(machine,230,1380,85,90,C.navy,8);rect(machine,765,1380,85,90,C.navy,8);let coin=circle(g,550,580,70,C.cream);text(g,'会员',550,602,45);let fly=group(g);rect(fly,-90,-65,180,130,C.cream,9);text(fly,'用户',0,18,56);tf(fly,540,1430);
 ACTIONS.push(t=>{if(t<22||t>=26)return;let q=(t-22)%1;coin.setAttribute('cy',580+q*220);op(coin,1-q*.8);tf(machine,Math.sin(t*33)*3,0,1);tf(fly,540+seg(t,23.3,24.8)*900,1430-seg(t,23.3,24.8)*150,1,seg(t,23.3,24.8)*70)});
 // 07: the invitation to all humanity ends in a sorting apparatus.
 g=scene('humanity',26,30,C.blue);dots(g,{x:850,y:1000,r:1400,col:C.navy});headline(g,'对齐全人类？',430,124,C.cream,26.05);headline(g,'先查你是哪类',630,119,C.cream,26.2);
 let funnel=group(g,{filter:'url(#boil)'});path(funnel,'M180 850H900L690 1110V1330L390 1430V1110Z',C.yellow,C.navy,10);text(funnel,'人类筛选器',540,1028,66);tf(funnel,0,0);
 let tiny=[];for(let i=0;i<5;i++){let pp=person(g);tiny.push(pp)}let stampPaper=group(g);rect(stampPaper,-390,-112,780,224,C.cream,9);let finalStamp=stampEl(g,'人类筛选中',{size:115,color:C.red,border:12});
 ACTIONS.push(t=>{if(t<26)return;tiny.forEach((pp,i)=>{let q=seg(t,26.15+i*.20,27.0+i*.20);pose(pp,t,{x:230+i*155,y:850-q*80,s:.29,mood:i===2?'shock':'neutral',glasses:i===2});op(pp.g,t<27.4?1:0)});tf(stampPaper,540,1320,Math.max(.001,pop(t,26.9)),-10);stampAnim(finalStamp,t,27.15,540,1320,-10);});
}
function makeCaption(entry){let g=group(document.getElementById('captions'));let lines=entry.sub,sz=entry.id==='v04en'?42:48,h=lines.length===2?164:104;rect(g,115,1645+h/2-82,866,h,C.pink,16,false);rect(g,107,1637+h/2-82,866,h,C.navy,16,false);lines.forEach((s,i)=>text(g,s,540,(lines.length===2?1688:1701)+i*69,sz,i===lines.length-1?C.yellow:C.cream));return {entry,g}}
function buildPaper(){let cv=document.getElementById('paper'),cx=cv.getContext('2d'),r=rng(3),im=cx.createImageData(W,H);for(let i=0;i<im.data.length;i+=4){let v=247+(r()-.5)*14;im.data[i]=v;im.data[i+1]=v-1;im.data[i+2]=v-5;im.data[i+3]=255}cx.putImageData(im,0,0);let gr=cx.createRadialGradient(540,920,360,540,920,1250);gr.addColorStop(0,'rgba(255,255,255,0)');gr.addColorStop(1,'rgba(125,108,82,.21)');cx.fillStyle=gr;cx.fillRect(0,0,W,H);cx.strokeStyle='rgba(140,120,100,.10)';cx.lineWidth=3;cx.beginPath();cx.moveTo(540,0);cx.lineTo(543,H);cx.stroke()}
function dust(t){let cv=document.getElementById('fx'),cx=cv.getContext('2d'),r=rng(1000+Math.floor(t*15));cx.clearRect(0,0,W,H);cx.fillStyle='rgba(255,248,235,.62)';for(let i=0;i<540;i++){cx.beginPath();cx.arc(r()*W,r()*H,.5+r()*1.2,0,7);cx.fill()}cx.fillStyle='rgba(20,41,59,.18)';for(let i=0;i<85;i++)cx.fillRect(r()*W,r()*H,1.5,1.5)}
let caps=[],hud,wipe,flash,model=[],hudTitle,hudFooter,modelLabels;
function render(t){
 t=clamp(t,0,29.999);currentTime=t;const sheet=new URLSearchParams(location.search).get('sheet')==='model';
 show(modelLabels,sheet);if(sheet){SCENES.forEach(s=>show(s.g,false));show(hud,false);caps.forEach(c=>show(c.g,false));show(wipe,false);model.forEach((p,i)=>{show(p.g,true);pose(p,t,{x:270+(i%2)*540,y:800+Math.floor(i/2)*700,s:1.1,mood:['neutral','happy','sad','shock'][i],glasses:i===3});});dust(t);return}
 model.forEach(p=>show(p.g,false));SCENES.forEach(s=>show(s.g,t>=s.a&&t<s.b));ACTIONS.forEach(f=>f(t));caps.forEach(c=>{show(c.g,t>=c.entry.t&&t<c.entry.end);if(t>=c.entry.t&&t<c.entry.end)tf(c.g,0,-24+28*(1-E.out(seg(t,c.entry.t,c.entry.t+.25))),1)});
 const dark=t<3.4||(t>=12.3&&t<17.5)||t>=26;hudTitle.setAttribute('fill',dark?C.cream:C.navy);hudFooter.setAttribute('fill',dark?C.cream:C.navy);
 let dx=0,dy=0;for(let [at,a] of hits){let d=t-at;if(d>=0&&d<.35){let k=(1-d/.35)**2;dx+=Math.sin(d*96)*a*k;dy+=Math.cos(d*82)*a*k}}
 const pulse=1+.004*Math.exp(-(t%.5)/.065);cam.setAttribute('transform',`translate(${dx+540*(1-pulse)} ${dy+960*(1-pulse)}) scale(${pulse})`);
 document.getElementById('boilT').setAttribute('seed',1+(Math.floor(t*10)%40));
 let nearest=cuts.find(c=>Math.abs(t-c)<.23);show(wipe,nearest!==undefined);if(nearest!==undefined){let amount=1-Math.abs(t-nearest)/.23;Array.from(wipe.children).forEach((q,i)=>{let delay=((i%15)+Math.floor(i/15))*.0035;q.setAttribute('r',clamp((amount-delay)*1.65)*61)})}
 let f=0;for(let[at]of hits){if(t>=at&&t<at+.12)f=Math.max(f,.32*(1-(t-at)/.12))}op(flash,f);dust(t);
}
async function init(){
 await Promise.all(['900 48px "Noto Serif SC"','900 48px "Noto Sans SC"','400 48px "Bagel Fat One"','800 48px "JetBrains Mono"'].map(f=>document.fonts.load(f,document.documentElement.innerHTML+'会员刚买查时区中国用户情书申诉全程英语人工负责充值智能拉黑先查你是哪类')));await document.fonts.ready;
 buildPaper();build();hud=group(document.getElementById('hud'));hudTitle=text(hud,'CLAUDE / CASE 002',100,130,27,C.navy,F.mono,'start');let badge=rect(hud,680,90,300,58,C.cream,8);text(hud,'虚构讽刺',830,130,29);hudFooter=text(hud,'剧情、邮件与风控逻辑均为虚构',540,1840,27,C.navy,F.sans);caps=VO.map(makeCaption);
 wipe=group(document.getElementById('wipe'));for(let y=-80;y<H+80;y+=80)for(let x=-80;x<W+80;x+=80)el('circle',{cx:x,cy:y,r:0,fill:C.yellow},wipe);flash=document.getElementById('flash');
 for(let i=0;i<4;i++){let p=person(world);model.push(p)}
 modelLabels=group(world);text(modelLabels,'主角表情与伪装设定',540,180,65);['普通','开心','失落','伪装'].forEach((s,i)=>text(modelLabels,s,270+i%2*540,430+Math.floor(i/2)*700,62));
 window.DUR=30;window.VOICE_CUES=VO;window.EV=[...cuts.map(t=>({t:t-.15,type:'paper'})),...hits.map(([t])=>({t,type:'stamp'})),{t:9.9,type:'whoosh'},{t:13.1,type:'pop'},{t:14.2,type:'pop'},{t:20.2,type:'alarm'}];
 const reading=[...document.querySelectorAll('#world [data-read],#world [data-read-label]')];reading.forEach((e,i)=>e.dataset.readId='r'+i);
 window.TEXTS=t=>{render(t);return reading.map(e=>{let b=e.getBoundingClientRect(),visible=b.width>1&&b.height>1;for(let p=e;p&&p.id!=='stage';p=p.parentElement){let s=getComputedStyle(p);if(s.display==='none'||+s.opacity<.05)visible=false}return visible?{id:e.dataset.readId,text:e.dataset.readLabel||e.dataset.read,x0:b.left,y0:b.top,x1:b.right,y1:b.bottom}:null}).filter(Boolean)};window.render=render;render(0);window.READY=true;
}
init();
