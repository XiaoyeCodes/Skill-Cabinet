Claude 封号奇遇记 / 30s portrait satire

Original story based on the user's brief; original character, staging, graphic props, score arrangement and melody.
Lemo-Opuscar by lemomo-ai: https://github.com/lemomo-ai/lemo-opuscar
MIT license (a copy accompanies the source). Drawing helpers adapted from styles/halftone-dossier/demo/index.html; synthesizer primitives adapted from demo/music.py; renderer and TTS/checking tools from core/. The skill package contains editable source and OFL fonts; no source-film footage, completed video or recorded speech is bundled.

Fonts, self-hosted subsets via Google Fonts, SIL Open Font License 1.1:
Noto Serif SC — https://github.com/google/fonts/tree/main/ofl/notoserifsc
Noto Sans SC — https://github.com/google/fonts/tree/main/ofl/notosanssc
Bagel Fat One — https://github.com/google/fonts/tree/main/ofl/bagelfatone
JetBrains Mono — https://github.com/google/fonts/tree/main/ofl/jetbrainsmono

Voice synthesis: Microsoft online neural voices via edge-tts; zh-CN-YunxiNeural and en-US-GuyNeural. No real person's voice was cloned. Microsoft service terms apply to generated speech.

All BGM and foley are procedural synthesis, with a new D-minor arrangement and melody for this film. No third-party recording, stock music or source-film music was copied.

Claude and Anthropic are the subjects of commentary. Textual brand references only; no official logos, product screenshots or real notices were used. Fictional satire, no affiliation or endorsement.
