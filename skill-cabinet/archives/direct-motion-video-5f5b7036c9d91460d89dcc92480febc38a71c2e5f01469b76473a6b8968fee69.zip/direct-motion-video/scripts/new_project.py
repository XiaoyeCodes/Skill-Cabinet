"""Create an isolated film project from the bundled starter. Never overwrite existing work."""
import argparse,json,os,shutil,subprocess
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('output',type=Path)
    ap.add_argument('--title')
    ap.add_argument('--deps-from',type=Path,help='Explicitly reuse compatible node_modules from this project')
    args=ap.parse_args()
    dest=args.output.expanduser().resolve()
    if dest.exists() and (not dest.is_dir() or any(dest.iterdir())):
        ap.error(f'Refusing to overwrite a non-empty destination: {dest}')
    source=Path(__file__).resolve().parents[1]/'assets/project'
    dependencies=None
    if args.deps_from:
        dependencies=(args.deps_from.expanduser().resolve()/'node_modules').resolve()
        expected=json.loads((source/'package.json').read_text(encoding='utf-8'))['dependencies']
        for name,version in expected.items():
            manifest=dependencies/name/'package.json'
            if not manifest.is_file() or json.loads(manifest.read_text(encoding='utf-8'))['version']!=version:
                ap.error(f'Incompatible dependency {name}; install the starter dependencies instead')
    shutil.copytree(source,dest,dirs_exist_ok=True)
    for folder in ['public','src/generated','out','qa','.tmp']:(dest/folder).mkdir(parents=True,exist_ok=True)
    if args.title:
        film=json.loads((dest/'film.json').read_text(encoding='utf-8'));film['title']=args.title
        (dest/'film.json').write_text(json.dumps(film,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if dependencies:
        link=dest/'node_modules'
        if os.name=='nt':
            shell=shutil.which('pwsh') or shutil.which('powershell')
            if not shell:raise RuntimeError('PowerShell is required to create a Windows dependency junction')
            env={**os.environ,'MOTION_LINK':str(link),'MOTION_DEPS':str(dependencies)}
            subprocess.run([shell,'-NoProfile','-NonInteractive','-Command','New-Item -ItemType Junction -Path $env:MOTION_LINK -Target $env:MOTION_DEPS | Out-Null'],env=env,check=True)
        else:link.symlink_to(dependencies,target_is_directory=True)
    print(json.dumps({'project':str(dest),'reused_dependencies':str(dependencies) if dependencies else None,'next':['Edit film.json and SOURCES.md','python build_audio.py','node render.mjs --stills','node render.mjs --preview','node render.mjs','python verify.py']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
