"""Read-only runtime and disk inspection for a motion-video project."""
import argparse,importlib.util,json,os,shutil,subprocess
from pathlib import Path

def output(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20)
        return (p.stdout+p.stderr).strip()
    except (OSError,subprocess.SubprocessError) as e:return str(e)

ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('project',type=Path);ap.add_argument('--node');a=ap.parse_args()
root=a.project.expanduser().resolve()
if not root.is_dir():ap.error('Project directory does not exist')
browser=os.environ.get('CHROME_PATH')
candidates=[browser] if browser else []
for base in [os.environ.get('PROGRAMFILES'),os.environ.get('PROGRAMFILES(X86)'),os.environ.get('LOCALAPPDATA')]:
    if base:candidates.append(str(Path(base)/'Google/Chrome/Application/chrome.exe'))
candidates+=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']
candidates+=[shutil.which(n) for n in ['google-chrome','chromium','chromium-browser','chrome']]
browser=next((str(Path(p)) for p in candidates if p and Path(p).is_file()),None)
node=a.node or shutil.which('node');ff=shutil.which('ffmpeg');probe=shutil.which('ffprobe')
report={'project':str(root),'free_gb':round(shutil.disk_usage(root).free/1e9,2),'node':node,'node_version':output([node,'--version']) if node else None,'ffmpeg':ff,'ffprobe':probe,'libx264':bool(ff and 'libx264' in output([ff,'-hide_banner','-encoders'])),'browser':browser,'python_modules':{m:bool(importlib.util.find_spec(m)) for m in ['numpy','PIL','edge_tts']},'dependencies_present':(root/'node_modules/@remotion/renderer/package.json').is_file(),'notes':['No software was installed and no browser or render process was started.','Set CHROME_PATH if browser detection does not find the intended installation.']}
print(json.dumps(report,ensure_ascii=False,indent=2))
