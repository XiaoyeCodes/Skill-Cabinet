import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderMedia,renderStill} from '@remotion/renderer';
import {existsSync,mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=path.dirname(fileURLToPath(import.meta.url));process.chdir(root);
for(const dir of ['.tmp','qa','out'])mkdirSync(dir,{recursive:true});
process.env.TEMP=path.join(root,'.tmp');process.env.TMP=process.env.TEMP;process.env.TMPDIR=process.env.TEMP;
if(!existsSync('src/generated/timeline.json'))throw new Error('Run python build_audio.py before rendering.');
const film=JSON.parse(readFileSync('film.json','utf8')),tl=JSON.parse(readFileSync('src/generated/timeline.json','utf8'));
const {width,height,fps}=film.video;
if(!Number.isInteger(width)||!Number.isInteger(height)||width%2||height%2||width<2||height<2)throw new Error('Use positive even output dimensions for H.264.');
if(Math.abs(width/height-16/9)>0.001)throw new Error('This starter layout is 16:9. Adapt its layout and safe areas before rendering another aspect ratio.');
if(fps!==tl.fps)throw new Error('FPS changed; rebuild the audio timeline.');
const candidates=[process.env.CHROME_PATH];
for(const base of [process.env.PROGRAMFILES,process.env['PROGRAMFILES(X86)'],process.env.LOCALAPPDATA])if(base)candidates.push(path.join(base,'Google/Chrome/Application/chrome.exe'));
candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
if(process.platform!=='win32')for(const command of ['google-chrome','chromium','chromium-browser']){try{candidates.push(execFileSync('which',[command],{encoding:'utf8'}).trim());}catch{}}
const browserExecutable=candidates.find(x=>x&&existsSync(x));
if(!browserExecutable)throw new Error('Chrome was not found. Set CHROME_PATH to an installed browser.');
const chromiumOptions={gl:process.env.MOTION_GL||'angle'};
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),outDir:path.join(root,'build')});
const browser=await openBrowser('chrome',{browserExecutable,chromiumOptions});
const logs=[];
try{
 const common={serveUrl,browserExecutable,chromiumOptions,puppeteerInstance:browser,timeoutInMilliseconds:120000,onBrowserLog:l=>{if(l.type==='error')logs.push(l.text);}};
 const composition=await selectComposition({...common,id:'Film'});
 if(process.argv.includes('--stills')){
  for(const scene of tl.scenes){const frame=scene.from+Math.min(scene.frames-1,Math.max(0,Math.floor(scene.frames*.55)));await renderStill({...common,composition,frame,imageFormat:'png',output:`qa/${scene.id}.png`});console.log(`STILL ${scene.id} ${frame}`);}
 }else{
  const preview=process.argv.includes('--preview'),lastFrame=preview?Math.min(tl.totalFrames-1,Math.ceil(fps*12)-1):tl.totalFrames-1;
  let last=0;
  await renderMedia({...common,composition,codec:'h264',crf:17,concurrency:Number(process.env.MOTION_CONCURRENCY||2),imageFormat:'jpeg',jpegQuality:92,audioBitrate:'320k',frameRange:[0,lastFrame],outputLocation:preview?'out/preview.mp4':'out/film.mp4',
   onProgress:p=>{if(Date.now()-last>15000||p.progress===1){last=Date.now();const info={progress:+(p.progress*100).toFixed(1),renderedFrames:p.renderedFrames,encodedFrames:p.encodedFrames,etaSeconds:Math.round(p.renderEstimatedTime/1000),updatedAt:new Date().toISOString()};writeFileSync('qa/render-progress.json',JSON.stringify(info,null,2));console.log(JSON.stringify(info));}}
  });
  if(!preview)writeFileSync('qa/render-settings.json',JSON.stringify({width,height,fps,frames:tl.totalFrames,crf:17,jpegQuality:92,browserExecutable,chromiumOptions,audioExpected:tl.audioExpected},null,2));
  console.log(preview?'PREVIEW_COMPLETE':'RENDER_COMPLETE');
 }
}finally{writeFileSync('qa/browser-errors.json',JSON.stringify(logs,null,2));await browser.close({silent:true});}
