import React from 'react';
import {Composition} from 'remotion';
import film from '../film.json';
import TL from './generated/timeline.json';
import {Main} from './Main';
export const Root:React.FC=()=> <Composition id="Film" component={Main} durationInFrames={TL.totalFrames} fps={film.video.fps} width={film.video.width} height={film.video.height}/>;
