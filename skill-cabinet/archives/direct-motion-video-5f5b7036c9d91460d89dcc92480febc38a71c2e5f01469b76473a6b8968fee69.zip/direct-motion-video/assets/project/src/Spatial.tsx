import React from 'react';
import * as THREE from 'three';
import {ThreeCanvas} from '@remotion/three';
import {cancelRender,continueRender,delayRender,staticFile} from 'remotion';
import film from '../film.json';

const cache=new Map<string,THREE.Texture>();
function texture(file?:string){
 if(!file)return undefined;
 if(cache.has(file))return cache.get(file);
 const handle=delayRender(`Texture ${file}`);
 const t=new THREE.TextureLoader().load(staticFile(file),()=>continueRender(handle),undefined,e=>cancelRender(new Error(`Could not load texture ${file}: ${String(e)}`)));
 t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;cache.set(file,t);return t;
}
const vert='varying vec3 N;varying vec3 V;void main(){vec4 p=modelViewMatrix*vec4(position,1.);N=normalize(normalMatrix*normal);V=-p.xyz;gl_Position=projectionMatrix*p;}';
const frag='uniform vec3 tint;varying vec3 N;varying vec3 V;void main(){float f=pow(1.-abs(dot(normalize(N),normalize(V))),3.4);gl_FragColor=vec4(tint,f*.3);}';

export function Spatial({visual,f}:{visual:any;f:number}){
 const color=visual.color||film.style.secondary;
 const map=texture(visual.texture);
 const rotation:[number,number,number]=[.35,0,-(visual.tilt||0)*Math.PI/180];
 return <div style={{position:'absolute',left:0,top:0,width:film.video.width,height:film.video.height,transform:`scale(${1920/film.video.width})`,transformOrigin:'top left'}}><ThreeCanvas width={film.video.width} height={film.video.height} style={{position:'absolute',left:0,top:0}} camera={{position:[0,0,12],fov:35}} gl={{alpha:true,antialias:true}}>
  <ambientLight intensity={.23}/><directionalLight position={[-4,3,7]} intensity={2.5}/><directionalLight position={[4,-2,-3]} intensity={.15} color={film.style.secondary}/>
  <group position={[2.25,.12,0]} rotation={rotation}>
   <mesh rotation={[0,f*.002,0]}><sphereGeometry args={[visual.rings?1.4:2,72,48]}/><meshStandardMaterial color={map?'#ffffff':color} map={map} roughness={.8}/></mesh>
   <mesh scale={(visual.rings?1.4:2)*1.018}><sphereGeometry args={[1,64,40]}/><shaderMaterial uniforms={{tint:{value:new THREE.Color(color)}}} vertexShader={vert} fragmentShader={frag} transparent blending={THREE.AdditiveBlending} depthWrite={false}/></mesh>
   {visual.rings?[1.9,2.2,2.5,2.8].map((r,i)=><mesh key={r} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[r,r+.06+i*.02,144]}/><meshBasicMaterial color={color} side={THREE.DoubleSide} transparent opacity={.45-i*.06} depthWrite={false}/></mesh>):null}
  </group>
 </ThreeCanvas></div>;
}
