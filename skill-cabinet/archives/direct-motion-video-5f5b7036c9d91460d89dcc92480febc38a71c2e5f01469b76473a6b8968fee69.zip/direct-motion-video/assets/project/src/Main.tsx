import React from 'react';
import {AbsoluteFill,Audio,Img,Sequence,cancelRender,continueRender,delayRender,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import film from '../film.json';
import TL from './generated/timeline.json';
import {Spatial} from './Spatial';

const S=film.style,FONT=S.fontFamily,MONO='Consolas, monospace';
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(x:number)=>1-Math.pow(1-clamp(x),3);
const smooth=(x:number)=>{x=clamp(x);return x*x*(3-2*x);};
const rand=(n:number)=>{const a=Math.sin(n*127.1+311.7)*43758.5453123;return a-Math.floor(a);};
const alpha=(color:string,a:number)=>{const c=color.replace('#','');return `rgba(${parseInt(c.slice(0,2),16)},${parseInt(c.slice(2,4),16)},${parseInt(c.slice(4,6),16)},${a})`;};
const fonts=(S.fontFiles||[]) as {family:string;path:string;weight?:string}[];
if(fonts.length){const h=delayRender('Film fonts');Promise.all(fonts.map(x=>new FontFace(x.family,`url(${staticFile(x.path)})`,{weight:x.weight||'400'}).load())).then(fs=>{fs.forEach(f=>document.fonts.add(f));continueRender(h);}).catch(e=>cancelRender(e));}

function Network({f,light=false}:{f:number;light?:boolean}){
 const pts=Array.from({length:11},(_,i)=>({x:1290+Math.cos(i*2.4+f*.001)*350*(.5+rand(i)*.5),y:510+Math.sin(i*2.4+f*.001)*250}));
 return <svg width={1920} height={1080} style={{position:'absolute',inset:0,opacity:light?.3:.8}}>{pts.map((p,i)=><g key={i}>{pts.slice(i+1).filter((_,j)=>(i+j)%3===0).map((q,j)=><line key={j} x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke={S.secondary} opacity={.22} strokeWidth={1}/>)}<circle cx={p.x} cy={p.y} r={i%3?5:9} fill={i%2?S.accent:S.secondary}/></g>)}</svg>;
}
function Visual({v,f}:{v:any;f:number}){
 if(v?.kind==='sphere')return <Spatial visual={v} f={f}/>;
 if(v?.kind==='image')return <Img src={staticFile(v.src)} style={{position:'absolute',left:920,top:185,width:860,height:580,objectFit:'contain'}}/>;
 return <Network f={f}/>;
}
function Heading({s}:{s:any}){return <div style={{position:'absolute',left:95,top:155,right:95}}><div style={{fontFamily:MONO,fontSize:19,letterSpacing:5,color:S.accent,marginBottom:18}}>{s.eyebrow||'STORY IN MOTION'}</div><div style={{fontSize:s.type==='hero'?82:64,fontWeight:700,lineHeight:1.35,maxWidth:s.type==='hero'?740:1700}}>{s.title}</div>{s.subtitle?<div style={{fontSize:27,color:S.muted,lineHeight:1.7,marginTop:19,maxWidth:s.type==='hero'?700:1650}}>{s.subtitle}</div>:null}</div>;}

function Scene({s,index}:{s:any;index:number}){
 const f=useCurrentFrame(),p=ease(f/26),opacity=Math.min(smooth(f/12),smooth((s.frames-1-f)/14));
 let body:React.ReactNode=null;
 if(s.type==='title')body=<><Network f={f} light/><div style={{position:'absolute',left:120,top:300,maxWidth:1620,opacity:p,transform:`translateY(${(1-p)*35}px)`}}><div style={{fontFamily:MONO,fontSize:24,color:S.accent,letterSpacing:7}}>{s.eyebrow}</div><div style={{fontWeight:700,fontSize:106,lineHeight:1.45,marginTop:35}}>{s.title}</div><div style={{fontSize:34,color:S.muted,marginTop:30}}>{s.subtitle}</div><div style={{width:620,height:2,background:S.accent,marginTop:48,transform:`scaleX(${p})`,transformOrigin:'left'}}/></div></>;
 if(s.type==='hero')body=<><Visual v={s.visual} f={f}/><Heading s={s}/><div style={{position:'absolute',left:100,top:455,maxWidth:700,opacity:p}}>{(s.bullets||[]).map((b:string,i:number)=><div key={i} style={{fontSize:28,lineHeight:1.8,marginBottom:13,color:i?S.muted:S.foreground}}><span style={{color:S.accent,marginRight:18}}>·</span>{b}</div>)}<div style={{display:'flex',gap:42,marginTop:42}}>{(s.metrics||[]).map((m:any,i:number)=><div key={i}><div style={{fontSize:19,color:S.muted,marginBottom:12}}>{m.label}</div><div style={{fontSize:38,color:S.accent}}>{m.value}</div></div>)}</div></div></>;
 if(s.type==='compare'){
  const data=s.data||[],max=Math.max(1,...data.map((x:any)=>x.value)),step=Math.min(125,520/Math.max(1,data.length));
  body=<><Heading s={s}/><svg width={1920} height={1080} style={{position:'absolute',inset:0}}>{data.map((d:any,i:number)=>{const y=390+i*step,w=1130*d.value/max*ease((f-i*4)/35);return <g key={i}><text x={100} y={y+31} fontFamily={FONT} fontSize={28} fill={S.foreground}>{d.label}</text><rect x={420} y={y} width={1130} height={46} rx={5} fill={alpha(S.secondary,.1)}/><rect x={420} y={y} width={w} height={46} rx={5} fill={d.color||(i%2?S.secondary:S.accent)}/><text x={1590} y={y+32} fontFamily={MONO} fontSize={31} fill={S.foreground}>{d.value} {s.unit||''}</text></g>;})}<line x1={420} x2={420} y1={365} y2={405+Math.max(0,data.length-1)*step} stroke={S.muted} opacity={.5}/></svg></>;
 }
 if(s.type==='timeline'){
  const events=s.events||[],n=events.length;
  body=<><Heading s={s}/><svg width={1920} height={1080} style={{position:'absolute',inset:0}}><line x1={200} x2={1720} y1={570} y2={570} stroke={alpha(S.secondary,.25)} strokeWidth={2}/><line x1={200} x2={200+1520*p} y1={570} y2={570} stroke={S.accent} strokeWidth={3}/>{events.map((e:any,i:number)=>{const x=n===1?960:200+1520*i/(n-1),on=clamp((f-i*6)/24);return <g key={i} opacity={on}><circle cx={x} cy={570} r={10} fill={S.accent}/><text x={x} y={495} textAnchor={'middle'} fontFamily={MONO} fontSize={35} fill={S.accent}>{e.at}</text><text x={x} y={650} textAnchor={'middle'} fontFamily={FONT} fontSize={30} fill={S.foreground}>{e.label}</text><text x={x} y={710} textAnchor={'middle'} fontFamily={FONT} fontSize={23} fill={S.muted}>{e.detail||''}</text></g>;})}</svg></>;
 }
 if(s.type==='diagram'){
  const nodes=s.nodes||[],n=nodes.length,positions=nodes.map((x:any,i:number)=>({...x,x:960+Math.cos(-Math.PI/2+i*Math.PI*2/Math.max(1,n))*510,y:610+Math.sin(-Math.PI/2+i*Math.PI*2/Math.max(1,n))*205}));
  body=<><Heading s={s}/><svg width={1920} height={1080} style={{position:'absolute',inset:0}}>{(s.links||[]).map((l:any,i:number)=>{const a=positions.find((x:any)=>x.id===l.from),b=positions.find((x:any)=>x.id===l.to);if(!a||!b)return null;return <line key={i} x1={a.x} y1={a.y} x2={a.x+(b.x-a.x)*ease((f-i*3)/30)} y2={a.y+(b.y-a.y)*ease((f-i*3)/30)} stroke={S.secondary} strokeWidth={2} opacity={.5}/>;})}{positions.map((x:any,i:number)=><g key={x.id} opacity={clamp((f-i*3)/20)}><circle cx={x.x} cy={x.y} r={60} fill={S.background} stroke={S.accent} strokeWidth={2}/><circle cx={x.x} cy={x.y} r={68} fill={'none'} stroke={S.secondary} opacity={.15}/><text x={x.x} y={x.y+10} textAnchor={'middle'} fontFamily={FONT} fontSize={27} fill={S.foreground}>{x.label}</text></g>)}</svg></>;
 }
 if(s.type==='end')body=<><Network f={f} light/><div style={{position:'absolute',left:100,right:100,top:290,textAlign:'center'}}><div style={{fontFamily:MONO,fontSize:22,color:S.accent,letterSpacing:5}}>{s.eyebrow}</div><div style={{fontSize:85,fontWeight:700,marginTop:30}}>{s.title}</div><div style={{fontSize:30,lineHeight:1.8,color:S.muted,marginTop:30}}>{s.subtitle}</div><div style={{marginTop:90,fontSize:20,color:S.muted,lineHeight:2}}>{film.credits.map((x:string,i:number)=><div key={i}>{x}</div>)}</div></div></>;
 if(!body)throw new Error(`Unsupported scene type ${s.type}`);
 return <AbsoluteFill style={{opacity}}><div style={{position:'absolute',left:95,right:95,top:42,borderBottom:`1px solid ${alpha(S.muted,.25)}`,paddingBottom:18,display:'flex',alignItems:'center',fontSize:17,color:S.muted}}><span style={{fontFamily:MONO,letterSpacing:4,color:S.accent}}>MOTION / {String(index+1).padStart(2,'0')}</span><span style={{marginLeft:25}}>{film.title}</span></div>{body}{s.note?<div style={{position:'absolute',left:95,right:95,top:886,fontSize:20,color:S.muted}}>{s.note}</div>:null}</AbsoluteFill>;
}

export function Main(){
 const f=useCurrentFrame(),config=useVideoConfig(),scale=config.width/1920,now=f/config.fps;
 const caption=TL.captions.find((c:any)=>now>=c.start&&now<=c.end);
 return <AbsoluteFill style={{background:S.background}}><div style={{position:'absolute',width:1920,height:1080,transform:`scale(${scale})`,transformOrigin:'top left',fontFamily:FONT,color:S.foreground,overflow:'hidden'}}>
  <AbsoluteFill style={{background:`radial-gradient(ellipse at 68% 40%,${alpha(S.secondary,.1)},transparent 65%)`}}/>
  <svg width={1920} height={1080} style={{position:'absolute',inset:0}}>{Array.from({length:85},(_,i)=><circle key={i} cx={rand(i)*1920} cy={rand(i+200)*1080} r={.7} fill={S.secondary} opacity={.15+rand(i+40)*.16}/>)}</svg>
  {TL.audioExpected?<Audio src={staticFile('mix.wav')}/>:null}
  {TL.scenes.map((s:any,i:number)=><Sequence key={s.id} from={s.from} durationInFrames={s.frames}><Scene s={s} index={i}/></Sequence>)}
  {caption?<div style={{position:'absolute',left:95,right:95,bottom:27,textAlign:'center',fontSize:29,lineHeight:1.55,padding:'6px 14px',background:alpha(S.background,.86)}}>{caption.text}</div>:null}
  <div style={{position:'absolute',bottom:0,left:0,height:3,width:100*f/Math.max(1,TL.totalFrames-1)+'%',background:`linear-gradient(90deg,${S.accent},${S.secondary})`}}/>
 </div></AbsoluteFill>;
}
