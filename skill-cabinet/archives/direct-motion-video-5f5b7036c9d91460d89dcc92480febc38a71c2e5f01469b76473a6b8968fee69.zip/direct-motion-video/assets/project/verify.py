"""Verify the complete film; successful decoding does not validate facts or artistic quality."""
import hashlib,json,subprocess
from fractions import Fraction
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent
def run(a):return subprocess.run(a,check=True,capture_output=True)
def main():
    cfg=json.loads((ROOT/'film.json').read_text(encoding='utf-8'));tl=json.loads((ROOT/'src/generated/timeline.json').read_text(encoding='utf-8'))
    movie=ROOT/'out/film.mp4';qa=ROOT/'qa'
    meta=json.loads(run(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,width,height,r_frame_rate,nb_frames,sample_rate,channels','-of','json',str(movie)]).stdout)
    v=next(s for s in meta['streams'] if s['codec_name']=='h264')
    assert (v['width'],v['height'])==(cfg['video']['width'],cfg['video']['height'])
    assert Fraction(v['r_frame_rate'])==Fraction(tl['fps'])
    assert int(v['nb_frames'])==tl['totalFrames']
    assert abs(float(meta['format']['duration'])-tl['duration'])<max(.1,1/tl['fps'])
    cursor=0
    for scene in tl['scenes']:assert scene['from']==cursor;cursor+=scene['frames']
    assert cursor==tl['totalFrames']
    for c in tl['captions']:assert 0<=c['start']<c['end']<=tl['duration']
    assert all(a['end']<=b['start'] for a,b in zip(tl['captions'],tl['captions'][1:]))
    decoded=run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'])
    assert not decoded.stderr.strip(),decoded.stderr.decode(errors='replace')
    audio=[s for s in meta['streams'] if s['codec_name']=='aac'];stats=None
    if tl['audioExpected']:
        assert audio and audio[0]['channels']==2,'Expected a stereo audio track'
        pcm=np.frombuffer(run(['ffmpeg','-v','error','-i',str(movie),'-vn','-ar','48000','-ac','2','-f','f32le','-']).stdout,dtype='<f4')
        peak=float(np.max(np.abs(pcm)));rms=float(np.sqrt(np.mean(pcm**2)))
        assert rms>1e-7 and peak<1.01,'Silent or clipped expected audio'
        stats={'peak':peak,'rms':rms}
    elif audio:raise AssertionError('An unexpected audio track was included in a declared silent film')
    samples=[]
    cols=3;rows=(len(tl['scenes'])+cols-1)//cols
    canvas=Image.new('RGB',(cols*480,rows*290),'#151a22');draw=ImageDraw.Draw(canvas)
    for i,scene in enumerate(tl['scenes']):
        time=(scene['from']+int(scene['frames']*.55))/tl['fps'];dest=qa/f'final-{scene["id"]}.png'
        run(['ffmpeg','-v','error','-y','-ss',str(time),'-i',str(movie),'-frames:v','1','-update','1',str(dest)])
        with Image.open(dest) as im:
            assert im.size==(v['width'],v['height'])
            canvas.paste(im.convert('RGB').resize((480,270)),(i%cols*480,i//cols*290+20))
        draw.text((i%cols*480+8,i//cols*290+3),scene['id'],fill='white');samples.append(str(dest))
    canvas.save(qa/'contact-sheet.jpg',quality=93)
    report={'metadata':meta,'frames_expected':tl['totalFrames'],'full_decode_passed':True,'timeline_contiguous':True,'captions':len(tl['captions']),'audio_expected':tl['audioExpected'],'audio':stats,'samples':samples,'sha256':hashlib.file_digest(movie.open('rb'),'sha256').hexdigest(),'scope':'Technical output checks; inspect images, narration and sources separately. Not a pixel-identity claim.'}
    (qa/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'frames':tl['totalFrames'],'seconds':tl['duration'],'decode':True,'audio_expected':tl['audioExpected'],'captions':len(tl['captions'])},ensure_ascii=False))
if __name__=='__main__':main()
