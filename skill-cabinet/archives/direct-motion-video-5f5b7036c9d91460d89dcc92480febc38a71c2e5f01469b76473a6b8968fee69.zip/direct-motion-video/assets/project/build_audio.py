"""Build real-duration narration, an editable timeline, captions and a voice-led mix."""
import asyncio,hashlib,json,math,re,subprocess,wave
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
SR=48000
def run(args):return subprocess.run(args,check=True,capture_output=True)
def public_file(name):
    base=(ROOT/'public').resolve();p=(base/name).resolve()
    if not p.is_relative_to(base) or not p.is_file():raise ValueError(f'Missing project public asset: {name}')
    return p
def decode(file,channels=1):
    return np.frombuffer(run(['ffmpeg','-v','error','-i',str(file),'-ar',str(SR),'-ac',str(channels),'-f','f32le','-']).stdout,dtype='<f4').copy().reshape(-1,channels)
def wav(path,a):
    with wave.open(str(path),'wb') as f:
        f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR)
        f.writeframes((np.clip(a,-1,1)*32767).astype('<i2').tobytes())
def timecode(t):
    x=round(t*1000);h,x=divmod(x,3600000);m,x=divmod(x,60000);s,x=divmod(x,1000)
    return f'{h:02d}:{m:02d}:{s:02d},{x:03d}'

async def edge_clip(text,settings):
    import edge_tts
    rate=str(settings.get('rate','+0%'));pitch=str(settings.get('pitch','+0Hz'))
    if not rate.startswith(('+','-')):rate='+'+rate
    if not pitch.startswith(('+','-')):pitch='+'+pitch
    if not re.fullmatch(r'[+-]\d+%',rate) or not re.fullmatch(r'[+-]\d+Hz',pitch):raise ValueError('Edge rate must be signed percent and pitch signed Hz')
    key={'text':text,'voice':settings.get('voice','zh-CN-YunxiNeural'),'rate':rate,'pitch':pitch}
    cache=ROOT/'.tmp/voice';cache.mkdir(parents=True,exist_ok=True)
    token=hashlib.sha256(json.dumps(key,ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
    dest=cache/f'{token}.mp3';meta=cache/f'{token}.json'
    if dest.is_file() and meta.is_file() and dest.stat().st_size>1000:return dest,key
    for attempt in range(3):
        try:
            part=cache/f'{token}.part.mp3'
            await edge_tts.Communicate(**key).save(str(part))
            if part.stat().st_size<1000:raise RuntimeError('Empty narration result')
            decode(part)
            part.replace(dest);meta.write_text(json.dumps(key,ensure_ascii=False),encoding='utf-8')
            return dest,key
        except Exception:
            if attempt==2:raise
            await asyncio.sleep(2+attempt*2)

def original_score(n,seconds,settings,starts):
    music=np.zeros((n,2),dtype=np.float32);tempo=float(settings.get('tempo',80))
    if not 30<=tempo<=200:raise ValueError('Music tempo must be between 30 and 200 BPM')
    rng=np.random.default_rng(int(settings.get('seed',42)))
    def hz(m):return 440*2**((m-69)/12)
    def add(sig,t,gain,pan=0):
        p=round(t*SR)
        if not 0<=p<n:return
        sig=np.asarray(sig[:n-p],dtype=np.float32)*gain
        music[p:p+len(sig),0]+=sig*np.sqrt((1-pan)/2)
        music[p:p+len(sig),1]+=sig*np.sqrt((1+pan)/2)
    def bell(m):
        t=np.arange(int(2.2*SR),dtype=np.float32)/SR
        return (np.sin(2*np.pi*hz(m)*t)+.23*np.sin(2*np.pi*hz(m)*2.002*t))*np.minimum(1,t/.012)*np.exp(-2.7*t)
    bar=240/tempo
    chords=[[48,55,60,63],[44,51,55,60],[46,53,58,62],[41,48,55,60]]
    for k,start in enumerate(np.arange(0,seconds,bar*2)):
        d=bar*2+2;t=np.arange(round(d*SR),dtype=np.float32)/SR
        env=np.minimum(1,t/1.4)*np.minimum(1,np.maximum(0,d-t)/2.3)
        for j,m in enumerate(chords[k%4]):
            sig=(np.sin(2*np.pi*hz(m)*t)+.28*np.sin(2*np.pi*hz(m)*1.002*t))*env
            add(sig,float(start),.020,-.6+j*.4)
    for k,start in enumerate(np.arange(.5,seconds,60/tempo)):
        if k%4==3:continue
        add(bell([72,79,75,82,79,74,70,67][k%8]),float(start),.014,float(rng.uniform(-.45,.45)))
    for start in starts[1:]:add(bell(72),start,.025,.1)
    wet=np.zeros_like(music)
    for d,g in [(.23,.15),(.47,.1),(.71,.06)]:
        q=round(d*SR)
        if q<n:wet[q:]+=music[:-q,::-1]*g
    return (music+wet)*float(settings.get('gain',.6))

async def main():
    cfg=json.loads((ROOT/'film.json').read_text(encoding='utf-8'));fps=int(cfg['video']['fps'])
    if fps!=cfg['video']['fps'] or not 1<=fps<=120:raise ValueError('Starter uses integer fps between 1 and 120')
    ids=[s['id'] for s in cfg['scenes']]
    if not ids or len(set(ids))!=len(ids) or any(not re.fullmatch(r'[A-Za-z0-9_-]+',x) for x in ids):raise ValueError('Scene IDs must be unique safe names')
    types={'title','hero','compare','timeline','diagram','end'}
    for s in cfg['scenes']:
        if s['type'] not in types:raise ValueError(f'Implement the new scene type before rendering: {s["type"]}')
        if not math.isfinite(float(s.get('seconds',5))) or float(s.get('seconds',5))<=0:raise ValueError('Scene duration must be positive')
        if s['type']=='compare':
            for d in s.get('data',[]):
                if type(d['value']) not in (int,float) or not math.isfinite(d['value']) or d['value']<0:raise ValueError('Starter compare chart requires finite nonnegative numeric values; adapt the chart for other data')
        if s['type']=='diagram':
            nodes=[x['id'] for x in s.get('nodes',[])]
            if len(nodes)!=len(set(nodes)):raise ValueError('Diagram node IDs must be unique')
            if any(x['from'] not in nodes or x['to'] not in nodes for x in s.get('links',[])):raise ValueError('Diagram link references a missing node')
    for p in ['public','out','qa','.tmp','src/generated']:(ROOT/p).mkdir(parents=True,exist_ok=True)
    audio=cfg.get('audio',{});settings=audio.get('narration',{'mode':'none'});mode=settings.get('mode','none')
    music_settings=audio.get('music',{'mode':'none'});music_mode=music_settings.get('mode','none')
    if mode not in {'none','edge','local'} or music_mode not in {'none','original','file'}:raise ValueError('Unknown audio mode')
    supplied_music=public_file(music_settings['file']) if music_mode=='file' else None
    scenes=[];captions=[];pieces=[];voices=[];frame=0
    for s in cfg['scenes']:
        offset=.7
        if mode!='none':
            for entry in s.get('narration',[]):
                text=entry if isinstance(entry,str) else entry['text']
                if mode=='edge':file,key=await edge_clip(text,settings)
                else:
                    if isinstance(entry,str) or not entry.get('audio'):raise ValueError('Local narration requires {text,audio} entries')
                    file=public_file(entry['audio']);key={'text':text,'file':entry['audio'],'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
                voice=decode(file).reshape(-1);length=len(voice)/SR
                pieces.append((frame/fps+offset,voice));voices.append(key)
                captions.append({'start':round(frame/fps+offset,5),'end':round(frame/fps+offset+length,5),'text':text,'scene':s['id']})
                offset+=length+.25
        frames=math.ceil(max(float(s.get('seconds',5)),offset+.8 if mode!='none' else 0)*fps)
        scenes.append({**s,'from':frame,'frames':frames});frame+=frames
    seconds=frame/fps;n=round(seconds*SR)
    narration=np.zeros((n,2),dtype=np.float32)
    for t,v in pieces:
        p=round(t*SR);v=v[:n-p];narration[p:p+len(v)]+=v[:,None]*.85
    music=np.zeros_like(narration)
    if music_mode=='original':music=original_score(n,seconds,music_settings,[s['from']/fps for s in scenes])
    elif music_mode=='file':
        b=decode(supplied_music,2);m=min(len(b),n);music[:m]=b[:m]*float(music_settings.get('gain',.25))
        if len(b)<n:print('Music is shorter than the film; remaining music is silent. Review the edit.')
    duck=np.ones(n,dtype=np.float32)
    for c in captions:
        a=max(0,round((c['start']-.15)*SR));b=min(n,round((c['end']+.2)*SR));duck[a:b]=.55
    fade=np.minimum(np.arange(n)/SR/1.2,1)*np.minimum((n-np.arange(n))/SR/1.8,1)
    music*=duck[:,None]*fade[:,None];mix=narration+music
    peak=float(np.max(np.abs(mix)))
    if peak>.94:mix*=.94/peak
    audible=bool(float(np.sqrt(np.mean(mix**2)))>1e-7)
    wav(ROOT/'.tmp/raw-mix.wav',mix)
    if audible:run(['ffmpeg','-v','error','-y','-i',str(ROOT/'.tmp/raw-mix.wav'),'-af','loudnorm=I=-18:TP=-1.5:LRA=9','-ar',str(SR),'-ac','2',str(ROOT/'public/mix.wav')])
    else:wav(ROOT/'public/mix.wav',mix)
    tl={'fps':fps,'totalFrames':frame,'duration':seconds,'audioExpected':audible,'scenes':scenes,'captions':captions}
    (ROOT/'src/generated/timeline.json').write_text(json.dumps(tl,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'out/captions.srt').write_text('\n\n'.join(f'{i+1}\n{timecode(c["start"])} --> {timecode(c["end"])}\n{c["text"]}' for i,c in enumerate(captions)),encoding='utf-8')
    board=[f'# {cfg["title"]}', '',cfg.get('subtitle',''),'']
    for s in scenes:
        board += [f'## {s["from"]/fps:.2f}s — {(s["from"]+s["frames"])/fps:.2f}s | {s.get("title",s["id"])}','',f'场景：{s["type"]}',s.get('subtitle',''),s.get('note','')]+[c['text'] for c in captions if c['scene']==s['id']]+['']
    (ROOT/'out/storyboard.md').write_text('\n'.join(board),encoding='utf-8')
    (ROOT/'qa/audio.json').write_text(json.dumps({'duration':seconds,'frames':frame,'narration_mode':mode,'music_mode':music_mode,'audio_expected':audible,'voice_cache_keys':voices,'mastering':'-18 LUFS / -1.5 dBTP'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Built {frame} frames / {seconds:.2f}s; {len(captions)} captions; audible={audible}')

if __name__=='__main__':asyncio.run(main())
