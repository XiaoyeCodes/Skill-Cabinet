# `film.json` 与扩展位置

`assets/project/film.json` 是可运行、明确标作演示的非天文示例。替换内容，并按题材新增镜头。

## 顶层

| 字段 | 用途 |
|---|---|
| `title`, `subtitle`, `language` | 片名、核心说明、语言标签 |
| `video.width/height/fps` | 输出规格；起点布局支持 16:9 |
| `style.background/foreground/accent/secondary/muted` | 色彩标记，不限制为金蓝色 |
| `style.fontFamily`, `fontFiles` | CSS 字体族与 `[{family,path,weight}]`；路径相对 `public/` |
| `audio.narration.mode` | `none` / `edge` / `local` |
| `audio.narration.voice/rate/pitch` | Edge 配置，仅该模式使用 |
| `audio.music.mode` | `original` / `file` / `none` |
| `audio.music.file`, `gain`, `tempo`, `seed` | 已有音乐位置或原创音乐设置 |
| `scenes` | 有序场景数组，数量由叙事决定 |
| `credits` | 片尾署名；事实与许可仍写入 `SOURCES.md` |

## 场景共有字段

`id` 唯一且只含字母、数字、下划线、短横线。`type` 为下表之一；`title`、`eyebrow`、`subtitle`、`note` 可选。`seconds` 是画面预算；`narration` 是字符串或 `{text,audio}` 组成的数组，`local` 模式下每句需有 `audio` 路径（相对 `public/`）。

| 类型 | 字段 | 用途与扩展 |
|---|---|---|
| `title` | `visual` | 片头、提问、主题揭示 |
| `hero` | `bullets`, `metrics:[{label,value}]`, `visual` | 主体、产品、人物或概念 |
| `compare` | `data:[{label,value,color?}]`, `unit`, `note` | 同单位、非负数、零基线条形图；负值或双轴需改组件 |
| `timeline` | `events:[{label,at,detail?}]` | 顺序或阶段；真实时间比例需要改坐标映射 |
| `diagram` | `nodes:[{id,label}]`, `links:[{from,to}]` | 关系、流程与网络；可扩展坐标与边路由 |
| `end` | `subtitle` | 观点回收与署名 |

`metrics.value` 是展示字符串，可带单位；`compare.data.value` 是非负数。不能用带单位字符串冒充数值。跨项目复用先确认来源与量纲，不沿用示例数字。

## `visual`

`kind` 是 `network`、`image` 或 `sphere`。`image` 需要 `src`；`sphere` 可配 `color`、`texture`、`tilt`（度）、`rings`。图片和纹理相对 `public/`，缺失会报错。无纹理时是示意材质，不声称为真实主体影像。

## 扩展位置

- `src/Main.tsx`：场景、构图、字幕、转场与路由。
- `src/Spatial.tsx`：三维主体、环系与光晕，不是完整天文或 CAD 引擎。
- `build_audio.py`：语音供应商、实际时长、配乐、混音。
- `render.mjs`：浏览器、参数、代表帧、进度。
- `verify.py`：输出约束；按新关键行为增加合适的检查。

起点没有星体数据、历史事实、品牌资产或专有字体。新的内容仍需要导演判断、资料核验与实际观看。
