# 本地制作流程

## 起点与依赖

1. 运行 `scripts/new_project.py <新目录>`，在 `film.json` 改写内容。
2. 运行 `scripts/doctor.py <目录>` 检查磁盘、Node、FFmpeg、Chrome 和 Python 模块。优先使用当前环境提供的运行时发现工具，不把本机工具路径抄到通用 Skill 中。
3. 新项目需要其 `package.json` 的依赖、Python 3.11+、`requirements.txt` 的 Python 包和支持 libx264 的 FFmpeg。可在项目 `.venv` 安装 Python 依赖；用同一个 Python 环境运行 doctor 和音频构建。`--deps-from` 仅复用明确选择的现成依赖，不复制其源码和素材。
4. `CHROME_PATH` 可指定浏览器；ANGLE 后端可通过 `MOTION_GL` 配置。

## 音频与时间线

项目 `build_audio.py` 根据 `film.json` 创建 `src/generated/timeline.json`、`public/mix.wav`、`out/captions.srt`、`out/storyboard.md` 和 `qa/audio.json`。字幕根据实际句子音频时长定位。

支持不解说、Edge TTS 和本地语音。网络解说是可替换能力，非唯一必需供应商。缓存键包含文本、声线、语速、音调或本地文件内容，防止改稿后复用旧解说。

`audio.music.mode` 可为 `original`、`file`、`none`。`original` 是代码合成的氛围配乐，可改写配器；不能描述成管弦乐录音。`file` 需要记录素材来源或许可。音量退让依语音区间实施。

`scene.seconds` 是画面预算。实际语音长于预算时，模板延长镜头以保留完整句子；目标时长固定的任务必须改稿、调速或重剪后重新生成，不能默默超时。没有声音时明确设置模式为 `none`。

## 画面与渲染

- `node render.mjs --stills`：所有场景代表帧；
- `node render.mjs --preview`：首段最多 12 秒；
- `node render.mjs`：完整 MP4；
- `python verify.py`：规格、时间线、音轨（有声时）、全片解码与画面抽样核验。

起点使用 1920×1080 逻辑画布，16:9 输出可按 `video.width/height` 改分辨率，三维画布使用实际像素。其他画幅必须改布局，不把缩小后的横屏当成完整竖屏设计。

`MOTION_CONCURRENCY` 默认 2。低显存或有其他任务时先测较低并发。不要因渲染慢而静默降低用户要求的帧率、分辨率、采样或特效。

## 资源与故障

- 相对素材路径指向项目 `public/`。保留 `SOURCES.md` 与署名，不复制私人字体、不相关素材和上次影片的歌曲进分发包。
- `style.fontFiles` 配置文件，`fontFamily` 选择字体。未配置时使用系统回退，换机器可能改变字形；已指定的字体文件缺失时终止渲染。
- 临时文件在 `.tmp/`，日志在 `qa/`。失败时保存日志并修正原因，不将半成品当完成。中断后检查实际进程、写入时间和封装状态。
- 站点连不上可合理重试或使用有明确来源与许可的镜像；不把一次网络问题变成所有环境强制 IPv4 的规则。

编译成功不代表视觉正确，抽样图像不证明每帧一致，全片解码成功也不证明事实正确。分别检查运行、观看、声音与资料，交付时只报告实际完成的核验。
