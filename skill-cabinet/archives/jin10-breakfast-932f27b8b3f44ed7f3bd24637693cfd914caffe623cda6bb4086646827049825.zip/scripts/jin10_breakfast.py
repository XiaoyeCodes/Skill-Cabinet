#!/usr/bin/env python3
"""Fetch, inspect and render Jin10 breakfast. Python 3.9+. No sending/scheduling."""
import argparse
import base64
from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
import hashlib
import html as html_std
import io
import json
from pathlib import Path
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid

from lxml import html
from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parents[1]
TOPIC = 'https://xnews.jin10.com/topic/343'
BJ = timezone(timedelta(hours=8))
SCHEMA = 'jin10-breakfast/1'
TITLE = re.compile(r'^金十数据全球财经早餐\s*[|｜]\s*(\d{4})年(\d{1,2})月(\d{1,2})日$')
DATE_RE = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
AUDIO_LABELS = ['男生普通话版', '男声普通话版', '女声普通话版', '粤语版', '西南方言版', '东北话版', '上海话版', '下载mp3']
STYLE = {
    'p': 'margin:0 0 17px;font-size:15px;line-height:1.95;color:#48443e;word-wrap:break-word;overflow-wrap:anywhere;',
    'h2': 'margin:36px 0 23px;padding:23px 0 0;border-top:1px solid #d7cbb8;font-size:23px;line-height:1.5;font-weight:600;letter-spacing:1px;color:#282622;',
    'blockquote': 'margin:0 0 26px;padding:3px 0 1px 21px;border-left:2px solid #a9987d;',
    'strong': 'font-weight:600;color:#282622;',
    'b': 'font-weight:600;color:#282622;',
}

class Failure(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def class_nodes(node, name):
    return node.xpath('.//*[contains(concat(" ", normalize-space(@class), " "), " ' + name + ' ")]')


def one(node, name):
    found = class_nodes(node, name)
    if len(found) != 1:
        raise Failure('structure_error', 'Expected exactly one .' + name)
    return found[0]


def title_date(text):
    m = TITLE.fullmatch(text.strip())
    if not m:
        raise Failure('structure_error', 'Unexpected breakfast title: ' + text[:100])
    try:
        return date(*map(int, m.groups())).isoformat()
    except ValueError as exc:
        raise Failure('structure_error', 'Invalid title date') from exc


def safe_url(value, image=False):
    url = urllib.parse.urljoin(TOPIC, value)
    u = urllib.parse.urlsplit(url)
    allowed = {'img.jin10.com'} if image else {'xnews.jin10.com'}
    if (u.scheme != 'https' or u.hostname not in allowed or u.username or u.password
            or u.port not in (None, 443) or u.fragment or u.query
            or any(ord(c) < 32 for c in url)):
        raise Failure('unsafe_url', 'URL is outside the allowed HTTPS origin/path')
    pattern = r'/news/[A-Za-z0-9_./-]+\.(?:jpg|jpeg|png)' if image else r'/(?:topic/343|details/\d+)'
    if not re.fullmatch(pattern, u.path, re.I) or '..' in u.path.split('/'):
        raise Failure('unsafe_url', 'Unexpected source URL path')
    return url


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, image):
        self.image = image
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        safe_url(newurl, self.image)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch(url, image=False):
    url = safe_url(url, image)
    opener = urllib.request.build_opener(SafeRedirect(image))
    req = urllib.request.Request(url, headers={'User-Agent': 'Jin10BreakfastSkill/1.0 (read-only)', 'Accept': 'image/*' if image else 'text/html'})
    limit = 20_000_000 if image else 4_000_000
    try:
        with opener.open(req, timeout=25) as response:
            safe_url(response.geturl(), image)
            content_type = response.headers.get_content_type()
            if image and content_type not in ('image/jpeg', 'image/png', 'application/octet-stream'):
                raise Failure('access_error', 'Image response is not an image')
            if not image and content_type not in ('text/html', 'application/xhtml+xml'):
                raise Failure('access_error', 'Source response is not HTML')
            data = response.read(limit + 1)
            if len(data) > limit:
                raise Failure('access_error', 'Source exceeds size limit')
            return data
    except urllib.error.HTTPError as exc:
        raise Failure('access_error', 'HTTP %d for %s. Do not treat this as no update.' % (exc.code, url)) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise Failure('access_error', 'Network/TLS/timeout error for ' + url + ': ' + str(exc)) from exc


def parse_dom(data):
    try:
        text = data.decode('utf-8-sig') if isinstance(data, bytes) else data
        if '\ufffd' in text:
            raise ValueError('replacement characters')
        return html.fromstring(text)
    except (ValueError, UnicodeError) as exc:
        raise Failure('structure_error', 'Source is not valid UTF-8 HTML') from exc


def discover(topic_data, target, historical=False):
    dom = parse_dom(topic_data)
    rows = class_nodes(dom, 'jin10-news-list-item-title')
    if not rows:
        raise Failure('structure_error', 'Topic list is absent; possible access challenge or changed page')
    result = []
    dates = []
    for row in rows:
        text = row.text_content().strip()
        if not TITLE.fullmatch(text):
            continue
        d = title_date(text)
        dates.append(d)
        anchors = row.xpath('ancestor::a[@href][1]')
        if len(anchors) != 1:
            raise Failure('structure_error', 'Topic title is not attached to one article URL')
        url = safe_url(anchors[0].get('href'))
        if d == target and url not in result:
            result.append(url)
    if not dates:
        raise Failure('structure_error', 'No valid breakfast entries in topic list')
    if not result:
        if historical:
            raise Failure('date_not_found', 'Requested historical date is not in the loaded topic page. Supply its verified article URL; do not use a different date.')
        if max(dates) > target:
            raise Failure('date_mismatch', 'Topic contains a breakfast newer than the current Beijing date; verify host clock')
        raise Failure('no_update', 'No breakfast for today in the successfully loaded topic page')
    if len(result) > 5:
        raise Failure('structure_error', 'Too many same-date candidates')
    return result


def nuxt_metadata(dom, article_id):
    """Read only JSON literals and scalar assignments. Never execute page JavaScript."""
    scripts = [n.text for n in dom.xpath('//script') if n.text and n.text.startswith('window.__NUXT__=')]
    for script in scripts:
        m = re.fullmatch(r'window\.__NUXT__=\(function\(([^)]*)\)\{(.*)\}\((.*)\)\);?', script, re.S)
        if not m:
            continue
        try:
            args = json.loads('[' + m[3] + ']')
        except json.JSONDecodeError:
            continue
        names = m[1].split(',')
        if len(names) != len(args):
            continue
        bindings = dict(zip(names, args))
        objects = {}
        assignment = r'\b([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)=("(?:[^"\\]|\\.)*"|[A-Za-z_$][\w$]*|-?\d+(?:\.\d+)?);'
        for var, prop, value in re.findall(assignment, m[2]):
            try:
                decoded = json.loads(value)
            except json.JSONDecodeError:
                decoded = bindings.get(value)
            objects.setdefault(var, {})[prop] = decoded
        matches = [v for v in objects.values() if str(v.get('id')) == article_id and v.get('title')]
        if len(matches) == 1:
            return matches[0]
    raise Failure('structure_error', 'Cannot independently resolve article publication metadata from Nuxt; review changed structure')


def clean_body(source):
    body = deepcopy(source)
    # Find table semantically, not by image index or dated URL.
    candidates = []
    for image in body.xpath('.//img'):
        before = image.xpath('preceding::h2[1]')
        after = image.xpath('following::h2[1]')
        if before and after and before[0].text_content().strip() == '市场盘点' and after[0].text_content().strip() == '国际要闻':
            candidates.append(image)
    if len(candidates) != 1:
        raise Failure('structure_error', 'Cannot uniquely locate closing table between 市场盘点 and 国际要闻')
    selected = candidates[0]
    table_url = safe_url(selected.get('src', ''), image=True)
    figures = selected.xpath('ancestor::figure[1]')
    if len(figures) != 1 or len(figures[0].xpath('.//img')) != 1:
        raise Failure('structure_error', 'Closing table figure structure changed')
    keep = figures[0]
    for node in list(body.xpath('.//*[contains(concat(" ",normalize-space(@class)," ")," insert-audio ")]')):
        # Known audio row only. Unexpected accompanying prose requires review.
        text = node.text_content().strip()
        residual = text
        for label in AUDIO_LABELS:
            residual = residual.replace(label, '')
        if residual.strip():
            raise Failure('structure_error', 'Audio row contains unrecognized prose; do not delete blindly')
        node.drop_tree()
    for node in list(body.xpath('.//figure')):
        if node is not keep:
            node.drop_tree()
    for node in list(keep):
        keep.remove(node)
    keep.text = None
    keep.attrib.clear()
    keep.set('id', 'closing-table')
    keep.set('style', 'margin:25px 0 27px;padding:0;')
    image = html.Element('img', src='__CLOSING_TABLE_IMAGE__', alt='', width='550')
    image.set('style', 'display:block;width:100%;max-width:550px;height:auto;border:0;outline:none;text-decoration:none;')
    keep.append(image)
    # Images outside figures are excluded too, without deleting neighboring prose.
    for node in list(body.xpath('.//img')):
        if node is not image:
            node.drop_tree()
    for node in list(body.xpath('.//figcaption')):
        node.drop_tree()
    forbidden = body.xpath('.//audio|.//video|.//iframe|.//script|.//object|.//embed|.//form')
    if forbidden:
        raise Failure('structure_error', 'Unexpected active/media element outside recognized removable audio rows')
    serialized = html.tostring(body, encoding='unicode')
    if re.search(r'\.mp3(?:[?"\s<]|$)', serialized, re.I) or any(x in body.text_content() for x in AUDIO_LABELS):
        raise Failure('structure_error', 'Unrecognized audio link or label remains')
    expected_text = body.text_content()
    expected_paragraphs = [n.text_content() for n in body.xpath('.//p')]
    expected_bold = [n.text_content() for n in body.xpath('.//strong|.//b')]
    allowed = {'div','p','h2','h3','h4','blockquote','strong','b','em','i','u','span','br','a','ol','ul','li','figure','img','sup','sub'}
    for node in body.iter():
        if not isinstance(node.tag, str) or node.tag not in allowed:
            raise Failure('structure_error', 'Unexpected article markup requires review: ' + str(node.tag))
        if node.tag in ('img','figure'):
            continue
        href = node.get('href') if node.tag == 'a' else None
        list_attrs = {k: node.get(k) for k in ('start','value','type') if node.get(k) is not None and node.tag in ('ol','ul','li')}
        node.attrib.clear()
        for k,v in list_attrs.items():
            node.set(k,v)
        if href:
            parsed = urllib.parse.urlsplit(urllib.parse.urljoin(TOPIC, href))
            if parsed.scheme == 'https' and not parsed.username and not parsed.password:
                node.set('href', urllib.parse.urlunsplit(parsed))
                node.set('rel', 'noopener noreferrer')
        if node.tag in STYLE:
            style = STYLE[node.tag]
            if node.tag == 'p' and re.match(r'^\s*[②③④⑤⑥⑦⑧⑨⑩]', node.text_content()):
                style += 'padding-left:18px;'
            node.set('style', style)
        if node.tag == 'h2':
            node.set('class','section-heading')
    if body.text_content() != expected_text or [n.text_content() for n in body.xpath('.//p')] != expected_paragraphs or [n.text_content() for n in body.xpath('.//strong|.//b')] != expected_bold:
        raise Failure('validation_error', 'Text or emphasis changed during sanitization')
    return body, table_url


def parse_article(data, source_url, target):
    source_url = safe_url(source_url)
    article_id = urllib.parse.urlsplit(source_url).path.rsplit('/',1)[-1]
    dom = parse_dom(data)
    title_node = one(dom, 'jin10-news-cdetails-title')
    intro = one(dom, 'jin10-cnews-introduction').text_content()
    article = one(dom, 'jin10-news-cdetails-article')
    disclaimer = one(dom, 'new-decale').text_content()
    title = title_node.text_content().strip()
    if title_date(title) != target:
        raise Failure('date_mismatch', 'Article title is not the requested Beijing date')
    meta = nuxt_metadata(dom, article_id)
    publication = meta.get('display_datetime', '')
    if not DATE_RE.fullmatch(publication):
        raise Failure('structure_error', 'Missing strict publication timestamp')
    try:
        pub = datetime.strptime(publication,'%Y-%m-%d %H:%M:%S').replace(tzinfo=BJ)
    except ValueError as exc:
        raise Failure('structure_error', 'Invalid publication timestamp') from exc
    if pub.date().isoformat() != target or meta.get('title') != title or meta.get('introduction','').strip() != intro.strip():
        raise Failure('date_mismatch', 'SSR title/introduction and publication metadata do not agree')
    if not intro.strip() or not disclaimer.strip():
        raise Failure('structure_error', 'Missing introduction or disclaimer')
    body, table_url = clean_body(article)
    headings = [n.text_content() for n in body.xpath('.//h2')]
    if headings != ['今日优选','市场盘点','国际要闻','国内要闻','风险预警']:
        raise Failure('structure_error', 'Section structure changed; inspect before accepting')
    paragraphs = [n.text_content() for n in body.xpath('.//p')]
    if len(paragraphs) < 15:
        raise Failure('structure_error', 'Body appears truncated')
    source_html = html.tostring(body, encoding='unicode')
    return {'schema':SCHEMA,'date':target,'title':title,'introduction':intro,'publication_beijing':publication,
            'source_url':source_url,'table_source_url':table_url,'disclaimer':disclaimer,
            'article_html':source_html,'headings':headings,'paragraphs':paragraphs,
            'bold_spans':[n.text_content() for n in body.xpath('.//strong|.//b')],
            'body_text':body.text_content(),'source_html_sha256':sha(data if isinstance(data,bytes) else data.encode())}


def inspect_crop(data):
    try:
        image = Image.open(io.BytesIO(data))
        if image.format not in ('JPEG','PNG') or image.width < 300 or image.height < 500 or image.width*image.height > 25_000_000:
            raise ValueError('Unexpected table image format or dimensions')
        image.load()
        image = image.convert('RGB')
    except Exception as exc:
        raise Failure('image_error', 'Cannot decode expected table image: ' + str(exc)) from exc
    w,h = image.size
    # Wide pale-gray horizontal border candidates, independent of date/dimensions.
    pixels = image.load()
    left,right = max(1,round(w*.01)), min(w-1,round(w*.99))
    step = max(1,w//700)
    xs = list(range(left,right,step))
    border_rows = []
    for y in range(int(h*.40),int(h*.94)):
        gray = sum(218 <= min(pixels[x,y]) <= 249 and max(pixels[x,y])-min(pixels[x,y]) < 8 for x in xs)/len(xs)
        if gray >= .85:
            border_rows.append(y)
    groups = []
    for y in border_rows:
        if not groups or y > groups[-1][-1]+1:
            groups.append([y])
        else:
            groups[-1].append(y)
    proposals = []
    margin = max(2,round(w/240))
    for rows in groups:
        bottom = rows[-1]+1+margin
        if bottom >= h:
            continue
        # Promotional area should have an immediately clear gap then dark content.
        gap_end = min(h,bottom+max(10,round(w*.035)))
        gap_samples = [pixels[x,y] for y in range(bottom,gap_end,2) for x in xs]
        gap_dark = sum(max(p)<220 for p in gap_samples)/max(1,len(gap_samples))
        below = [pixels[x,y] for y in range(gap_end,h,max(2,h//200)) for x in xs]
        dark_below = sum(max(p)<130 for p in below)/max(1,len(below))
        score = .95 if gap_dark < .004 and dark_below > .025 and len(rows) >= 2 else .45
        proposals.append({'crop_bottom':bottom,'border_rows':[rows[0],rows[-1]],'confidence':score,
                          'gap_dark_fraction':round(gap_dark,6),'below_dark_fraction':round(dark_below,6)})
    proposals.sort(key=lambda p:(p['confidence'],p['crop_bottom']),reverse=True)
    proposal = proposals[0] if len([p for p in proposals if p['confidence']>=.9])==1 else None
    return image, {'source_dimensions':[w,h], 'candidates':proposals,'proposal':proposal,
                   'method':'wide-gray-border-gap-v1','visual_verification_required':True,
                   'note':'Heuristic confidence is not proof. Verify full last data row/title/watermarks and removed APP/QR block.'}


def exact_crop(image, bottom):
    w,h = image.size
    if not 1 < bottom < h:
        raise Failure('crop_error','Crop bottom must retain a proper upper rectangle')
    crop = image.crop((0,0,w,bottom))
    if ImageChops.difference(crop,image.crop((0,0,w,bottom))).getbbox() is not None:
        raise Failure('validation_error','Retained pixels differ')
    output = io.BytesIO()
    crop.save(output,format='PNG')
    reloaded = Image.open(io.BytesIO(output.getvalue())).convert('RGB')
    if reloaded.tobytes() != image.crop((0,0,w,bottom)).tobytes():
        raise Failure('validation_error','Encoded PNG differs from original decoded RGB pixels')
    return output.getvalue()


def inner(node):
    return (node.text or '') + ''.join(html.tostring(c,encoding='unicode',with_tail=True) for c in node)


def render(record, crop, masthead):
    body = parse_dom(record['article_html'])
    body_html = inner(body).replace('__CLOSING_TABLE_IMAGE__','data:image/png;base64,'+base64.b64encode(crop).decode('ascii'))
    esc = html_std.escape
    content = '<div id="original-content"><h1 class="original-title" style="margin:0 0 17px;font-size:23px;line-height:1.65;font-weight:600;letter-spacing:.1px;color:#282622;">'+esc(record['title'])+'</h1>\n'
    content += '<div class="source-introduction" style="margin:0 0 27px;font-size:15px;line-height:1.95;color:#827563;">'+esc(record['introduction'])+'</div>\n'+body_html
    content += '<div class="source-disclaimer" style="margin:30px 0 0;padding:21px 0 0;border-top:1px solid #e3d9c9;font-size:11px;line-height:1.95;color:#918574;">'+esc(record['disclaimer'])+'</div></div>'
    dt = date.fromisoformat(record['date'])
    chinese_date = '%d年%d月%d日' % (dt.year,dt.month,dt.day)
    template = (ROOT/'assets/template-v3.html').read_text(encoding='utf-8')
    values = {'{{DATE}}':chinese_date,'{{ORIGINAL_CONTENT}}':content,
              '{{MASTHEAD}}':'data:image/png;base64,'+base64.b64encode(masthead).decode('ascii'),
              '{{SOURCE_URL}}':esc(record['source_url'],quote=True),
              '{{PUBLICATION}}':chinese_date+' '+record['publication_beijing'].split(' ')[1]}
    for key,value in values.items():
        template = template.replace(key,value)
    if re.search(r'\{\{[A-Z_]+\}\}',template) or 'cid:' in template:
        raise Failure('validation_error','Unresolved template token or CID')
    dom = parse_dom(template)
    original = dom.get_element_by_id('original-content')
    if [n.text_content() for n in original.xpath('.//p')] != record['paragraphs'] or [n.text_content() for n in original.xpath('.//strong|.//b')] != record['bold_spans']:
        raise Failure('validation_error','Rendered paragraphs/emphasis changed')
    if len(original.xpath('.//img')) != 1 or len(dom.xpath('//img')) != 2:
        raise Failure('validation_error','Unexpected image count')
    if any(not n.get('src','').startswith('data:image/png;base64,') for n in dom.xpath('//img')):
        raise Failure('validation_error','Non-embedded image in standalone HTML')
    text = [record['title'],record['introduction'].strip()]
    for node in body.iter():
        if node.tag in ('h2','h3','h4','p','li'):
            text.append(node.text_content())
    text.extend([record['disclaimer'].strip(),'来源：金十数据',record['source_url'],'原文发布于 '+values['{{PUBLICATION}}']])
    return template,'\n\n'.join(text)+'\n'


def prepare(args):
    target = args.date or datetime.now(BJ).date().isoformat()
    date.fromisoformat(target)
    out = Path(args.out) if args.out else Path('jin10-output')/(target+'-'+datetime.now(BJ).strftime('%H%M%S')+'-'+uuid.uuid4().hex[:6])
    if out.exists() and any(out.iterdir()):
        raise Failure('output_exists','Output folder must be new or empty. This prevents mixing stale and current artifacts.')
    out.mkdir(parents=True,exist_ok=True)
    manifest = {'schema':SCHEMA,'target_date':target,'mode':'historical' if args.date else 'today',
                'created_at':datetime.now(timezone.utc).isoformat(),'status':'working','ready':False,'artifacts':[]}
    try:
        if args.source_url:
            urls = [safe_url(args.source_url)]
        else:
            topic = Path(args.topic_html).read_bytes() if args.topic_html else fetch(TOPIC)
            urls = discover(topic,target,bool(args.date))
        if args.article_html and (len(urls)!=1 or not args.source_url):
            raise Failure('input_error','Saved article HTML requires one verified --source-url')
        records = []
        for url in urls:
            data = Path(args.article_html).read_bytes() if args.article_html else fetch(url)
            records.append(parse_article(data,url,target))
        record = max(records,key=lambda r:r['publication_beijing'])
        data = Path(args.table_image).read_bytes() if args.table_image else fetch(record['table_source_url'],image=True)
        image, report = inspect_crop(data)
        (out/'table-original.image').write_bytes(data)
        image.save(out/'table-original.png')
        if report['proposal']:
            (out/'table-candidate.png').write_bytes(exact_crop(image,report['proposal']['crop_bottom']))
        record['table_original_sha256'] = sha(data)
        json_write(out/'review-data.json',record)
        json_write(out/'crop-review.json',report)
        manifest.update(status='review_required',source_url=record['source_url'],publication_beijing=record['publication_beijing'],
                        source_image_sha256=sha(data),review_data_sha256=sha((out/'review-data.json').read_bytes()),
                        reason='Visually inspect original/candidate. Only confirm when all actual rows/title/watermarks are intact and APP/QR promotion is removed.',
                        proposed_crop_bottom=report['proposal']['crop_bottom'] if report['proposal'] else None,
                        inspection_files=['table-original.png','crop-review.json','review-data.json']+(['table-candidate.png'] if report['proposal'] else []))
    except Failure as exc:
        manifest.update(status=exc.status,reason=str(exc))
    except (OSError,ValueError) as exc:
        manifest.update(status='input_error',reason=str(exc))
    json_write(out/'status.json',manifest)
    print(json.dumps({'output_directory':str(out),**manifest},ensure_ascii=False,indent=2))
    return 0 if manifest['status']=='review_required' else (10 if manifest['status']=='no_update' else 20)


def finalize(args):
    out = Path(args.out)
    manifest = json.loads((out/'status.json').read_text(encoding='utf-8'))
    if manifest.get('schema')!=SCHEMA or manifest.get('status')!='review_required' or manifest.get('ready'):
        raise Failure('input_error','Only an untouched review_required run can be finalized')
    if not args.confirm_table:
        raise Failure('crop_error','Explicit visual confirmation is required')
    data = (out/'table-original.image').read_bytes()
    record_bytes = (out/'review-data.json').read_bytes()
    if sha(data)!=args.source_sha256 or sha(data)!=manifest['source_image_sha256'] or sha(record_bytes)!=manifest['review_data_sha256']:
        raise Failure('validation_error','Reviewed source or article changed; prepare again')
    record = json.loads(record_bytes)
    if manifest['mode']=='today' and record['date']!=datetime.now(BJ).date().isoformat():
        raise Failure('date_mismatch','Beijing date changed during review. Fetch today again.')
    image,report = inspect_crop(data)
    crop = exact_crop(image,args.crop_bottom)
    masthead = (ROOT/'assets/masthead.png').read_bytes()
    output_html,output_text = render(record,crop,masthead)
    # Write deliverables only after every validation passes.
    (out/'breakfast.html').write_text(output_html,encoding='utf-8')
    (out/'breakfast.txt').write_text(output_text,encoding='utf-8')
    (out/'closing-table.png').write_bytes(crop)
    record['article_html'] = record['article_html'].replace('__CLOSING_TABLE_IMAGE__','closing-table.png')
    record['crop'] = {'rectangle_xywh':[0,0,image.width,args.crop_bottom],'retained_pixels_exact':True,
                      'human_or_host_visual_confirmation':True,'confirmation_note':args.note,
                      'source_sha256':sha(data),'cropped_png_sha256':sha(crop),'detection':report}
    json_write(out/'breakfast.json',record)
    artifacts = ['breakfast.html','breakfast.txt','breakfast.json','closing-table.png']
    manifest.update(status='ready',ready=True,reason='Verbatim text validated; table visually confirmed and retained RGB pixels exact.',
                    finalized_at=datetime.now(timezone.utc).isoformat(),artifacts=artifacts,
                    checks={'paragraphs':len(record['paragraphs']),'bold_spans':len(record['bold_spans']),'sections':record['headings'],
                            'original_article_images':1,'total_html_images':2,'images_embedded':True,'pixel_exact':True},
                    sha256={name:sha((out/name).read_bytes()) for name in artifacts})
    json_write(out/'status.json',manifest)
    print(json.dumps({'output_directory':str(out),**manifest},ensure_ascii=False,indent=2))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command',required=True)
    p = sub.add_parser('prepare',help='Fetch and validate source; stop for visual table review')
    p.add_argument('--date',help='Explicit historical date YYYY-MM-DD; default is Beijing today only')
    p.add_argument('--out',help='New/empty output folder; default creates a unique run')
    p.add_argument('--source-url',help='Verified official article URL; title/date checks still apply')
    p.add_argument('--topic-html',help='Locally saved authorized topic page for browser fallback/tests')
    p.add_argument('--article-html',help='Locally saved authorized full article HTML for browser fallback/tests')
    p.add_argument('--table-image',help='Original table downloaded from this article, for browser fallback/tests')
    f = sub.add_parser('finalize',help='Render only after actual visual verification of this run')
    f.add_argument('--out',required=True)
    f.add_argument('--source-sha256',required=True,help='Exact source_image_sha256 from reviewed run')
    f.add_argument('--crop-bottom',required=True,type=int,help='Exclusive bottom pixel of top/full-width rectangle, verified visually')
    f.add_argument('--confirm-table',action='store_true',help='Attest all rows/title/watermarks preserved and APP/QR removed')
    f.add_argument('--note',required=True,help='Brief actual visual checks, including last row and promotion removal')
    args = parser.parse_args()
    try:
        return prepare(args) if args.command=='prepare' else finalize(args)
    except Failure as exc:
        print(json.dumps({'schema':SCHEMA,'status':exc.status,'ready':False,'reason':str(exc)},ensure_ascii=False),file=sys.stderr)
        return 20
    except (OSError,ValueError,KeyError) as exc:
        print(json.dumps({'schema':SCHEMA,'status':'input_error','ready':False,'reason':str(exc)},ensure_ascii=False),file=sys.stderr)
        return 20

if __name__=='__main__':
    sys.exit(main())
