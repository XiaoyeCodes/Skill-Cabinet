# 金十财经早餐 Skill

完整可移植技能包。把整个 `jin10-breakfast` 文件夹放入宿主智能体支持的 skills 目录，或让智能体先阅读 `SKILL.md`。无需本助手账号、邮箱或原运行环境。

## 快速使用

1. Python 3.9+，安装 `python -m pip install -r requirements.txt`。
2. 运行 `python scripts/jin10_breakfast.py prepare`。
3. 让智能体查看本次原图/候选图，确认完整收盘表和正确的推广裁切。
4. 按 `SKILL.md` 的 `finalize` 命令完成。最终 HTML 内嵌图片，直接双击即可阅读。

提供北京时间当天原文，不做摘要；删除音频、下载标签及其他配图；保留原始收盘表，裁去底部推广。米色 V3 版式与财经线稿题头已包含。

无更新、访问失败、待裁切审核会明确区分。未审核不会产生标成 ready 的成品。可用 `--date YYYY-MM-DD` 明确请求历史日期，不能自动退回旧稿。

`examples/2026-10-20/` 是历史演示，不代表今天，不是失败备用。`tests/fixtures/` 是回归测试用公开源页面/原图，不参与正常抓取。

测试：`python -m unittest discover -s tests -v`。详情见 `references/implementation.md`；浏览器替代取数见 `references/browser-fallback.md`。

本包不包含邮件推送、定时任务、邮箱地址、账户凭证或任何账户依赖。Python 脚本仅对金十官方公开 HTTPS 页面及选中的收盘图进行只读获取。
