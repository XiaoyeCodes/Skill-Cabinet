# 实现与验收

## 来源与完整性

- 专题入口固定为官方 `https://xnews.jin10.com/topic/343`；列表标题 `.jin10-news-list-item-title`，对应官方 `/details/数字`。
- 详情 SSR：`.jin10-news-cdetails-title`、`.jin10-cnews-introduction`、`.jin10-news-cdetails-article`。免责声明 `.new-decale` 在正文外，必须额外读取。
- Publication 从该文章 ID 对应的 Nuxt 标量赋值读取，函数参数仅按 JSON 数据解析，绝不执行网站 JavaScript。标题、导语与日期与 SSR 交叉核对。不能误用相关文章的时间或音频 reduced_content。
- 当前结构严格检查五个章节及至少 15 个新闻段落。未来如增加/改变章节，报结构错误；人工适配时应保留新增内容，不删去校验、硬凑旧结构。
- 删除明确的音频行、其标签/MP3/播放器，删除其他原图及图注。不把图片 OCR 成新闻正文。正文所有保留的文本、段落、编号和加粗顺序在清洗/渲染间核对，正文标题、导语、免责声明单独原文存入 JSON。仅替换排版样式及危险属性。
- 收盘图按所在章节唯一识别，不按“第二张图”的索引，也不使用固定 dated URL。

## 图片与审核

纯 Pillow 解码与矩形裁剪；动态寻找较宽灰色表格下边框、边框下留白及下方推广的深色像素。尺寸、图像高度和候选位置都来自本次原图。置信分数只用于提出候选；任何分数都不会自动 ready。

最终裁剪为 `(0, 0, 原宽, 已核实bottom)`，bottom 为不包含的 Y 边界。验证 PNG 再解码后与源图同矩形 RGB 字节完全一致。JPEG 源先解码为 RGB，保存无损 PNG，故是保留解码像素，不是保证文件字节相同。没有缩放、生成填充、重绘或水印擦除。

人为/宿主图像审核是必需条件；程序不能证明“最后一行”的语义。只有真实查看并确认全表和推广分界之后才能调用 finalize。若候选不明确，不生成 ready 成品。

## 输出与状态

- `prepare` 在独立新目录写 `status.json`，只读抓取。无更新时无 HTML/TXT/成品 JSON/PNG。
- `review_required` 只输出审核中间文件，`artifacts=[]`、`ready=false`。
- `finalize` 绑定本次源图及原文 SHA256，核验后写独立 HTML、TXT、结构化 JSON、裁切 PNG 和状态清单。
- HTML 两图均为真实 PNG 的 data URI，无 CID、无外部图片依赖。JSON 的 `article_html` 以同目录 `closing-table.png` 为图源。
- TXT 是原文纯文本和出处，不能承载加粗/图片；结构化 JSON 的 `bold_spans` 和 HTML 保留强调。表格数值不 OCR 重建，表格 PNG 是权威视觉内容。
- 退出码：0 表示 prepare 待审核或 finalize 完成，10 表示当天无更新，20 表示错误。始终读取 `status.json` / `ready`，不能将 0 当作全部成功。
- 新目录避免旧产物误读；未取得完整源的失败不会复用历史产物。

## 网络边界

25 秒 socket 超时，页面 4 MB、图片 20 MB 的读取上限，图片最多 25M 像素。页面来源仅 HTTPS `xnews.jin10.com` 的指定专题和数字详情路径；图片仅 HTTPS `img.jin10.com/news/...jpg|jpeg|png`。每次重定向重新校验；拒绝外域、用户名/密码、查询参数、片段及不正常路径。来源变化需审核适配，不能随意扩充域名。

未作 HTTP 自动重试或反爬绕过。网络/403/错误 MIME 与真实无更新分开。宿主应为整个命令设合理总耗时限制，因为 socket timeout 不是绝对墙钟超时。

## 维护测试

```sh
python -m unittest discover -s tests -v
```

测试包含原文/加粗顺序、日期不符、无更新、访问错误、图选择、主动内容拒绝、安全 URL、像素一致、动态候选、待审核门禁与最终内嵌图片。历史样例及 fixtures 显式日期为 2026-10-20，不会由主流程自动加载。
