import argparse
import contextlib
from datetime import date,timedelta
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from lxml import html
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('jin10_breakfast',ROOT/'scripts/jin10_breakfast.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
FIX=ROOT/'tests/fixtures'
ARTICLE=(FIX/'article-2026-10-20.html').read_bytes()
TOPIC=(FIX/'topic-2026-10-20.html').read_bytes()
TABLE=(FIX/'table-2026-10-20.jpg').read_bytes()
URL='https://xnews.jin10.com/details/232830'
DATE='2026-10-20'

class SkillTests(unittest.TestCase):
    def record(self):
        return m.parse_article(ARTICLE,URL,DATE)
    def args(self,out,**kwargs):
        d=dict(date=DATE,out=str(out),source_url=URL,article_html=str(FIX/'article-2026-10-20.html'),table_image=str(FIX/'table-2026-10-20.jpg'),topic_html=None)
        d.update(kwargs)
        return argparse.Namespace(**d)
    def prepare(self,out,**kwargs):
        with contextlib.redirect_stdout(io.StringIO()):
            return m.prepare(self.args(out,**kwargs))
    def finalize_args(self,out,**kwargs):
        d=dict(out=str(out),source_sha256=m.sha(TABLE),crop_bottom=1812,confirm_table=True,note='Regression fixture visual baseline: all 19 rows remain; final row 创业板指数; promotion removed.')
        d.update(kwargs)
        return argparse.Namespace(**d)
    def assert_failure(self,status,fn,*args):
        with self.assertRaises(m.Failure) as got:
            fn(*args)
        self.assertEqual(got.exception.status,status)

    def test_source_paragraphs_and_sections(self):
        r=self.record()
        self.assertEqual(len(r['paragraphs']),44)
        self.assertEqual(r['headings'],['今日优选','市场盘点','国际要闻','国内要闻','风险预警'])
        self.assertEqual(r['publication_beijing'],'2026-10-20 06:59:36')
        self.assertTrue(r['paragraphs'][0].startswith('李在明'))
        self.assertIn('责任自负。',r['disclaimer'])
    def test_source_exact_paragraphs_and_bold(self):
        dom=m.parse_dom(ARTICLE)
        a=m.one(dom,'jin10-news-cdetails-article')
        for n in list(m.class_nodes(a,'insert-audio')):
            n.drop_tree()
        self.assertEqual(self.record()['paragraphs'],[n.text_content() for n in a.xpath('.//p')])
        self.assertEqual(self.record()['bold_spans'],[n.text_content() for n in a.xpath('.//strong|.//b')])
    def test_table_selection_not_index(self):
        r=self.record()
        self.assertEqual(r['table_source_url'],'https://img.jin10.com/news/26/10/TsRUzJA1Pyoiy7yAhVX8Z.jpg')
        self.assertNotIn('flash-scdn',r['article_html'])
        self.assertNotIn('.mp3',r['article_html'])
        self.assertNotIn('普通话版',r['article_html'])
    def test_intro_title_verbatim(self):
        r=self.record(); d=m.parse_dom(ARTICLE)
        self.assertEqual(r['introduction'],m.one(d,'jin10-cnews-introduction').text_content())
        self.assertEqual(r['disclaimer'],m.one(d,'new-decale').text_content())
    def test_topic_matching(self):
        self.assertEqual(m.discover(TOPIC,DATE),[URL])
    def test_no_today_does_not_choose_yesterday(self):
        self.assert_failure('no_update',m.discover,TOPIC,'2026-10-21')
    def test_historical_missing_not_no_update(self):
        self.assert_failure('date_not_found',m.discover,TOPIC,'2000-01-01',True)
    def test_challenge_page_not_no_update(self):
        self.assert_failure('structure_error',m.discover,b'<html>Access denied</html>',DATE)
    def test_wrong_title_date(self):
        self.assert_failure('date_mismatch',m.parse_article,ARTICLE,URL,'2026-10-19')
    def test_wrong_publication_date(self):
        changed=ARTICLE.replace(b'2026-10-20 06:59:36',b'2026-10-19 06:59:36')
        self.assert_failure('date_mismatch',m.parse_article,changed,URL,DATE)
    def test_missing_metadata(self):
        d=m.parse_dom(ARTICLE)
        for n in d.xpath('//script'):
            n.drop_tree()
        self.assert_failure('structure_error',m.parse_article,html.tostring(d),URL,DATE)
    def test_missing_disclaimer(self):
        changed=ARTICLE.replace(b'class="new-decale"',b'class="other"')
        self.assert_failure('structure_error',m.parse_article,changed,URL,DATE)
    def test_new_section_fails_closed(self):
        changed=ARTICLE.replace('<h2>国际要闻</h2>'.encode(),'<h2>其他新闻</h2>'.encode(),1)
        self.assert_failure('structure_error',m.parse_article,changed,URL,DATE)
    def test_unknown_audio_prose_not_deleted(self):
        changed=ARTICLE.replace('<strong>男生普通话版</strong>'.encode(),'<strong>男生普通话版重要新闻</strong>'.encode(),1)
        self.assert_failure('structure_error',m.parse_article,changed,URL,DATE)
    def test_unexpected_active_markup(self):
        changed=ARTICLE.replace('<h2>今日优选</h2>'.encode(),'<h2>今日优选</h2><iframe src="https://example.com"></iframe>'.encode(),1)
        self.assert_failure('structure_error',m.parse_article,changed,URL,DATE)
    def test_unsafe_urls(self):
        for url in ['http://xnews.jin10.com/details/1','https://evil.example/details/1','https://xnews.jin10.com.evil.example/details/1','https://u:p@xnews.jin10.com/details/1','https://xnews.jin10.com:8443/details/1','https://xnews.jin10.com/details/1?next=x','https://xnews.jin10.com/details/1#x','https://xnews.jin10.com/details/../1','https://xnews.jin10.com/topic/999']:
            with self.subTest(url=url):
                self.assert_failure('unsafe_url',m.safe_url,url)
    def test_unwanted_image_origin_rejected(self):
        self.assert_failure('unsafe_url',m.safe_url,'https://flash-scdn.jin10.com/anything.jpg',True)
    def test_dynamic_crop_historical_proposal(self):
        image,report=m.inspect_crop(TABLE)
        self.assertEqual(image.size,(960,2200))
        self.assertEqual(report['proposal']['crop_bottom'],1812)
        self.assertTrue(report['visual_verification_required'])
    def test_dynamic_crop_different_height(self):
        image=Image.open(io.BytesIO(TABLE)).convert('RGB')
        # Add only blank bottom space: never interpret a fixed percentage as data boundary.
        expanded=Image.new('RGB',(image.width,image.height+200),'white'); expanded.paste(image,(0,0))
        b=io.BytesIO();expanded.save(b,format='PNG')
        _,report=m.inspect_crop(b.getvalue())
        self.assertEqual(report['proposal']['crop_bottom'],1812)
    def test_uncertain_crop_has_no_proposal(self):
        b=io.BytesIO();Image.new('RGB',(960,2200),'white').save(b,format='PNG')
        _,report=m.inspect_crop(b.getvalue())
        self.assertIsNone(report['proposal'])
    def test_crop_exact_pixels(self):
        image,_=m.inspect_crop(TABLE); png=m.exact_crop(image,1812)
        self.assertEqual(Image.open(io.BytesIO(png)).tobytes(),image.crop((0,0,960,1812)).tobytes())
    def test_invalid_crop_bounds(self):
        image,_=m.inspect_crop(TABLE)
        for bottom in [0,2200,3000]:
            self.assert_failure('crop_error',m.exact_crop,image,bottom)
    def test_prepare_review_gate(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run';self.assertEqual(self.prepare(out),0)
            status=json.loads((out/'status.json').read_text())
            self.assertEqual(status['status'],'review_required');self.assertFalse(status['ready'])
            self.assertEqual(status['artifacts'],[])
            self.assertFalse((out/'breakfast.html').exists())
    def test_existing_output_refused(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td);(out/'old.html').write_text('previous')
            self.assert_failure('output_exists',self.prepare,out)
    def test_no_update_only_status(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run'
            with patch.object(m,'discover',side_effect=m.Failure('no_update','No today')):
                result=self.prepare(out,source_url=None,topic_html=str(FIX/'topic-2026-10-20.html'),article_html=None,table_image=None,date=None)
            self.assertEqual(result,10);self.assertEqual([p.name for p in out.iterdir()],['status.json'])
            self.assertFalse(json.loads((out/'status.json').read_text())['ready'])
    def test_access_error_distinct(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run'
            with patch.object(m,'fetch',side_effect=m.Failure('access_error','HTTP 403')):
                self.prepare(out,source_url=None,article_html=None,table_image=None,date=None)
            self.assertEqual(json.loads((out/'status.json').read_text())['status'],'access_error')
            self.assertEqual([p.name for p in out.iterdir()],['status.json'])
    def test_network_fetch_only_selected_image(self):
        with tempfile.TemporaryDirectory() as td:
            calls=[]
            def fetch(url,image=False):
                calls.append((url,image));return TABLE if image else (TOPIC if 'topic' in url else ARTICLE)
            with patch.object(m,'fetch',side_effect=fetch):
                self.prepare(Path(td)/'run',source_url=None,article_html=None,table_image=None)
            self.assertEqual(calls,[(m.TOPIC,False),(URL,False),(self.record()['table_source_url'],True)])
    def test_finalize_without_confirmation(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run';self.prepare(out)
            self.assert_failure('crop_error',m.finalize,self.finalize_args(out,confirm_table=False))
            self.assertFalse((out/'breakfast.html').exists())
    def test_finalize_wrong_source_hash(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run';self.prepare(out)
            self.assert_failure('validation_error',m.finalize,self.finalize_args(out,source_sha256='0'*64))
    def test_finalize_modified_article(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run';self.prepare(out);p=out/'review-data.json';p.write_bytes(p.read_bytes()+b' ')
            self.assert_failure('validation_error',m.finalize,self.finalize_args(out))
    def test_finalize_outputs_self_contained(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run';self.prepare(out)
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(m.finalize(self.finalize_args(out)),0)
            status=json.loads((out/'status.json').read_text());self.assertTrue(status['ready'])
            output=(out/'breakfast.html').read_text();self.assertNotIn('cid:',output)
            dom=html.fromstring(output)
            self.assertEqual(len(dom.xpath('//img')),2)
            self.assertTrue(all(n.get('src').startswith('data:image/png;base64,') for n in dom.xpath('//img')))
            self.assertEqual([n.text_content() for n in dom.get_element_by_id('original-content').xpath('.//p')],self.record()['paragraphs'])
            self.assertTrue((out/'breakfast.txt').is_file());self.assertTrue((out/'closing-table.png').is_file())
    def test_today_run_expiry(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'run';self.prepare(out)
            p=out/'status.json';s=json.loads(p.read_text());s['mode']='today';p.write_text(json.dumps(s))
            # Record date far in past, with its recorded digest intentionally aligned for this test.
            rp=out/'review-data.json';r=json.loads(rp.read_text());r['date']='2000-01-01';m.json_write(rp,r)
            s['review_data_sha256']=m.sha(rp.read_bytes());m.json_write(p,s)
            self.assert_failure('date_mismatch',m.finalize,self.finalize_args(out))

if __name__=='__main__':
    unittest.main()
