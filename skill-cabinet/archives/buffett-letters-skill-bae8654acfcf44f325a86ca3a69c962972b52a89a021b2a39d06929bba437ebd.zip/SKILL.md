---
name: "buffett-letters-skill"
display_name: "巴菲特股东信 · 投资方法"
description: "从巴菲特 1957—2023 年股东信提炼的 20 个投资子技能，涵盖能力圈、安全边际、经济护城河、复利、资本配置与风控；保留完整索引和原始模块。"
version: "1.0.0"
author: "袋鼠帝 kangarooking"
tags: ["巴菲特","价值投资","资本配置","风险管理"]
category: "投资与金融"
---

# 巴菲特股东信 · 投资方法

本文件为 Skill Cabinet 添加的技能集导航入口。上游 20 个子技能与资料均保留原目录结构和原始内容。

## 适用任务

从巴菲特 1957—2023 年股东信提炼的 20 个投资子技能，涵盖能力圈、安全边际、经济护城河、复利、资本配置与风控；保留完整索引和原始模块。

## 使用步骤

1. 先读取 [INDEX.md](INDEX.md)，了解子技能的触发条件、依赖和组合关系。
2. 根据用户的具体问题，选择相关模块并读取对应的 SKILL.md；需要上下文时读取 [BOOK_OVERVIEW.md](BOOK_OVERVIEW.md)。
3. 按模块中的执行步骤处理问题，遵守它的适用边界，必要时通过索引组合其他模块。
4. 各模块的 test-prompts.json 是上游测试用例；导入不代表已执行这些测试或验证模型回答效果。

## 子技能索引

- [伊索三问 / 内在价值评估](aesop-three-questions/SKILL.md)
- [做生意不做股票](business-picker/SKILL.md)
- [CEO = 首席风险官（含诺亚法则）](ceo-as-risk-officer/SKILL.md)
- [雪茄蒂 vs 伟大企业](cigar-butt-vs-great-business/SKILL.md)
- [能力圈判断](circle-of-competence/SKILL.md)
- [复利思维](compounding-thinking/SKILL.md)
- [经济商誉 / 护城河识别](economic-moat/SKILL.md)
- [恐惧与贪婪逆向](fear-and-greed/SKILL.md)
- [资本配置第一法则](first-law-of-capital-allocation/SKILL.md)
- [浮存金思维](float-thinking/SKILL.md)
- [永久持有](hold-forever/SKILL.md)
- [机构强制力](institutional-imperative/SKILL.md)
- [透视盈余（含所有者收益/反EBITDA）](look-through-earnings/SKILL.md)
- [安全边际](margin-of-safety/SKILL.md)
- [市场先生思维（含投票机vs称重机）](mr-market/SKILL.md)
- [不用股票收购](never-issue-shares/SKILL.md)
- [不用杠杆 / 财务堡垒](no-leverage/SKILL.md)
- [只与喜欢和钦佩的人合作（含吃自己的饭）](partner-with-admired/SKILL.md)
- [保守≠传统 / 独立思考](real-conservatism/SKILL.md)
- [三类投资分类法](three-asset-categories/SKILL.md)

## 来源与文件完整性

上游来源：[kangarooking/buffett-letters-skill](https://github.com/kangarooking/buffett-letters-skill/tree/5b1fbe1d93f155fcf4acf236841bf8e1b5951c91)。本入口不改写原有子技能。LICENSE、README、INDEX、原始候选、验证记录及其余跟踪文件均随包保存。收藏入口版本为 1.0.0；上游未声明发布版本。
