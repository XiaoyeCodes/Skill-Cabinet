# 作者示例与演示来源

本包保留原作者自己的代码示例：

- fold_C/：夜曲风格的《折叠》开头，含分镜、绘图代码与布局生成器。
- pigeon_B/：寓言风格的《鸽子的迷信》开头，含分镜与绘图代码。
- kit_gallery/：绘图组件的最小调用示例。
- fold_old_vs_new.jpg、look_fold_C.jpg、look_pigeon_B.jpg、look_kit_gallery.jpg：对应作者示例的静态参考。

大型演示 GIF 使用源链接：[折叠](https://github.com/HeyChengC/vibe-knowledge-film/blob/62d51508aad00003dc6209afa80c4b5dc540de59/examples/fold_C.gif)、[鸽子的迷信](https://github.com/HeyChengC/vibe-knowledge-film/blob/62d51508aad00003dc6209afa80c4b5dc540de59/examples/pigeon_B.gif)。

第三方参考片的复刻工程 stim_B/、info_C/ 及对应截图不在本包重新发布。请阅读[原始示例说明](https://github.com/HeyChengC/vibe-knowledge-film/blob/62d51508aad00003dc6209afa80c4b5dc540de59/examples/README.md)与根目录 LICENSE。新项目从 scripts/new_film.py 建立空骨架，按自己的分镜编写。
