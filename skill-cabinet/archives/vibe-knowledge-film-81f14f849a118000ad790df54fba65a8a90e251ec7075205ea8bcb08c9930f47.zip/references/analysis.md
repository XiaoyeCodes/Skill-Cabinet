# 参考片拆解来源

原作者的完整参考片分析含第三方字幕及画面记录。本收藏包保留来源链接，不复制该材料：[四条参考片的拆解](https://github.com/HeyChengC/vibe-knowledge-film/blob/62d51508aad00003dc6209afa80c4b5dc540de59/references/analysis.md)。

制作流程使用本包的 SKILL.md、visualization.md 的方法章节、visual-grammar.md、script.md、worlds.md 与 engine.md。请使用自己的选题、事实表、字幕和分镜；参考片素材的权利边界见根目录 LICENSE。
