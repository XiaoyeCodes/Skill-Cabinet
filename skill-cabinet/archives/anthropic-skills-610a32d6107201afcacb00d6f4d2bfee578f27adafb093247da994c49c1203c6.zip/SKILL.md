---
name: "anthropic-skills"
display_name: "Anthropic Skills -办公与开发技能合集"
description: "Anthropic 官方 19 项技能的统一目录与选择入口，覆盖网页设计、视觉、开发测试和办公任务。14 项可分发技能随包保存；Word、PDF、PPT、Excel 等受限或未明确授权条目仅保留官方入口。"
version: "1.0.0"
author: "Anthropic · 个人整理入口"
tags: ["官方合集","网页设计","开发工具","办公","技能目录"]
category: "开发与工具"
metadata:
  version: 1.0.0
  source: https://github.com/anthropics/skills
---

# Anthropic Skills -办公与开发技能合集

这是个人整理的官方技能目录与路由入口，不是 Anthropic 新发布的独立官方产品。一个收藏条目包含完整目录；可分发的子技能位于 `library/`，其他条目为官方入口，不提供其文件副本。

## 根据任务选择

先阅读 [catalog.md](catalog.md) 找到与用户任务相符的一项，再加载它的 `library/<名称>/SKILL.md` 及其按需引用的文件。不要把整个集合同时加载，也不要以“官方合集”为由改动当前任务以外的项目。

用户有明确产出时直接选择对应技能，例如网页选择 `frontend-design`，演示型网页组件选择 `web-artifacts-builder`，网页行为测试选择 `webapp-testing`，海报视觉选择 `canvas-design`。几个条目都可能适用时，用一句话说明建议；只有选择会明显影响结果时才询问用户。

读取子技能时把它自己的目录当作相对路径基准，而不是本合集根目录。保留用户的产品、技术栈、指定风格和已有授权范围。子技能里的安装、发消息、上传、发布等操作不因收录而获得执行授权；按用户当前任务和宿主工具规则执行。

## 官方入口条目

`docx`、`pdf`、`pptx`、`xlsx` 的许可明确限制复制分发，本包只列其官方链接。`doc-coauthoring` 在当前快照未附单独许可，亦仅保留链接。不要把这些入口说成本地已安装或完整离线可用的文档技能。用户需要它们时，说明本包不含实现，转到当前环境可用且已授权的相应文档工具，或由用户通过官方渠道使用；不自动抓取、转载受限内容。

完整机器索引见 [catalog.json](catalog.json)，来源与逐文件校验见 [upstream/source.json](upstream/source.json)，许可边界见 [RIGHTS.md](RIGHTS.md)。随包文件只保存，不自动执行、安装到宿主或发布项目。
