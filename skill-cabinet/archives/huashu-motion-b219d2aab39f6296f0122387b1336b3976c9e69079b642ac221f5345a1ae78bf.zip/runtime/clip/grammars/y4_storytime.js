// 片段 · 故事型简笔角色（y4，storytime）：豆子花叔在小房间里对镜头讲，姿势快切（0.1s）后定住，笑点靠反应特写和插入镜头。
// cues：point | title（他说一句：at 这一帧气泡弹出、开始张嘴；嘴按 text 的字数说 ≈6.5 字/秒；data.pose 指定姿势 talk/point/shrug/type）
//         气泡里写什么：有 sub 就写 sub（≤12 字的短句最好），没有才写 text——口播原文交给管线的字幕，气泡别和字幕重复一遍
//       highlight（「？」「！」弹出＋摊手担心：data.mark 默认「？」）
//       react（反应镜头：at 这一帧跳到大特写，死鱼眼＋汗滴，一言不发；dur 默认到下一个 cue）
//       insert（插入镜头：at 这一帧切到桌上那台电脑的屏幕特写——sub = 他打的那一行（打字、发送），之后 AI 的回复像代码墙一样越滚越快，
//               text = 砸出来的大字（如「3000行」），在 data.hit（绝对秒，默认 at+1.3，没有 sub 时 at+0.4）砸出、屏幕一震；
//               data.count + data.unit 让右上角计数器在砸出那一刻停在这个数；dur 默认到下一个 cue）
// 房间里有桌上的电脑（插入镜头切进去的就是它的屏幕）、马克杯、墙上的书架和绿植，右边不再是空墙。
// 没有口播包络时，口型由字数和时间合成（一拍二，0/1/2 三张嘴）；有包络就把 window.VO_ENV 交给管线（TOON.mouth 自动读）。
// safe：气泡、插入镜头的大字排在 top..H−bottom 之间。alpha：不画房间，角色和气泡照画（气泡本来就是白底黑字）；插入镜头只画显示器和后脑勺，四周透明。
CLIPS.y4_storytime = (() => {
const { clamp, lerp, rng } = U;
const C = { wall: '#DCE9EC', wall2: '#CFE0E4', floor: '#E8DCC8', desk: '#E2C29B', deskSide: '#CDA97F', line: '#5B6470', sky: '#BFE3F5', screen: '#20222D' };
const COLS = ['#C792EA', '#82AAFF', '#C3E88D', '#F78C6C', '#89DDFF', '#FFCB6B', '#676E95'];
const LINES = (() => { const r = rng(42), out = []; let ind = 0;
  for (let i = 0; i < 400; i++) { if (r() < 0.18) ind = Math.min(4, ind + 1); else if (r() < 0.2) ind = Math.max(0, ind - 1);
    const toks = []; let x = ind * 34; const n = 1 + (r() * 4 | 0); for (let k = 0; k < n; k++) { const w = 30 + r() * 150; toks.push([x, w, COLS[(r() * COLS.length) | 0]]); x += w + 14; } out.push(toks); } return out; })();
let keys, says, L, shots;
return {
  fonts: ['PuHui-Bold', 'PuHui-Black'],
  faces: ['PuHui-Bold', 'PuHui-Black'],
  safe: true,
  // huashu-motion: one scene label per shot change; regions = the character, the computer, each speech bubble, the insert shot's parts
  scenes: ctx => CLIP.beats(ctx.cues, q => ({ point: 'talk', title: 'talk', insert: 'screen', react: 'react', highlight: 'punchline' })[q.kind] || null),
  regions: ctx => [{ id: 'character', label: '角色' }, { id: 'computer', label: '桌上的电脑' },
    ...ctx.of('point', 'title').map((q, i) => ({ id: CLIP.rid('line', i), label: `第 ${i + 1} 句的气泡` })),
    ...(ctx.of('highlight').length ? [{ id: 'mark', label: '？／！' }] : []),
    ...(ctx.of('insert').length ? [{ id: 'screen', label: '电脑屏幕特写' }, { id: 'typed', label: '他打的那一行' }, { id: 'big-text', label: '砸出来的大字' }, { id: 'counter', label: '右上角计数器' }] : [])],
  init(ctx) {
    const { W, H, u } = ctx;
    L = { cx: ctx.portrait ? W * 0.42 : W * 0.3, fy: ctx.portrait ? H * 0.8 : H * 1.02, R: (ctx.portrait ? 230 : 215) * u };
    L.dy = L.fy - L.R * 0.55;                                             // 桌面高度
    L.mon = ctx.portrait ? { x: W * 0.66, w: 330 * u, h: 240 * u } : { x: W * 0.6, w: 520 * u, h: 340 * u };   // 桌上的电脑（屏幕左上角 x、宽高）
    says = ctx.of('point', 'title').map(q => ({ q, end: q.at + Math.max(0.6, [...(q.text || '')].length / 6.5) }));
    keys = [[0, 'rest', 'happy']]; let n = 0;
    for (const q of ctx.cues) {
      if (q.kind === 'point' || q.kind === 'title') keys.push([q.at, (q.data && q.data.pose) || (n++ % 2 ? 'point' : 'talk'), 'talk']);
      if (q.kind === 'highlight') keys.push([q.at, 'shrug', 'worry']);
      if (q.kind === 'react' || q.kind === 'insert') keys.push([q.at, 'stiff', 'blank']);
    }
    // 特写镜头（react / insert）占的时间段
    shots = ctx.of('react', 'insert').map(q => { const nx = ctx.cues.find(z => z.at > q.at + 1e-6); const end = q.dur ? q.at + q.dur : nx ? nx.at : ctx.dur + 1;
      const hit = q.kind === 'insert' ? (q.data && q.data.hit != null ? +q.data.hit : q.at + (q.sub ? 1.3 : 0.4)) : 0; return { q, end, hit }; });
  },
  draw(c, t, ctx) {
    const { W, H, u } = ctx, ts = MO.step(t, 24);                         // 角色 24fps，镜头 60fps
    const shot = shots.find(s => t >= s.q.at - 1e-6 && t < s.end);
    if (shot && shot.q.kind === 'insert') return insert(c, t, ctx, shot);
    const inReact = !!shot;
    // 镜头：中景慢推 3%；反应＝同机位跳到 1.9 倍大特写（砸镜：前 0.3s 从 2.2 弹回）
    let z = 1.0 + 0.03 * MO.quintOut(clamp(t / 3)), cy = L.fy - L.R * 1.6;
    if (inReact) { const l = t - shot.q.at; z = 1.9 * (1 + 0.15 * Math.max(0, 1 - MO.springHz(l, 3, 11))) * (1 + 0.03 * clamp(l / 1.5)); cy = L.fy - L.R * 2.2; }
    const [dx, dy] = CAM.drift(t, 3 * u, 1);
    if (!ctx.alpha) { c.fillStyle = C.wall; c.fillRect(0, 0, W, H); }
    CAM.with(c, { x: (inReact ? L.cx : W / 2) + dx, y: (inReact ? cy : H / 2) + dy, z }, g => {
      if (!ctx.alpha) room(g, t, ctx);
      const st = TOON.poseAt(keys, ts), say = says.find(s => t >= s.q.at - 1e-6 && t < s.end);
      const mouth = window.VO_ENV ? TOON.mouth(t) : say ? [1, 2, 1, 0, 2, 1][Math.floor(MO.step(t - say.q.at + 1e-6, 12) * 12) % 6] : 0;
      const blink = TOON.blinkAt(ts, [0.9, 3.4, 6.1, 8.8, 11.5]), br = 1 + 0.012 * Math.sin(2 * Math.PI * t / 1.6);
      const info = TOON.bean(g, { x: L.cx, y: L.fy, s: L.R, pose: st.pose, expr: inReact ? 'blank' : st.expr, mouth: inReact ? 0 : mouth, blink, squash: st.squash * br, bob: mouth * L.R * 0.015, tilt: st.expr === 'worry' ? -0.06 : 0.02 * Math.sin(t), lw: inReact ? 12 * u : undefined });
      CLIP.mark(g, 'character', L.cx - L.R * 1.2, info.head[1] - L.R * 1.05, L.R * 2.4, L.fy - info.head[1] + L.R * 1.05);
      if (!ctx.alpha) desk(g, t, ctx);
      if (inReact) { const sw = clamp((t - shot.q.at - 0.3) / 0.9); if (sw > 0) TOON.sweat(g, L.cx + L.R * 0.88, info.head[1] - L.R * 0.1, 30 * u, MO.expoOut(sw) * 0.6 + sw * 0.4); }
      for (const h of ctx.of('highlight')) { const l = ctx.lt(t, h.at); if (l <= 0) continue;
        g.save(); g.translate(info.head[0] + L.R * 1.35, info.head[1] - L.R * 0.6); g.rotate(0.14 + 0.05 * Math.sin(t * 6)); TOON.mark(g, (h.data && h.data.mark) || '？', 0, 0, clamp(l / 0.26), 130 * u); CLIP.mark(g, 'mark', -70 * u, -125 * u, 140 * u, 150 * u); g.restore(); }
    });
    // 对话气泡（屏幕空间，不跟镜头）：at 这一帧弹出，说完 0.6s 后收起；特写切回来后，特写之前的那句不再出现
    if (!inReact) for (const s of says) {
      const l = ctx.lt(t, s.q.at), out = clamp((t - s.end - 0.6) / 0.2); if (l <= 0 || out >= 1) continue;
      const nx = says[says.indexOf(s) + 1]; if (nx && t >= nx.q.at - 1e-6) continue;
      if (shots.some(sh => sh.q.at > s.q.at && sh.q.at <= t)) continue;
      const txt = s.q.sub || s.q.text || '';
      const bw0 = ctx.portrait ? W * 0.84 : W * 0.42, f = TY.fit(c, txt, bw0 - 80 * u, (ctx.portrait ? 64 : 62) * u, 'PuHui-Bold', { maxLines: 2, min: 0.72, balance: true });
      c.font = `${f.size}px "PuHui-Bold"`; const bw = Math.min(bw0, Math.max(...f.lines.map(x => c.measureText(x).width)) + 80 * u);
      const bh = f.lines.length * f.size * 1.3 + 56 * u, bx = ctx.portrait ? (W - bw) / 2 : W * 0.5, by = ctx.safe.top + (ctx.portrait ? H * 0.06 : H * 0.09);
      const sc = MO.backOut(clamp(l / 0.25), 2.2) * (1 - out);
      c.save(); c.translate(bx + 60 * u, by + bh); c.scale(sc, sc); c.translate(-(bx + 60 * u), -(by + bh));
      c.fillStyle = '#fff'; c.strokeStyle = '#1B1B1F'; c.lineWidth = 6 * u; c.lineJoin = 'round';
      c.beginPath(); c.roundRect(bx, by, bw, bh, 40 * u); c.moveTo(bx + 70 * u, by + bh); c.lineTo(bx + (ctx.portrait ? 40 : 10) * u, by + bh + 60 * u); c.lineTo(bx + 130 * u, by + bh); c.fill(); c.stroke();
      c.fillStyle = '#fff'; c.fillRect(bx + 76 * u, by + bh - 8 * u, 50 * u, 12 * u);
      c.fillStyle = '#1B1B1F'; c.textBaseline = 'alphabetic';
      f.lines.forEach((ln, i) => c.fillText(ln, bx + 40 * u, by + 26 * u + (i + 1) * f.size * 1.2));
      CLIP.mark(c, CLIP.rid('line', says.indexOf(s)), bx, by, bw, bh + 60 * u);
      c.restore();
    }
  },
};
// 房间：墙、地、窗（慢飘的云）、书架、画框。只画一次的东西不缓存——片段短，画得起
function room(g, t, ctx) {
  const { W, H, u } = ctx, X0 = -W, Y0 = -H, fy = L.fy;
  g.fillStyle = C.wall; g.fillRect(X0, Y0, W * 3, H * 3);
  g.fillStyle = C.floor; g.fillRect(X0, fy + 10 * u, W * 3, H * 2);
  g.lineWidth = 3 * u; g.strokeStyle = C.line; g.lineJoin = 'round'; g.beginPath(); g.moveTo(X0, fy + 10 * u); g.lineTo(X0 + W * 3, fy + 10 * u); g.stroke();
  // 窗：天空＋慢飘的云
  const wx = ctx.portrait ? W * 0.08 : W * 0.05, wy = ctx.portrait ? H * 0.2 : H * 0.12, ww = ctx.portrait ? W * 0.3 : W * 0.17, wh = ww * 0.7;
  g.save(); g.beginPath(); g.roundRect(wx, wy, ww, wh, 12 * u); g.clip(); g.fillStyle = C.sky; g.fillRect(wx, wy, ww, wh);
  for (const [k, r, sp] of [[0.2, 46, 18], [0.7, 34, 12]]) { const x = wx - 60 * u + ((k * ww + t * sp * u) % (ww + 120 * u)), y = wy + wh * (0.35 + k * 0.3); g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, r * u, 0, 7); g.arc(x + r * 0.9 * u, y + 6 * u, r * 0.75 * u, 0, 7); g.arc(x - r * 0.9 * u, y + 8 * u, r * 0.65 * u, 0, 7); g.fill(); }
  g.restore(); g.strokeStyle = C.line; g.beginPath(); g.roundRect(wx, wy, ww, wh, 12 * u); g.moveTo(wx + ww / 2, wy); g.lineTo(wx + ww / 2, wy + wh); g.moveTo(wx, wy + wh / 2); g.lineTo(wx + ww, wy + wh / 2); g.stroke();
  // 墙上：横屏右边一块书架；竖屏书架在窗下方右侧
  const r = rng(9), sx = ctx.portrait ? W * 0.62 : W * 0.68, sy = ctx.portrait ? H * 0.3 : H * 0.36, sw = ctx.portrait ? W * 0.3 : W * 0.22;
  g.fillStyle = '#D9C3A0'; g.fillRect(sx, sy, sw, 16 * u); g.strokeRect(sx, sy, sw, 16 * u);
  let x = sx + 16 * u; while (x < sx + sw * 0.7) { const w = (22 + r() * 22) * u, h = (70 + r() * 40) * u; g.fillStyle = ['#8FB3C9', '#E7A37B', '#B9C98F', '#C6A0C9'][(r() * 4) | 0]; g.fillRect(x, sy - h, w, h); g.strokeRect(x, sy - h, w, h); x += w + 5 * u; }
  g.fillStyle = '#E7A37B'; const px = sx + sw * 0.83; g.beginPath(); g.moveTo(px - 30 * u, sy); g.lineTo(px - 38 * u, sy - 56 * u); g.lineTo(px + 38 * u, sy - 56 * u); g.lineTo(px + 30 * u, sy); g.closePath(); g.fill(); g.stroke();
  g.fillStyle = '#8DBF8B'; for (const [dx, a] of [[-18, -0.5], [0, 0], [18, 0.5]]) { g.beginPath(); g.ellipse(px + dx * u, sy - 100 * u, 16 * u, 46 * u, a, 0, 7); g.fill(); g.stroke(); }
}
// 桌子挡在腰前（角色线最黑最粗，背景线细而灰）；桌上的电脑、马克杯
function desk(g, t, ctx) {
  const { W, H, u } = ctx, X0 = -W, dy = L.dy; g.lineWidth = 3 * u; g.strokeStyle = C.line;
  // 电脑：屏幕微微发光，上面是滚动的代码色块（插入镜头切进去就是它）
  const M = L.mon, mx = M.x, my = dy - M.h - 60 * u;
  g.fillStyle = '#9AA0AC'; g.fillRect(mx + M.w / 2 - 18 * u, dy - 62 * u, 36 * u, 62 * u); g.strokeRect(mx + M.w / 2 - 18 * u, dy - 62 * u, 36 * u, 62 * u);
  g.beginPath(); g.ellipse(mx + M.w / 2, dy, 90 * u, 10 * u, 0, 0, 7); g.fill(); g.stroke();
  g.fillStyle = '#2B2D36'; g.beginPath(); g.roundRect(mx, my, M.w, M.h, 16 * u); g.fill(); g.stroke();
  CLIP.mark(g, 'computer', mx, my, M.w, M.h + 62 * u);
  g.save(); g.beginPath(); g.roundRect(mx + 14 * u, my + 14 * u, M.w - 28 * u, M.h - 28 * u, 6 * u); g.clip(); g.fillStyle = C.screen; g.fillRect(mx, my, M.w, M.h);
  const lh = 22 * u, off = (t * 30 * u) % lh; for (let i = 0; i < 20; i++) { const y = my + 30 * u + i * lh - off; for (const [x, w, col] of LINES[i % LINES.length]) { g.fillStyle = col; g.globalAlpha = 0.75; g.fillRect(mx + 26 * u + x * 0.3 * u, y, w * 0.3 * u, 8 * u); } }
  g.restore(); g.globalAlpha = 1;
  g.fillStyle = C.desk; g.fillRect(X0, dy, W * 3, 40 * u); g.strokeRect(X0, dy, W * 3, 40 * u);
  g.fillStyle = C.deskSide; g.fillRect(X0, dy + 40 * u, W * 3, H); g.strokeRect(X0, dy + 40 * u, W * 3, H);
  // 马克杯
  const cx = ctx.portrait ? W * 0.1 : L.cx - L.R * 1.9; g.fillStyle = '#F26B4F'; g.beginPath(); g.roundRect(cx, dy - 92 * u, 70 * u, 92 * u, 10 * u); g.fill(); g.stroke();
  g.beginPath(); g.arc(cx + 78 * u, dy - 52 * u, 22 * u, -1.2, 1.2); g.lineWidth = 9 * u; g.stroke(); g.lineWidth = 3 * u;
}
// 插入镜头：电脑屏幕特写（过肩），打字→发送→代码墙加速滚→大字砸出＋屏幕一震（和示范片 s2_screen 同一套）
function insert(c, t, ctx, shot) {
  const { W, H, u, safe } = ctx, q = shot.q, d = q.data || {}, t0 = q.at, msg = q.sub || '', T_SEND = t0 + (msg ? 0.1 + Math.min(0.9, [...msg].length / 14) + 0.1 : 0.05), T_HIT = Math.max(shot.hit, T_SEND + 0.2);
  const lt = t - t0, slam = t - T_HIT;
  const scrollAt = tt => { const k = Math.max(0, tt - T_SEND - 0.15), span = Math.max(0.3, T_HIT - T_SEND - 0.15); return 46 * u * (k * 6 + Math.pow(k / span * 1.8, 3) * 6); };
  const shake = slam > 0 && slam < 0.3 ? MO.settle(slam, 14 * u, 9, 14) : 0;
  const zoom = 1.06 - 0.06 * MO.expoOut(clamp(lt / 0.25)) + 0.02 * clamp(lt / 2.2) + (slam > 0 ? 0.04 * MO.expoOut(clamp(slam / 0.12)) : 0);   // 切进来：1.06 落到 1（像推过去的一下）
  if (!ctx.alpha) { c.fillStyle = '#15161C'; c.fillRect(0, 0, W, H); }   // 透明模式：只留显示器和后脑勺，口播画面从四周透出来
  const bx = W * 0.06, by = safe.top + H * 0.05, bw = W * 0.88, bh = H - safe.bottom - by - H * (ctx.portrait ? 0.2 : 0.06);
  CAM.with(c, { x: W / 2 + shake, y: H / 2 - shake * 0.5, z: zoom }, c => {
    c.fillStyle = '#2B2D36'; c.beginPath(); c.roundRect(bx, by, bw, bh, 34 * u); c.fill();
    CLIP.mark(c, 'screen', bx, by, bw, bh);
    const sx = bx + 40 * u, sy = by + 40 * u, sw = bw - 80 * u, sh = bh - 80 * u;
    c.save(); c.beginPath(); c.roundRect(sx, sy, sw, sh, 14 * u); c.clip(); c.fillStyle = C.screen; c.fillRect(sx, sy, sw, sh);
    const scr = scrollAt(t), top = sy + 64 * u;
    // 我那一行：右侧气泡，打字（光标闪），发送后变蓝
    if (msg) { const bubY = top + 110 * u - Math.min(scr, 600 * u), p = clamp((t - t0 - 0.1) / Math.max(0.2, T_SEND - t0 - 0.2));
      const mf = TY.fit(c, msg, sw * 0.7 - 60 * u, (ctx.portrait ? 44 : 40) * u, 'PuHui-Bold', { maxLines: 3, min: 0.75, balance: true }), fs = mf.size, lh = fs * 1.3;   // 长句折行（最多 3 行），气泡往下长
      const bwid = Math.max(...mf.lines.map(l => TY.width(c, l, fs, 'PuHui-Bold'))) + 60 * u, bht = 78 * u + (mf.lines.length - 1) * lh;
      if (bubY > sy) { c.fillStyle = t >= T_SEND ? '#3B82F6' : '#2F3342'; c.beginPath(); c.roundRect(sx + sw - 30 * u - bwid, bubY - 52 * u, bwid, bht, 24 * u); c.fill();
        if (slam <= 0) CLIP.mark(c, 'typed', sx + sw - 30 * u - bwid, bubY - 52 * u, bwid, bht);
        let left = Math.round(p * mf.lines.reduce((a, l) => a + [...l].length, 0));   // 逐行打出来，光标跟在最后打到的那一行
        const ns = mf.lines.map(ln => { const n = Math.min(left, [...ln].length); left -= n; return n; }), curK = Math.max(0, ns.findLastIndex(n => n > 0)), blink = t < T_SEND && Math.floor(t * 4) % 2;
        mf.lines.forEach((ln, k) => { if (k > curK) return;
          TY.text(c, [...ln].slice(0, ns[k]).join('') + (blink && k === curK ? '|' : ''), sx + sw - 30 * u - bwid + 30 * u, bubY + 2 * u + k * lh, { size: fs, fam: 'PuHui-Bold', color: '#fff', align: 'left' }); }); } }
    // AI 的回复：代码墙，越滚越快
    if (t > T_SEND + 0.05) { const lh = 46 * u, y0 = top + (msg ? 220 : 40) * u - scr;
      for (let i = Math.max(0, Math.floor((top - y0) / lh)); ; i++) { const y = y0 + i * lh; if (y > sy + sh) break; if (y < top) continue;
        const shown = clamp((t - T_SEND - 0.05 - Math.min(i, 12) * 0.03) / 0.05); if (shown <= 0) continue;
        c.fillStyle = '#4A4F66'; c.fillRect(sx + 30 * u, y - 12 * u, 44 * u, 16 * u);
        for (const [x, w, col] of LINES[i % LINES.length]) { c.fillStyle = col; c.globalAlpha = 0.9; c.beginPath(); c.roundRect(sx + 110 * u + x * u, y - 14 * u, w * u * shown, 20 * u, 10 * u); c.fill(); } c.globalAlpha = 1; }
      const v = (scrollAt(t + 1 / 60) - scr) * 60; if (v > 1500 * u) { c.fillStyle = `rgba(32,34,45,${clamp((v - 1500 * u) / (6000 * u)) * 0.5})`; c.fillRect(sx, top, sw, sh); } }
    // 顶栏：三个圆点、标题、计数器（砸出那一刻停在 data.count）
    c.fillStyle = '#2A2D3A'; c.fillRect(sx, sy, sw, 64 * u);
    ['#FF5F57', '#FEBC2E', '#28C840'].forEach((col, i) => { c.fillStyle = col; c.beginPath(); c.arc(sx + 42 * u + i * 34 * u, sy + 32 * u, 10 * u, 0, 7); c.fill(); });
    TY.text(c, d.app || 'AI助手', sx + sw / 2, sy + 44 * u, { size: 30 * u, fam: 'PuHui-Bold', color: '#9AA3B8' });
    if (d.count != null && t > T_SEND + 0.1) { const N = +d.count, k = slam >= 0 ? N : Math.min(N - 1, Math.floor(Math.pow(clamp((t - T_SEND - 0.15) / Math.max(0.2, T_HIT - T_SEND - 0.15)), 2.4) * (N - 1)));
      TY.text(c, `${k}${d.unit || ''}`, sx + sw - 30 * u, sy + 44 * u, { size: 32 * u, fam: 'PuHui-Bold', color: slam >= 0 ? '#FFCB6B' : '#9AA3B8', align: 'right' });
      const cw = TY.width(c, `${N}${d.unit || ''}`, 32 * u, 'PuHui-Bold'); CLIP.mark(c, 'counter', sx + sw - 30 * u - cw - 10 * u, sy + 8 * u, cw + 20 * u, 48 * u); }
    // 大字砸出（backOut 过冲）＋压暗
    if (slam > 0 && q.text) { c.fillStyle = `rgba(10,10,16,${0.6 * MO.expoOut(clamp(slam / 0.15))})`; c.fillRect(sx, sy, sw, sh);
      const fs = TY.fit(c, q.text, sw * 0.86, (ctx.portrait ? 200 : 230) * u, 'PuHui-Black', { maxLines: 2, min: 0.4, balance: true });
      fs.lines.forEach((ln, i) => TY.pop(c, ln, sx + sw / 2, sy + sh / 2 + fs.size * 0.35 + (i - (fs.lines.length - 1) / 2) * fs.size * 1.1, clamp(slam / 0.24), { size: fs.size, fam: 'PuHui-Black', color: '#FFCB6B', over: 3.5, stroke: '#15161C', strokeW: 18 * u }));
      const bw2 = Math.max(...fs.lines.map(l => TY.width(c, l, fs.size, 'PuHui-Black'))), bh2 = fs.lines.length * fs.size * 1.1; CLIP.mark(c, 'big-text', sx + sw / 2 - bw2 / 2, sy + sh / 2 - bh2 / 2, bw2, bh2); }
    c.restore();
  });
  // 前景：他的后脑勺（过肩），随呼吸起伏，砸出时往后一缩
  const hx = W * (ctx.portrait ? 0.2 : 0.17), hy = by + bh - 60 * u + 6 * u * Math.sin(2 * Math.PI * t / 1.6) + (slam > 0 ? -MO.settle(slam, 18 * u, 4, 7) : 0), s = (ctx.portrait ? 0.8 : 0.75) * u;
  c.save(); c.translate(hx, hy); c.scale(s, s); c.lineWidth = 7; c.strokeStyle = '#1B1B1F'; c.lineJoin = 'round';
  c.fillStyle = '#FFFFFF'; c.beginPath(); c.ellipse(0, 300, 330, 200, 0, Math.PI, 0); c.fill(); c.stroke();
  c.fillStyle = '#FFE2CC'; c.beginPath(); c.roundRect(-70, 120, 140, 110, 30); c.fill(); c.stroke();
  for (const k of [-1, 1]) { c.beginPath(); c.ellipse(k * 196, 40, 34, 52, k * 0.2, 0, 7); c.fill(); c.stroke(); }
  c.fillStyle = '#1B1B1F'; c.beginPath(); c.ellipse(0, 40, 190, 175, 0, 0, 7); c.fill();
  c.fillStyle = '#FFFFFF'; c.beginPath(); c.moveTo(-180, -20); c.bezierCurveTo(-180, -290, 180, -290, 180, -20); c.closePath(); c.fill(); c.stroke();
  c.beginPath(); c.ellipse(0, -12, 280, 64, 0, 0, 7); c.fill(); c.stroke();
  c.restore();
}
})();
