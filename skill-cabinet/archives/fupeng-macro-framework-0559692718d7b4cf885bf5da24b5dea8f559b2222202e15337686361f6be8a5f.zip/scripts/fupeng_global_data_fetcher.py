"""
付鹏宏观框架 - 全球多源数据自动抓取工具 v2.0
================================================
从全球多个权威数据源自动抓取付鹏框架核心指标：
- 美国财政部：国债收益率 + TIPS实际利率
- 中债登：中国国债收益率曲线
- Yahoo Finance：黄金、比特币、VIX、美股、美元指数
- 世界银行API：全球宏观数据
- 国家统计局：中国CPI/PPI

使用方法：
    python fupeng_global_data_fetcher.py

输出：
    fupeng_global_data_YYYYMMDD.xlsx
"""

import datetime
import json
import sys
import time
from pathlib import Path
from io import StringIO

import pandas as pd
import numpy as np
import requests

# 配置
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
}

TODAY = datetime.date.today()
OUTPUT_PATH = Path.cwd() / f"fupeng_global_data_{TODAY.strftime('%Y%m%d')}.xlsx"

results = {}  # 存储所有抓取结果


# ============================================================
# 1. 美国财政部：国债收益率 + TIPS
# ============================================================

def fetch_us_treasury():
    """从美国财政部获取名义收益率和TIPS实际收益率"""
    print("\n[1/5] 美国财政部 - 国债收益率曲线...")

    year = TODAY.year
    month = f"{TODAY.month:02d}"

    base_url = "https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv"

    datasets = {
        "名义收益率": f"{base_url}/{year}/all?type=daily_treasury_yield_curve&field_tdr_date_value={year}&page&_format=csv",
        "实际利率TIPS": f"{base_url}/{year}/all?type=daily_treasury_real_yield_curve&field_tdr_date_value={year}&page&_format=csv",
    }

    us_data = {}
    for name, url in datasets.items():
        for attempt in range(3):
            try:
                resp = requests.get(url, timeout=45, headers=HEADERS)
                resp.raise_for_status()
                df = pd.read_csv(StringIO(resp.text))
                if not df.empty:
                    latest = df.iloc[0]
                    # 统一列名格式（TIPS是大写YR，名义是Yr）
                    latest.index = [c.title() if c != 'Date' else c for c in latest.index]
                    us_data[name] = latest
                    print(f"  ✓ {name}：{latest['Date']}")
                    # 打印关键期限
                    for term in ["2 Yr", "5 Yr", "10 Yr", "30 Yr"]:
                        if term in latest.index:
                            print(f"    {term}: {latest[term]}%")
                    break
            except Exception as e:
                if attempt < 2:
                    print(f"  重试 {attempt+1}/3...")
                    time.sleep(2)
                else:
                    print(f"  ✗ {name}失败：{e}")

    results["美国利率"] = us_data
    return us_data


# ============================================================
# 2. 中债登：中国国债收益率曲线
# ============================================================

def fetch_china_bond():
    """从中债登获取中国国债收益率曲线"""
    print("\n[2/5] 中债登 - 中国国债收益率曲线...")

    # 中债登数据接口（尝试多个端点）
    urls = [
        "https://yield.chinabond.com.cn/cbweb-pbc-web/pbc/more?locale=zh_CN",
        "https://yield.chinabond.com.cn/cbweb-mn/pgxh/pgxhIndex",
    ]

    cn_data = {}
    for url in urls:
        try:
            resp = requests.get(url, timeout=20, headers=HEADERS)
            resp.raise_for_status()
            # 尝试从HTML中提取表格数据
            # 中债登页面可能是JS渲染，这里尝试解析静态表格
            tables = pd.read_html(StringIO(resp.text))
            if tables:
                for table in tables:
                    if len(table.columns) > 3 and any('收益率' in str(c) or '年' in str(c) for c in table.columns):
                        print(f"  ✓ 找到收益率表格（{len(table)}行）")
                        cn_data["raw_table"] = table
                        break
            if cn_data:
                break
        except Exception as e:
            print(f"  接口尝试失败：{type(e).__name__}")
            continue

    if not cn_data:
        print("  ⚠ 中债登数据需手动获取（JS渲染，requests无法直接解析）")
        print("  请访问 https://yield.chinabond.com.cn/ 查看最新数据")
        # 使用已知的最新数据作为备用（2026-09-07）
        cn_data = {
            "3月": 1.21, "6月": 1.24, "1年": 1.23, "3年": 1.25,
            "5年": 1.40, "7年": 1.52, "10年": 1.68, "30年": 2.13,
            "_source": "备用数据（2026-09-07），请手动更新"
        }
        print("  使用备用数据（2026-09-07）")

    results["中国利率"] = cn_data
    return cn_data


# ============================================================
# 3. Yahoo Finance：市场数据
# ============================================================

def fetch_market_data():
    """从Yahoo Finance获取市场数据"""
    print("\n[3/5] Yahoo Finance - 市场数据...")

    try:
        import yfinance as yf
    except ImportError:
        print("  ⚠ 未安装yfinance，跳过市场数据")
        print("  安装命令：pip install yfinance")
        results["市场数据"] = {}
        return {}

    tickers = {
        "黄金": "GC=F",
        "比特币": "BTC-USD",
        "VIX恐慌指数": "^VIX",
        "标普500": "^GSPC",
        "纳斯达克": "^IXIC",
        "美元指数": "DX-Y.NYB",
        "美国10年国债期货": "ZN=F",
        "美国30年国债期货": "ZB=F",
    }

    market_data = {}
    for name, ticker in tickers.items():
        for attempt in range(2):
            try:
                data = yf.Ticker(ticker)
                hist = data.history(period="5d")
                if not hist.empty:
                    latest = hist.iloc[-1]
                    prev = hist.iloc[-2] if len(hist) > 1 else latest
                    change = (latest["Close"] - prev["Close"]) / prev["Close"] * 100
                    market_data[name] = {
                        "价格": round(float(latest["Close"]), 2),
                        "日涨跌%": round(float(change), 2),
                        "日期": hist.index[-1].strftime("%Y-%m-%d"),
                        "代码": ticker
                    }
                    print(f"  ✓ {name}: {latest['Close']:.2f} ({change:+.2f}%)")
                    break
            except Exception as e:
                if attempt < 1:
                    time.sleep(1)
                else:
                    print(f"  ✗ {name}失败：{type(e).__name__}")

    results["市场数据"] = market_data
    return market_data


# ============================================================
# 4. 世界银行API：全球宏观数据
# ============================================================

def fetch_worldbank_data():
    """从世界银行API获取全球宏观数据"""
    print("\n[4/5] 世界银行 - 全球宏观数据...")

    # 世界银行API指标
    indicators = {
        "中国GDP增速": "NY.GDP.MKTP.KD.ZG",
        "美国GDP增速": "NY.GDP.MKTP.KD.ZG",
        "中国通胀": "FP.CPI.TOTL.ZG",
        "美国通胀": "FP.CPI.TOTL.ZG",
        "中国失业率": "SL.UEM.TOTL.ZS",
        "美国失业率": "SL.UEM.TOTL.ZS",
    }

    wb_data = {}
    for name, indicator in indicators.items():
        country = "CN" if "中国" in name else "US"
        url = f"https://api.worldbank.org/v2/country/{country}/indicator/{indicator}?format=json&per_page=5"
        try:
            resp = requests.get(url, timeout=15, headers=HEADERS)
            resp.raise_for_status()
            data = resp.json()
            if len(data) > 1 and data[1]:
                latest = data[1][0]
                wb_data[name] = {
                    "数值": latest["value"],
                    "年份": latest["date"],
                }
                print(f"  ✓ {name}: {latest['value']} ({latest['date']})")
            else:
                print(f"  ✗ {name}: 无数据")
        except Exception as e:
            print(f"  ✗ {name}失败：{type(e).__name__}")

    results["全球宏观"] = wb_data
    return wb_data


# ============================================================
# 5. 计算关键指标
# ============================================================

def calculate_indicators():
    """基于抓取的数据计算付鹏框架关键指标"""
    print("\n[5/5] 计算关键指标...")

    indicators = []

    # 美国利率相关
    us = results.get("美国利率", {})
    if "名义收益率" in us and "实际利率TIPS" in us:
        nominal = us["名义收益率"]
        tips = us["实际利率TIPS"]

        # 实际利率曲线
        for term in ["5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]:
            if term in tips.index and term in nominal.index:
                real = float(tips[term])
                nom = float(nominal[term])
                infl = nom - real
                indicators.append({
                    "指标": f"美国{term}实际利率",
                    "数值": f"{real:.2f}%",
                    "通胀预期": f"{infl:.2f}%",
                    "框架解读": "黄金定价锚" if "10" in term else "实际利率曲线"
                })

        # 收益率曲线形态
        if "2 Yr" in nominal.index and "10 Yr" in nominal.index:
            spread = float(nominal["10 Yr"]) - float(nominal["2 Yr"])
            indicators.append({
                "指标": "美债2年-10年利差",
                "数值": f"{spread:.2f}%",
                "通胀预期": "",
                "框架解读": "倒挂=衰退预警" if spread < 0 else "正常形态"
            })

    # 市场数据相关
    market = results.get("市场数据", {})
    if "VIX恐慌指数" in market:
        vix = market["VIX恐慌指数"]["价格"]
        indicators.append({
            "指标": "VIX恐慌指数",
            "数值": f"{vix:.1f}",
            "通胀预期": "",
            "框架解读": ">30恐慌，<15平静"
        })

    if "黄金" in market:
        gold = market["黄金"]["价格"]
        indicators.append({
            "指标": "黄金价格",
            "数值": f"${gold:.0f}/盎司",
            "通胀预期": "",
            "框架解读": "实际利率+秩序溢价"
        })

    if "比特币" in market:
        btc = market["比特币"]["价格"]
        indicators.append({
            "指标": "比特币价格",
            "数值": f"${btc:,.0f}",
            "通胀预期": "",
            "框架解读": "全球流动性先行指标"
        })

    df = pd.DataFrame(indicators)
    results["关键指标"] = df
    print(f"  ✓ 计算了 {len(indicators)} 个关键指标")
    return df


# ============================================================
# 生成Excel报告
# ============================================================

def generate_report():
    """生成综合Excel报告"""
    print(f"\n生成报告：{OUTPUT_PATH}")

    with pd.ExcelWriter(OUTPUT_PATH, engine='openpyxl') as writer:
        # Sheet 1: 数据概览
        overview_rows = []

        # 美国利率
        us = results.get("美国利率", {})
        if us:
            overview_rows.append(["=== 美国利率 ===", "", "", ""])
            for name, series in us.items():
                if hasattr(series, 'index'):
                    overview_rows.append([f"{name}（{series.get('Date', 'N/A')}）", "", "", ""])
                    for term in ["3 Mo", "6 Mo", "1 Yr", "2 Yr", "3 Yr", "5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]:
                        if term in series.index:
                            overview_rows.append([f"  {term}", f"{series[term]}%", "", ""])

        # 中国利率
        cn = results.get("中国利率", {})
        if cn and isinstance(cn, dict):
            overview_rows.append(["", "", "", ""])
            overview_rows.append(["=== 中国利率 ===", "", "", ""])
            source = cn.pop("_source", "")
            for term, rate in cn.items():
                overview_rows.append([f"  {term}", f"{rate}%", "", source if term == list(cn.keys())[0] else ""])

        # 市场数据
        market = results.get("市场数据", {})
        if market:
            overview_rows.append(["", "", "", ""])
            overview_rows.append(["=== 市场数据 ===", "", "", ""])
            for name, data in market.items():
                overview_rows.append([
                    name,
                    f"{data['价格']}",
                    f"{data['日涨跌%']:+.2f}%",
                    data["日期"]
                ])

        # 全球宏观
        wb = results.get("全球宏观", {})
        if wb:
            overview_rows.append(["", "", "", ""])
            overview_rows.append(["=== 全球宏观（世界银行）===", "", "", ""])
            for name, data in wb.items():
                overview_rows.append([name, f"{data['数值']}", "", data["年份"]])

        df_overview = pd.DataFrame(overview_rows, columns=["项目", "数值", "变动", "备注/日期"])
        df_overview.to_excel(writer, sheet_name="数据概览", index=False)

        # Sheet 2: 关键指标
        if "关键指标" in results and not results["关键指标"].empty:
            results["关键指标"].to_excel(writer, sheet_name="关键指标", index=False)

        # Sheet 3: 美国利率曲线（带图表）
        if us and "名义收益率" in us and "实际利率TIPS" in us:
            nominal = us["名义收益率"]
            tips = us["实际利率TIPS"]

            curve_data = []
            for term in ["1 Yr", "2 Yr", "3 Yr", "5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]:
                if term in nominal.index:
                    row = {"期限": term, "名义收益率": float(nominal[term])}
                    if term in tips.index:
                        row["实际利率TIPS"] = float(tips[term])
                        row["通胀预期"] = float(nominal[term]) - float(tips[term])
                    curve_data.append(row)

            df_curve = pd.DataFrame(curve_data)
            df_curve.to_excel(writer, sheet_name="美国利率曲线", index=False)

            # 创建图表
            from openpyxl.chart import LineChart, Reference
            wb_obj = writer.book
            ws = wb_obj["美国利率曲线"]

            chart = LineChart()
            chart.title = "美国利率曲线"
            chart.y_axis.title = "收益率(%)"
            chart.x_axis.title = "期限"
            chart.width = 20
            chart.height = 12

            data = Reference(ws, min_col=2, min_row=1, max_col=4, max_row=len(curve_data) + 1)
            cats = Reference(ws, min_col=1, min_row=2, max_row=len(curve_data) + 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(cats)
            ws.add_chart(chart, "F2")

    print(f"✓ 报告已生成：{OUTPUT_PATH}")


# ============================================================
# 主程序
# ============================================================

def main():
    print("=" * 60)
    print("付鹏宏观框架 - 全球多源数据自动抓取工具 v2.0")
    print("=" * 60)
    print(f"日期：{TODAY.strftime('%Y-%m-%d')}")

    # 执行各数据源抓取
    fetch_us_treasury()
    fetch_china_bond()
    fetch_market_data()
    fetch_worldbank_data()
    calculate_indicators()

    # 生成报告
    generate_report()

    # 统计
    def has_data(v):
        if isinstance(v, pd.DataFrame):
            return not v.empty
        return bool(v)
    total = sum(1 for v in results.values() if has_data(v))
    print(f"\n{'='*60}")
    print(f"完成！成功获取 {total}/5 个数据源")
    print(f"报告路径：{OUTPUT_PATH}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
