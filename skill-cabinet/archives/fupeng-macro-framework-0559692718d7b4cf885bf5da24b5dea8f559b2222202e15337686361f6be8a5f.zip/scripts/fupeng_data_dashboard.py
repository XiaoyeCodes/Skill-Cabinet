"""
付鹏宏观框架 - 关键数据自动获取工具
====================================
自动获取付鹏分析框架中的核心宏观数据，生成带图表的Excel报告。

数据来源：
- 美国国债/TIPS收益率：美国财政部官网
- 中国国债收益率：中国债券信息网
- 黄金/比特币/VIX：Yahoo Finance

使用方法：
    python fupeng_data_dashboard.py

输出：
    fupeng_macro_data_YYYYMMDD.xlsx
"""

import datetime
import json
import sys
from pathlib import Path

try:
    import pandas as pd
    import numpy as np
except ImportError:
    print("请先安装依赖：pip install pandas numpy openpyxl")
    sys.exit(1)

try:
    import yfinance as yf
except ImportError:
    print("警告：未安装yfinance，将跳过黄金/比特币/VIX数据获取")
    yf = None

try:
    import requests
except ImportError:
    print("请先安装依赖：pip install requests")
    sys.exit(1)


# ============================================================
# 1. 美国国债收益率（名义 + TIPS实际利率）
# ============================================================

def fetch_us_treasury_yields(date_str=None):
    """
    从美国财政部获取国债收益率曲线
    返回：DataFrame，包含各期限名义收益率和TIPS实际收益率
    """
    if date_str is None:
        date_str = datetime.date.today().strftime("%Y-%m-%d")

    year = date_str[:4]
    month = date_str[5:7]

    # 名义收益率
    nominal_url = f"https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/{year}/{month}/all?type=daily_treasury_yield_curve&field_tdr_date_value_month={year}{month}&page&_format=csv"

    # TIPS实际收益率
    tips_url = f"https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/{year}/{month}/all?type=daily_treasury_real_yield_curve&field_tdr_date_value_month={year}{month}&page&_format=csv"

    results = {}

    for name, url in [("名义", nominal_url), ("实际(TIPS)", tips_url)]:
        try:
            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            from io import StringIO
            df = pd.read_csv(StringIO(resp.text))
            if not df.empty:
                # 取最新一行
                latest = df.iloc[0]
                results[name] = latest
                print(f"  ✓ 获取美国{name}收益率成功（{latest['Date']}）")
            else:
                print(f"  ✗ 美国{name}收益率数据为空")
        except Exception as e:
            print(f"  ✗ 获取美国{name}收益率失败：{e}")

    return results


# ============================================================
# 2. 中国国债收益率
# ============================================================

def fetch_china_bond_yields():
    """
    中国国债收益率（手动输入或从公开数据源获取）
    注意：中债登数据需要专业接口，这里提供框架，用户可填入最新数据
    """
    # 中债登数据接口（需要专业权限，这里提供备用方案）
    # 数据源：https://yield.chinabond.com.cn/
    # 由于反爬限制，建议手动获取后填入，或使用Wind/Choice等终端

    print("  ⚠ 中国国债收益率需手动获取（中债登有反爬限制）")
    print("  请访问 https://yield.chinabond.com.cn/ 获取最新数据")
    print("  或使用 Wind/Choice/同花顺 等终端导出")

    # 返回空DataFrame，由用户补充
    return None


# ============================================================
# 3. 黄金、比特币、VIX
# ============================================================

def fetch_market_data():
    """从Yahoo Finance获取黄金、比特币、VIX最新价格"""
    if yf is None:
        print("  ⚠ 未安装yfinance，跳过市场数据获取")
        return {}

    tickers = {
        "黄金": "GC=F",
        "比特币": "BTC-USD",
        "VIX": "^VIX",
        "标普500": "^GSPC",
        "纳斯达克": "^IXIC",
        "美元指数": "DX-Y.NYB",
    }

    results = {}
    for name, ticker in tickers.items():
        try:
            data = yf.Ticker(ticker)
            hist = data.history(period="5d")
            if not hist.empty:
                latest = hist.iloc[-1]
                prev = hist.iloc[-2] if len(hist) > 1 else latest
                change = (latest["Close"] - prev["Close"]) / prev["Close"] * 100
                results[name] = {
                    "价格": round(latest["Close"], 2),
                    "日涨跌%": round(change, 2),
                    "日期": hist.index[-1].strftime("%Y-%m-%d")
                }
                print(f"  ✓ {name}: {latest['Close']:.2f} ({change:+.2f}%)")
        except Exception as e:
            print(f"  ✗ 获取{name}失败：{e}")

    return results


# ============================================================
# 4. 计算关键指标
# ============================================================

def calculate_indicators(us_data, china_data=None, market_data=None):
    """计算付鹏框架中的关键指标"""
    indicators = []

    if us_data and "名义" in us_data and "实际(TIPS)" in us_data:
        nominal = us_data["名义"]
        tips = us_data["实际(TIPS)"]

        # 实际利率曲线
        for term in ["5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]:
            if term in tips.index and term in nominal.index:
                real_yield = float(tips[term])
                nom_yield = float(nominal[term])
                inflation_exp = nom_yield - real_yield
                indicators.append({
                    "指标": f"美国{term}实际利率",
                    "数值": f"{real_yield:.2f}%",
                    "含义": "黄金定价锚" if "10" in term else "实际利率曲线",
                    "阈值": ">2%为高实际利率，<0%为负实际利率"
                })
                indicators.append({
                    "指标": f"美国{term}通胀预期",
                    "数值": f"{inflation_exp:.2f}%",
                    "含义": "名义-实际",
                    "阈值": "2%为美联储目标"
                })

        # 收益率曲线形态
        if "2 Yr" in nominal.index and "10 Yr" in nominal.index:
            spread_2s10s = float(nominal["10 Yr"]) - float(nominal["2 Yr"])
            indicators.append({
                "指标": "美债2年-10年利差",
                "数值": f"{spread_2s10s:.2f}%",
                "含义": "衰退预警指标",
                "阈值": "<0为倒挂（衰退预警）"
            })

        if "3 Mo" in nominal.index and "10 Yr" in nominal.index:
            spread_3m10y = float(nominal["10 Yr"]) - float(nominal["3 Mo"])
            indicators.append({
                "指标": "美债3月-10年利差",
                "数值": f"{spread_3m10y:.2f}%",
                "含义": "更可靠的衰退预警",
                "阈值": "<0为倒挂"
            })

    # 中美利差（需中国数据）
    if china_data is not None and "名义" in us_data:
        if "10 Yr" in us_data["名义"].index:
            us_10y = float(us_data["名义"]["10 Yr"])
            cn_10y = china_data.get("10年", 1.68)  # 默认值，需更新
            spread = us_10y - cn_10y
            indicators.append({
                "指标": "中美10年利差",
                "数值": f"{spread:.2f}%",
                "含义": "资本流动方向",
                "阈值": ">1%为资本流出压力"
            })

    return pd.DataFrame(indicators)


# ============================================================
# 5. 生成Excel报告
# ============================================================

def generate_excel_report(us_data, china_data, market_data, indicators, output_path):
    """生成带图表的Excel报告"""

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        # Sheet 1: 数据概览
        overview_data = []
        overview_data.append(["=== 美国利率 ===", "", "", ""])
        if us_data:
            for name, series in us_data.items():
                overview_data.append([f"美国{name}收益率", "", "", f"日期：{series.get('Date', 'N/A')}"])
                for term in ["3 Mo", "6 Mo", "1 Yr", "2 Yr", "3 Yr", "5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]:
                    if term in series.index:
                        overview_data.append([f"  {term}", f"{float(series[term]):.2f}%", "", ""])

        overview_data.append(["", "", "", ""])
        overview_data.append(["=== 市场数据 ===", "", "", ""])
        if market_data:
            for name, data in market_data.items():
                overview_data.append([name, f"{data['价格']:.2f}", f"{data['日涨跌%']:+.2f}%", data["日期"]])

        df_overview = pd.DataFrame(overview_data, columns=["项目", "数值", "变动", "备注"])
        df_overview.to_excel(writer, sheet_name="数据概览", index=False)

        # Sheet 2: 关键指标
        if not indicators.empty:
            indicators.to_excel(writer, sheet_name="关键指标", index=False)

        # Sheet 3: 美国利率曲线（用于画图）
        if us_data and "名义" in us_data and "实际(TIPS)" in us_data:
            nominal = us_data["名义"]
            tips = us_data["实际(TIPS)"]

            curve_data = []
            for term in ["1 Yr", "2 Yr", "3 Yr", "5 Yr", "7 Yr", "10 Yr", "20 Yr", "30 Yr"]:
                if term in nominal.index and term in tips.index:
                    curve_data.append({
                        "期限": term,
                        "名义收益率": float(nominal[term]),
                        "实际收益率(TIPS)": float(tips[term]),
                        "通胀预期": float(nominal[term]) - float(tips[term])
                    })

            df_curve = pd.DataFrame(curve_data)
            df_curve.to_excel(writer, sheet_name="美国利率曲线", index=False)

            # 创建图表
            from openpyxl.chart import LineChart, Reference
            from openpyxl.chart.label import DataLabelList

            wb = writer.book
            ws = wb["美国利率曲线"]

            chart = LineChart()
            chart.title = "美国利率曲线（名义 vs 实际 vs 通胀预期）"
            chart.style = 10
            chart.y_axis.title = "收益率(%)"
            chart.x_axis.title = "期限"
            chart.width = 20
            chart.height = 12

            data = Reference(ws, min_col=2, min_row=1, max_col=4, max_row=len(curve_data) + 1)
            cats = Reference(ws, min_col=1, min_row=2, max_row=len(curve_data) + 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(cats)

            ws.add_chart(chart, "F2")

    print(f"\n✓ 报告已生成：{output_path}")


# ============================================================
# 主程序
# ============================================================

def main():
    print("=" * 60)
    print("付鹏宏观框架 - 关键数据自动获取工具")
    print("=" * 60)

    today = datetime.date.today().strftime("%Y%m%d")
    output_path = Path.cwd() / f"fupeng_macro_data_{today}.xlsx"

    # 1. 获取美国利率数据
    print("\n[1/4] 获取美国国债收益率...")
    us_data = fetch_us_treasury_yields()

    # 2. 中国国债收益率（需手动补充）
    print("\n[2/4] 中国国债收益率...")
    china_data = fetch_china_bond_yields()

    # 3. 市场数据
    print("\n[3/4] 获取黄金/比特币/VIX...")
    market_data = fetch_market_data()

    # 4. 计算关键指标
    print("\n[4/4] 计算关键指标...")
    indicators = calculate_indicators(us_data, china_data, market_data)
    if not indicators.empty:
        print("\n关键指标：")
        print(indicators.to_string(index=False))

    # 5. 生成报告
    print("\n生成Excel报告...")
    generate_excel_report(us_data, china_data, market_data, indicators, output_path)

    print("\n" + "=" * 60)
    print("完成！请查看生成的Excel文件。")
    print("=" * 60)


if __name__ == "__main__":
    main()
