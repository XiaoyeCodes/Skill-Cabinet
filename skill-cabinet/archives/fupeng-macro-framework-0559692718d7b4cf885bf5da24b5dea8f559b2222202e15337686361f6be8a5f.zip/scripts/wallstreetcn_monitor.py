"""
付鹏框架 - 华尔街见闻事件监控器
================================
自动抓取华尔街见闻热门新闻，用付鹏宏观框架判断事件重要性，
触发关键事件时记录并推送提醒。

触发逻辑基于付鹏Skill中的观察指标清单：
- 利率与流动性（美债曲线、TIPS、中美利差、美联储政策）
- 市场结构（VIX、集中度、估值）
- 企业盈利（科技巨头FCF、资本开支）
- 中国经济（国债收益率、社融、居民杠杆）
- 黄金与加密（实际利率曲线、比特币流动性信号）

使用方法：
    python wallstreetcn_monitor.py

输出：
    alerts/ 目录下生成事件提醒文件
    控制台打印触发的事件
"""

import datetime
import json
import os
import re
import sys
from pathlib import Path

import requests

# ============================================================
# 配置
# ============================================================

ALERTS_DIR = Path(__file__).parent.parent / "alerts"
ALERTS_DIR.mkdir(exist_ok=True)

HISTORY_FILE = ALERTS_DIR / "seen_articles.json"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKitKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

# ============================================================
# 付鹏框架事件触发规则
# ============================================================

# 排除词：包含这些词的新闻不触发（日常市场动态、非核心事件）
EXCLUDE_KEYWORDS = [
    "早盘收盘", "午盘", "收盘综述", "日经", "韩国", "澳洲联储", "新西兰",
    "加拿大", "英国央行", "欧央行", "日本", "法国", "意大利",
    "期货早盘", "期货午盘", "A股收盘", "港股收盘", "欧股收盘",
    "黑客", "失窃", "被盗", "攻击案", "发图", "梗图", "社交媒体",
    "英镑债", "欧元债", "发行债券", "聘请银行",
    "停办", "代理", "贵金属业务", "银行调整",
]

# 高优先级：立即触发提醒
HIGH_PRIORITY_RULES = {
    "美联储政策转向": {
        "keywords": ["美联储", "加息", "降息", "暂停加息", "缩表", "扩表", "QE", "QT", "点阵图", "FOMC", "鲍威尔"],
        "framework": "利率与流动性 - 全球资产定价之锚变动",
        "impact": "直接影响分母端（利率/估值），所有资产重新定价"
    },
    "美债收益率异动": {
        "keywords": ["美债", "美国国债", "10年期美债", "30年期美债", "美债收益率", "美债倒挂", "长端美债"],
        "framework": "利率与流动性 - 全球无风险利率基准",
        "impact": "收益率突破关键阈值（5%/4%）影响全球资本流动"
    },
    "实际利率/黄金": {
        "keywords": ["实际利率", "TIPS", "黄金", "金价", "通胀保值", "实际收益率"],
        "framework": "黄金与加密 - 黄金定价锚变动",
        "impact": "实际利率全曲线下移=黄金大牛市信号"
    },
    "中国重大政策": {
        "keywords": ["降准", "降息", "LPR", "MLF", "逆回购", "地产政策", "刺激计划", "特别国债", "化债", "城中村"],
        "framework": "中国经济 - 政策转向影响有效需求",
        "impact": "中国流动性和需求端的关键变量"
    },
    "债务/财政危机": {
        "keywords": ["债务上限", "美债违约", "评级下调", "财政赤字", "利息支出", "政府停摆", "主权评级"],
        "framework": "债务-杠杆 - 坏债务占比上升",
        "impact": "美元信用受损，黄金长期看多逻辑强化"
    },
    "地缘政治/供应链": {
        "keywords": ["战争", "制裁", "关税", "贸易战", "供应链", "脱钩", "红海", "霍尔木兹", "油价", "OPEC", "极右翼", "选择党", "默茨", "德国选举", "欧洲政治", "勒庞", "特朗普", "地缘"],
        "framework": "三级分工体系 - 全球循环受阻 + K形社会政治表达",
        "impact": "政治极端化推高风险溢价，影响欧元/能源/避险资产，可能加速缩圈行情"
    },
    "金融风险事件": {
        "keywords": ["银行倒闭", "流动性危机", "爆仓", "踩踏", "熔断", "暴跌", "闪崩", "对冲基金", "保证金"],
        "framework": "市场结构 - 流动性收缩极端情况",
        "impact": "VIX飙升，缩圈行情加速，避险资产受益"
    },
    "AI产业拐点": {
        "keywords": ["资本开支", "自由现金流", "FCF", "AI应用", "大模型", "AI资本开支", "算力需求", "AI盈利", "AI证伪"],
        "framework": "企业盈利 - AI从第二阶段向第三阶段切换",
        "impact": "FCF拐点决定科技成长股估值是否打问号"
    },
    "比特币/流动性信号": {
        "keywords": ["比特币", "BTC", "以太坊", "稳定币", "USDT", "加密货币暴跌", "加密货币暴涨", "币圈流动性"],
        "framework": "黄金与加密 - 全球流动性先行指标",
        "impact": "比特币率先下跌=全球流动性收缩开始信号"
    },
}

# 中优先级：汇总提醒
MEDIUM_PRIORITY_RULES = {
    "经济数据": {
        "keywords": ["CPI", "PPI", "非农", "失业率", "GDP", "社融", "信贷", "PMI", "零售销售", "工业增加值"],
        "framework": "宏观数据验证",
    },
    "官员讲话": {
        "keywords": ["鲍威尔", "耶伦", "央行", "行长", "主席", "讲话", "证词", "表态"],
        "framework": "政策预期管理",
    },
    "房地产": {
        "keywords": ["房价", "楼市", "房地产", "房贷", "首付", "限购"],
        "framework": "中国经济 - 资产负债表衰退观察",
    },
}

# ============================================================
# 新闻抓取
# ============================================================

def fetch_wallstreetcn_news():
    """从华尔街见闻抓取热门新闻"""
    print("\n[1/3] 抓取华尔街见闻新闻...")

    articles = []

    # 华尔街见闻API端点（热门/最新新闻）
    endpoints = [
        "https://api-one-wscn.awtmt.com/apiv1/content/lives?channel=global-channel&limit=30",
        "https://api-one-wscn.awtmt.com/apiv1/content/articles?limit=20",
    ]

    for url in endpoints:
        try:
            resp = requests.get(url, timeout=15, headers=HEADERS)
            resp.raise_for_status()
            data = resp.json()

            items = data.get("data", {}).get("items", []) or data.get("data", {}).get("articles", [])
            for item in items:
                title = item.get("title", "") or item.get("content_text", "")[:100]
                if title and len(title) > 5:
                    articles.append({
                        "title": title.strip(),
                        "url": item.get("uri", ""),
                        "time": item.get("display_time", item.get("created_at", "")),
                        "source": "华尔街见闻"
                    })
        except Exception as e:
            print(f"  端点失败: {type(e).__name__}: {e}")
            continue

    # 去重
    seen = set()
    unique = []
    for a in articles:
        if a["title"] not in seen:
            seen.add(a["title"])
            unique.append(a)

    print(f"  ✓ 获取到 {len(unique)} 条新闻")
    return unique


def load_seen_articles():
    """加载已处理的文章记录"""
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                return set(json.load(f))
        except:
            return set()
    return set()


def save_seen_articles(seen):
    """保存已处理的文章记录"""
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(list(seen)[-500:], f, ensure_ascii=False)  # 只保留最近500条


# ============================================================
# 事件匹配（付鹏框架）
# ============================================================

def match_events(articles):
    """用付鹏框架匹配新闻事件"""
    print("\n[2/3] 用付鹏框架匹配事件...")

    seen = load_seen_articles()
    new_alerts = []

    for article in articles:
        title = article["title"]

        # 跳过已处理
        if title in seen:
            continue

        # 排除词检查：日常市场动态不触发
        if any(ex in title for ex in EXCLUDE_KEYWORDS):
            seen.add(title)
            continue

        # 高优先级匹配
        for event_name, rule in HIGH_PRIORITY_RULES.items():
            if any(kw in title for kw in rule["keywords"]):
                alert = {
                    "priority": "HIGH",
                    "event_type": event_name,
                    "title": title,
                    "framework": rule["framework"],
                    "impact": rule["impact"],
                    "url": article["url"],
                    "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "source": article["source"]
                }
                new_alerts.append(alert)
                print(f"  🔴 [高优先级] {event_name}: {title[:50]}...")
                break  # 一条新闻只触发一个高优先级事件

        # 中优先级匹配（仅当未触发高优先级时）
        else:
            for event_name, rule in MEDIUM_PRIORITY_RULES.items():
                if any(kw in title for kw in rule["keywords"]):
                    alert = {
                        "priority": "MEDIUM",
                        "event_type": event_name,
                        "title": title,
                        "framework": rule["framework"],
                        "impact": "",
                        "url": article["url"],
                        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "source": article["source"]
                    }
                    new_alerts.append(alert)
                    print(f"  🟡 [中优先级] {event_name}: {title[:50]}...")
                    break

        seen.add(title)

    save_seen_articles(seen)

    high_count = sum(1 for a in new_alerts if a["priority"] == "HIGH")
    medium_count = sum(1 for a in new_alerts if a["priority"] == "MEDIUM")
    print(f"  ✓ 触发 {high_count} 个高优先级事件，{medium_count} 个中优先级事件")

    return new_alerts


# ============================================================
# 事件推送
# ============================================================

def push_alerts(alerts):
    """推送事件提醒"""
    print("\n[3/3] 生成事件提醒...")

    if not alerts:
        print("  无新事件触发")
        return

    high_alerts = [a for a in alerts if a["priority"] == "HIGH"]
    medium_alerts = [a for a in alerts if a["priority"] == "MEDIUM"]

    # 生成提醒文件
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    alert_file = ALERTS_DIR / f"alert_{timestamp}.md"

    content = f"""# 付鹏框架事件提醒
生成时间：{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 🔴 高优先级事件（{len(high_alerts)}条）

"""
    for i, alert in enumerate(high_alerts, 1):
        content += f"""### {i}. [{alert['event_type']}] {alert['title']}

- **付鹏框架定位**：{alert['framework']}
- **影响分析**：{alert['impact']}
- **来源**：{alert['source']}
- **时间**：{alert['time']}
- **链接**：{alert['url']}

"""

    if medium_alerts:
        content += f"""## 🟡 中优先级事件（{len(medium_alerts)}条）

"""
        for i, alert in enumerate(medium_alerts, 1):
            content += f"{i}. **[{alert['event_type']}]** {alert['title']}\n"

    content += f"""
---
*本提醒由付鹏宏观框架事件监控器自动生成*
*触发规则基于 fupeng-macro-framework Skill 的观察指标清单*
"""

    with open(alert_file, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f"  ✓ 提醒文件已生成：{alert_file}")

    # 同时追加到总日志
    log_file = ALERTS_DIR / "alert_log.md"
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"\n\n## {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 监控结果\n")
        f.write(f"高优先级：{len(high_alerts)}条，中优先级：{len(medium_alerts)}条\n")
        for alert in high_alerts:
            f.write(f"- 🔴 [{alert['event_type']}] {alert['title']}\n")
        for alert in medium_alerts:
            f.write(f"- 🟡 [{alert['event_type']}] {alert['title']}\n")

    # 控制台汇总
    print(f"\n{'='*60}")
    print(f"监控完成：触发 {len(high_alerts)} 个高优先级，{len(medium_alerts)} 个中优先级")
    if high_alerts:
        print(f"\n🔴 高优先级事件：")
        for alert in high_alerts:
            print(f"  - [{alert['event_type']}] {alert['title'][:60]}")
    print(f"{'='*60}")

    return alert_file


# ============================================================
# 主程序
# ============================================================

def main():
    print("=" * 60)
    print("付鹏框架 - 华尔街见闻事件监控器")
    print("=" * 60)
    print(f"启动时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # 1. 抓取新闻
    articles = fetch_wallstreetcn_news()

    if not articles:
        print("\n⚠ 未获取到新闻，可能是网络问题或API变更")
        return

    # 2. 匹配事件
    alerts = match_events(articles)

    # 3. 推送提醒
    if alerts:
        alert_file = push_alerts(alerts)
        return alert_file
    else:
        print("\n✓ 本次监控无新事件触发")


if __name__ == "__main__":
    main()
