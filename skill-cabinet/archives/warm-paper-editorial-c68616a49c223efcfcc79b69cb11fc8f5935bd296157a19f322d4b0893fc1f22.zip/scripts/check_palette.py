"""Check the semantic foreground/background pairs declared in tokens.json."""
import json
from pathlib import Path

def luminance(color):
    channels = [int(color.lstrip('#')[i:i+2], 16) / 255 for i in (0, 2, 4)]
    linear = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in channels]
    return sum(c * w for c, w in zip(linear, (0.2126, 0.7152, 0.0722)))

def main():
    data = json.loads((Path(__file__).resolve().parents[1] / 'assets/tokens.json').read_text(encoding='utf-8'))
    result = []
    for pair in data['contrastChecks']:
        lo, hi = sorted([luminance(data['colors'][pair['fg']]), luminance(data['colors'][pair['bg']])])
        ratio = (hi + .05) / (lo + .05)
        result.append(dict(name=pair['name'], ratio=round(ratio, 2), minimum=pair['minimum'], passed=ratio >= pair['minimum']))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not all(row['passed'] for row in result):
        raise SystemExit(1)

if __name__ == '__main__':
    main()
