---
name: "warm-paper-editorial"
display_name: "暖纸编辑设计"
description: "以暖白纸面、陶土色强调、衬线标题和原创细线图形，统一网页、项目界面、图片、Word 与 PDF 的视觉语言；附配色规范、排版指南、CSS、SVG 和质量检查方法。"
version: "1.0.0"
author: "我的创作"
tags: ["视觉设计","网页设计","文档排版","PDF","线稿插画"]
category: "图像与设计"
metadata:
  author: personal
  version: 1.0.0
---

# 暖纸编辑设计

把信息组织得像一本值得阅读的书，让技术产品带有纸张、书房与手工制图的亲近感。风格由材质、字形、节奏和图形语法共同建立。配色只负责其中一部分。

## 从任务出发

判断载体、受众、主题与主要操作。沿用用户已有的主题、品牌、语言和内容；缺少示例内容时可选择简单的虚构主题并标明。制作前简短确定纸色、字体、图形隐喻和强调位置，信息足够就直接执行，不设置固定确认轮次。

## 设计骨架

1. **纸面承载内容。** 暖白底与略深一阶的辅助底构成平整、安静的表面。纸纹至多轻微可见，小字背后保持净色。
2. **字先于装饰。** 中文标题用宋体类衬线，拉丁标题用古典衬线；正文和操作界面用清晰的无衬线。字号随阅读距离调整。
3. **陶土色安排注意力。** 落在主要动作、少量关键词和一两个插画物件上。深陶土用于小字和白字按钮，浅陶土用于装饰。
4. **留白形成节奏。** 以对齐、分隔线和段落建立结构；有交互或分组需要时才用卡片。章节间距应大于段落间距。
5. **细线表达具体事物。** 根据主题画物件、路径或有机形态。圆端圆角、统一线宽、少量平涂，手绘感来自构图与曲线，不来自随机抖动。
6. **使用原创识别图形。** 折页、种子、器具和轨道都可成为标记。不要复用 Anthropic 品牌标识或暗示官方关联。

默认数值见 [assets/tokens.json](assets/tokens.json)，判断依据见 [references/visual-language.md](references/visual-language.md)。这些是个人工作规范，不能称为 Anthropic 官方品牌规范。

## 按输出读取

| 输出 | 参考 | 重点 |
|---|---|---|
| 网页与项目界面 | [references/web.md](references/web.md) | 响应式、真实交互、键盘焦点、文本对比度 |
| Word 与 PDF | [references/documents-pdf.md](references/documents-pdf.md) | 物理字号、版心、字体、分页、可编辑文字 |
| 图片与海报 | [references/image-prompts.md](references/image-prompts.md) | 画面留白、原创线稿、准确文字、比例适配 |
| 所有成品 | [references/quality-check.md](references/quality-check.md) | 实际渲染与可用性检查 |

只读取本次任务相关的参考。

## 随包资源

- `assets/paper.css`：网页基础样式与状态。
- `assets/line-art.svg`：原创书页、书脊、枝叶与灯具组合；换主题时重新选择隐喻。
- `assets/folio-mark.svg`：原创折页标记，需测试小尺寸识别。
- `assets/reference.png`：用户提供的审美参考，不自动放进其他成品。
- `scripts/check_palette.py`：检查默认文字配色的对比度。

## 交付

先验证内容与功能，再看风格。网页测试窄屏和键盘，文档与 PDF 真实渲染后逐页看图，图片逐字检查。记录实际结果，不把未验证的项目写成通过。

提供成品和可编辑源文件，说明关键选择。上传 Skill Cabinet、Git 提交或网络发布，只在用户授权的范围内执行。
