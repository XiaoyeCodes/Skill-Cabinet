# 金十财经早餐完整技能包（2026-10-29）

## 快速使用
1. 解压后保留整个 `jin10-breakfast-market-watch` 文件夹。支持技能目录的客户端可将此文件夹放入自己的 skills 目录；否则让智能体读取 `SKILL.md`。
2. Python **3.10+**：`python -m pip install -r requirements.txt`。依赖来自官方 PyPI；安装按执行环境权限处理。
3. 对智能体说：“使用此技能生成今天的金十财经早餐，重新获取并核验全部十项行情，输出 HTML（另需 PDF 时请导出）。”

含 SOXX、比特币排序、美债 bp、沪港午休识别、备用候选、带原时间的有效历史缓存、黄金分钟/日线校验。与邮件采用同一模板和原创刊头；不包含发邮件或定时任务，也不会改变既有日报。

## 环境依赖
原文准备脚本可联网获取金十网页。**行情需要执行智能体可用的只读行情连接或可访问的可信公开来源**，由智能体按来源说明收集并填入 quotes.json。仅运行 Python 不会自动取得全部市场数据；本包不含账号、密钥或付费数据服务。没有可信数据时会停止而不是填假值。

## 输出
- `breakfast.html`：独立 HTML，刊头内嵌，可直接浏览。
- `breakfast.txt`：纯文本。
- `market-verified.json` / `status.json`：验证与完成状态。
- `breakfast-email.html`、PNG 与 inline-attachments.json：可用于另行授权的邮件流程，本技能不发送。
- `breakfast.pdf`：按需生成，不是默认主输出。

## 可选 PDF
需本机已有 Chromium/Google Chrome，或另行安装 WeasyPrint 及其系统字体/库。优先运行：
`python scripts/export_pdf.py --html run-YYYYMMDD/breakfast.html --output run-YYYYMMDD/breakfast.pdf`
可用 `--engine weasyprint` 或 `--browser /path/to/chromium`。需要中文字体，否则可能缺字。PDF 分页与 HTML 邮件可能不同，导出后必须查看每页，不能仅凭文件存在声称视觉一致。受限沙箱可能禁止浏览器启动，届时使用已生成 HTML，不能伪称 PDF 已完成。

## 离线测试与演示
`python -m unittest discover -s tests -v`
`python scripts/demo.py --out demo`
演示输出显著标注“模拟演示，非真实新闻与行情”，测试夹具不得用于日报或历史回退。生产恢复包内的个人路径、原始研究工具响应和生产缓存不随包交付。
