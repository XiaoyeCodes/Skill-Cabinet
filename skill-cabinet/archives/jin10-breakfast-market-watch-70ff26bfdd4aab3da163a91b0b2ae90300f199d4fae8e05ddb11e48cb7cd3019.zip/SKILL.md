---
name: "jin10-breakfast-market-watch"
display_name: "金十财经日报 - HTML日报版"
description: "生成金十财经早餐原文与十项已核验市场行情的同款 HTML 日报，支持可选 PDF 导出；适用于临时或每日生成，不包含邮件发送与定时任务。"
version: "1.0.0"
author: ""
tags: []
category: "新闻日报"
---

# 金十财经早餐 · 十项行情

输出与已测试邮件相同的浅米色单栏 HTML：原创线条刊头、完整新闻、简洁三列行情。默认北京时间当天，必须联网取新文章和新行情；本技能不是无需数据连接的一键行情爬虫。

## 使用流程
1. 阅读 `references/source-policy.md`。确认执行智能体可读行情工具或可信公开网站。按用户实际授权访问，不读账户资产、不交易。仅生成文件，不发送邮件、不新增排期。
2. 新建运行目录，执行 `python scripts/jin10_breakfast.py prepare --out run-YYYYMMDD`。核对文章日期；无当日稿则正常停止，不发旧文。浏览器取得的正常页面可用 `--topic-html` / `--article-html` 输入，不绕过站点限制。
3. 按 `references/quote-schema.md` 采集并核验十项数据，保存 `quotes.json` 与本轮原始证据。行情取得时间与报价时间分开记录，不以取得时间冒充报价时间。所有测试夹具禁止用于正式输出或缓存。
4. 执行 `python scripts/jin10_breakfast.py render --out run-YYYYMMDD --quotes run-YYYYMMDD/quotes.json --evidence-root run-YYYYMMDD/evidence`。
5. 检查 `status.json` 的 `ready=true` 和 `verified_quote_count=10`。任何剩余缺值都阻止正式输出，退出码 20；诊断源失败，必要时说明阻碍，不编造数字。不得交付目录中上次运行遗留文件为本次结果。
6. 打开 `breakfast.html` 核对版式。新闻标题、导语、段落、强调、免责声明保留原文；删全部原站图片及音频，只保留原创刊头，行情在“今日优选”前。需要 PDF 时执行 `python scripts/export_pdf.py --html run-YYYYMMDD/breakfast.html --output run-YYYYMMDD/breakfast.pdf`；依赖与验证见 README。

## 固定口径与呈现
顺序：纳斯达克综合、标普 500、MAGS、SOXX、比特币现货、上证指数、恒生指数、现货黄金、布伦特原油、10 年期美债收益率。
SOXX 是 iShares Semiconductor ETF，不是 SOX 指数；比特币在 SOXX 下方。美债值显示收益率%，变动为 `(本次百分数−前次百分数)×100 bp`，如 5.05%−4.99%=+6 bp；其余九项变动用百分比。

开市用可信常规时段报价；休市用最近完整收盘；沪港午休使用核实过的上午末笔。先尝试主源和独立备用源，仍失败才尝试有证据的历史缓存。回退必须显示原始时间，不能冒充当天涨跌；时效上限及不可用规则见来源说明。最终十项都须通过，不能承诺上游永不失效。

## 可复用缓存
本包不带生产缓存或私人账户资料。首次正式运行需要取得十项真实行情。
`python scripts/cache_quotes.py --quotes RUN/quotes.json --evidence-root RUN/evidence --destination-root CACHE --prefix verified-cache/UNIQUE_RUN`
保留输出 file/sha256 指针和所有源文件；后续把缓存原样复制到本轮 evidence-root，写入 fallback_snapshots。不得更改原始时间，不得把测试夹具或已回退数据重新包装为新验证结果。持久保存到调用方选择的位置，不依赖临时目录。

## 边界与测试
默认生成独立 HTML、TXT、校验 JSON，并保留可用于外部邮件流程的 CID HTML/图片清单，但无发送功能。PDF 为可选派生件，HTML 是基准版式。`--date` 仅显式历史研究使用；`--preview-only` 仅预览，不作为正式日报。
运行 `python -m unittest discover -s tests -v`。离线演示：`python scripts/demo.py --out demo`，全部标为模拟数据，不联网、不生成正式日报。
