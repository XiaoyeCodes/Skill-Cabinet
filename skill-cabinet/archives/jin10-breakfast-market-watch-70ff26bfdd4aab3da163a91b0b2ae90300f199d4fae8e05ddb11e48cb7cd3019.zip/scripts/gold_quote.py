"""Resolve London spot gold from fresh IBKR responses; no network or old samples.
CLI: gold_quote.py --current current.json --minutes minutes.json --daily daily.json
                  --fetched-at ISO --output gold.json
ONE_DAY minute chart bounds provide the provider's observed session boundary.
A completed prior daily bar is corroborated by its whole intraday interval and
terminal minute, not by guessing calendar dates or using the partial daily row.
"""
import argparse
import json
from datetime import datetime, timedelta
from decimal import Decimal
from hashlib import sha256
from pathlib import Path

def dt(s):
    d=datetime.fromisoformat(s.replace('Z','+00:00'))
    if d.tzinfo is None: raise ValueError('timezone required')
    return d

def payload(raw):
    if raw.get('isError'): raise ValueError('IBKR tool error')
    p=raw.get('structuredContent')
    if not p:
        p=next((json.loads(b['text']) for b in raw.get('content',[]) if b.get('type')=='text'),None)
    if not p or p.get('error'): raise ValueError('missing/error IBKR payload')
    return p

def bars(p, step):
    if p.get('chart_step')!=step or p.get('source')!='MidPoint':
        raise ValueError('wrong interval or price basis')
    t=p.get('time',[]); c=p.get('close',[])
    if not t or len(t)!=len(c): raise ValueError('empty/misaligned bars')
    result=[(dt(x),Decimal(str(y))) for x,y in zip(t,c)]
    if any(not v.is_finite() or v<=0 for _,v in result): raise ValueError('invalid price')
    if any(a[0]>=b[0] for a,b in zip(result,result[1:])): raise ValueError('unordered/duplicate bars')
    return result

def resolve(current, minutes, daily, fetched_at, current_retrieved_at=None):
    now=dt(fetched_at); observed=min(now,dt(current_retrieved_at)) if current_retrieved_at else now
    if now-observed>timedelta(minutes=5): raise ValueError('stale retrieval')
    cp,mp,dp=map(payload,(current,minutes,daily))
    cb,mb,db=bars(cp,60),bars(mp,60),bars(dp,86400)
    start,end=dt(cp['chart_start']),dt(cp['chart_end'])
    if not start<now<end or not timedelta(hours=18)<=end-start<=timedelta(hours=25):
        raise ValueError('not within an observed active provider session; require independently verified closed-session fallback')
    if any(t<start or t>=end for t,_ in cb): raise ValueError('current chart outside declared session')
    if not any(t==start for t,_ in db): raise ValueError('daily/current session boundary disagreement')
    if any(t>start for t,_ in db): raise ValueError('future daily bar')
    eligible=[(t,v) for t,v in cb if t+timedelta(minutes=1)<=observed]
    if not eligible: raise ValueError('no complete current minute')
    qt,q=eligible[-1]; qe=qt+timedelta(minutes=1)
    if now-qe>timedelta(minutes=5): raise ValueError('stale current minute')
    mirror=dict(mb).get(qt)
    if mirror!=q: raise ValueError('current/multiday completed minute disagreement')
    prior=[(t,v) for t,v in db if t<start]
    if not prior: raise ValueError('no previous daily bar')
    ps,pv=prior[-1]
    session=[(t,v) for t,v in mb if ps<=t<start]
    if len(session)<600 or session[0][0]!=ps:
        raise ValueError('insufficient prior-session minute coverage; expand to ONE_WEEK then investigate short session')
    # No silent sparse-history endpoint masquerading as a completed daily close.
    if any(b[0]-a[0]!=timedelta(minutes=1) for a,b in zip(session,session[1:])):
        raise ValueError('gap inside previous session; investigate rather than guess')
    pt,p= session[-1]; pe=pt+timedelta(minutes=1)
    if not pe<start or p!=pv: raise ValueError('prior daily close not confirmed by terminal minute')
    if not any(t==start for t,_ in mb): raise ValueError('no observed next-session reopening')
    if not timedelta(hours=8)<=pe-ps<=timedelta(hours=25): raise ValueError('invalid completed session length')
    # A long weekend/holiday gap is acceptable only because BOTH bounding sessions
    # are directly present and the current session has fresh completed minutes.
    if start-pe>timedelta(days=5): raise ValueError('unexplained long inter-session gap')
    return {'id':'XAUUSD','status':'verified','baseline':'previous_close',
      'value':str(q),'previous_value':str(pv),'quote_at':qe.isoformat(),
      'previous_at':pe.isoformat(),'fetched_at':now.isoformat(),
      'quote_kind':'bar_close','quote_time_precision':'minute_bar_end',
      'quote_basis':'IBKR London XAUUSD spot midpoint, completed one-minute close',
      'instrument':'London spot gold XAUUSD / 69067924 / SMART / CMDTY',
      'unit':'美元/盎司','source_name':'Interactive Brokers London spot gold',
      'source_url':'https://www.interactivebrokers.co.uk/en/trading/products-metals.php',
      'change_pct':str((q/pv-1)*100),
      'session_proof':{'method':'observed_provider_session_transition_v1',
        'current_start':start.isoformat(),'current_end':end.isoformat(),
        'previous_start':ps.isoformat(),'previous_end':pe.isoformat(),
        'previous_contiguous_minute_count':len(session),'terminal_minute_matches_daily':True,
        'partial_daily_excluded':True,'source_timezone':'UTC ISO offsets from connector; no fixed DST offsets'}}

def main():
    ap=argparse.ArgumentParser();
    for n in ['current','minutes','daily','manifest','fetched-at','output']: ap.add_argument('--'+n,required=True)
    ap.add_argument('--minute-period',choices=['TWO_DAYS','THREE_DAYS','ONE_WEEK','TWO_WEEKS'],default='TWO_DAYS')
    a=ap.parse_args(); paths=[Path(a.current),Path(a.minutes),Path(a.daily)]
    raws=[json.loads(p.read_text()) for p in paths]
    manifest=json.loads(Path(a.manifest).read_text())
    expected=[('ONE_DAY','ONE_MIN'),(a.minute_period,'ONE_MIN'),('ONE_WEEK','ONE_DAY')]
    records=manifest['calls']
    if len(records)!=3: raise ValueError('need three actual call records')
    for p,r,(period,step) in zip(paths,records,expected):
        query={'contract_id':69067924,'exchange':'SMART','security_type':'CMDTY','outside_rth':True,'period':period,'step':step}
        if r['query']!=query or r['sha256']!=sha256(p.read_bytes()).hexdigest():
            raise ValueError('identity/query/evidence hash mismatch')
        if not dt(a.fetched_at)-timedelta(minutes=5)<=dt(r['retrieved_at'])<=dt(a.fetched_at):
            raise ValueError('call not freshly retrieved in current run')
    row=resolve(*raws,a.fetched_at,current_retrieved_at=records[0]['retrieved_at'])
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    # Bundle immutable inputs in one evidence file, same directory for normalize.
    ep=out.with_suffix('.evidence.json')
    ep.write_text(json.dumps({'queries':[
      {'contract_id':69067924,'exchange':'SMART','security_type':'CMDTY','outside_rth':True,'period':p,'step':s}
      for p,s in [('ONE_DAY','ONE_MIN'),(a.minute_period,'ONE_MIN'),('ONE_WEEK','ONE_DAY')]],
      'retrieved_at':a.fetched_at,'actual_call_manifest':manifest,'responses':raws},ensure_ascii=False))
    row.update(evidence_file=ep.name,evidence_sha256=sha256(ep.read_bytes()).hexdigest())
    out.write_text(json.dumps(row,ensure_ascii=False,indent=2));print(json.dumps(row,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
