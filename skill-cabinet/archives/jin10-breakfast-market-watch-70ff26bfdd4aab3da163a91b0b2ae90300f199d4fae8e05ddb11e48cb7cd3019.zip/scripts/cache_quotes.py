#!/usr/bin/env python3
"""Archive strictly verified raw quote rows and their original evidence for bounded fallback."""
import argparse, json, shutil
from pathlib import Path
from hashlib import sha256
import market_module as m

def archive(snapshot, evidence_root, destination_root, prefix):
    source, target = Path(evidence_root).resolve(), Path(destination_root).resolve()
    relative = Path(prefix)
    if relative.is_absolute() or '..' in relative.parts or not relative.parts:
        raise ValueError('Cache prefix must be a safe relative path')
    folder=target/relative
    if folder.exists():
        raise ValueError('Use a new immutable cache prefix')
    # Resolve fresh primaries/alternates only; never re-archive a fallback as newly checked.
    checked=m.normalize({'collected_at':snapshot['collected_at'], 'quotes':snapshot.get('quotes',[]),
                         'alternate_quotes':snapshot.get('alternate_quotes',[])},source)
    rows=[dict(r) for r in checked['quotes'] if r['status']=='verified']
    if not rows:
        raise ValueError('No independently verified current quotes to archive')
    folder.mkdir(parents=True)
    for row in rows:
        for field in ('evidence_file','baseline_evidence_file'):
            if row.get(field):
                src=(source/row[field]).resolve()
                if not src.is_relative_to(source): raise ValueError('Evidence escapes source')
                # Use content-addressed names to avoid source-file basename collisions.
                name=sha256(src.read_bytes()).hexdigest()+src.suffix
                shutil.copyfile(src,folder/name)
                row[field]=(relative/name).as_posix()
    archived={'collected_at':snapshot['collected_at'],'quotes':rows}
    path=folder/'snapshot.json'
    path.write_text(json.dumps(archived,ensure_ascii=False,indent=2)+'\n')
    # Validate against new root before publishing the pointer.
    if m._normalize_current(archived,target)['verified_count'] != len(rows):
        raise ValueError('Archived evidence failed verification')
    return {'file':path.relative_to(target).as_posix(),'sha256':sha256(path.read_bytes()).hexdigest()}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--quotes',required=True);p.add_argument('--evidence-root',required=True)
    p.add_argument('--destination-root',required=True);p.add_argument('--prefix',required=True)
    a=p.parse_args();print(json.dumps(archive(json.loads(Path(a.quotes).read_text()),a.evidence_root,a.destination_root,a.prefix)))
