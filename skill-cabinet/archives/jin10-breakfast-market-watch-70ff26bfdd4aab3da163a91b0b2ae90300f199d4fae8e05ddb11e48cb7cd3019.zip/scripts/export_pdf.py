#!/usr/bin/env python3
"""Optional local PDF export; requires Chrome/Chromium or WeasyPrint."""
import argparse,shutil,subprocess,tempfile,os
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--html',required=True);p.add_argument('--output',required=True);p.add_argument('--engine',choices=['chromium','weasyprint'],default='chromium');p.add_argument('--browser');a=p.parse_args()
 src=Path(a.html).resolve();dest=Path(a.output).resolve()
 if not src.is_file(): p.error('HTML input does not exist')
 if dest.suffix.lower()!='.pdf' or dest==src: p.error('Output must be a separate .pdf file')
 dest.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='jin10-pdf-') as td:
  temp=Path(td)/'result.pdf'
  if a.engine=='weasyprint':
   try: from weasyprint import HTML
   except ImportError: p.error('Optional dependency missing: install WeasyPrint and system libraries, or use Chromium')
   HTML(filename=str(src)).write_pdf(str(temp))
  else:
   browser=a.browser or next((shutil.which(n) for n in ('chromium','chromium-browser','google-chrome','chrome') if shutil.which(n)),None)
   if not browser:p.error('No Chromium/Chrome found; pass --browser PATH or use --engine weasyprint')
   cmd=[browser,'--headless','--disable-gpu','--no-pdf-header-footer','--user-data-dir='+str(Path(td)/'profile'),'--print-to-pdf='+str(temp),src.as_uri()]
   proc=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
   if proc.returncode or not temp.exists(): raise SystemExit('PDF export failed; keep HTML. '+proc.stderr[-1500:])
  if not temp.is_file() or temp.stat().st_size<100 or not temp.read_bytes().startswith(b'%PDF-'):raise SystemExit('No valid PDF generated')
  os.replace(temp,dest)
 print(dest)
if __name__=='__main__':main()
