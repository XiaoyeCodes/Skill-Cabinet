#!/usr/bin/env python3
"""Explicit offline synthetic preview. Never a live newsletter."""
import argparse,json,copy
from pathlib import Path
import jin10_breakfast as j
import market_module as m
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 raw=json.loads((ROOT/'tests/fixtures/market/quotes.json').read_text())
 row=copy.deepcopy(next(x for x in raw['quotes'] if x['id']=='MAGS'))
 row.update(id='SOXX',symbol='SOXX',security_type='STK',contract_id=12658194,exchange='SMART',price_basis='regular_session_market_price');raw['quotes'].append(row)
 record={'date':'2026-10-22','title':'模拟演示：非真实新闻与行情','introduction':'仅用于离线检验版式；数字为测试夹具，不得用于投资或正式日报。','article_html':'<div><h2>今日优选</h2><p><strong>模拟新闻</strong>：展示正文与强调样式。</p><h2>市场盘点</h2><p>此处为合成演示内容。</p></div>','paragraphs':['模拟新闻：展示正文与强调样式。','此处为合成演示内容。'],'bold_spans':['模拟新闻'],'disclaimer':'模拟演示，不构成投资建议。','source_url':'https://xnews.jin10.com/topic/343','publication_beijing':'2026-10-22 00:00:00'}
 html,txt=j.build(record,m.normalize(raw,ROOT/'tests/fixtures/market'),(ROOT/'assets/masthead.png').read_bytes())
 (out/'DEMO-NOT-LIVE.html').write_text(html);(out/'DEMO-NOT-LIVE.txt').write_text(txt)
 print(out/'DEMO-NOT-LIVE.html')
if __name__=='__main__':main()
