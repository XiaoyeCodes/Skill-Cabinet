# 行情输入结构
顶层：`collected_at`（本轮实际 UTC/带时区截止时间）、`quotes`（主源行）、可选 `alternate_quotes`（同 schema 备用行）、`fallback_snapshots`（历史 snapshot 的 `{file, sha256}` 指针）。证据路径均相对 `--evidence-root`，禁止逃逸目录。

每行必需：id、status="verified"、instrument、unit、source_name、source_url（https）、value、previous_value、baseline、quote_kind、fetched_at、evidence_file、evidence_sha256。实际字段约束以 scripts/market_module.py 为准。只有人工/智能体读过原证据且信息一致才填写 verified，脚本不会代替联网采集或理解原始文档。

baseline：COMP/SPX/MAGS/SOXX/SSE/HSI 为 regular_close，BTCUSD 为 rolling_24h，XAUUSD 为 previous_close，BRENT 为 provider_daily_close，US10Y 为 yield_previous_observation。

完整收盘/官方日度：quote_kind=regular_close/official_daily/session_close，asof_date、previous_date、expected_session_date、calendar_verified=true、session_timezone。
当前：quote_kind=live/delayed/bar_close，quote_at、previous_at 或 previous_date；股票还需 market_state=open、calendar_verified、session_timezone。delayed 需 delay_seconds；bar_close 需 quote_time_precision=minute_bar_end、quote_basis。
SOXX：symbol=SOXX、security_type=STK、contract_id=12658194、exchange=SMART、price_basis=regular_session_market_price；官方 Nasdaq/iShares 备用可 exchange=NASDAQ + identity_verified=true，source_url 必须该官方域名。
BRENT：contract_code、contract_expiry、contract_confirmed=true；不硬编码合约月份。
有独立前值文件时加 baseline_evidence_file、baseline_evidence_sha256；可加 provider_change_pct 作交叉检查。

模板结构可参考 tests/fixtures/market/quotes.json，但那是合成测试，不是真实来源，禁止更改时间冒充新行情。黄金使用 gold_quote.py 产出的当次 row 与证据。午休字段与缓存用法见 source-policy.md 和 SKILL.md。
