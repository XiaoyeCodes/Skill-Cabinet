# 数据来源与可用性
每次生成重新获取；标的定义不因备用源改变。工具名称随宿主环境适配，下面合约 ID 是核对线索而非永远有效的保证。

| ID | 标的与主源 | 备用与比较基准 |
|---|---|---|
| COMP | Nasdaq Composite，IBKR IND 18342287 / NASDAQ | Nasdaq 指数官网，当前或常规收盘 / 前一完整常规收盘 |
| SPX | S&P 500 价格指数，IBKR IND 416904 / CBOE | S&P 指数官网；不是 SPY 或期货 |
| MAGS | 美国 Roundhill MAGS，IBKR STK 624756922 / SMART | 发行商/交易所市场价；不是 NAV |
| SOXX | 美国 iShares SOXX，IBKR STK 12658194 / SMART | Nasdaq/iShares 市场价；不是 SOX、NAV 或墨西哥同名品种 |
| BTCUSD | Paxos BTC/USD 现货分钟行情 | Coinbase BTC-USD 同源分钟；精确 24 小时前对应完成分钟，不用自然日涨跌 |
| SSE | 上证综指 000001 | 上交所、CFI、Investing 同指数；不是深圳 000001 股票；对时点与前收交叉核验 |
| HSI | 恒生价格指数，IBKR IND 1328298 / HKFE | 恒生指数公司；不是期货 |
| XAUUSD | 伦敦现货黄金 USD/盎司，IBKR 69067924 / SMART / CMDTY | 有时间的现货同源前收，非 GC 期货、ETF 或拍卖定盘 |
| BRENT | ICE 近月 Brent 期货，运行时解析当前合约 | ICE/可信具体合约行情；分子分母必须同合约，换月不可混接 |
| US10Y | 美国财政部官方最新 10 年 CMT | 官方 HTML/CSV/XML，相邻公布日的 10 Yr 栏，非实时债券或 TNX |

所有报价需原始响应、实际取得时间、报价时间、源 URL、品种/单位、前值与对应日期、hash。hash 只绑定字节，不能自动证明字段提取正确，执行智能体必须核对原证据。公开备用路线不保证每个地区或时段都可访问；不可绕过登录、付费或拒绝。

股票闭市可读 ONE_WEEK/ONE_DAY、outside_rth=false，选最近两个已完整结束的交易日；不足时扩展区间。开市时确认常规时段和延迟，不能拿部分日 K 当完整收盘。每次核交易日历、节假日、夏令时。ETF 拆股/分红时比较同口径价格，无法调和不发布。

沪市 11:30–13:00、港市 12:00–13:00 的已确认交易日午休：quote_kind 与 market_state 为 lunch_break，填写 break_start/break_end、末笔 quote_at、calendar_verified、session_timezone。末笔窗口为午休开始前五分钟至后一分钟；下午重开后不可继续用此分支。

主源失败后尝试独立备用；同源分子分母优先。若全部新源失败，读取真实历史缓存：原证据、原取得和观察时间、原比较基准必须完整。上限为美股/黄金/布油 7 天、SSE 14 天、HSI/US10Y 10 天、BTC 1 天；期限是最大容忍，不代表目标时效。按真实报价时间选择最新可信值，不按重新取回时间排序。界面显示“最近核验 MM-DD HH:MM”，原涨跌不是今天涨跌。十项仍有缺失则 ready=false / exit 20，只生成预览并报告阻碍。

## 黄金专用流程
On EACH run newly fetch contract_id=69067924, exchange=SMART,
security_type=CMDTY, outside_rth=true:
1. period=ONE_DAY, step=ONE_MIN (`current.json`), retaining chart_start/chart_end.
2. period=TWO_DAYS, step=ONE_MIN (`minutes.json`); if full prior session does not
   fit, expand to ONE_WEEK, retaining the actual period in the manifest.
3. period=ONE_WEEK, step=ONE_DAY (`daily.json`).
Run `scripts/gold_quote.py --current current.json --minutes minutes.json --daily daily.json --manifest manifest.json --fetched-at ACTUAL_UTC_RETRIEVAL_CUTOFF --minute-period TWO_DAYS --output gold.json`.
The manifest has `calls` in current/minutes/daily order, each with the EXACT
actual `query` object, actual `retrieved_at` UTC timestamp recorded immediately
after that tool returns, and `sha256` of its saved raw response file. Identity,
query parameters, hash, fresh retrieval and current/multiday selected-minute
agreement are mandatory. Fetch current first, minutes second, daily third.
Determine whether a minute is complete at the CURRENT RESPONSE retrieval time,
NOT the later aggregate cutoff: a request at 09:03:57 must never promote its
unfinished 09:03 bar just because another request finishes after 09:04.
Use the returned row in THIS run's `quotes`, and copy its `.evidence.json` into the
normalizer's evidence directory; preserve the SHA. Never use the historical
research fixtures as inputs. Retrieval cutoff must be captured after the new
calls, not invented from expires. All three calls must be made together in the
same run; do not combine files from previous runs.

Acceptance requires current fresh completed minutes within the explicit source
ONE_DAY session, a matching daily start for the current session, the immediately
preceding daily bar, continuous minute coverage of that preceding session from
its declared start to its final minute, exact terminal-minute/daily-close match,
and observed reopening at the new session start. The partial current daily bar
is excluded. Partial current minute is excluded. Timestamped source boundaries
avoid fixed-hour DST assumptions; observed reopening plus fresh minutes proves
a weekend/holiday is over without guessing that every weekday is open. Greater
than 5-day unexplained gaps, missing minutes, sparse coverage, mismatches,
future/stale values and closed-market conditions fail closed.

For genuinely CLOSED sessions the active-session resolver intentionally fails;
verify the latest complete session and calendar/closure separately before using
a session-close quote. Do not relabel old Friday prices as a fresh Sunday quote.
The active route is not a substitute for a closed-market calendar. If official
holiday/short-session verification is unavailable, retain unavailable rather
than invent a value. Never loosen tests just to produce a row.


## 官方参考
https://home.treasury.gov/resource-center-data-chart-center/interest-rates
https://www.ishares.com/us/products/239705/ishares-phlx-semiconductor-etf
https://www.ice.com/products/219/Brent-Crude-Futures
https://www.roundhillinvestments.com/etf/mags/
