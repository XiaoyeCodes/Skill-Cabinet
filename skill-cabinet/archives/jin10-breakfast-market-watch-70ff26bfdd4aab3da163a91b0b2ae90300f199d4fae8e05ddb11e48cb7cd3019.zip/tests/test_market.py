import unittest,json,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import market_module as m
import jin10_breakfast as j
import jin10_source as s
ROOT=Path(__file__).resolve().parents[1]
class MarketTests(unittest.TestCase):
 def setUp(self):
  self.data=json.loads((ROOT/'tests/fixtures/market/quotes.json').read_text())
  # Synthetic identity fixture only; never a live SOXX quote or newsletter input.
  soxx=copy.deepcopy(next(r for r in self.data['quotes'] if r['id']=='MAGS'))
  soxx.update(id='SOXX', instrument='iShares Semiconductor ETF (synthetic test)', symbol='SOXX', security_type='STK', contract_id=12658194, exchange='SMART', price_basis='regular_session_market_price')
  self.data['quotes'].append(soxx)
 def norm(self): return m.normalize(self.data,ROOT/'tests/fixtures/market')
 def test_all_verified_and_calculations(self):
  out=self.norm(); self.assertEqual(out['verified_count'],10)
  by={r['id']:r for r in out['quotes']}
  self.assertEqual(m.signed(by['COMP']['change_pct']),'+1.05%')
  self.assertEqual(m.signed(by['US10Y']['change_bp'],' bp'),'+1.00 bp')
 def test_no_quotes_is_failure(self):
  self.data['quotes']=[]; self.assertEqual(self.norm()['status'],'market_data_incomplete')
 def test_stale_quote_unavailable(self):
  r=next(r for r in self.data['quotes'] if r['id']=='BTCUSD');r['quote_at']='2026-10-22T02:00:00Z'
  self.assertEqual(self.norm()['verified_count'],9)
 def test_future_quote_unavailable(self):
  r=next(r for r in self.data['quotes'] if r['id']=='BTCUSD');r['quote_at']='2026-10-22T04:00:00Z'
  self.assertEqual(self.norm()['verified_count'],9)
 def test_bad_baseline_not_displayed(self):
  self.data['quotes'][0]['baseline']='rolling_24h';self.assertEqual(self.norm()['verified_count'],9)
 def test_incomplete_session_not_used(self):
  self.data['quotes'][0]['asof_date']='2026-10-22';self.assertEqual(self.norm()['verified_count'],9)
 def test_duplicate_fails(self):
  self.data['quotes'].append(copy.deepcopy(self.data['quotes'][0]));self.assertRaises(ValueError,self.norm)
 def test_nan_missing(self):
  self.data['quotes'][0]['value']='NaN';self.assertEqual(self.norm()['verified_count'],9)
 def test_source_mismatch_missing(self):
  self.data['quotes'][0]['evidence_sha256']='x';self.assertEqual(self.norm()['verified_count'],9)
 def test_pct_disagreement_missing(self):
  self.data['quotes'][0]['provider_change_pct']=99;self.assertEqual(self.norm()['verified_count'],9)
 def test_simple_display_metadata_retained(self):
  verified=self.norm(); out,text=m.render(verified)
  self.assertNotIn('中间价',out);self.assertNotIn('1分钟收盘',out);self.assertNotIn('24小时',out);self.assertNotIn('CMT',out);self.assertNotIn('期货',out)
  self.assertEqual(next(r for r in verified['quotes'] if r['id']=='BTCUSD')['baseline'],'rolling_24h')
 def test_remove_only_target_and_keep_news(self):
  raw=(ROOT/'tests/fixtures/article-2026-10-22.html').read_bytes()
  old=s.parse_article(raw,'https://xnews.jin10.com/details/233030','2026-10-22')
  new=j.remove_table(old)
  self.assertEqual(new['paragraphs'],old['paragraphs']);self.assertEqual(new['bold_spans'],old['bold_spans'])
  out,text=j.build(new,self.norm(),(ROOT/'assets/masthead.png').read_bytes())
  d=s.parse_dom(out);self.assertEqual(len(d.xpath('//img')),1);self.assertFalse(d.xpath('//figure[@id="closing-table"]'))
  self.assertEqual(len(d.xpath('//section[@id="market-watch"]')),1)
  self.assertLess(out.index('id="market-watch"'),out.index('>今日优选</h2>'))
  self.assertEqual(len(d.xpath('//section[@id="market-watch"]//tbody/tr')),10)
 def test_negative_zero_neutral(self): self.assertEqual(m.signed('-.0001'),'0.00%')

 def test_order_and_ready_count(self):
  out=self.norm()
  self.assertEqual(out['status'],'ready')
  self.assertEqual([r['id'] for r in out['quotes']],['COMP','SPX','MAGS','SOXX','BTCUSD','SSE','HSI','XAUUSD','BRENT','US10Y'])
  self.data['quotes']=[r for r in self.data['quotes'] if r['id']!='SOXX']
  out=self.norm();self.assertEqual(out['status'],'market_data_incomplete');self.assertEqual(len(out['quotes']),10)
 def test_soxx_wrong_identity(self):
  for field,bad in [('symbol','SOX'),('security_type','IND'),('contract_id',16513756),('price_basis','NAV')]:
   with self.subTest(field=field):
    row=next(r for r in self.data['quotes'] if r['id']=='SOXX'); old=row[field];row[field]=bad
    self.assertEqual(next(r for r in self.norm()['quotes'] if r['id']=='SOXX')['status'],'unavailable')
    row[field]=old
 def test_soxx_intraday_requires_open(self):
  row=next(r for r in self.data['quotes'] if r['id']=='SOXX')
  row.update(quote_kind='live',quote_at=self.data['collected_at'],previous_date='2026-10-21',market_state='closed')
  self.assertEqual(next(r for r in self.norm()['quotes'] if r['id']=='SOXX')['status'],'unavailable')
 def test_treasury_bp_visible_and_other_pct_unchanged(self):
  row=next(r for r in self.data['quotes'] if r['id']=='US10Y')
  row.pop('provider_change_pct',None)
  for current,prior,expected in [('5.05','4.99','+6.00 bp'),('4.99','5.05','-6.00 bp'),('5.05','5.05','0.00 bp')]:
   row.update(value=current,previous_value=prior)
   out,plain=m.render(self.norm())
   self.assertIn('10年期美债收益率 | '+current+'% | '+expected,plain)
   self.assertIn('纳斯达克综合 | ',plain);self.assertIn('+1.05%',plain)
 def test_treasury_only_official_daily(self):
  next(r for r in self.data['quotes'] if r['id']=='US10Y')['quote_kind']='session_close'
  self.assertEqual(next(r for r in self.norm()['quotes'] if r['id']=='US10Y')['status'],'unavailable')

if __name__=='__main__':unittest.main()
