import unittest,copy,json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import market_module as m
from cache_quotes import archive
ROOT=Path(__file__).resolve().parents[1]
class Availability(unittest.TestCase):
 def setUp(self):
  self.data=json.loads((ROOT/'tests/fixtures/market/quotes.json').read_text())
  soxx=copy.deepcopy(next(r for r in self.data['quotes'] if r['id']=='MAGS'))
  soxx.update(id='SOXX',symbol='SOXX',security_type='STK',contract_id=12658194,exchange='SMART',price_basis='regular_session_market_price')
  self.data['quotes'].append(soxx)
 def lunch(self,key='SSE'):
  row=copy.deepcopy(next(r for r in self.data['quotes'] if r['id']==key))
  start='11:30:00' if key=='SSE' else '12:00:00'
  row.update(quote_kind='lunch_break',market_state='lunch_break',fetched_at='2026-10-22T12:40:00+08:00',quote_at='2026-10-22T'+start+'+08:00',break_start='2026-10-22T'+start+'+08:00',break_end='2026-10-22T13:00:00+08:00',previous_date='2026-10-21',calendar_verified=True,session_timezone='Asia/Shanghai' if key=='SSE' else 'Asia/Hong_Kong')
  return {'collected_at':row['fetched_at'],'quotes':[row]}
 def row(self,data,key): return next(r for r in m.normalize(data,ROOT/'tests/fixtures/market')['quotes'] if r['id']==key)
 def test_sse_lunch_old_but_latest(self): self.assertEqual(self.row(self.lunch(),'SSE')['status'],'verified')
 def test_hsi_lunch(self): self.assertEqual(self.row(self.lunch('HSI'),'HSI')['status'],'verified')
 def test_lunch_after_reopen_rejected(self):
  d=self.lunch();d['collected_at']='2026-10-22T13:01:00+08:00';self.assertEqual(self.row(d,'SSE')['status'],'unavailable')
 def test_lunch_old_morning_quote_rejected(self):
  d=self.lunch();d['quotes'][0]['quote_at']='2026-10-22T11:00:00+08:00';self.assertEqual(self.row(d,'SSE')['status'],'unavailable')
 def test_lunch_wrong_calendar_rejected(self):
  d=self.lunch();d['quotes'][0]['calendar_verified']=False;self.assertEqual(self.row(d,'SSE')['status'],'unavailable')
 def test_lunch_future_quote_rejected(self):
  d=self.lunch();d['quotes'][0]['quote_at']='2026-10-22T12:00:00+08:00';self.assertEqual(self.row(d,'SSE')['status'],'unavailable')
 def test_alternate_all_assets(self):
  d={'collected_at':self.data['collected_at'],'quotes':[],'alternate_quotes':self.data['quotes']}
  out=m.normalize(d,ROOT/'tests/fixtures/market');self.assertTrue(out['complete']);self.assertEqual(out['verified_count'],10)
 def test_partial_is_not_ready(self):
  d=copy.deepcopy(self.data);d['quotes'].pop();self.assertFalse(m.normalize(d,ROOT/'tests/fixtures/market')['complete'])
 def test_verified_cache_all_assets_labelled(self):
  with tempfile.TemporaryDirectory() as td:
   ref=archive(self.data,ROOT/'tests/fixtures/market',td,'cache/one')
   now=m.dt(self.data['collected_at'])+m.timedelta(hours=1)
   d={'collected_at':now.isoformat(),'quotes':[],'fallback_snapshots':[ref]}
   out=m.normalize(d,td);self.assertEqual(out['verified_count'],10);self.assertEqual(out['fallback_count'],10)
   h,t=m.render(out);self.assertEqual(t.count('最近核验'),10)
   self.assertNotIn('暂无可信报价',h)
   for row in out['quotes']: self.assertEqual(row['fallback_original_collected_at'],m.dt(self.data['collected_at']).isoformat())
 def test_cache_corruption_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   ref=archive(self.data,ROOT/'tests/fixtures/market',td,'cache/one');ref['sha256']='bad'
   out=m.normalize({'collected_at':self.data['collected_at'],'quotes':[],'fallback_snapshots':[ref]},td)
   self.assertFalse(out['complete']);self.assertEqual(out['verified_count'],0)
 def test_expired_history_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   ref=archive(self.data,ROOT/'tests/fixtures/market',td,'cache/one')
   d={'collected_at':(m.dt(self.data['collected_at'])+m.timedelta(days=15)).isoformat(),'quotes':[],'fallback_snapshots':[ref]}
   self.assertEqual(m.normalize(d,td)['verified_count'],0)
 def test_fresh_primary_wins(self):
  d=copy.deepcopy(self.data);d['fallback_snapshots']=[{'file':'../escape','sha256':'bad'}]
  out=m.normalize(d,ROOT/'tests/fixtures/market');self.assertEqual(out['verified_count'],10);self.assertEqual(out['fallback_count'],0)
 def test_cached_treasury_still_bp(self):
  with tempfile.TemporaryDirectory() as td:
   ref=archive(self.data,ROOT/'tests/fixtures/market',td,'cache/one')
   out=m.normalize({'collected_at':self.data['collected_at'],'quotes':[],'fallback_snapshots':[ref]},td)
   h,t=m.render(out);self.assertIn('+1.00 bp',t)
 def test_cache_prefers_newer_observation_over_newer_retrieval(self):
  with tempfile.TemporaryDirectory() as td:
   morning=self.lunch(); morning['collected_at']='2026-10-22T12:40:00+08:00'
   ref_morning=archive(morning,ROOT/'tests/fixtures/market',td,'cache/morning')
   daily=copy.deepcopy(self.data); daily['quotes']=[r for r in daily['quotes'] if r['id']=='SSE']
   row=daily['quotes'][0]
   # Synthetic prior-day completed close freshly fetched after morning snapshot.
   row.update(quote_kind='regular_close',asof_date='2026-10-21',expected_session_date='2026-10-21',previous_date='2026-10-20',calendar_verified=True,session_timezone='Asia/Shanghai',fetched_at='2026-10-22T12:45:00+08:00')
   daily['collected_at']=row['fetched_at']
   ref_daily=archive(daily,ROOT/'tests/fixtures/market',td,'cache/daily')
   out=m.normalize({'collected_at':'2026-10-22T12:50:00+08:00','quotes':[],'fallback_snapshots':[ref_daily,ref_morning]},td)
   row=next(r for r in out['quotes'] if r['id']=='SSE')
   self.assertEqual(row['quote_kind'],'lunch_break')
   self.assertIn('11:30',row['display_note'])
 def test_lunch_weekend_rejected(self):
  d=self.lunch()
  d['collected_at']=d['collected_at'].replace('2026-10-22','2026-10-24')
  for key in ('quote_at','fetched_at','break_start','break_end'):
   d['quotes'][0][key]=d['quotes'][0][key].replace('2026-10-22','2026-10-24')
  self.assertEqual(self.row(d,'SSE')['status'],'unavailable')
 def test_fallback_never_advances_retrieval_time(self):
  with tempfile.TemporaryDirectory() as td:
   ref=archive(self.data,ROOT/'tests/fixtures/market',td,'cache/one')
   d={'collected_at':(m.dt(self.data['collected_at'])+m.timedelta(hours=1)).isoformat(),'quotes':[],'fallback_snapshots':[ref]}
   out=m.normalize(d,td)
   old={r['id']:r for r in self.data['quotes']}
   for row in out['quotes']:
    self.assertEqual(row['fetched_at'],old[row['id']]['fetched_at'])
 def test_cli_partial_outputs_preview_and_exit20(self):
  import subprocess
  import jin10_source as source
  import jin10_breakfast as j
  with tempfile.TemporaryDirectory() as td:
   run=Path(td)
   record=j.remove_table(source.parse_article((ROOT/'tests/fixtures/article-2026-10-22.html').read_bytes(),'https://xnews.jin10.com/details/233030','2026-10-22'))
   (run/'news.json').write_text(json.dumps(record,ensure_ascii=False))
   (run/'status.json').write_text(json.dumps({'mode':'historical','news_sha256':source.sha((run/'news.json').read_bytes())}))
   d=copy.deepcopy(self.data);d['quotes']=[d['quotes'][0]]
   now=m.datetime.now(m.timezone.utc).isoformat();d['collected_at']=now;d['quotes'][0]['fetched_at']=now
   (run/'quotes.json').write_text(json.dumps(d))
   proc=subprocess.run([sys.executable,str(ROOT/'scripts/jin10_breakfast.py'),'render','--out',td,'--quotes',str(run/'quotes.json'),'--evidence-root',str(ROOT/'tests/fixtures/market')],capture_output=True,text=True)
   self.assertEqual(proc.returncode,20,proc.stdout+proc.stderr)
   status=json.loads((run/'status.json').read_text())
   self.assertFalse(status['ready']);self.assertEqual(status['status'],'market_data_incomplete')
   self.assertEqual(status['verified_quote_count'],1)
   self.assertTrue((run/'layout-preview-email.html').exists());self.assertFalse((run/'breakfast-email.html').exists())
 def test_soxx_official_alternative_identity(self):
  row=copy.deepcopy(next(r for r in self.data['quotes'] if r['id']=='SOXX'))
  row.update(exchange='NASDAQ',source_url='https://www.nasdaq.com/market-activity/etf/soxx',identity_verified=True)
  row.pop('contract_id')
  d={'collected_at':self.data['collected_at'],'quotes':[row]}
  self.assertEqual(self.row(d,'SOXX')['status'],'verified')
  row['source_url']='https://www.nasdaq.com.evil.example/market-activity/etf/soxx'
  self.assertEqual(self.row(d,'SOXX')['status'],'unavailable')
  row['source_url']='https://www.ishares.com/us/products/239705/ishares-semiconductor-etf'
  row['price_basis']='NAV'
  self.assertEqual(self.row(d,'SOXX')['status'],'unavailable')
 def test_cache_archives_verified_alternate_without_repainting_time(self):
  with tempfile.TemporaryDirectory() as td:
   d={'collected_at':self.data['collected_at'],'quotes':[],'alternate_quotes':self.data['quotes']}
   ref=archive(d,ROOT/'tests/fixtures/market',td,'cache/alt')
   old=json.loads((Path(td)/ref['file']).read_text())
   self.assertEqual(len(old['quotes']),10)
   self.assertEqual(old['collected_at'],self.data['collected_at'])
   self.assertEqual(m._normalize_current(old,td)['verified_count'],10)
if __name__=='__main__':unittest.main()
