import copy,sys,unittest,json,tempfile,subprocess,hashlib
from datetime import datetime,timedelta,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from gold_quote import resolve

def fixture(weekend=False,shift=0):
    start=datetime(2026,10,27,22,tzinfo=timezone.utc)+timedelta(hours=shift)
    ps=start-timedelta(days=3 if weekend else 1)
    pe=ps+timedelta(hours=23)
    now=start+timedelta(hours=2,seconds=30) # 08:00 Beijing after 22Z reopening
    def pack(times,vals,step,s,e):return {'structuredContent':{'source':'MidPoint','chart_step':step,'chart_start':s.isoformat(),'chart_end':e.isoformat(),'time':[t.isoformat() for t in times],'close':vals}}
    pt=[ps+timedelta(minutes=i) for i in range(1380)]
    ct=[start+timedelta(minutes=i) for i in range(121)]
    cur=pack(ct,[4100]*120+[9999],60,start,start+timedelta(hours=23))
    minutes=pack(pt+ct,[4000]*1380+[4100]*121,60,ps,start+timedelta(hours=23))
    day=pack([ps,start],[4000,9999],86400,ps,start+timedelta(days=1))
    return cur,minutes,day,now.isoformat()
class GoldTests(unittest.TestCase):
    def test_0800_and_partial_minute_daily_excluded(self):
        r=resolve(*fixture());self.assertEqual(r['value'],'4100');self.assertEqual(r['previous_value'],'4000');self.assertEqual(r['change_pct'],'2.500')
    def test_retrieval_crosses_minute_boundary(self):
        a=list(fixture());cut=datetime.fromisoformat(a[3]);a[3]=(cut+timedelta(seconds=31)).isoformat()
        r=resolve(*a,current_retrieved_at=cut.isoformat());self.assertEqual(r['value'],'4100')
    def test_quote_disagreement_rejected(self):
        a=list(fixture());a[1]['structuredContent']['close'][-2]=4101
        with self.assertRaisesRegex(ValueError,'disagreement'):resolve(*a)
    def test_weekend_observed_gap(self): self.assertEqual(resolve(*fixture(True))['status'],'verified')
    def test_dst_source_boundary_not_fixed_offset(self): self.assertEqual(resolve(*fixture(shift=1))['status'],'verified')
    def test_future_daily_rejected(self):
        a=list(fixture());p=a[2]['structuredContent'];p['time'].append('2026-10-29T22:00:00Z');p['close'].append(4000)
        with self.assertRaisesRegex(ValueError,'future'):resolve(*a)
    def test_wrong_daily_close_rejected(self):
        a=list(fixture());a[2]['structuredContent']['close'][0]=4001
        with self.assertRaisesRegex(ValueError,'terminal'):resolve(*a)
    def test_stale_rejected(self):
        a=list(fixture());a[3]=(datetime.fromisoformat(a[3])+timedelta(minutes=10)).isoformat()
        with self.assertRaisesRegex(ValueError,'stale'):resolve(*a)
    def test_sparse_history_rejected(self):
        a=list(fixture());p=a[1]['structuredContent'];p['time'].pop(600);p['close'].pop(600)
        with self.assertRaisesRegex(ValueError,'gap'):resolve(*a)
    def test_missing_reopening_rejected(self):
        a=list(fixture());p=a[1]['structuredContent'];p['time'].pop(1380);p['close'].pop(1380)
        with self.assertRaisesRegex(ValueError,'reopening'):resolve(*a)
    def test_closed_market_not_invented(self):
        a=list(fixture());a[3]='2026-10-28T21:30:00+00:00'
        with self.assertRaisesRegex(ValueError,'active'):resolve(*a)
    def test_cli_wrong_identity_and_hash_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);a=fixture();calls=[];args=[]
            for name,raw,(period,step) in zip(['current','minutes','daily'],a[:3],[('ONE_DAY','ONE_MIN'),('TWO_DAYS','ONE_MIN'),('ONE_WEEK','ONE_DAY')]):
                f=root/(name+'.json');f.write_text(json.dumps(raw));args+=['--'+name,str(f)]
                calls.append({'query':{'contract_id':69067924,'exchange':'SMART','security_type':'CMDTY','outside_rth':True,'period':period,'step':step},'retrieved_at':a[3],'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
            m=root/'manifest.json';cmd=[sys.executable,str(Path(__file__).resolve().parents[1]/'scripts/gold_quote.py'),*args,'--manifest',str(m),'--fetched-at',a[3],'--output',str(root/'gold.json')]
            for mutate in ['identity','hash']:
                bad=copy.deepcopy(calls)
                if mutate=='identity':bad[0]['query']['contract_id']=123
                else:bad[1]['sha256']='0'*64
                m.write_text(json.dumps({'calls':bad}));p=subprocess.run(cmd,capture_output=True,text=True)
                self.assertNotEqual(p.returncode,0);self.assertIn('identity/query/evidence hash mismatch',p.stderr)
    def test_wrong_source_rejected(self):
        a=list(fixture());a[0]['structuredContent']['source']='Trades'
        with self.assertRaisesRegex(ValueError,'basis'):resolve(*a)
if __name__=='__main__':unittest.main()
