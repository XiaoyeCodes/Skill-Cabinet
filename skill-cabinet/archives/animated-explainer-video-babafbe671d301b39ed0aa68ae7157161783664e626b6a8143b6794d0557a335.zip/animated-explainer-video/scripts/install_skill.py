"""Install this folder for Codex and/or Claude Code, without config edits."""
import argparse
import hashlib
from pathlib import Path
import shutil
SOURCE=Path(__file__).resolve().parents[1]
NAME='animated-explainer-video'

def install(target,scope,project):
    base=Path.home() if scope=='user' else Path(project).expanduser().resolve()
    destination=base/('.agents' if target=='codex' else '.claude')/'skills'/NAME
    if destination.resolve()==SOURCE.resolve():return destination
    if destination.resolve().is_relative_to(SOURCE.resolve()):
        raise SystemExit('Install destination cannot be inside this skill folder.')
    if destination.exists():raise SystemExit(f'Existing skill preserved: {destination}. Rename this exact folder before reinstalling.')
    shutil.copytree(SOURCE,destination,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for path in SOURCE.rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.pyc':continue
        counterpart=destination/path.relative_to(SOURCE)
        if hashlib.sha256(path.read_bytes()).digest()!=hashlib.sha256(counterpart.read_bytes()).digest():
            raise RuntimeError(f'Install verification failed: {path.relative_to(SOURCE)}')
    return destination

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target',choices=['codex','claude','both'],required=True)
    parser.add_argument('--scope',choices=['user','project'],default='user')
    parser.add_argument('--project-dir')
    args=parser.parse_args()
    if args.scope=='project' and not args.project_dir:parser.error('--project-dir is required for project scope')
    for target in ['codex','claude'] if args.target=='both' else [args.target]:
        print(f'{target}: {install(target,args.scope,args.project_dir)}')
