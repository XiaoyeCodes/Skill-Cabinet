"""Create a project-local venv and install only the declared video dependencies."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',required=True)
    parser.add_argument('--install',action='store_true',help='Create .venv and install requirements.txt')
    args=parser.parse_args();root=Path(args.project).expanduser().resolve()
    if not (root/'story.json').is_file():parser.error('Project needs story.json')
    interpreter=root/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if args.install:
        if not interpreter.is_file():subprocess.run([sys.executable,'-m','venv',str(root/'.venv')],check=True)
        subprocess.run([str(interpreter),'-m','pip','install','-r',str(root/'requirements.txt')],check=True)
    report={'python':str(interpreter if interpreter.is_file() else Path(sys.executable)),
            'ffmpeg':os.environ.get('FFMPEG') or shutil.which('ffmpeg'),
            'ffprobe':os.environ.get('FFPROBE') or shutil.which('ffprobe'),
            'font':str(root/'assets/fonts/NotoSansSC.ttf'),
            'font_exists':(root/'assets/fonts/NotoSansSC.ttf').is_file()}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not report['ffmpeg'] or not report['ffprobe']:
        print('Install FFmpeg including ffprobe with your platform package manager, then rerun.',file=sys.stderr)
        sys.exit(2)
