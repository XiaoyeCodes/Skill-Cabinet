"""Create an independent editable project without machine-specific paths."""
import argparse
import json
import shutil
from pathlib import Path

SKILL=Path(__file__).resolve().parents[1]

def initialize(destination,template):
    destination=Path(destination).expanduser().resolve()
    if destination.is_relative_to(SKILL):
        raise SystemExit('Create generated projects outside the installed skill folder.')
    if destination.exists() and any(destination.iterdir()):
        raise SystemExit(f'Refusing to overwrite nonempty project: {destination}')
    destination.mkdir(parents=True,exist_ok=True)
    for folder in [SKILL/'assets/runtime',SKILL/'assets'/template]:
        for item in folder.iterdir():
            if item.name=='__pycache__':continue
            target=destination/item.name
            if item.is_dir():shutil.copytree(item,target,dirs_exist_ok=True)
            else:shutil.copy2(item,target)
    fonts=destination/'assets/fonts';fonts.mkdir(parents=True,exist_ok=True)
    for item in (SKILL/'assets/fonts').iterdir():shutil.copy2(item,fonts/item.name)
    (destination/'requirements.txt').write_text(
        'moviepy==2.2.1\nPillow==11.3.0\nedge-tts==7.3.1\nnumpy>=1.25,<3\n',encoding='utf-8')
    print(f'Project created: {destination}')
    print('Next: set up dependencies, then run narrate.py, render.py --preview, render.py, verify.py --package.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True)
    parser.add_argument('--template',choices=['potato','starter'],default='starter')
    args=parser.parse_args();initialize(args.output,args.template)
