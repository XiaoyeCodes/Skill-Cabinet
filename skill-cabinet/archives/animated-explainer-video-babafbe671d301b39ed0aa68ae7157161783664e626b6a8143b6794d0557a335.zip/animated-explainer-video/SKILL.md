---
name: animated-explainer-video
description: "Create editable animated explainer and popular-science videos from a topic using MoviePy, Pillow, NumPy, edge-tts and FFmpeg. Produces narrated MP4, Chinese subtitles, cover, storyboard and source project. Use for 趣味科普视频、食物历史、卡通讲解、知识短视频 or reproducing the potato-history workflow. Supports Codex and Claude Code; requires local Python and FFmpeg."
---

# 趣味科普动画视频

把用户给出的主题做成可观看的 MP4，同时交付旁白、字幕与可编辑源码。完整参考作品是《土豆的历史》：约100秒，8幕，1920×1080、30fps、中文合成配音、程序绘制卡通、原创合成音乐。

## 执行方式

用户要求“做视频”时，持续完成调研、编排、实际渲染和交付。需求足够时自行选择合理参数，先告知再制作；不要停在给脚本、列命令或询问能否继续。执行权限以宿主和用户授权为准。素材和结果写入独立项目目录，不修改已安装 Skill。

- 原片复现：用 `potato` 模板，包内配音缓存可离线复用。
- 新主题：用 `starter` 模板，智能体负责改写 `story.json`、核实 `sources.json`，并编写主题对应的 `visuals.py`。默认起步示例是香蕉，不要把示例文字或香蕉插画留在无关主题里。
- 画幅：沿用用户要求；未指定时采用原片的16:9横屏。明确用于抖音等竖屏平台时优先9:16，并按竖屏重新排版。土豆参考插画固定1920×1080，通用模板支持横竖屏。
- 风格：原片为暖米色纸感、深绿文字、橙黄强调、拟人化角色。可依用户要求改变，避免只有文字卡片和静态图片。

## 工作流程

1. **初始化与环境**：读取 [制作方法](references/workflow.md)，执行 `scripts/init_project.py --output <项目目录> --template potato|starter`。用 `scripts/setup_env.py --project <项目目录> --install` 建立项目虚拟环境。依赖包和开源项目见 [技术与许可](references/projects-and-licenses.md)。FFmpeg及ffprobe须可执行，中文字体已随包提供。
2. **选题与史实**：用宿主提供的搜索能力核实关键事实，优先原始机构、博物馆、论文或专业科普；保存每个关键主张的来源。没有浏览能力时使用用户给出的来源或包内已核实案例，不伪造引用。
3. **分镜与画面**：按 [项目结构与接口](references/project-contract.md) 编写 `story.json` 和 `visuals.py`。每幕有问题、动作或解释；一条字幕对应一段短旁白。新主题必须替换角色、场景和图解，不能只改标题。困难事实用图示讲清，不把传说当史实。
4. **配音与时间线**：运行项目中的 `narrate.py`。文字、音色、语速或音高改变会自动使对应缓存失效。时间线由每段真实音频长度生成，不按字数估时后直接渲染。支持相对路径的自有配音；网络不可用时用缓存或已提供音频，不以静音冒充成功。
5. **预览并修正**：运行 `render.py --preview`，用宿主图像查看能力检查 `output/storyboard.jpg`。检查中文缺字、字幕完整、标题安全边距、角色被裁切、画幅适配、信息与旁白是否一致。预览发现问题就修正再生成。
6. **成片与检查**：运行 `render.py`，再运行 `verify.py --package`。后者检查尺寸、fps、编码、音画时长、字幕覆盖、完整解码及响度，并抽取实际编码后的画面。查看 `output/encoded_contact_sheet.jpg`；如修改过内容，重跑受影响步骤。
7. **交付**：给出 MP4、封面、SRT、源码ZIP和必要的使用说明。说明实际使用的工具、片长、画幅及验证结果；不要声称运行过没有运行的环境或工具。不自动上传、发布或联系他人。

## 路径与命令

所有 `scripts/`、`references/`、`assets/` 路径相对本文件所在目录。使用宿主给出的 Skill 实际路径，给带空格或中文的路径正确加引号。项目脚本从其所在目录解析素材，不依赖当前工作目录。

```text
python <skill-dir>/scripts/init_project.py --output <project-dir> --template starter
python <skill-dir>/scripts/setup_env.py --project <project-dir> --install
<project-python> <project-dir>/narrate.py
<project-python> <project-dir>/render.py --preview
<project-python> <project-dir>/render.py
<project-python> <project-dir>/verify.py --package
```

`<project-python>` 是 Windows 的 `.venv/Scripts/python.exe` 或 macOS/Linux 的 `.venv/bin/python`。土豆复现可把配音一步改为 `narrate.py --offline`。

## 迁移与故障

- 给其他 Codex / Claude Code 的安装方式和示例指令：[安装与使用](references/install-and-use.md)。Skill采用标准`SKILL.md`，不依赖原对话、MCP服务或特定模型。
- TTS是Microsoft的在线语音服务，经开源`edge-tts`客户端调用；它不是离线模型。仅待合成文字会送到该服务，三次失败后明确报告并保留可用产物。
- MoviePy已预编码音频时会使用流复制，因此`loudnorm`在独立的FFmpeg混流步骤中应用，视频流直接复制。不要把音频滤镜与`-c:a copy`放在同一步。
- 自动检查不能替代看图检查。竖屏模板不等于所有画幅已在所有操作系统测试。
