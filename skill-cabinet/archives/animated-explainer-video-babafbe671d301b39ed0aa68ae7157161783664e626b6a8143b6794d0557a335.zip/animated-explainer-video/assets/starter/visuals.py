"""Responsive starter. Replace subject art and composition for the user's topic."""
import math
from functools import lru_cache
import numpy as np
from PIL import Image,ImageDraw
from common import load_timeline,font

TL=load_timeline();SCENES=TL['scenes'];W=TL['render']['width'];H=TL['render']['height']
PORTRAIT=H>W;M=round(W*.07);INK='#263F36';PAPER='#F6EEDD';ACCENT='#CF603D';GOLD='#F0C45B'

def text(im,xy,value,size,fill=INK,bold=False,anchor='lt'):
    ImageDraw.Draw(im).text(xy,value,font=font(round(size),bold),fill=fill,anchor=anchor)

def rounded(im,box,fill,radius=28):
    ImageDraw.Draw(im).rounded_rectangle(tuple(round(x) for x in box),radius=radius,fill=fill)

def wrap(value,size,width):
    rows=[];row='';f=font(round(size),True)
    for ch in value:
        if row and f.getlength(row+ch)>width:rows.append(row);row=ch
        else:row+=ch
    if row:rows.append(row)
    return rows

@lru_cache(maxsize=1)
def subject():
    # Replace this drawing when producing an unrelated subject.
    im=Image.new('RGBA',(640,480));d=ImageDraw.Draw(im)
    d.arc((86,20,550,422),10,170,fill=INK,width=100)
    d.arc((86,20,550,422),10,170,fill=GOLD,width=82)
    d.line((120,287,73,270,61,235),fill=INK,width=10)
    d.line((516,280,565,258,578,222),fill=INK,width=10)
    d.line((264,402,250,452,218,452),fill=INK,width=10)
    d.line((382,403,397,452,426,452),fill=INK,width=10)
    d.ellipse((271,347,285,371),fill=INK);d.ellipse((351,347,365,371),fill=INK)
    d.arc((299,363,340,397),0,180,fill=INK,width=6)
    d.ellipse((240,372,275,387),fill='#DA9C72');d.ellipse((363,372,398,387),fill='#DA9C72')
    return im

def character(im,x,y,size,angle=0):
    asset=subject();scale=size/640
    asset=asset.resize((round(asset.width*scale),round(asset.height*scale)),Image.Resampling.BICUBIC)
    if angle:asset=asset.rotate(angle,Image.Resampling.BICUBIC,expand=True)
    im.paste(asset,(round(x-asset.width/2),round(y-asset.height/2)),asset)

def draw(t,with_subtitles=True):
    scene=next((s for s in SCENES if t<s['end']),SCENES[-1]);local=t-scene['start']
    im=Image.new('RGB',(W,H),PAPER);d=ImageDraw.Draw(im)
    d.rounded_rectangle((M,H*.035,W-M,H*.08),radius=18,fill=INK)
    text(im,(M+22,H*.046),TL.get('subtitle',TL['title']),min(W*.025,H*.023),'#FFF8EA',True)
    size=W*(.065 if PORTRAIT else .045)
    titles=wrap(scene['title'],size,W-2*M)
    for j,row in enumerate(titles):text(im,(M,H*.12+j*size*1.3),row,size,INK,True)
    tag_y=H*.12+len(titles)*size*1.3+H*.015
    tag_size=W*.027
    for j,row in enumerate(wrap(scene.get('tag',''),tag_size,W-2*M)):
        text(im,(M,tag_y+j*tag_size*1.3),row,tag_size,ACCENT,True)
    top=max(H*.31,tag_y+tag_size*2.5);bottom=H*.76;cy=(top+bottom)/2
    rounded(im,(M,top,W-M,bottom),'#E2DCC9')
    visual=scene.get('visual',{});kind=visual.get('type','banana');labels=visual.get('labels',[])
    bob=math.sin(local*2.5)*W*.009
    if kind=='comparison':
        for j,label in enumerate(labels[:2]):
            x=W*(.30 if j==0 else .70)
            character(im,x,cy+bob,min(W*.29,(bottom-top)*.70),math.sin(local*2+j)*4)
            text(im,(x,bottom-H*.055),label,min(W*.035,H*.038),INK,True,'mt')
        text(im,(W*.50,cy),'+',W*.07,ACCENT,True,'mm')
    elif kind=='journey':
        count=max(1,len(labels));step=(W-2*M)/count
        for j,label in enumerate(labels):
            x=M+step*(j+.5)
            character(im,x,cy+bob,min(W*.22,(bottom-top)*.64),math.sin(local*2+j)*4)
            label_size=min(W*.028,H*.032)
            for k,row in enumerate(wrap(label,label_size,step*.92)):
                text(im,(x,bottom-H*.07+k*label_size*1.3),row,label_size,INK,True,'mt')
            if j<count-1:text(im,(x+step/2,cy),'→',W*.045,ACCENT,True,'mm')
    else:
        character(im,W/2,cy+bob,min(W*.75,(bottom-top)*1.1),math.sin(local*1.8)*4)
    if with_subtitles:
        active=next((line for line in scene['lines'] if line['start']<=t<line['end']),None)
        if active:
            caption_size=W*(.037 if PORTRAIT else .022)
            rows=wrap(active['text'],caption_size,W-2*M-48)
            if len(rows)>3:raise ValueError('Narration too long for one caption; split it into shorter story lines.')
            box_h=max(H*.065,len(rows)*caption_size*1.45+28)
            y=H*.82
            rounded(im,(M,y,W-M,y+box_h),INK)
            for j,row in enumerate(rows):text(im,(W/2,y+14+j*caption_size*1.45),row,caption_size,'#FFF8EA',True,'mt')
    text(im,(M,H*.95),scene.get('label',''),min(W*.022,H*.025),INK)
    d.line((M,H*.985,W-M,H*.985),fill='#C9C4B5',width=4)
    d.line((M,H*.985,M+(W-2*M)*t/TL['duration'],H*.985),fill=ACCENT,width=5)
    return im

def render_frame(t):return np.asarray(draw(t))
def make_cover():return draw(min(1.5,TL['duration']/2),with_subtitles=False)
