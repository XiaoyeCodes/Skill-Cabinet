"""Render the project's editable visuals.py using MoviePy and FFmpeg."""
import argparse
import math
import os
import wave
from common import ROOT, load_timeline, stem, tool, run, font
os.environ['IMAGEIO_FFMPEG_EXE']=tool('ffmpeg')
import numpy as np
from PIL import Image, ImageDraw
from moviepy import VideoClip, AudioFileClip, CompositeAudioClip

TL=load_timeline(); SCENES=TL['scenes']; DURATION=TL['duration']; OUT=ROOT/'output'
OUT.mkdir(exist_ok=True)
import visuals

def frame(t):
    value=visuals.render_frame(min(t,DURATION-1e-6))
    if isinstance(value,Image.Image): value=np.asarray(value.convert('RGB'))
    expected=(TL['render']['height'],TL['render']['width'],3)
    if value.shape!=expected or value.dtype!=np.uint8:
        raise ValueError(f'visuals.render_frame must return uint8 RGB {expected}; got {value.shape} / {value.dtype}')
    return value

def preview():
    rows=math.ceil(len(SCENES)/2)
    tw,th=(360,640) if TL['render']['height']>TL['render']['width'] else (640,360)
    sheet=Image.new('RGB',(tw*2,rows*(th+45)),'#F6EEDD')
    for i,s in enumerate(SCENES):
        t=s['start']+min(3.4,s['duration']*.45)
        im=Image.fromarray(frame(t))
        im.save(OUT/f'scene_{i+1:02d}.jpg',quality=92)
        x=i%2*tw;y=i//2*(th+45)
        small=im.copy();small.thumbnail((tw,th),Image.Resampling.LANCZOS)
        sheet.paste(small,(x+(tw-small.width)//2,y+(th-small.height)//2))
        label=f'{i+1:02d}  {t:.1f}s  {s["title"]}'
        while font(17,True).getlength(label)>tw-24:label=label[:-2]+'…'
        ImageDraw.Draw(sheet).text((x+12,y+th+8),label,font=font(17,True),fill='#263F36')
        # Catch render errors at entrances, later narration and scene boundaries.
        for p in [.01,.50,.90,.99]: frame(s['start']+s['duration']*p)
    sheet.save(OUT/'storyboard.jpg',quality=94)
    cover=visuals.make_cover() if hasattr(visuals,'make_cover') else Image.fromarray(frame(min(2.,DURATION/2)))
    if not isinstance(cover,Image.Image): cover=Image.fromarray(cover)
    cover.convert('RGB').save(OUT/f'{stem(TL)}_cover.jpg',quality=95)
    print('Preview: output/storyboard.jpg',flush=True)

def music():
    sr=44100;n=math.ceil(DURATION*sr);mono=np.zeros(n,dtype=np.float32)
    def put(start,dur,freq,amp,pad=False):
        offset=round(start*sr);length=min(round(dur*sr),n-offset)
        if length<=0:return
        t=np.arange(length,dtype=np.float32)/sr
        env=np.minimum(1,t/(.14 if pad else .008))
        env*=np.minimum(1,np.maximum(0,dur-t)/.25) if pad else np.exp(-t*5)
        sound=np.sin(math.tau*freq*t)+.25*np.sin(math.tau*2*freq*t)
        mono[offset:offset+length]+=sound*env*amp
    beat=60/96;melody=[523.25,659.25,783.99,659.25,587.33,523.25,440,392]
    chords=[[130.81,164.81,196],[110,130.81,164.81],[87.31,110,130.81],[98,123.47,146.83]]
    for j,start in enumerate(np.arange(0,DURATION,beat)):
        scene=next(s for s in SCENES if start<s['end'])
        if scene.get('serious'):
            if j%8==0:
                for f in [110,130.81,164.81]:put(start,3.5,f,.004,True)
        else:
            chord=chords[j//8%4]
            put(start,.6,melody[j%8],.016)
            if j%2==0:put(start,1.,chord[0],.016)
            if j%4==0:
                for f in chord:put(start,2.,f,.006,True)
    for scene in SCENES:
        if not scene.get('serious'):
            for k,f in enumerate([660,880,1100]):put(scene['start']+.15+k*.06,.35,f,.025)
    t=np.arange(n)/sr;mono*=np.minimum(1,t/1.5)*np.minimum(1,(DURATION-t)/2)
    pcm=np.column_stack([mono,mono*.95])
    path=OUT/'original_music.wav'
    with wave.open(str(path),'wb') as wf:
        wf.setnchannels(2);wf.setsampwidth(2);wf.setframerate(sr)
        wf.writeframes((np.clip(pcm,-1,1)*32767).astype('<i2').tobytes())
    return path

def render():
    preview();clips=[];audio=None;video=None
    try:
        clips.append(AudioFileClip(str(music())))
        for scene in SCENES:
            for line in scene['lines']:
                clips.append(AudioFileClip(str(ROOT/line['path'])).with_start(line['start']))
        audio=CompositeAudioClip(clips).with_duration(DURATION)
        video=VideoClip(frame_function=frame,duration=DURATION).with_audio(audio)
        intermediate=OUT/'render_intermediate.mp4';output=OUT/f'{stem(TL)}.mp4'
        video.write_videofile(str(intermediate),fps=TL['render']['fps'],codec='libx264',audio_codec='aac',
            audio_bitrate='192k',preset='fast',threads=TL['render'].get('threads',4),pixel_format='yuv420p',
            ffmpeg_params=['-crf','19','-movflags','+faststart'],temp_audiofile=str(OUT/'temp_audio.m4a'))
        # MoviePy stream-copies the audio it pre-encoded. Apply loudnorm in a
        # second mux pass with H.264 copied, avoiding a second picture encode.
        run([tool('ffmpeg'),'-y','-hide_banner','-loglevel','warning','-i',intermediate,
             '-c:v','copy','-c:a','aac','-b:a','192k','-af','loudnorm=I=-16:TP=-1.5:LRA=9',
             '-ar','48000','-movflags','+faststart',output])
        intermediate.unlink()
        print(f'Video: {output}',flush=True)
    finally:
        if video: video.close()
        if audio: audio.close()
        for clip in clips:clip.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preview',action='store_true')
    args=parser.parse_args()
    preview() if args.preview else render()
