"""Decode and measure final output; create an encoded-frame inspection sheet."""
import argparse
import math
import re
import json
import zipfile
from common import ROOT, load_timeline, probe, run, tool, font, stem, save_json
from PIL import Image, ImageDraw

def verify(package=False):
    tl=load_timeline();out=ROOT/'output';video=out/f'{stem(tl)}.mp4'
    data=probe(video)
    v=next(s for s in data['streams'] if s['codec_type']=='video')
    a=next(s for s in data['streams'] if s['codec_type']=='audio')
    def require(test,message):
        if not test:raise RuntimeError(message)
    require((v['width'],v['height'])==(tl['render']['width'],tl['render']['height']),'Unexpected frame dimensions')
    num,den=map(int,v['r_frame_rate'].split('/'))
    require(abs(num/den-tl['render']['fps'])<.01,'Unexpected FPS')
    require(v['codec_name']=='h264' and a['codec_name']=='aac','Expected H.264 and AAC')
    require(v['pix_fmt']=='yuv420p','Expected yuv420p')
    tolerance=max(.15,2/tl['render']['fps'])
    require(abs(float(data['format']['duration'])-tl['duration'])<tolerance,'Duration mismatch')
    delta=abs(float(v['duration'])-float(a['duration']))
    require(delta<tolerance,'Audio/video durations disagree')
    decoded=run([tool('ffmpeg'),'-hide_banner','-v','error','-i',video,'-f','null','-'],capture_output=True)
    require(not decoded.stderr.strip(),decoded.stderr.decode(errors='replace'))
    measured=run([tool('ffmpeg'),'-hide_banner','-nostats','-i',video,'-vn','-af',
                   'loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'],capture_output=True)
    blocks=re.findall(r'\{\s*"input_i".*?\}',measured.stderr.decode(errors='replace'),re.S)
    require(bool(blocks),'No loudness measurement returned')
    levels=json.loads(blocks[-1]);lufs=float(levels['input_i']);peak=float(levels['input_tp'])
    require(-18<lufs<-14,f'Unexpected loudness: {lufs}')
    require(peak<-.5,f'True peak too high: {peak}')
    previous=0
    for scene in tl['scenes']:
        require(abs(scene['start']-previous)<.001,'Non-contiguous scenes')
        for line in scene['lines']:
            require(scene['start']<=line['start']<line['end']<=scene['end'],'Subtitle outside scene')
        previous=scene['end']
    count=sum(len(s['lines']) for s in tl['scenes'])
    srt=(out/f'{stem(tl)}.srt').read_text(encoding='utf-8-sig')
    require(srt.count(' --> ')==count,'Missing subtitle segments')
    tw,th=(360,640) if tl['render']['height']>tl['render']['width'] else (640,360)
    sheet=Image.new('RGB',(tw*2,math.ceil(len(tl['scenes'])/2)*(th+45)),'#F6EEDD')
    for i,scene in enumerate(tl['scenes']):
        t=scene['start']+min(3.4,scene['duration']*.45)
        path=out/f'encoded_{i+1:02d}.jpg'
        run([tool('ffmpeg'),'-y','-hide_banner','-loglevel','error','-ss',str(t),'-i',video,
             '-frames:v','1','-q:v','2',path],capture_output=True)
        image=Image.open(path).convert('RGB')
        image.thumbnail((tw,th),Image.Resampling.LANCZOS)
        x=i%2*tw;y=i//2*(th+45)
        sheet.paste(image,(x+(tw-image.width)//2,y+(th-image.height)//2))
        label=f'{i+1:02d}  {t:.1f}s  {scene["title"]}'
        while font(17,True).getlength(label)>tw-24:label=label[:-2]+'…'
        ImageDraw.Draw(sheet).text((x+12,y+th+8),label,font=font(17,True),fill='#263F36')
    sheet.save(out/'encoded_contact_sheet.jpg',quality=94)
    result={'status':'passed','full_decode':'passed','duration_seconds':float(data['format']['duration']),
            'width':v['width'],'height':v['height'],'fps':num/den,'video_codec':v['codec_name'],
            'audio_codec':a['codec_name'],'audio_channels':a['channels'],
            'scene_count':len(tl['scenes']),'subtitle_segments':count,'loudness_lufs':lufs,
            'true_peak_dbfs':peak,'audio_video_duration_delta':delta,'file_size_bytes':video.stat().st_size,
            'visual_review':'Pending agent inspection of storyboard.jpg and encoded_contact_sheet.jpg'}
    save_json(out/'validation.json',result)
    if package:
        destination=out/f'{stem(tl)}_editable_project.zip'
        files=[p for p in ROOT.glob('*.py')]+[p for p in ROOT.glob('*.json')]+[ROOT/'requirements.txt']
        files+=list((ROOT/'assets').rglob('*'))
        files += [p for p in out.iterdir() if p.suffix.lower() in {'.mp4','.srt','.jpg','.json'}]
        with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
            for path in files:
                if path.is_file():z.write(path,path.relative_to(ROOT))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package',action='store_true',help='Include editable project, cached voice and MP4 in ZIP')
    verify(parser.parse_args().package)
