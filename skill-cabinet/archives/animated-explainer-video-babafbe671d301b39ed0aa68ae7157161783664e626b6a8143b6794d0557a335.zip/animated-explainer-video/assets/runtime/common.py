"""Portable project paths, tools, fonts, story validation and narration identity."""
from pathlib import Path
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
from functools import lru_cache

ROOT = Path(__file__).resolve().parent
if (ROOT / '.vendor').is_dir():
    sys.path.insert(0, str(ROOT / '.vendor'))

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def tool(name):
    value = os.environ.get(name.upper()) or shutil.which(name)
    if not value:
        raise RuntimeError(f'{name} is missing. Install FFmpeg with ffprobe or set {name.upper()} to its executable path.')
    return value

def run(args, **kwargs):
    return subprocess.run([str(a) for a in args], check=True, **kwargs)

def project_path(value):
    path = (ROOT / value).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError(f'Asset must stay inside the project: {value}')
    return path

def stem(story):
    value = story.get('output_name', story['title'])
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', value).strip(' .')[:100]
    if not value or value in {'.', '..'}:
        raise ValueError('Invalid output_name')
    if value.upper().split('.')[0] in {'CON','PRN','AUX','NUL',*[f'COM{x}' for x in range(1,10)],*[f'LPT{x}' for x in range(1,10)]}:
        value = '_' + value
    return value

def load_story():
    s = read_json(ROOT / 'story.json')
    if not isinstance(s.get('title'), str) or not s['title'].strip():
        raise ValueError('story.title must be nonempty')
    if not isinstance(s.get('scenes'), list) or not s['scenes']:
        raise ValueError('story.scenes must be a nonempty list')
    ids = set()
    for scene in s['scenes']:
        if scene.get('id') in ids or not isinstance(scene.get('id'), str):
            raise ValueError('Each scene needs a unique string id')
        ids.add(scene['id'])
        if not scene.get('lines'):
            raise ValueError('Each scene needs narration lines')
        for line in scene['lines']:
            if not isinstance(line, (str, dict)) or not line_text(line).strip():
                raise ValueError('A line is nonempty text or {text, audio}')
            if isinstance(line, dict) and line.get('audio'):
                project_path(line['audio'])
    render = s.setdefault('render', {})
    for key, default in [('width',1920),('height',1080),('fps',30)]:
        val = render.setdefault(key, default)
        if not isinstance(val,int) or val<=0:
            raise ValueError(f'render.{key} must be a positive integer')
    if render['width']%2 or render['height']%2:
        raise ValueError('H.264 yuv420p requires even width and height')
    for key in ('lead_in','line_gap','tail'):
        if key in s and (not isinstance(s[key],(int,float)) or not math.isfinite(s[key]) or s[key]<0):
            raise ValueError(f'{key} must be finite and nonnegative')
    stem(s)
    return s

def line_text(line):
    return line if isinstance(line,str) else line.get('text','')

def narration_key(story, text):
    value = [text, story.get('voice','zh-CN-YunxiNeural'), story.get('rate','+10%'), story.get('pitch','+0Hz')]
    return hashlib.sha256(json.dumps(value,ensure_ascii=False).encode('utf-8')).hexdigest()[:24]

def story_digest(story):
    return hashlib.sha256(json.dumps(story,sort_keys=True,ensure_ascii=False).encode('utf-8')).hexdigest()

def load_timeline():
    story = load_story()
    timeline = read_json(ROOT/'timeline.json')
    if timeline.get('story_digest') != story_digest(story):
        raise RuntimeError('story.json changed. Run python narrate.py to rebuild the timeline first.')
    return timeline

def probe(path):
    result = run([tool('ffprobe'),'-v','error','-show_format','-show_streams','-of','json',path],capture_output=True)
    return json.loads(result.stdout)

def duration(path):
    value = float(probe(path)['format']['duration'])
    if not math.isfinite(value) or value<=0:
        raise ValueError(f'Invalid audio duration: {path}')
    return value

def font_path(bold=False):
    story=load_story()
    configured=os.environ.get('EXPLAINER_FONT_BOLD' if bold else 'EXPLAINER_FONT')
    configured=configured or story.get('font_bold' if bold else 'font')
    candidates=[]
    if configured:
        candidate=Path(configured).expanduser()
        candidates.append(candidate if candidate.is_absolute() else ROOT/candidate)
    candidates += [ROOT/'assets/fonts/NotoSansSC.ttf',
                   Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'/('msyhbd.ttc' if bold else 'msyh.ttc'),
                   Path('/System/Library/Fonts/PingFang.ttc'),
                   Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')]
    for candidate in candidates:
        if candidate.is_file(): return candidate
    raise RuntimeError('Chinese font not found. Restore assets/fonts/NotoSansSC.ttf or set EXPLAINER_FONT.')

@lru_cache(maxsize=128)
def font(size,bold=False):
    from PIL import ImageFont
    result=ImageFont.truetype(str(font_path(bold)),int(size))
    try:
        names=result.get_variation_names()
        desired=b'Bold' if bold else b'Regular'
        if desired in names: result.set_variation_by_name(desired)
    except (OSError,AttributeError):
        pass
    return result
