"""Hash-cached TTS / supplied audio -> measured timeline + SRT."""
import argparse
import asyncio
import os
import tempfile
from pathlib import Path
from common import ROOT, load_story, line_text, narration_key, story_digest, project_path, duration, save_json, stem

async def build(offline=False,refresh=False):
    story=load_story(); out=ROOT/'output'; out.mkdir(exist_ok=True)
    cache=ROOT/'assets/voice'; cache.mkdir(parents=True,exist_ok=True)
    semaphore=asyncio.Semaphore(3)
    results={}
    # Deduplicate identical narration, avoiding concurrent writes to one cache file.
    jobs={}
    for scene in story['scenes']:
        for entry in scene['lines']:
            text=line_text(entry)
            if isinstance(entry,dict) and entry.get('audio'):
                path=project_path(entry['audio'])
                if not path.is_file(): raise FileNotFoundError(path)
                results[(text,entry['audio'])]=path
            else:
                jobs[narration_key(story,text)]=text

    async def speak(key,text):
        path=cache/f'{key}.mp3'
        async with semaphore:
            valid=False
            if path.is_file() and not refresh:
                try: valid=path.stat().st_size>1024 and duration(path)>0
                except Exception: valid=False
            if not valid:
                if offline: raise RuntimeError(f'No valid cached voice for: {text}. Supply audio or run without --offline.')
                import edge_tts
                for attempt in range(3):
                    temp=path.with_suffix('.partial.mp3')
                    try:
                        await edge_tts.Communicate(text,story.get('voice','zh-CN-YunxiNeural'),
                            rate=story.get('rate','+10%'),pitch=story.get('pitch','+0Hz')).save(str(temp))
                        if temp.stat().st_size<1024: raise ValueError('TTS returned an empty file')
                        duration(temp)
                        temp.replace(path)
                        break
                    except Exception:
                        temp.unlink(missing_ok=True)
                        if attempt==2: raise
                        await asyncio.sleep(attempt+1)
            results[key]=path
            print(f'Voice ready: {key} ({duration(path):.2f}s)',flush=True)
    await asyncio.gather(*(speak(key,text) for key,text in jobs.items()))

    cursor=0.; scenes=[]; subtitles=[]
    for source in story['scenes']:
        start=cursor; cursor+=story.get('lead_in',.45); lines=[]
        for entry in source['lines']:
            text=line_text(entry)
            key=(text,entry['audio']) if isinstance(entry,dict) and entry.get('audio') else narration_key(story,text)
            path=results[key]; dur=duration(path)
            line={'text':text,'path':path.relative_to(ROOT).as_posix(),'start':cursor,'end':cursor+dur,'duration':dur}
            lines.append(line); subtitles.append(line)
            cursor+=dur+story.get('line_gap',.12)
        cursor+=story.get('tail',.60)
        scenes.append(dict(source,start=start,end=cursor,duration=cursor-start,lines=lines))
    timeline=dict(story,scenes=scenes,duration=cursor,story_digest=story_digest(story))
    save_json(ROOT/'timeline.json',timeline)
    def stamp(t):
        ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
        return f'{h:02}:{m:02}:{s:02},{ms:03}'
    srt='\n\n'.join(f'{i+1}\n{stamp(x["start"])} --> {stamp(x["end"])}\n{x["text"]}' for i,x in enumerate(subtitles))+'\n'
    (out/f'{stem(story)}.srt').write_text(srt,encoding='utf-8-sig')
    print(f'Timeline: {len(scenes)} scenes, {cursor:.2f}s',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--offline',action='store_true',help='Use only cached / supplied narration')
    parser.add_argument('--refresh',action='store_true',help='Regenerate synthesized voice even if cached')
    args=parser.parse_args()
    if args.offline and args.refresh: parser.error('--offline and --refresh cannot be combined')
    asyncio.run(build(args.offline,args.refresh))
