from pathlib import Path
import math
import random
from functools import lru_cache
from common import ROOT, load_timeline, font
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W,H=1920,1080
TL=load_timeline(); SCENES=TL['scenes']; DURATION=TL['duration']
INK='#263F36'; CREAM='#F6EEDD'; ORANGE='#D15E38'; YELLOW='#F1C75B'
GREEN='#628775'; BLUE='#6C9CA8'; BROWN='#A96C39'; WHITE='#FFF9EE'
if (TL['render']['width'],TL['render']['height']) != (W,H):
    raise ValueError('The potato art uses a 1920x1080 composition. Use starter for a responsive layout or redesign visuals.py.')

def text(im,xy,s,size=40,fill=INK,bold=False,anchor='lt'):
    ImageDraw.Draw(im).text(xy,s,font=font(size,bold),fill=fill,anchor=anchor)

def rr(im,box,fill,rad=24,outline=None,width=3):
    ImageDraw.Draw(im).rounded_rectangle(tuple(round(v) for v in box),radius=rad,fill=fill,outline=outline,width=width)

def pill(im,x,y,s,fill=INK,fg=CREAM,size=26):
    f=font(size,True); width=f.getlength(s)+48
    rr(im,(x,y,x+width,y+size+26),fill,24)
    text(im,(x+24,y+10),s,size,fg,True)
    return width

def line(im,points,fill=INK,width=5):
    ImageDraw.Draw(im).line(points,fill=fill,width=width,joint='curve')

def ease(x):
    x=max(0,min(1,x)); return 1-(1-x)**3

def paste(im,asset,x,y,angle=0,scale=1):
    if scale!=1:
        asset=asset.resize((max(1,round(asset.width*scale)),max(1,round(asset.height*scale))),Image.Resampling.BICUBIC)
    if angle:
        asset=asset.rotate(angle,Image.Resampling.BICUBIC,expand=True)
    im.paste(asset,(round(x-asset.width/2),round(y-asset.height/2)),asset)

@lru_cache(maxsize=1)
def paper():
    rng=np.random.default_rng(58)
    base=np.zeros((H,W,3),dtype=np.int16)+np.array([246,238,221],dtype=np.int16)
    noise=rng.integers(-3,4,(H,W,1),dtype=np.int16)
    im=Image.fromarray(np.clip(base+noise,0,255).astype(np.uint8))
    d=ImageDraw.Draw(im)
    for x in range(40,W,54):
        for y in range(40,H,54):
            d.ellipse((x,y,x+2,y+2),fill='#DCD5C5')
    return im

def star(im,x,y,r=15,color=ORANGE,angle=0):
    pts=[]
    for i in range(8):
        a=angle+i*math.pi/4; k=r if i%2==0 else r*.25
        pts.append((x+math.cos(a)*k,y+math.sin(a)*k))
    ImageDraw.Draw(im).polygon(pts,fill=color)

@lru_cache(maxsize=32)
def potato(color='#DBA55E',mood='happy',hat=False):
    im=Image.new('RGBA',(540,570),(0,0,0,0)); d=ImageDraw.Draw(im)
    # Feet, arms and sticker contour; the tuber is intentionally irregular.
    d.line((212,424,203,501,171,507),fill=INK,width=12)
    d.line((314,425,331,501,366,503),fill=INK,width=12)
    d.line((132,293,77,309,51,275),fill=INK,width=12)
    d.line((388,283,447,267,465,227),fill=INK,width=12)
    d.ellipse((36,255,66,285),fill=INK)
    d.ellipse((449,209,478,239),fill=INK)
    pts=[(173,128),(220,87),(300,85),(357,111),(393,178),(415,259),
         (401,349),(367,410),(301,450),(217,442),(155,406),(124,343),
         (122,256),(139,179)]
    d.polygon(pts,fill=WHITE)
    # Smooth potato silhouette using a closed spline approximated by dense Catmull-Rom.
    smooth=[]
    for i in range(len(pts)):
        p0,p1,p2,p3=[np.array(pts[k%len(pts)],float) for k in (i-1,i,i+1,i+2)]
        for t in np.linspace(0,1,12,endpoint=False):
            p=.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t)
            smooth.append(tuple(p))
    d.polygon(smooth,fill=color)
    d.line(smooth+[smooth[0]],fill=INK,width=8,joint='curve')
    for x,y in [(177,191),(333,177),(165,346),(351,354),(258,399),(309,219),(220,137)]:
        d.arc((x-9,y-5,x+9,y+8),0,180,fill='#946333',width=4)
    d.ellipse((175,285,213,306),fill='#DC866A')
    d.ellipse((314,278,350,299),fill='#DC866A')
    if mood=='sad':
        d.line((209,250,229,255),fill=INK,width=7)
        d.line((294,255,314,250),fill=INK,width=7)
        d.arc((242,296,289,328),180,360,fill=INK,width=6)
    else:
        d.ellipse((211,238,226,263),fill=INK)
        d.ellipse((293,235,308,260),fill=INK)
        d.ellipse((214,241,218,246),fill=WHITE)
        d.ellipse((296,238,300,243),fill=WHITE)
        d.arc((237,267,287,312),0,180,fill=INK,width=7)
    if hat:
        d.polygon([(151,145),(205,59),(317,55),(375,141)],fill=ORANGE,outline=INK,width=6)
        d.rounded_rectangle((133,131,392,158),12,fill=ORANGE,outline=INK,width=5)
        d.rectangle((193,99,338,119),fill=YELLOW)
    return im

@lru_cache(maxsize=1)
def ship():
    im=Image.new('RGBA',(450,400)); d=ImageDraw.Draw(im)
    d.polygon([(38,271),(411,271),(359,338),(112,338)],fill=BROWN,outline=INK,width=7)
    d.line((225,52,225,275),fill=INK,width=8)
    d.polygon([(235,67),(235,239),(374,239)],fill=WHITE,outline=INK,width=6)
    d.polygon([(211,95),(82,231),(211,231)],fill=YELLOW,outline=INK,width=6)
    for x in [153,225,298]: d.ellipse((x-14,287,x+14,315),fill=CREAM,outline=INK,width=4)
    d.polygon([(224,44),(292,62),(224,79)],fill=ORANGE)
    return im

def plant(im,x,y,scale=1,wilt=False):
    d=ImageDraw.Draw(im); s=scale; c='#8B7E61' if wilt else GREEN
    def P(a,b): return (x+a*s,y+b*s)
    d.line([P(0,0),P(-6,-95),P(6,-170)],fill=INK,width=max(2,round(7*s)))
    for dx,dy,side in [(-6,-67,-1),(-3,-113,1),(5,-148,-1)]:
        if wilt:
            pts=[P(dx,dy),P(dx+side*51,dy+16),P(dx+side*39,dy+52),P(dx+side*10,dy+29)]
        else:
            pts=[P(dx,dy),P(dx+side*55,dy-42),P(dx+side*52,dy-3),P(dx+side*19,dy+8)]
        d.polygon(pts,fill=c)
        d.line(pts+[pts[0]],fill=INK,width=max(1,round(3*s)))

def sun(im,x,y,r=45):
    d=ImageDraw.Draw(im)
    for a in np.linspace(0,math.tau,12,endpoint=False):
        d.line((x+math.cos(a)*(r+12),y+math.sin(a)*(r+12),x+math.cos(a)*(r+28),y+math.sin(a)*(r+28)),fill=YELLOW,width=6)
    d.ellipse((x-r,y-r,x+r,y+r),fill=YELLOW)

def cloud(im,x,y,scale=1,color=WHITE):
    d=ImageDraw.Draw(im)
    for a,b,r in [(-45,3,28),(0,-20,42),(49,2,29)]:
        a=x+a*scale; b=y+b*scale; r*=scale
        d.ellipse((a-r,b-r,a+r,b+r),fill=color)
    d.rounded_rectangle((x-69*scale,y-2*scale,x+72*scale,y+30*scale),14*scale,fill=color)

def arrow(im,a,b,color=ORANGE,width=6):
    line(im,[a,b],color,width)
    dx,dy=b[0]-a[0],b[1]-a[1]; ang=math.atan2(dy,dx)
    d=ImageDraw.Draw(im)
    d.polygon([b,(b[0]-23*math.cos(ang-.45),b[1]-23*math.sin(ang-.45)),
                 (b[0]-23*math.cos(ang+.45),b[1]-23*math.sin(ang+.45))],fill=color)

def chrome(i):
    s=SCENES[i]; im=paper().copy()
    pill(im,90,48,'食物履历局',INK,size=25)
    text(im,(1830,58),s['label'],25,INK,anchor='rt')
    if i not in [0,7]:
        text(im,(92,139),s['title'],78,INK,True)
        text(im,(96,248),s['tag'],29,ORANGE,True)
        line(im,[(96,310),(1824,310)],'#C9C8B4',2)
    text(im,(100,1025),'FOOD FILES  /  POTATO',18,INK)
    text(im,(1820,1025),'原创程序动画  ·  中文合成配音',18,INK,anchor='rt')
    return im

@lru_cache(maxsize=8)
def background(i):
    im=chrome(i); d=ImageDraw.Draw(im)
    if i==0:
        d.ellipse((1005,178,1800,925),fill=YELLOW)
        text(im,(100,200),'土豆的',132,INK,True)
        text(im,(100,365),'历  史',154,ORANGE,True)
        text(im,(105,575),'一颗土豆的八千年逆袭',43,INK,True)
        text(im,(108,654),'从南美高原，到你的餐桌。',31,INK)
        pill(im,108,746,'薯条，只是我的一个马甲。',INK,size=28)
        text(im,(1520,224),'POTATO',38,INK,True,anchor='mm')
    elif i==1:
        rr(im,(100,350,1820,860),'#D9E5D9',28)
        for pts,c in [([(100,735),(470,376),(870,735)],'#B7C8B7'),
                       ([(474,754),(1040,355),(1480,754)],'#9BAE99'),
                       ([(1090,750),(1550,415),(1820,750)],'#C0CAB0')]:
            d.polygon(pts,fill=c)
        d.polygon([(942,425),(1040,355),(1120,427),(1072,414),(1030,436),(1004,415)],fill=WHITE)
        d.polygon([(399,445),(470,376),(546,448),(495,435),(464,454),(444,435)],fill=WHITE)
        for y,c in [(685,'#728F73'),(739,'#60836A'),(795,'#4C7058')]:
            d.rounded_rectangle((100,y,1820,870),24,fill=c)
            d.line((100,y,1820,y),fill=INK,width=4)
        for x in range(170,1770,140): plant(im,x,786,.42)
        pill(im,141,383,'约 8,000 年前',INK,size=27)
        pill(im,1430,791,'安第斯山地区',INK,size=24)
    elif i==2:
        rr(im,(100,350,904,855),'#253E4D',28)
        rr(im,(1017,350,1820,855),'#F2D791',28)
        text(im,(140,388),'寒夜 · 冻结',35,WHITE,True)
        text(im,(1057,388),'脱水 · 日晒',35,INK,True)
        d.ellipse((728,385,813,470),fill=CREAM)
        d.ellipse((757,370,831,448),fill='#253E4D')
        sun(im,1714,426,35)
        for xx,yy in [(255,491),(651,448),(737,620),(382,555)]: star(im,xx,yy,8,CREAM)
        d.rectangle((101,770,903,831),fill='#A7BCC5')
        d.rectangle((1018,770,1819,831),fill='#C39755')
        text(im,(140,798),'借用高原的天然低温',24,INK)
        text(im,(1057,798),'楚纽：让土豆更耐储存',24,INK)
    elif i==3:
        rr(im,(100,350,1820,855),'#D6E6E4',28)
        for y in range(406,840,56):
            for x in range(120,1800,100): d.arc((x,y,x+80,y+22),0,180,fill='#ADCBD0',width=3)
        d.polygon([(172,411),(299,398),(393,457),(416,517),(352,549),(405,599),(375,701),(294,795),(252,678),(243,595),(189,539)],fill=GREEN,outline=INK,width=4)
        d.polygon([(1326,452),(1430,409),(1530,415),(1592,464),(1724,480),(1745,551),(1619,568),(1555,626),(1500,575),(1410,580),(1356,529)],fill=GREEN,outline=INK,width=4)
        text(im,(270,808),'南美洲',27,INK,True)
        text(im,(1480,665),'欧洲',27,INK,True)
        pill(im,724,377,'16 世纪',INK,size=32)
        text(im,(1516,802),'路线为传播示意',22,INK)
    elif i==4:
        rr(im,(100,350,1820,855),'#E7E8CF',28)
        d.rectangle((102,660,1817,852),fill='#C29A66')
        for x in range(130,1800,70): d.arc((x,690,x+130,770),190,350,fill='#A37C50',width=3)
        for j in range(6):
            plant(im,300+j*255,673,1.0)
            for k in [-1,1]:
                d.ellipse((270+j*255+k*40,720,334+j*255+k*40,765),fill='#E1B66C',outline=INK,width=3)
        pill(im,143,387,'换个环境，需要适应',INK,size=28)
        pill(im,1265,387,'从选育到日常',ORANGE,size=28)
        sun(im,1660,512,32)
    elif i==5:
        rr(im,(100,350,1820,855),'#DADBCD',28)
        d.rectangle((102,723,1817,852),fill='#A79579')
        for j in range(9): plant(im,210+j*185,730,.95,True)
        for j in range(5): cloud(im,330+j*335,405,1.1,'#A4AFA8')
        pill(im,145,570,'晚疫病  +  高度依赖',INK,size=31)
        pill(im,1060,570,'贫困  /  土地  /  救济',ORANGE,size=29)
        text(im,(143,789),'病害是触发因素，社会条件让灾难加剧。',30,INK,True)
    elif i==6:
        rr(im,(100,350,1820,855),'#E8E2D2',28)
        for j,(x,c,label) in enumerate([(340,'#D8AD63','黄'),(750,'#9D769D','紫'),(1160,'#BD716B','红'),(1570,'#DFCC91','白')]):
            d.ellipse((x-173,412,x+173,758),fill=WHITE)
            pill(im,x-46,777,label,INK,size=26)
        text(im,(960,381),'不同外形，不同遗传资源',27,INK,True,anchor='mt')
    elif i==7:
        text(im,(98,137),'小土豆，大历史',97,INK,True)
        text(im,(101,262),'从安第斯山，到你面前这一口。',35,ORANGE,True)
        for x,c in [(405,'#E8D6B4'),(960,'#D8E2CB'),(1515,'#E9C7AC')]:
            d.ellipse((x-230,390,x+230,850),fill=c)
            d.ellipse((x-180,538,x+180,773),fill=WHITE,outline=INK,width=5)
            d.ellipse((x-148,558,x+148,746),outline='#D9CDB5',width=3)
        # Shredded potato dish.
        rng=random.Random(44)
        for j in range(76):
            x=405+rng.uniform(-108,108); y=646+rng.uniform(-53,52)
            d.line((x-33,y-8,x+37,y+7),fill='#D5AF46' if j%3 else GREEN,width=7)
        # Mashed potatoes.
        for a,b,r in [(-54,9,53),(0,-17,67),(61,16,49)]:
            d.ellipse((960+a-r,641+b-r*.65,960+a+r,641+b+r*.65),fill='#E8D3A0')
        d.rectangle((939,591,983,617),fill=YELLOW)
        for j in range(11):
            x=1410+j*19; y=530+(j%3)*18
            d.rounded_rectangle((x,y,x+16,690),4,fill=YELLOW,outline='#B78635',width=2)
        d.polygon([(1395,620),(1639,620),(1609,731),(1422,731)],fill=ORANGE,outline=INK,width=4)
        for x,lab in [(405,'土豆丝'),(960,'土豆泥'),(1515,'薯条')]: text(im,(x,798),lab,31,INK,True,anchor='mt')
    return im

def subtitle(im,s,t):
    active=next((x for x in s['lines'] if x['start']<=t<x['end']),None)
    if not active:return
    value=active['text']; max_width=1570; f=font(36,True)
    rows=[]; row=''
    for ch in value:
        if f.getlength(row+ch)>max_width:
            rows.append(row); row=ch
        else:row+=ch
    if row: rows.append(row)
    assert len(rows)<=2, 'Subtitle exceeds two lines'
    top=916 if len(rows)==1 else 886
    rr(im,(115,top,1805,1008),INK,22)
    for j,row in enumerate(rows): text(im,(960,top+20+j*47),row,36,WHITE,True,anchor='mt')

def render_frame(t):
    i=next((j for j,s in enumerate(SCENES) if t<s['end']),len(SCENES)-1)
    s=SCENES[i]; local=t-s['start']; p=local/s['duration']
    im=background(i).copy(); d=ImageDraw.Draw(im)
    bob=math.sin(local*2.4)*9; sway=math.sin(local*1.8)*3
    entrance=ease(local/.7)
    if i==0:
        paste(im,potato(),1405,582+bob,angle=-7+sway,scale=1.38*entrance+.01)
        for j,(x,y) in enumerate([(1130,309),(1742,495),(1182,802),(1632,820)]):
            star(im,x,y,22+math.sin(local*2+j)*5,ORANGE,local*.18)
        pill(im,1540,777,'履历：8,000 年',INK,size=23)
    elif i==1:
        cloud(im,480+(local*9)%100,483,.75)
        paste(im,potato(hat=True),1155,594+bob,angle=sway,scale=.85*entrance+.01)
        for j in range(3):
            paste(im,potato(['#D8AD63','#9D769D','#BD716B'][j]),450+j*176,701+math.sin(local*2+j)*6,scale=.29)
        star(im,1340,466,20,ORANGE,local)
    elif i==2:
        paste(im,potato('#B9CBD0'),502,613+bob,angle=-sway,scale=.70)
        paste(im,potato('#BD9C66'),1418,613+math.sin(local*2.4+1)*6,angle=sway,scale=.65)
        arrow(im,(926,604),(993,604),ORANGE,7)
        for j in range(12):
            x=160+(j*67)%650; y=464+((j*79+local*39)%240)
            star(im,x,y,8,'#DFECEB',local*.3)
        for j in range(5):
            x=1270+j*77; y=520-(local*31+j*42)%130
            line(im,[(x,y+23),(x+6,y+8),(x,y)],'#AC864A',3)
    elif i==3:
        # Cubic route is drawn progressively, then the vessel follows it.
        def route(q):
            return (340+1160*q,640-210*math.sin(q*math.pi))
        progress=min(1,local/(s['duration']*.7))
        pts=[route(q) for q in np.linspace(0,progress,110)]
        for j in range(0,len(pts)-2,6): line(im,pts[j:j+4],ORANGE,5)
        x,y=route(progress)
        paste(im,ship(),x,y-33+math.sin(local*3)*7,angle=math.sin(local*2)*2,scale=.58)
        for xx,yy in [(340,640),(1500,640)]:
            d.ellipse((xx-12,yy-12,xx+12,yy+12),fill=ORANGE,outline=WHITE,width=4)
        paste(im,potato(),640,732+bob,angle=sway,scale=.34)
    elif i==4:
        # Growth / adaptation time is a moving scan, distinct from rain below.
        x=173+int((local*.10%1)*1570)
        line(im,[(x,478),(x,808)],ORANGE,3)
        pill(im,max(140,min(1400,x-70)),787,'适应 + 选育',INK,size=22)
        paste(im,potato(),961,593+bob,angle=sway,scale=.58)
        cloud(im,610+local*8,454,.6)
    elif i==5:
        for j in range(45):
            x=130+(j*97+local*12)%1640; y=465+(j*83+local*110)%230
            line(im,[(x,y),(x-6,y+22)],'#7C9391',2)
        # No humorous character animation during the famine scene.
    elif i==6:
        for j,(x,c) in enumerate([(340,'#D8AD63'),(750,'#9D769D'),(1160,'#BD716B'),(1570,'#DFCC91')]):
            appear=ease((local-j*.22)/.65)
            paste(im,potato(c),x,586+math.sin(local*2+j)*10,angle=math.sin(local*1.7+j)*6,scale=.57*appear+.01)
        for j in range(3): star(im,546+j*400,737,12,ORANGE,local*.5)
    elif i==7:
        for j,x in enumerate([405,960,1515]):
            phase=local*1.8+j
            for k in range(3):
                xx=x-38+k*35; yy=485-((local*27+k*19)%55)
                line(im,[(xx,yy+24),(xx+7,yy+11),(xx,yy)],'#AC9D7C',3)
        for x,y in [(1740,192),(1690,292),(1820,410)]: star(im,x,y,16,ORANGE,local*.5)
    subtitle(im,s,t)
    # Global progress and eight chapter markers.
    line(im,[(100,1064),(1820,1064)],'#D3CDBD',4)
    line(im,[(100,1064),(100+1720*t/DURATION,1064)],ORANGE,5)
    for ch in SCENES:
        x=100+1720*ch['start']/DURATION
        d.ellipse((x-4,1060,x+4,1068),fill=INK)
    # Short exposure transition, keeping subtitles and titles comfortably legible.
    fade=min(1,local/.20,(s['duration']-local)/.20)
    if fade<1: im=Image.blend(paper(),im,max(0,fade))
    return np.array(im)

def make_cover():
    base=background(0).copy()
    paste(base,potato(),1405,582,angle=-7,scale=1.38)
    for x,y in [(1130,309),(1742,495),(1182,802),(1632,820)]:star(base,x,y,22)
    pill(base,1540,777,'履历：8,000 年',INK,size=23)
    return base
