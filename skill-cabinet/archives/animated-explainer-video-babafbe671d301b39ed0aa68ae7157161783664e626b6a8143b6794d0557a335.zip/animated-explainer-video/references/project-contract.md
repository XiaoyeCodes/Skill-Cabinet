# 项目结构和可编辑接口

```text
project/
  common.py        路径、中文字体、FFmpeg、缓存键、输入检查
  narrate.py       配音缓存、音频时长、时间线和SRT
  render.py        MoviePy合成、程序音乐、预览与编码
  verify.py        解码、响度、抽帧、项目打包
  visuals.py       按主题编写的全部画面
  story.json      内容与输出配置
  sources.json    主张与来源
  requirements.txt
  assets/fonts/   Noto Sans SC和OFL许可
  assets/voice/   缓存或自有音频
  timeline.json   自动生成，不手工编辑
  output/         交付产物
```

## story.json

```json
{
  "title":"视频标题",
  "subtitle":"系列名或副标题",
  "output_name":"可选的文件名前缀",
  "voice":"zh-CN-YunxiNeural",
  "rate":"+10%",
  "pitch":"+0Hz",
  "render":{"width":1920,"height":1080,"fps":30,"threads":4},
  "lead_in":0.45,
  "line_gap":0.12,
  "tail":0.6,
  "scenes":[
    {"id":"intro","label":"01 / 开场","title":"一个具体的问题","tag":"补充信息",
     "serious":false,"visual":{"type":"自定义场景类型"},
     "lines":["一段较短的旁白。",{"text":"自有配音对应的台词。","audio":"assets/voice/local.wav"}]}
  ]
}
```

场景数量可变，id唯一。`serious`控制该幕的音乐氛围。`visual`是视觉模块自己的数据，不由渲染器解释。宽高为正偶数，fps为正整数；土豆案例画面固定1920×1080，想换画幅需重新设计其visuals.py。

## visuals.py

```python
from common import load_timeline, font
import numpy as np
from PIL import Image

TL = load_timeline()
W, H = TL['render']['width'], TL['render']['height']

def render_frame(t):
    scene = next(s for s in TL['scenes'] if t < s['end'])
    local_time = t - scene['start']
    image = Image.new('RGB', (W, H), '#F6EEDD')
    # Draw theme-specific characters, diagrams, titles and current subtitles.
    return np.asarray(image)

def make_cover():
    # Return a PIL RGB image without subtitles.
    return Image.new('RGB', (W, H), '#F6EEDD')
```

这个最小代码只说明接口，不是合格的成片画面。实际创作参照两份可执行模板，实现与主题相关的插画与动作。

每个场景有`start/end/duration`；每段台词有`text/path/start/end/duration`。时间单位均为秒，`path`为项目内相对路径。`render_frame`需要覆盖完整时间线，返回`uint8`、`(height,width,3)`数组或同尺寸PIL图像。不要依赖系统时钟或每次变化的随机数；随机纹理使用固定种子。

当前句段：`line['start'] <= t < line['end']`。文字按真实字体测量后分行，不用固定字符数假设等宽。每帧不联网、不读取外部网页；静态素材缓存，动态部分按时间计算。

`load_timeline()`会检查story摘要。如果story更改，重新生成时间线。仅改画面代码时通常只需预览和渲染。
