# 分享、安装与调用

把整个`animated-explainer-video`文件夹交给对方，或发送本Skill ZIP。必须保留`SKILL.md`、`scripts`、`references`、`assets`；只发SKILL.md会丢失可执行制作流程。

## Codex / Claude Code

解压后，在包的上级目录执行：

下文的`python`在部分macOS/Linux环境需写成`python3`。推荐Python 3.10—3.13；本包实际使用Python 3.13验证。

```text
python animated-explainer-video/scripts/install_skill.py --target codex
python animated-explainer-video/scripts/install_skill.py --target claude
```

两者都安装可用`--target both`。脚本只复制Skill并核对文件摘要，不编辑模型配置或权限，不覆盖同名已安装目录。

- 当前Codex官方用户路径：`~/.agents/skills/animated-explainer-video/`；项目路径：`<项目>/.agents/skills/animated-explainer-video/`。[官方说明](https://learn.chatgpt.com/docs/build-skills)
- Claude Code用户路径：`~/.claude/skills/animated-explainer-video/`；项目路径：`<项目>/.claude/skills/animated-explainer-video/`。[官方说明](https://code.claude.com/docs/en/skills)
- 部分既有Codex桌面环境也加载`~/.codex/skills/`。以宿主实际列出的Skill目录为准，避免在两个已被扫描的目录中重复安装同名Skill。
- 项目级安装：`python animated-explainer-video/scripts/install_skill.py --target both --scope project --project-dir <项目路径>`。

安装后新开会话使宿主发现Skill。即使尚未自动发现，也可以让具备本地文件与命令执行能力的智能体读取解压目录中的SKILL.md并照做。

Codex指令示例：

```text
使用 $animated-explainer-video，做一部“辣椒来中国之前，四川人怎么吃辣”的趣味科普视频。
60秒，中文配音，9:16竖屏，原创卡通角色。请核实史实，制作动画，渲染并检查，
交付MP4、字幕、封面和可编辑源码。
```

Claude Code指令示例：

```text
/animated-explainer-video 做一部“香蕉没有种子，下一代哪来的”的趣味科普视频，
60秒，9:16，中文配音和字幕，完成实际渲染后交付。
```

复现原案例：

```text
使用 animated-explainer-video 的 potato 模板，复现《土豆的历史》。使用缓存配音，
输出1080p横屏，检查分镜和成片，并打包可编辑项目。
```

## 使用边界

接收方需要能执行Python、安装项目依赖、运行FFmpeg以及查看生成图片。普通只读聊天或没有文件/执行工具的会话无法只靠一段提示直接渲染；可将完整Skill包放到Claude Code或Codex可访问的文件目录。

Windows、macOS、Linux采用同一套Python代码和随包中文字体；这里只把实际测试的平台写入随包测试报告，不宣称所有平台均已实测。新主题配音需要网络，或提供本地音频。土豆缓存允许在依赖已安装时离线完成媒体制作。
