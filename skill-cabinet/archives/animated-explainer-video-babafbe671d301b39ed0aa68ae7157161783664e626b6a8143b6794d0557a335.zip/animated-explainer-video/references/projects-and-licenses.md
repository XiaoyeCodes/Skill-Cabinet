# 实际使用的开源项目与素材来源

以下是原视频和本Skill实际采用的技术链；未把此前调研过的其他框架算进来。

| 项目 | 原片版本/配置 | 用途 | 上游许可和链接 |
|---|---|---|---|
| MoviePy | 2.2.1 | 逐帧视频、音轨组合、编码调用 | MIT；[仓库](https://github.com/Zulko/moviepy)、[文档](https://zulko.github.io/moviepy/) |
| Pillow | 11.3.0 | 卡通角色、文字、场景、图层和封面 | MIT-CMU；[仓库](https://github.com/python-pillow/Pillow)、[许可](https://pillow.readthedocs.io/en/stable/about.html#license) |
| NumPy | 原环境2.5.4；项目要求>=1.25,<3 | 像素数组、轨迹、程序音频 | 主要BSD-3-Clause；wheel可包含其他组件许可；[仓库](https://github.com/numpy/numpy) |
| edge-tts | 7.3.1；zh-CN-YunxiNeural，+10% | 调用Microsoft Edge在线语音服务生成中文旁白 | 主体LGPLv3，srt_composer为MIT；[仓库](https://github.com/rany2/edge-tts)、[许可](https://github.com/rany2/edge-tts/blob/master/LICENSE) |
| FFmpeg / ffprobe | 原环境8.1.2 | 测时、H.264/AAC、响度、混流、抽帧与解码 | 构建依配置采用LGPL/GPL等；libx264具有自己的许可；[官网](https://ffmpeg.org/)、[许可说明](https://ffmpeg.org/legal.html) |
| Noto Sans SC | 本迁移包新增 | 提供跨平台中文字体 | SIL OFL 1.1；[官方字体目录](https://github.com/google/fonts/tree/main/ofl/notosanssc)，随包保留OFL.txt |

原片使用本机微软雅黑。为方便分享，本Skill用可分发的Noto Sans SC替代，不打包Windows字体。随包字体为Google Fonts仓库中的未修改`NotoSansSC[wght].ttf`，本地仅简化文件名。下载来源：https://raw.githubusercontent.com/google/fonts/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf 。

Pillow绘制的插画、场景和NumPy合成的背景音乐由本工作流原创。包内保留了原土豆旁白的16段缓存，供复现使用。在线语音服务不是开源模型，不应把客户端的开源许可等同于该服务的授权条款。Python依赖、FFmpeg二进制不随Skill分发，安装时由包管理器取得并保留上游许可。

Remotion、HyperFrames、Motion Canvas、MoneyPrinterTurbo和claude-motion只是前期调研候选；本片未运行它们，也不依赖它们。新任务可以按用户明确要求改用其他框架，但那属于另一条实现路径。

具体史实来源保留在`assets/potato/sources.json`及`assets/starter/sources.json`。它们是案例来源，不是所有未来选题的通用依据；换主题后必须重做事实核实。
