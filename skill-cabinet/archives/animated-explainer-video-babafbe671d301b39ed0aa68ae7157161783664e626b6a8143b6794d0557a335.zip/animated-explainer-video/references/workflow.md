# 完整制作方法

## 这次视频是怎么做出来的

原片是代码生成的二维动画。智能体先核实土豆的安第斯起源、传播与饥荒背景，写出约419字旁白，拆成8幕、16段。`edge-tts`逐段生成中文MP3，`ffprobe`读取真实长度，拼出约99.94秒的时间线。字幕从同一时间线生成。

Pillow逐帧绘制纸感背景、土豆角色、山脉、船、农田与食物；NumPy处理像素、轨迹和音频。角色通过平移、旋转、缩放、错峰出场等方式运动，船沿时间控制的航线行驶。每帧由时间直接计算，保持重渲染可重复。音乐用正弦波、谐波、包络、和弦及短铃声合成，不依赖音乐素材库。饥荒一幕采用严肃画面与更弱配乐。

MoviePy组合逐帧画面与音轨，FFmpeg编码H.264/AAC。第二次混流使用`-c:v copy`保留视频，仅处理音频响度并添加`+faststart`。原片验证得到100秒、1920×1080、30fps、16段字幕，完整解码通过。迁移版用开源Noto字体替代原电脑的微软雅黑，字体字形可能略有不同。

## 初始化

1. 从实际Skill路径运行`python scripts/init_project.py --output <独立项目目录> --template potato`复现原案例；新主题改用`--template starter`。
2. 运行`python scripts/setup_env.py --project <项目目录> --install`。它只创建项目的`.venv`并安装`requirements.txt`，不覆盖系统Python包。
3. 确认FFmpeg与ffprobe可执行。可设置环境变量`FFMPEG`、`FFPROBE`为实际路径；带空格的路径作为单个参数传递，不拼接shell命令。
4. 后续使用新项目虚拟环境的Python。命令可从其他目录执行，项目根目录由脚本自身定位。

常见FFmpeg安装方式按实际环境选择：Windows使用已有winget或下载官方认可的构建；macOS可用`brew install ffmpeg`；Debian/Ubuntu可用`apt install ffmpeg`。优先复用已有工具，不自动申请管理员权限；遇到宿主明确权限限制时遵循其提示。

## 从主题到分镜

把“主题”收窄成一个观众愿意知道答案的问题；前几秒直接呈现问题或反差。再把答案拆成有因果关系的场景：人物/物体登场、起源、变化、关键机制、影响和收尾。6—8幕适合原片长度，但不要强制所有视频8幕。

先用目标时长粗定文案规模，再以实际TTS长度调整。原片419字在`zh-CN-YunxiNeural`、`+10%`语速下，加停顿约100秒；这只是一个实例，不是通用字数公式。新项目可先试45—90秒，用户指定时长则优先满足。

来源写进`sources.json`，包含主张、发布机构、URL、核实日期。不把旧产量统计当现状，不用未经核实的轶闻制造反转。科学机制要用真实结构和过程演示。

## 画面制作

- 入口在`visuals.py`：`render_frame(t)`返回RGB帧，`make_cover()`返回封面。
- `potato/visuals.py`保留完整原片绘图：角色样条、多层山景、冻干双面板、跨洋航线、农田、饥荒和多样性。
- `starter/visuals.py`提供横竖屏布局、分行字幕、卡通角色、双项比较与传播流程。默认香蕉只是可执行示例；新主题要改写`subject()`及场景图解。
- 背景、字体、角色静态素材可缓存；位移和旋转依赖场景局部时间。字幕从时间线中找当前句子，不另造一套时间。
- 横屏原片留约5%边距。竖屏应额外考虑平台右侧和底部操作区，关键文字放到更靠中央的位置，不靠简单裁切横屏来适配。

## 配音和字幕

执行`narrate.py`。默认语音是`zh-CN-YunxiNeural`，可在`story.json`更改`voice`、`rate`、`pitch`。每段旁白缓存文件名取文字和语音参数的SHA-256摘要，避免改文案后误用旧声音；相同段落只合成一次。

每个场景默认：前留0.45秒、句间0.12秒、尾留0.60秒。可通过`lead_in`、`line_gap`、`tail`调整。实际时长以ffprobe测量。SRT为句段级字幕，不是逐字高亮。

`narrate.py --offline`只读缓存/自有音频；`--refresh`重新合成。自有音频写成`{"text":"台词","audio":"assets/voice/my-line.wav"}`，文件需在项目内，文本应与声音匹配。脚本不自动识别或纠正录音文本。

在线TTS失败会有限重试3次，不请求凭据，也不静默换成无声视频。可继续完成脚本和画面，准确报告语音阻塞，并在有缓存或音频后恢复。

## 渲染与验证

依次运行：

```text
<project-python> <project-dir>/narrate.py
<project-python> <project-dir>/render.py --preview
<project-python> <project-dir>/render.py
<project-python> <project-dir>/verify.py --package
```

预览后、正式渲染前查看`output/storyboard.jpg`。最后查看`encoded_contact_sheet.jpg`，这是从编码后的MP4提取的画面。自动检查结果在`validation.json`，人工看图状态单独记录，不把自动通过当作画面已验收。

输出包含：主题名MP4、SRT、封面、分镜预览、成片抽帧、验证JSON、原创合成音乐，以及可编辑项目ZIP。包内保留中文字体与配音缓存；不打包`.venv`、系统FFmpeg或当前用户机器路径。

## 常见问题

| 现象 | 处理 |
|---|---|
| 中文方块 | 检查`assets/fonts/NotoSansSC.ttf`；或配置`font`/`font_bold`、`EXPLAINER_FONT`/`EXPLAINER_FONT_BOLD` |
| 修改文案后提示时间线过期 | 重跑`narrate.py`；只重做变化的配音 |
| 音频滤镜与streamcopy冲突 | 将音频标准化放到独立FFmpeg混流步骤，音频用AAC重新编码 |
| 竖屏标题挤压画面 | 精简标题、重排字号和图解位置；先看预览 |
| 旁白超过目标时长 | 优先改短文案和停顿，再考虑语速，不粗暴加速整段成片 |
| 字幕过长 | 在story里拆成更短的配音段，保证字幕与真实音频一致 |
| 缺少ffprobe | 安装完整FFmpeg发行包；imageio自带ffmpeg不一定包含ffprobe |
