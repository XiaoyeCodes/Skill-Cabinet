# Historical example only

Source article: 2026-10-22. Market collection cutoff: 2026-10-22 12:04:13 Asia/Shanghai (04:04:13 UTC). These files reproduce the confirmed format and retained source facts, NOT current market data.

The reproduction explicitly has `status=preview_only` and `ready=false`. Never use these quotes in a current run, change their timestamps, or copy them into a fresh request. Production scripts do not read this directory.

`layout-preview.html` is the standalone HTML; `layout-preview-email.html` is its CID variant; `layout-preview.txt` is plain text; `historical-example.pdf` is the optional 4-page native-text export. `quotes.json`, `evidence/`, and the parsed/verified JSON files provide historical audit evidence. The manifest paths are relative to this directory.

`python scripts/run_example.py --out NEW_EMPTY_DIRECTORY --pdf` from the skill root reproduces the files offline. Remove `--pdf` if its optional dependencies are not installed.
