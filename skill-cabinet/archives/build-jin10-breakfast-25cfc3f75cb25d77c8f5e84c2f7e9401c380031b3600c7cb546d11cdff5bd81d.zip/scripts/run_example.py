#!/usr/bin/env python3
"""Offline historical fixture, never a current report. No network, emails or schedule."""
import argparse,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',required=True);p.add_argument('--pdf',action='store_true');a=p.parse_args()
out=Path(a.out).resolve();example=ROOT/'examples/historical-2026-10-22'
subprocess.run([sys.executable,str(ROOT/'scripts/jin10_breakfast.py'),'prepare','--date','2026-10-22','--source-url','https://xnews.jin10.com/details/233030','--article-html',str(ROOT/'tests/fixtures/article-2026-10-22.html'),'--out',str(out)],check=True)
subprocess.run([sys.executable,str(ROOT/'scripts/jin10_breakfast.py'),'render','--out',str(out),'--quotes',str(example/'quotes.json'),'--evidence-root',str(example),'--preview-only'],check=True)
if a.pdf:
 subprocess.run([sys.executable,str(ROOT/'scripts/export_pdf.py'),'--html',str(out/'layout-preview.html'),'--out',str(out/'historical-example.pdf'),'--news-json',str(out/'news.json'),'--qa-dir',str(out/'pdf-qa')],check=True)
print('HISTORICAL EXAMPLE ONLY: 2026-10-22 12:04 Asia/Shanghai. Output status.ready=false. Never use as current data.')
