#!/usr/bin/env python3
"""
Download slides pages as PNG files and voice narrations as WAV files.
Exports everything as a ZIP archive (completely free).
"""

import os
import sys
import json
import argparse
import ipaddress
import re
import socket
import ssl
import http.client
import tempfile
import requests
from urllib.parse import urlparse
from typing import Optional, Dict, Any
from pathlib import Path


def safe_user_path(path_value, base_dir="."):
    """Resolve a CLI path under the current workspace."""
    if base_dir != ".":
        raise ValueError("Custom base directories are not supported for CLI paths")
    base_path = Path.cwd().resolve()
    resolved_path = Path(path_value).expanduser().resolve()
    try:
        resolved_path.relative_to(base_path)
    except ValueError as exc:
        raise ValueError(f"Path escapes allowed directory: {path_value}") from exc
    return resolved_path


API_BASE_URL = "https://2slides.com/api/v1"
JOB_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def validate_job_id(job_id: str) -> str:
    if not JOB_ID_RE.fullmatch(job_id or ""):
        raise ValueError("Job ID contains unsupported characters")
    return job_id


def validate_public_https_url(url: str) -> tuple[str, str]:
    if any(ord(c) < 33 or ord(c) == 127 for c in url):
        raise ValueError("Download URL contains whitespace/control characters")
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError("Download URL must be HTTPS")
    public_ips = []
    for info in socket.getaddrinfo(parsed.hostname, None):
        ip = ipaddress.ip_address(info[4][0])
        if not ip.is_global:
            raise ValueError("Download URL resolves to a non-public address")
        public_ips.append(str(ip))
    if not public_ips:
        raise ValueError("Download URL did not resolve")
    return url, public_ips[0]


def download_pinned_https(url: str, pinned_ip: str, output_path: Path, maximum_bytes: int = 128 * 1024 * 1024) -> int:
    """Download once from the verified IP while preserving TLS SNI/hostname checks."""
    parsed = urlparse(url)
    raw_socket = socket.create_connection((pinned_ip, 443), timeout=30)
    tls_context = ssl.create_default_context()
    tls_context.minimum_version = ssl.TLSVersion.TLSv1_2
    tls_socket = tls_context.wrap_socket(raw_socket, server_hostname=parsed.hostname)
    request_target = parsed.path or "/"
    if parsed.query:
        request_target += f"?{parsed.query}"
    host = parsed.hostname
    tls_socket.sendall(
        f"GET {request_target} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: 2slides-downloader/1\r\nAccept: application/zip\r\nConnection: close\r\n\r\n".encode("ascii")
    )
    response = http.client.HTTPResponse(tls_socket)
    response.begin()
    if 300 <= response.status < 400:
        raise ValueError("Download redirects are refused; request a fresh final URL from 2slides")
    if response.status != 200:
        raise ValueError(f"Download failed with HTTP {response.status}")
    declared = response.getheader("Content-Length")
    if declared and int(declared) > maximum_bytes:
        raise ValueError("Download exceeds the 128 MiB limit")
    total = 0
    with output_path.open("wb") as destination:
        while True:
            chunk = response.read(8192)
            if not chunk:
                break
            total += len(chunk)
            if total > maximum_bytes:
                raise ValueError("Download exceeds the 128 MiB limit")
            destination.write(chunk)
    response.close()
    return total


def get_api_key() -> str:
    """Get API key from environment variable."""
    api_key = os.environ.get("SLIDES_2SLIDES_API_KEY")
    if not api_key:
        raise ValueError(
            "API key not found. Set SLIDES_2SLIDES_API_KEY environment variable.\n"
            "Get your API key from: https://2slides.com/api"
        )
    return api_key


def download_slides_pages_voices(
    job_id: str,
    output_path: Optional[str] = None,
    api_key: Optional[str] = None
) -> str:
    """
    Download slides pages and voice narrations as a ZIP archive.

    Args:
        job_id: Job ID from slide generation
        output_path: Optional path to save the ZIP file (default: <job_id>.zip)
        api_key: API key (uses env var if not provided)

    Returns:
        Path to the downloaded ZIP file

    Notes:
        - Exports pages as PNG files
        - Exports voices as WAV files
        - Includes transcripts
        - Completely free (no credit cost)
        - Download URL valid for 1 hour
    """
    if api_key is None:
        api_key = get_api_key()
    job_id = validate_job_id(job_id)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "jobId": job_id
    }

    url = f"{API_BASE_URL}/slides/download-slides-pages-voices"

    print(f"Requesting download for job: {job_id}...", file=sys.stderr)

    response = requests.post(url, headers=headers, json=payload, timeout=30, allow_redirects=False)
    response.raise_for_status()

    result = response.json()

    # Check API response structure
    if not result.get("success"):
        error_msg = result.get("error", "Unknown error")
        raise ValueError(f"API error: {error_msg}")

    # Get download URL from data field
    data = result.get("data")
    if not data:
        raise ValueError("No data in API response")

    download_url = data.get("downloadUrl")
    if not download_url:
        raise ValueError("No download URL in response")
    download_url, pinned_ip = validate_public_https_url(download_url)

    # Optional: log additional info
    file_name = data.get("fileName", "unknown.zip")
    expires_in = data.get("expiresIn", 3600)
    print(f"  Filename: {file_name}", file=sys.stderr)
    print(f"  Expires in: {expires_in} seconds", file=sys.stderr)

    # Download the ZIP file
    if output_path is None:
        output_path = f"{job_id}.zip"

    print(f"Downloading ZIP archive to: {output_path}...", file=sys.stderr)

    destination = safe_user_path(output_path)
    if destination.exists():
        raise FileExistsError("Refusing to overwrite an existing output file")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=".2slides-", suffix=".zip", dir=destination.parent, delete=False) as tmp:
        temporary = Path(tmp.name)
    try:
        file_size = download_pinned_https(download_url, pinned_ip, temporary)
        os.chmod(temporary, 0o600)
        # Hard-link creation is atomic and fails if another writer won the name.
        os.link(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"✓ Downloaded successfully!", file=sys.stderr)
    print(f"  File: {output_path}", file=sys.stderr)
    print(f"  Size: {file_size:,} bytes", file=sys.stderr)

    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="Download 2slides pages and voices as ZIP archive (FREE)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Download with default filename
  %(prog)s --job-id "abc-123-def-456"

  # Download to specific path
  %(prog)s --job-id "abc-123-def-456" --output slides.zip

Archive Contents:
  - Pages as PNG files
  - Voice files as WAV
  - Transcripts

Note: Download URLs are valid for 1 hour only
Cost: Completely FREE (no credits used)
        """
    )

    parser.add_argument("--job-id", required=True, help="Job ID from slide generation")
    parser.add_argument("--output", help="Output ZIP file path (default: <job_id>.zip)")

    args = parser.parse_args()

    try:
        output_path = download_slides_pages_voices(
            job_id=args.job_id,
            output_path=args.output
        )

        # Output path for easy parsing
        print(json.dumps({"success": True, "output": output_path}, indent=2))

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
