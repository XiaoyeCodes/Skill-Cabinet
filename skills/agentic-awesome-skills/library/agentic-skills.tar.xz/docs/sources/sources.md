# 📜 Sources & Attributions

We believe in giving credit where credit is due.
If you recognize your work here and it is not properly attributed, please open an Issue.

| Skill / Category            | Original Source                                                            | License        | Notes                         |
| :-------------------------- | :------------------------------------------------------------------------- | :------------- | :---------------------------- |
| `cloud-penetration-testing` | [HackTricks](https://book.hacktricks.xyz/)                                 | MIT / CC-BY-SA | Adapted for agentic use.      |
| `active-directory-attacks`  | [HackTricks](https://book.hacktricks.xyz/)                                 | MIT / CC-BY-SA | Adapted for agentic use.      |
| `owasp-top-10`              | [OWASP](https://owasp.org/)                                                | CC-BY-SA       | Methodology adapted.          |
| `burp-suite-testing`        | [PortSwigger](https://portswigger.net/burp)                                | N/A            | Usage guide only (no binary). |
| `crewai`                    | [CrewAI](https://github.com/joaomdmoura/crewAI)                            | MIT            | Framework guides.             |
| `atlas-cloud-media`         | [Atlas Cloud](https://atlascloud.ai/)                                      | MIT            | Official source for asynchronous image and video generation through the Atlas Cloud API. |
| `hasdata`, `hasdata-cli`    | [HasData CLI](https://github.com/HasData/hasdata-cli)                      | MIT            | Official HasData API and CLI guidance. |
| `runapi-cli`                | [RunAPI CLI Skill](https://github.com/runapi-ai/cli-skill)                 | Apache-2.0     | Official RunAPI CLI skill for generating AI images, videos, and music/audio, plus other model API jobs. |
| `weaviate`, `weaviate-cookbooks` | [Weaviate Agent Skills](https://github.com/weaviate/agent-skills)     | BSD-3-Clause   | Official Weaviate vector database operations, RAG cookbooks, and agentic app blueprints. |
| `pre-release-review`, `drizzle-migration-conflict` | [chaunsin/agent-skills](https://github.com/chaunsin/agent-skills) | Apache-2.0 | Release-readiness and Drizzle Kit migration-conflict workflows. |
| `frontend-lighthouse`       | [stareezy-1/frontend-architecture-skill](https://github.com/stareezy-1/frontend-architecture-skill) | MIT | Lighthouse CI Core Web Vitals gate adapted for the skill catalog. |
| `browser-testing-with-devtools` | [addyosmani/agent-skills](https://github.com/addyosmani/agent-skills)  | MIT            | Chrome DevTools MCP browser verification and security-boundary guidance. |
| `langgraph`                 | [LangGraph](https://github.com/langchain-ai/langgraph)                     | MIT            | Framework guides.             |
| `react-patterns`            | [React Docs](https://react.dev/)                                           | CC-BY          | Official patterns.            |
| `apify-youtube-transcript-scraper` | [harshmaur/apify-youtube-transcript-scraper](https://github.com/harshmaur/apify-youtube-transcript-scraper) | MIT | Community skill by the Actor author for YouTube captions, timestamped quotations and transcript research. |
| `apify-facebook-ads-library-scraper` | [harshmaur/apify-facebook-ads-library-scraper](https://github.com/harshmaur/apify-facebook-ads-library-scraper) | MIT | Community skill by the Actor author for Meta ad copy, creative and transparency research. |
| `apify-tiktok-scraper` | [harshmaur/apify-tiktok-scraper](https://github.com/harshmaur/apify-tiktok-scraper) | MIT | Community skill by the Actor author for TikTok video, profile and comment research. |
| `apify-linkedin-jobs-scraper` | [harshmaur/apify-linkedin-jobs-scraper](https://github.com/harshmaur/apify-linkedin-jobs-scraper) | MIT | Community skill by the Actor author for LinkedIn job searches, salary and recruiter data. |
| `apify-reddit-scraper`      | [harshmaur/apify-reddit-scraper-skill](https://github.com/harshmaur/apify-reddit-scraper-skill) | MIT | Community skill by the Actor author; also published in [apify/awesome-skills](https://github.com/apify/awesome-skills/tree/main/skills/apify-reddit-scraper). |
| **All Official Skills**     | [Anthropic / Google / OpenAI / Microsoft / Supabase / Apify / Vercel Labs] | Proprietary    | Usage encouraged by vendors.  |

## Skills from zhaoxuya520/reverse-skill

The following 43 security skills were adapted from the [reverse-skill](https://github.com/zhaoxuya520/reverse-skill) cybersecurity routing pack (MIT). The GPLv3 `CTF-Sandbox-Orchestrator` sidecar and runtime bootstrap scripts were intentionally not bundled.

| Skill | Original Source | License | Notes |
| :---- | :-------------- | :------ | :---- |
| `api-security`, `apk-reverse`, `attack-chain`, `binary-diff`, `browser-extension-reverse`, `case-review`, `cloud-k8s`, `code-audit`, `database-security`, `diagram-generator`, `digital-forensics`, `docs-generator`, `dotnet-reverse`, `edr-bypass-re`, `email-security`, `firmware-pentest`, `ghidra-reverse`, `go-rust-reverse`, `hardware-security`, `ida-reverse`, `identity-federation`, `js-reverse`, `llm-security`, `macos-reverse`, `malware-analysis`, `mobile-reverse`, `ot-ics`, `patch-diff-exploit`, `pentest-tools`, `protocol-reverse`, `pwn-chain`, `radare2`, `radio-sdr`, `reverse-browser-automation`, `reverse-engineering`, `supply-chain-security`, `thick-client`, `threat-hunting`, `threat-intelligence`, `wifi-wireless`, `windows-ad`, `reverse-engineering/dsl-vm-reverse`, `pentest-tools/src-hunter` | [zhaoxuya520/reverse-skill](https://github.com/zhaoxuya520/reverse-skill) | MIT | Reverse engineering, binary analysis, offensive assessment, and threat-intelligence workflows, adapted with English metadata and upstream safety gates. |


## Skills from VoltAgent/awesome-agent-skills

The following skills were added from the curated collection at [VoltAgent/awesome-agent-skills](https://github.com/VoltAgent/awesome-agent-skills):

### Official Team Skills

| Skill                                                                                        | Original Source                                                           | License    | Notes                              |
| :------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------ | :--------- | :--------------------------------- |
| `vercel-deploy-claimable`                                                                    | [Vercel Labs](https://github.com/vercel-labs/agent-skills)                | MIT        | Official Vercel skill              |
| `design-md`                                                                                  | [Google Labs (Stitch)](https://github.com/google-labs-code/stitch-skills) | Compatible | Google Labs Stitch skills          |
| `hugging-face-cli`, `hugging-face-community-evals`, `hugging-face-dataset-viewer`, `hugging-face-gradio`, `hugging-face-jobs`, `hugging-face-model-trainer`, `hugging-face-paper-publisher`, `hugging-face-papers`, `hugging-face-trackio`, `hugging-face-vision-trainer`, `transformers-js` | [Hugging Face](https://github.com/huggingface/skills) | Compatible | Official Hugging Face skills |
| `culture-index`, `fix-review`, `sharp-edges`                                                 | [Trail of Bits](https://github.com/trailofbits/skills)                    | Compatible | Security skills from Trail of Bits |
| `expo-deployment`, `upgrading-expo`                                                          | [Expo](https://github.com/expo/skills)                                    | Compatible | Official Expo skills               |
| `commit`, `create-pr`, `find-bugs`, `iterate-pr`                                             | [Sentry](https://github.com/getsentry/skills)                             | Compatible | Sentry dev team skills             |
| `using-neon`                                                                                 | [Neon](https://github.com/neondatabase/agent-skills)                      | Compatible | Neon Postgres best practices       |
| `fal-audio`, `fal-generate`, `fal-image-edit`, `fal-platform`, `fal-upscale`, `fal-workflow` | [fal.ai Community](https://github.com/fal-ai-community/skills)            | Compatible | fal.ai AI model skills             |

### Community Skills

| Skill                                                               | Original Source                                                             | License    | Notes                          |
| :------------------------------------------------------------------ | :-------------------------------------------------------------------------- | :--------- | :----------------------------- |
| `automate-whatsapp`, `observe-whatsapp`                             | [gokapso](https://github.com/gokapso/agent-skills)                          | Compatible | WhatsApp automation skills     |
| `readme`                                                            | [Shpigford](https://github.com/Shpigford/skills)                            | Compatible | README generation              |
| `screenshots`                                                       | [Shpigford](https://github.com/Shpigford/skills)                            | Compatible | Marketing screenshots          |
| `aws-skills`                                                        | [zxkane](https://github.com/zxkane/aws-skills)                              | Compatible | AWS development patterns       |
| `deep-research`                                                     | [sanjay3290](https://github.com/sanjay3290/ai-skills)                       | Compatible | Gemini Deep Research Agent     |
| `ffuf-claude-skill`                                                 | [jthack](https://github.com/jthack/ffuf_claude_skill)                       | Compatible | Web fuzzing with ffuf          |
| `ui-skills`                                                         | [ibelick](https://github.com/ibelick/ui-skills)                             | Compatible | UI development constraints     |
| `vexor`                                                             | [scarletkc](https://github.com/scarletkc/vexor)                             | Compatible | Vector-powered CLI             |
| `pypict-skill`                                                      | [omkamal](https://github.com/omkamal/pypict-claude-skill)                   | Compatible | Pairwise test generation       |
| `makepad-skills`                                                    | [ZhangHanDong](https://github.com/ZhangHanDong/makepad-skills)              | Compatible | Makepad UI development         |
| `swiftui-expert-skill`                                              | [AvdLee](https://github.com/AvdLee/SwiftUI-Agent-Skill)                     | Compatible | SwiftUI best practices         |
| `threejs-skills`                                                    | [CloudAI-X](https://github.com/CloudAI-X/threejs-skills)                    | Compatible | Three.js 3D experiences        |
| `claude-scientific-skills`                                          | [K-Dense-AI](https://github.com/K-Dense-AI/claude-scientific-skills)        | Compatible | Scientific research skills     |
| `claude-win11-speckit-update-skill`                                 | [NotMyself](https://github.com/NotMyself/claude-win11-speckit-update-skill) | Compatible | Windows 11 management          |
| `imagen`                                                            | [sanjay3290](https://github.com/sanjay3290/ai-skills)                       | Compatible | Google Gemini image generation |
| `security-bluebook-builder`                                         | [SHADOWPR0](https://github.com/SHADOWPR0/security-bluebook-builder)         | Compatible | Security documentation         |
| `claude-ally-health`                                                | [huifer](https://github.com/huifer/Claude-Ally-Health)                      | Compatible | Health assistant               |
| `clarity-gate`                                                      | [frmoretto](https://github.com/frmoretto/clarity-gate)                      | Compatible | RAG quality verification       |
| `n8n-code-python`, `n8n-mcp-tools-expert`, `n8n-node-configuration` | [czlonkowski](https://github.com/czlonkowski/n8n-skills)                    | Compatible | n8n automation skills          |
| `varlock-claude-skill`                                              | [wrsmith108](https://github.com/wrsmith108/varlock-claude-skill)            | Compatible | Secure environment variables   |
| `beautiful-prose`                                                   | [SHADOWPR0](https://github.com/SHADOWPR0/beautiful_prose)                   | Compatible | Writing style guide            |
| `claude-speed-reader`                                               | [SeanZoR](https://github.com/SeanZoR/claude-speed-reader)                   | Compatible | Speed reading tool             |
| `skill-seekers`                                                     | [yusufkaraaslan](https://github.com/yusufkaraaslan/Skill_Seekers)           | Compatible | Skill conversion tool          |

- **frontend-slides** - [zarazhangrui](https://github.com/zarazhangrui/frontend-slides)
- **linear-claude-skill** - [wrsmith108](https://github.com/wrsmith108/linear-claude-skill)
- **skill-rails-upgrade** - [robzolkos](https://github.com/robzolkos/skill-rails-upgrade)
- **context-fundamentals** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **context-degradation** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **context-compression** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **context-optimization** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **multi-agent-patterns** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **tool-design** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **evaluation** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **memory-systems** - [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering)
- **terraform-skill** - [antonbabenko](https://github.com/antonbabenko/terraform-skill)

## Skills from whatiskadudoing/fp-ts-skills (v4.4.0)

| Skill             | Original Source                                                                 | License    | Notes                                                    |
| :---------------- | :------------------------------------------------------------------------------ | :--------- | :------------------------------------------------------- |
| `fp-ts-pragmatic` | [whatiskadudoing/fp-ts-skills](https://github.com/whatiskadudoing/fp-ts-skills) | Compatible | Pragmatic fp-ts guide – pipe, Option, Either, TaskEither |
| `fp-ts-react`     | [whatiskadudoing/fp-ts-skills](https://github.com/whatiskadudoing/fp-ts-skills) | Compatible | fp-ts with React 18/19 and Next.js                       |
| `fp-ts-errors`    | [whatiskadudoing/fp-ts-skills](https://github.com/whatiskadudoing/fp-ts-skills) | Compatible | Type-safe error handling with Either and TaskEither      |

## Skills from Dimillian/Skills

The following skills were added from [Dimillian/Skills](https://github.com/Dimillian/Skills), a curated Codex skills repository focused on Apple platforms, GitHub workflows, refactoring, and performance work.

| Skill / Group | Original Source | License | Notes |
| :------------ | :-------------- | :------ | :---- |
| `app-store-changelog`, `github`, `orchestrate-batch-refactor`, `project-skill-audit`, `react-component-performance`, `simplify-code` | [Dimillian/Skills](https://github.com/Dimillian/Skills) | MIT | Workflow, GitHub, React performance, and code simplification skills. |
| `ios-debugger-agent`, `macos-menubar-tuist-app`, `macos-spm-app-packaging`, `swift-concurrency-expert` | [Dimillian/Skills](https://github.com/Dimillian/Skills) | MIT | Apple-platform debugging, packaging, and Swift concurrency guidance. |
| `swiftui-liquid-glass`, `swiftui-performance-audit`, `swiftui-ui-patterns`, `swiftui-view-refactor` | [Dimillian/Skills](https://github.com/Dimillian/Skills) | MIT | SwiftUI-specific implementation, performance, and refactoring patterns. |

## Skills from Leonxlnx/taste-skill

The following skills were added from [Leonxlnx/taste-skill](https://github.com/Leonxlnx/taste-skill), a frontend design taste collection focused on premium UI generation, redesign audits, motion, and anti-generic output rules.

| Skill / Group | Original Source | License | Notes |
| :------------ | :-------------- | :------ | :---- |
| `design-taste-frontend`, `gpt-taste`, `high-end-visual-design`, `minimalist-ui`, `industrial-brutalist-ui` | [Leonxlnx/taste-skill](https://github.com/Leonxlnx/taste-skill) | Not declared upstream | Frontend visual design protocols for high-agency, motion-rich, minimalist, and brutalist UI generation. |
| `redesign-existing-projects`, `stitch-design-taste`, `full-output-enforcement` | [Leonxlnx/taste-skill](https://github.com/Leonxlnx/taste-skill) | Not declared upstream | Redesign audit workflow, Google Stitch design-system export, and full-output enforcement protocol. |

---

## March 2026 Skill Imports

The following skills were added during the March 2026 skills update:

### UI/UX & Frontend
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `baseline-ui`, `fixing-accessibility`, `fixing-metadata`, `fixing-motion-performance` | [ibelick/ui-skills](https://github.com/ibelick/ui-skills) | Compatible | UI polish and validation |
| `expo-ui-swift-ui`, `expo-ui-jetpack-compose`, `expo-tailwind-setup`, `building-native-ui`, `expo-api-routes`, `expo-dev-client`, `expo-cicd-workflows`, `native-data-fetching` | [expo/skills](https://github.com/expo/skills) | MIT | Expo/React Native skills |
| `swiftui-expert-skill` | [AvdLee/SwiftUI-Agent-Skill](https://github.com/AvdLee/SwiftUI-Agent-Skill) | Compatible | SwiftUI development |
| `threejs-fundamentals`, `threejs-geometry`, `threejs-materials`, `threejs-lighting`, `threejs-textures`, `threejs-animation`, `threejs-loaders`, `threejs-shaders`, `threejs-postprocessing`, `threejs-interaction` | [CloudAI-X/threejs-skills](https://github.com/CloudAI-X/threejs-skills) | Compatible | Three.js 3D graphics |
| `frontend-slides` | [zarazhangrui](https://github.com/zarazhangrui/frontend-slides) | Compatible | HTML presentations |

### Automation & Integration
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `gmail-automation`, `google-calendar-automation`, `google-docs-automation`, `google-sheets-automation`, `google-drive-automation`, `google-slides-automation` | [sanjay3290/ai-skills](https://github.com/sanjay3290/ai-skills) | Compatible | Google Workspace integration |
| `n8n-expression-syntax`, `n8n-mcp-tools-expert`, `n8n-workflow-patterns`, `n8n-validation-expert`, `n8n-node-configuration`, `n8n-code-javascript`, `n8n-code-python` | [czlonkowski/n8n-skills](https://github.com/czlonkowski/n8n-skills) | Compatible | n8n workflow automation |
| `automate-whatsapp` | [gokapso/agent-skills](https://github.com/gokapso/agent-skills) | Compatible | WhatsApp automation |
| `linear` | [wrsmith108/linear-claude-skill](https://github.com/wrsmith108/linear-claude-skill) | Compatible | Linear project management |
| `rails-upgrade` | [robzolkos](https://github.com/robzolkos/skill-rails-upgrade) | Compatible | Rails upgrade assistant |
| `vexor-cli` | [scarletkc/vexor](https://github.com/scarletkc/vexor) | Compatible | Semantic file discovery |

### Machine Learning & Data
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `hugging-face-datasets`, `hugging-face-evaluation`, `hugging-face-tool-builder` | [huggingface/skills](https://github.com/huggingface/skills) | Compatible | Hugging Face ecosystem extensions |
| `numpy`, `pandas`, `scipy`, `matplotlib`, `scikit-learn`, `jupyter-workflow` | [K-Dense-AI/claude-scientific-skills](https://github.com/K-Dense-AI/claude-scientific-skills) | Compatible | Data science essentials |
| `biopython`, `scanpy`, `uniprot-database`, `pubmed-database` | [K-Dense-AI/claude-scientific-skills](https://github.com/K-Dense-AI/claude-scientific-skills) | Compatible | Bioinformatics tools |

### Security & Auditing
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `semgrep-rule-creator`, `semgrep-rule-variant-creator`, `static-analysis`, `variant-analysis` | [trailofbits/skills](https://github.com/trailofbits/skills) | Compatible | Code security analysis |
| `golang-security-auditor`, `python-security-auditor`, `rust-security-auditor` | [trailofbits/skills](https://github.com/trailofbits/skills) | Compatible | Language-specific security |
| `burpsuite-project-parser`, `agentic-actions-auditor`, `audit-context-building`, `proof-of-vulnerability`, `yara-authoring` | [trailofbits/skills](https://github.com/trailofbits/skills) | Compatible | Security testing tools |

### Context Engineering & AI
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `context-fundamentals`, `context-degradation`, `context-compression`, `context-optimization`, `multi-agent-patterns`, `filesystem-context` | [muratcankoylan](https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering) | Compatible | Context engineering patterns |

### Health & Wellness
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `sleep-analyzer`, `nutrition-analyzer`, `fitness-analyzer` | [huifer/Claude-Ally-Health](https://github.com/huifer/Claude-Ally-Health) | Compatible | Health tracking |

### Quality & Verification
| Skill | Source | License | Notes |
|-------|--------|---------|-------|
| `clarity-gate` | [frmoretto/clarity-gate](https://github.com/frmoretto/clarity-gate) | Compatible | RAG quality verification |

**Total: 80+ new skills added**

---

## Skills from yylo-dev/yylo-skills

The following 7 skills were adapted from [yylo-skills](https://github.com/yylo-dev/yylo-skills) (MIT, v2.0.1) — repo-resident task and state management for coding-agent CLIs (Kanban/task ledger, wiki, workflows, artifacts, Ralph execution loop). Docs-only import: the `ralph-loop-yylo` `scripts/kanban.sh` wrapper is intentionally not bundled; `references/` holds the worker contract.

| Skill | Original Source | License | Notes |
| :---- | :-------------- | :------ | :---- |
| `ledger-tasks-yylo`, `plan-ledger-tasks-yylo`, `ralph-loop-yylo`, `understand-project-yylo`, `wiki-yylo`, `workflow-yylo`, `artifact-yylo` | [yylo-dev/yylo-skills](https://github.com/yylo-dev/yylo-skills) | MIT | Kanban ledger lifecycle, PDR planning, Ralph single-task execution loop, project understanding, wiki/workflow/artifact records; adapted with upstream frontmatter, When to Use/Limitations, and fail-closed safety boundaries. |

## Skills from issue #126, batch 1 (addyosmani + adhd + career-ops + geo-seo) — issue126-batch1

The following 19 skills were adapted for [FrancoStino/opencode-skills-collection#126](https://github.com/FrancoStino/opencode-skills-collection/issues/126). Docs-only imports: upstream helper scripts, runtimes, agents, hooks, and templates are intentionally not bundled.

| Skill | Original Source | License | Notes |
| :---- | :-------------- | :------ | :---- |
| `constraint-driven-development`, `interview-me`, `using-agent-skills` | [addyosmani/agent-skills](https://github.com/addyosmani/agent-skills) | MIT | New names only; 22/25 upstream names in this repo were already sourced from this repository. |
| `i-have-adhd` | [ayghri/i-have-adhd](https://github.com/ayghri/i-have-adhd) | MIT | ADHD-friendly output shaping (`/i-have-adhd` toggle). |
| `career-ops` | [career-ops-hq/career-ops](https://github.com/career-ops-hq/career-ops) | MIT | Multi-CLI job-search command center; Node runtime not bundled. |
| `geo-audit`, `geo-brand-mentions`, `geo-citability`, `geo-compare`, `geo-content`, `geo-crawlers`, `geo-llmstxt`, `geo-platform-optimizer`, `geo-proposal`, `geo-prospect`, `geo-report`, `geo-report-pdf`, `geo-schema`, `geo-technical` | [zubair-trabzada/geo-seo-claude](https://github.com/zubair-trabzada/geo-seo-claude) | MIT | GEO/SEO site audits and client reporting; `geo-update` (self-updating installer skill) intentionally excluded; `geo-technical` categories modularized under `references/`. |
## Skills from BagelHole/DevOps-Security-Agent-Skills: compliance (19) — issue126-devsec-compliance

Compliance batch of [FrancoStino/opencode-skills-collection#126](https://github.com/FrancoStino/opencode-skills-collection/issues/126) from [DevOps-Security-Agent-Skills](https://github.com/BagelHole/DevOps-Security-Agent-Skills) (MIT): governance, frameworks (SOC2/ISO27001/PCI-DSS/HIPAA/GDPR/FedRAMP), continuity, and auditing guidance. All `risk: safe`. Docs-only import: helper scripts and templates not bundled.
## Skills from BagelHole/DevOps-Security-Agent-Skills: security (35) — issue126-devsec-security

Security batch of [FrancoStino/opencode-skills-collection#126](https://github.com/FrancoStino/opencode-skills-collection/issues/126) from [DevOps-Security-Agent-Skills](https://github.com/BagelHole/DevOps-Security-Agent-Skills) (MIT): secrets management, scanning (SAST/DAST/dependency/container/SBOM/vulnerability), network defense, security operations, and AI security hardening. Risk split: `safe` for static guidance and read-only analysis, `critical` for privileged security operations, `offensive` (with `AUTHORIZED USE ONLY` + confirmation gate) for live probing (`vulnerability-scanning`, `dast-scanning`, `supply-chain-attack-response`) and `penetration-testing`. Docs-only import: helper scripts and templates not bundled.
## Skills from BagelHole/DevOps-Security-Agent-Skills: infrastructure (70) — issue126-devsec-infrastructure

Infrastructure batch of [FrancoStino/opencode-skills-collection#126](https://github.com/FrancoStino/opencode-skills-collection/issues/126) from [DevOps-Security-Agent-Skills](https://github.com/BagelHole/DevOps-Security-Agent-Skills) (MIT): servers, storage, databases (incl. `postgresql-devsec`, renamed — `postgresql` already exists in the catalog), networking, cloud (AWS/Azure/GCP), and local-AI infrastructure. All `risk: critical` (guidance mutates infrastructure state). Docs-only import: helper scripts and templates not bundled. `azure-functions` renamed to `azure-functions-devsec` (`azure-functions` already exists in the catalog).
## Skills from elementalsouls/Claude-BugHunter — issue126-bughunter

The following 83 skills were adapted from [Claude-BugHunter](https://github.com/elementalsouls/Claude-BugHunter) (MIT) for [FrancoStino/opencode-skills-collection#126](https://github.com/FrancoStino/opencode-skills-collection/issues/126) — bug-bounty and external red-team workflows across 24 vulnerability classes plus identity/infrastructure attack matrices. Docs-only import: helper scripts, slash commands, engine, and research assets are intentionally not bundled.

| Skill | Original Source | License | Notes |
| :---- | :-------------- | :------ | :---- |
| 5 process skills (`report-writing`, `redteam-report-template`, `bugcrowd-reporting`, `evidence-hygiene`, `mid-engagement-ir-detection` — reporting, evidence handling, detection notes) | [elementalsouls/Claude-BugHunter](https://github.com/elementalsouls/Claude-BugHunter) | MIT | Process guidance, no active probing; `risk: safe`. |

## Skills from BagelHole/DevOps-Security-Agent-Skills: devops (39) — issue126-devsec-devops

DevOps batch of [FrancoStino/opencode-skills-collection#126](https://github.com/FrancoStino/opencode-skills-collection/issues/126) from [DevOps-Security-Agent-Skills](https://github.com/BagelHole/DevOps-Security-Agent-Skills) (MIT): CI/CD, orchestration (Kubernetes/Helm/Kustomize/ArgoCD/OpenShift), observability (Prometheus/OTel/SRE), release practices, containers, and AI workload operations. All `risk: critical` (guidance executes against real environments). Docs-only import: helper scripts and templates not bundled.

## License Policy

- **Code**: All original code in this repository is **MIT**.
- **Content**: Documentation is **CC-BY-4.0**.
- **Third Party**: We respect the upstream licenses. If an imported skill is GPL, it will be marked clearly or excluded (we aim for MIT/Apache compatibility).
